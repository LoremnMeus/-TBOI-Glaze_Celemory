local CharacterMeus = RegisterMod("QING",1)
---------------mod注册的地方-------------
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
delay_buffer.Init(CharacterMeus)
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")	
ModConfig.init(CharacterMeus)
if (EID) then
	 require("Qing_Extra_scripts.translations.EID")
end
local enums = require("Qing_Extra_scripts.core.enums")
local manager = require("Qing_Extra_scripts.core.manager_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

manager.Init(CharacterMeus)
--translation.init(CharacterMeus)
------------------------------------------
--要用到的函数
local Fusion_Destiny = require("Qing_Extra_scripts.challanges.Fusion_Destiny")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")
--l local player = Game():GetPlayer(0) local familiar = Isaac.Spawn(3,1,0,player.Position + Vector(10,10),Vector(0,0),nil):ToFamiliar() familiar:RemoveFromFollowers() familiar:RemoveFromDelayed() familiar:RemoveFromOrbit() local q = Isaac.Spawn(966,0,0,player.Position + Vector(10,10),Vector(0,0),nil) q.Target = familiar q.Parent = player
--local siren = Isaac.Spawn(904,0,0,player.Position + Vector(10,10),Vector(0,0),nil)
------------------------------------------
local actionofdebuglist = 0
local delayofdebuglist = 0
local Debuglist={}
for i=1,15 do
	Debuglist[i]= 0
end
function Debugtext()
	if actionofdebuglist == 0 then
		for i=1,15 do
			Isaac.RenderText(Debuglist[i],100,40+10*i,255,0,0,255)
		end
	end
end
--CharacterMeus:AddCallback(ModCallbacks.MC_POST_RENDER, Debugtext)
------------------简易debug调试台---------------
function CharacterMeus:OnDebuglistUpdate()	
	if Input.IsButtonTriggered(85,0) or Input.IsButtonPressed(85,0) then
		actionofdebuglist = 1 - actionofdebuglist
		delayofdebuglist = 100
	end
	if delayofdebuglist > 0 then
		delayofdebuglist = delayofdebuglist - 1
	end
end
------------------调试开关(按U开关）-------------
CharacterMeus:AddCallback(ModCallbacks.MC_POST_UPDATE, CharacterMeus.OnDebuglistUpdate)
-----------功能性函数，只会被间接调用------------
function CharacterMeus:OnPostUpdate()				--只用于检测功能。
	local Sfx = SFXManager()
	local Mus = MusicManager()
	for i = 1,1000 do 
		if Sfx:IsPlaying(i) then
			if i ~= 480 and i ~= 491 then
				Debuglist[1] = i
				Debuglist[2] = Sfx:GetAmbientSoundVolume(i)
			end
		end
	end
	Debuglist[8] = Mus:GetCurrentMusicID()
end
CharacterMeus:AddCallback(ModCallbacks.MC_POST_UPDATE, CharacterMeus.OnPostUpdate)

function CharacterMeus:OnEffectInit(ent)			--只用于检测功能。
	if ent.Variant == 112 then
		Debuglist[3] = ent.Type
		Debuglist[4] = ent.Variant
		Debuglist[5] = ent.SubType
		Debuglist[6] = ent.SizeMulti.X
		Debuglist[7] = ent.SizeMulti.Y
	end
end
CharacterMeus:AddCallback(ModCallbacks.MC_POST_EFFECT_INIT, CharacterMeus.OnEffectInit)
---------------------------------------------
function CharacterMeus:Init(continued)
	math.randomseed(Game():GetSeeds():GetStartSeed())
	if continued then
	else
		print("Qing, V1.7.2")
	end	
end
function CharacterMeus:Exit(shouldSave)
end
CharacterMeus:AddCallback(ModCallbacks.MC_POST_GAME_STARTED, CharacterMeus.Init)
CharacterMeus:AddCallback(ModCallbacks.MC_PRE_GAME_EXIT, CharacterMeus.Exit)