local modReference
local funct = {}

local Delay_buffer = {		--延迟轴。用于实现延迟生效的任何特效。
}

function funct.addeffe(func,params,tim,isrender,isshader,continue_even_restart)		--添加延迟效果。在tim之后，执行func（params）
	local tbl = {func = func,params = params,TimeD = tim,render_mode = 1,continue_even_restart = continue_even_restart,}
	if isrender == nil or isrender ~= true then
		tbl.render_mode = 1
	else
		if isshader == nil or isshader ~= true then
			tbl.render_mode = 2
		else
			tbl.render_mode = 3
		end
	end
	table.insert(Delay_buffer,tbl)
end

function funct.OnDelayUpdate()
	for i = #Delay_buffer,1,-1 do
		if Delay_buffer[i] == nil then
		elseif Delay_buffer[i].render_mode == 1 and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD >= 0 then
			Delay_buffer[i].TimeD = Delay_buffer[i].TimeD - 1
		end
		if Delay_buffer[i].render_mode == 1 and Delay_buffer[i] ~= nil and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD <= 0 then
			if Delay_buffer[i].func ~= nil then
				local func = Delay_buffer[i].func
				func(Delay_buffer[i].params)
			end
			table.remove(Delay_buffer,i)
		end
	end
end

function funct.OnDelayRender()
	for i = #Delay_buffer,1,-1 do
		if Delay_buffer[i] == nil then
		elseif Delay_buffer[i].render_mode == 2 and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD >= 0 then
			Delay_buffer[i].TimeD = Delay_buffer[i].TimeD - 1
		end
		if Delay_buffer[i].render_mode == 2 and Delay_buffer[i] ~= nil and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD <= 0 then
			if Delay_buffer[i].func ~= nil then
				local func = Delay_buffer[i].func
				func(Delay_buffer[i].params)
			end
			table.remove(Delay_buffer,i)
		end
	end
end

function funct.OnShaderUpdate(_,name)
	if name == "Qing_HelpfulShader" then
		for i = #Delay_buffer,1,-1 do
			if Delay_buffer[i] == nil then
			elseif Delay_buffer[i].render_mode == 3 and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD >= 0 then
				Delay_buffer[i].TimeD = Delay_buffer[i].TimeD - 1
			end
			if Delay_buffer[i].render_mode == 3 and Delay_buffer[i] ~= nil and Delay_buffer[i].TimeD ~= nil and Delay_buffer[i].TimeD <= 0 then
				if Delay_buffer[i].func ~= nil then
					local func = Delay_buffer[i].func
					func(Delay_buffer[i].params)
				end
				table.remove(Delay_buffer,i)
			end
		end
	end
end

function funct.OnGameReStart(_,continue)		--不可沿用，除非有特殊说明。
	for i = #Delay_buffer,1,-1 do
		if Delay_buffer[i].continue_even_restart == nil then
			table.remove(Delay_buffer,i)
		end
	end
end

function funct.Init(mod)
	modReference = mod
	modReference:AddCallback(ModCallbacks.MC_POST_UPDATE,funct.OnDelayUpdate)
	modReference:AddCallback(ModCallbacks.MC_POST_RENDER,funct.OnDelayRender)
	modReference:AddCallback(ModCallbacks.MC_GET_SHADER_PARAMS,funct.OnShaderUpdate)
	modReference:AddCallback(ModCallbacks.MC_POST_GAME_STARTED,funct.OnGameReStart)
end

return funct