local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local enums = require("Qing_Extra_scripts.core.enums")
local g = require("Qing_Extra_scripts.core.globals")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local displaying_data = require("Qing_Extra_scripts.translations.data")
local consistance_holder
local addeffe = delay_buffer.addeffe
local funct = {}

local bomb_effe_list = {
	28,29,35,36,37,45,72,75,78
}
local bomb_effe_map = {
	{75,20},{30,10},{20,20},{50,15},{50,10},{75,15},{100,5},{100,15},{100,7}
}

local QingsAirs = Isaac.GetEntityVariantByName("QingsAir")
local MeusLink = Isaac.GetEntityVariantByName("MeusLink")
local QingsMarks = Isaac.GetEntityVariantByName("QingsMark")
local StabberKnife = Isaac.GetEntityVariantByName("StabberKnife")
local MeusSword = Isaac.GetEntityVariantByName("MeusSword")
local ID_EFFECT_MeusFetus = Isaac.GetEntityVariantByName("MeusFetus")
local ID_EFFECT_MeusRocket = Isaac.GetEntityVariantByName("MeusRocket")
local ID_EFFECT_MeusNIL = Isaac.GetEntityVariantByName("MeusNil")

function funct.GetPlayers()
	local players = {}
	for i=0,Game():GetNumPlayers()-1 do
		local player = Game():GetPlayer(i)
		players[i] = player
	end
	return players
end

function funct.rng_for_sake(rng)
	if rng then
		if rng:GetSeed() == 0 then
			rng:SetSeed(-1,0)
		end
		return rng
	else
		return nil
	end
end

function funct.MakeBitSet(i)
	if i >= 64 then
		return BitSet128(0,1<<(i-64))
	else
		return BitSet128(1<<(i),0)
	end
end 

function funct.bitset_flag(x,i)	--获取x第i位是否含有1。
	if i >= 64 then
		return (x & BitSet128(0,1<<(i-64)) == BitSet128(0,1<<(i-64)))
	else
		return (x & BitSet128(1<<(i),0) == BitSet128(1<<(i),0))
	end
end

function funct.random_1()
	return math.random(1000)/1000
end

function funct.Count_Flags(x)
	local ret = 0
	for i = 0, math.floor(math.log(x)/math.log(2)) +1 do
		if x%2==1 then
			ret = ret + 1
		end
		x = (x-x%2)/2
	end
	return ret
end

function funct.Get_Flags(x,fl)	--从第0位开始计算flag
	if (math.floor(x/(1<<fl)) %2 == 1) then
		return true
	end
	return false
end

function funct.Get__cos(vec)		--获取Vector类型的角度
	local t = (vec + Vector(vec:Length(),0)):Length()/2
	local q = t/vec:Length()
	return 1 - 2 * q * q
end

function funct.Get__sin(vec)		--获取Vector类型的角度
	local t=(vec + Vector(0,vec:Length())):Length()/2
	q = t/vec:Length()
	return 1 - 2 * q * q
end

function funct.Get__trans(t)			--获取cos对应的sin
	if t > 1 or t < -1 then
		return 0
	end
	return math.sqrt(1-t*t) 
end

function funct.Get_rotate(t)		--接收一个vector，获取旋转90度的vector
	return Vector(-t.Y,t.X)
end

function funct.get_by_rotate(v,ang)
	return v:Length() * funct.MakeVector(ang + v:GetAngleDegrees())
end

function funct.plu_s(v1,v2)
	return v1.X*v2.X+v1.Y*v2.Y
end

function funct.mul_t(v1,v2)
	return Vector(v1.X*v2.X,v1.Y*v2.Y)
end

function funct.MakeVector(x)
	return Vector(math.cos(math.rad(x)),math.sin(math.rad(x)))
end

function funct.SafeVector(v)
	if math.abs(v.X) < 0.00001 then v.X = 0.00001 end
	if math.abs(v.Y) < 0.00001 then v.Y = 0.00001 end
	return v
end

function funct.AntiVector(v)
	local v1 = funct.SafeVector(v)
	return Vector(1/v1.X,1/v1.Y)
end

function funct.AddColor(col_1,col_2,x,y,isKColor)
	if isKColor then
		return KColor(col_1.R * x + col_2.R * y,col_1.G * x+ col_2.G * y,col_1.B * x+ col_2.B * y,col_1.A * x+ col_2.A * y,col_1.RO * x+ col_2.RO * y,col_1.GO * x+ col_2.GO * y,col_1.BO * x+ col_2.BO * y)
	else
		return Color(col_1.R * x + col_2.R * y,col_1.G * x+ col_2.G * y,col_1.B * x+ col_2.B * y,col_1.A * x+ col_2.A * y,col_1.RO * x+ col_2.RO * y,col_1.GO * x+ col_2.GO * y,col_1.BO * x+ col_2.BO * y)
	end
end

function funct.MulColor(col_1,col_2)
	return Color(col_1.R * col_2.R,col_1.G * col_2.G,col_1.B * col_2.B,col_1.A *col_2.A ,col_1.RO *col_2.RO ,col_1.GO *col_2.GO ,col_1.BO *col_2.BO )
end

function funct.TearsUp(firedelay, val)
    local currentTears = 30 / (firedelay + 1)
    local newTears = currentTears + val
    return math.max((30 / newTears) - 1, -0.99)
end

function funct.getdir(player)
	if player == nil then
		print("Wrong player in function::getdir()")
		return Vector(0,0)
	end
	local ret = player:GetShootingInput()
	if ret:Length() > 0.05 then
		ret = ret / ret:Length()
	end
	return ret
end

function funct.getmov(player)
	if player == nil then
		print("Wrong player in function::getmov()")
		return Vector(0,0)
	end
	local ret = player:GetMovementInput()
	if ret:Length() > 0.05 then
		ret = ret / ret:Length()
	end
	return ret
end

local for_set_for_ggdir = {tim = 0,dir = Vector(0,0),ignore_marked = false}
function funct.ggdir(player,ignore_marked,allow_mouse,ignore_mouse_press,center,spe)		--这个函数忽略了实际上无视行动的策略。例如：某种无敌。
	if player:AreControlsEnabled() == false then
		return Vector(0,0)
	end
	if player:GetData().should_not_attack == true then return Vector(0,0) end
	if player:IsExtraAnimationFinished() == false or player.Visible == false then
		return Vector(0,0)
	end
	if ignore_marked == false then
		if player:HasCollectible(394) or player:HasCollectible(572) then		--别忘了准星！
			local n_entity = Isaac.GetRoomEntities()
			for i = 1, #n_entity do
				if n_entity[i] and n_entity[i].Type == 1000 and (n_entity[i].Variant == 153 or n_entity[i].Variant == 30) then
					local dir = (n_entity[i].Position - player.Position):Normalized()
					--for_set_for_ggdir.dir = dir
					return dir
				end
			end
		end
	end
	local frdr = player:GetFireDirection()			--似乎应该用这个？
	if frdr == Direction.NO_DIRECTION then return Vector(0,0) end		--检测无敌的方式。
	if center == nil then center = player.Position end
	local dir = funct.getdir(player)
	if dir:Length() < 0.05 then
		if allow_mouse and allow_mouse == true then
			if (player.ControllerIndex == 0) then
				if (Input.IsMouseBtnPressed(0) or ignore_mouse_press) then
					local leg_pos = (Input.GetMousePosition(true) - center)
					if leg_pos:Length() > 10 then
						dir = leg_pos:Normalized()
					elseif ignore_mouse_press then
						if leg_pos:Length() > 1 then
							dir = leg_pos/10
						end
					end
				end
			end
		end
	end
	--for_set_for_ggdir.dir = dir
	return dir
end

function funct.ggmov_dir_is_zero(player,SPQinghelper,allow_mouse,upon_click,center)		--传入player与一个辅助参数。
	if SPQinghelper == nil then SPQinghelper = false end
	if player:AreControlsEnabled() == false and SPQinghelper == true then
		return false
	end
	if (player:IsExtraAnimationFinished() == false or player.Visible == false) and SPQinghelper == true then
		return false
	end
	local dir = funct.ggdir(player,false,allow_mouse,upon_click,center)
	local mov = funct.getmov(player)
	return (dir:Length() < 0.05 and mov:Length() < 0.05)
end

function funct.getpickups(ents,ignore_items)
	local pickups = {}
    for _, ent in ipairs(ents) do
        if ent.Type == 5 and (ignore_items == false or ent.Variant ~= 100) then
            pickups[#pickups + 1] = ent
        end
    end
	return pickups
end

function funct.getenemies(ents)
	local enemies = {}
    for _, ent in ipairs(ents) do
        if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() and not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
            enemies[#enemies + 1] = ent
        end
    end
	return enemies
end

local movable_list = {
	[33] = true,
	[292] = true,
}

function funct.getmovable(ents)
	local targs = {}
    for _, ent in ipairs(ents) do
		if movable_list[ent.Type] then table.insert(targs,#targs + 1,ent) end
    end
	return targs
end

function funct.get_nearest_enemy(enemies,pos)
	if pos == nil or enemies == nil or #enemies == 0 then return nil end
	local targ = enemies[1]
	local dis = (targ.Position - pos):Length()
	for u,v in pairs(enemies) do
		local leg = (v.Position - pos):Length()
		if leg < dis then
			targ = v
			dis = leg
		end
	end
	return targ
end

function funct.get_farest_enemy(enemies,pos)
	if pos == nil or enemies == nil or #enemies == 0 then return nil end
	local targ = enemies[1]
	local dis = (targ.Position - pos):Length()
	for u,v in pairs(enemies) do
		local leg = (v.Position - pos):Length()
		if leg > dis then
			targ = v
			dis = leg
		end
	end
	return targ
end

function funct.get_by_nearest_enemy(pos)
	return funct.get_nearest_enemy(funct.getenemies(Isaac.GetRoomEntities()),pos)
end

function funct.get_by_farest_enemy(pos)
	return funct.get_farest_enemy(funct.getenemies(Isaac.GetRoomEntities()),pos)
end

function funct.isenemies(ent)
	if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() and not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
		return true
	end
	return false
end

function funct.getothers(ents,x,y,z,check_funct)
	local targs = {}
    for _, ent in ipairs(ents) do
        if x == nil or ent.Type == x then
			if y == nil or ent.Variant == y then
				if z == nil or ent.SubType == z then
					if check_funct == nil or check_funct(ent) == true then
						targs[#targs + 1] = ent
					end
				end
			end
        end
    end
	return targs
end

function funct.getothers_in_table(ents,x,y,z,check_funct)
	local tbl = {}
    for _, ent in ipairs(ents) do
        if x == nil or ent.Type == x or x == 0 then
			local x_tbl = tbl
			if x == 0 then 
				if tbl[ent.Type] == nil then tbl[ent.Type] = {} end
				x_tbl = tbl[ent.Type] 
			end
			if y == nil or ent.Variant == y or y == 0 then
				local y_tbl = x_tbl
				if y == 0 then 
					if x_tbl[ent.Variant] == nil then x_tbl[ent.Variant] = {} end
					y_tbl = x_tbl[ent.Variant] 
				end
				if z == nil or ent.SubType == z or z == 0 then
					local z_tbl = y_tbl
					if z == 0 then 
						if y_tbl[ent.Variant] == nil then y_tbl[ent.Variant] = {} end
						z_tbl = y_tbl[ent.Variant] 
					end
					if check_funct == nil or check_funct(ent) == true then
						table.insert(z_tbl,ent)
					end
				end
			end
        end
    end
	return tbl
end

function funct.getmultishot(cnt1,cnt2,id,cnt3)		--cnt1:总数量；cnt2：巫师帽数量；cnt3：宝宝套
	local cnt = math.ceil(cnt1/cnt2)		--此为每一弹道发射的眼泪数。不计入宝宝套给予的额外2发。
	if cnt3 == 1 and cnt2 < 3 then
		cnt = math.ceil((cnt1-2)/cnt2)
	end
	if cnt2 > 2 then
		cnt3 = 0
	end
	local dir = 180 / (cnt2+1)
	local inv1 = 30			--非常奇怪，存在巫师帽的时候，那个间隔随着cnt增大而减小，并不是特别好测量，因此我也就意思一下了（，不存在的时候，大概是10到5度角左右。
	local inv2 = 5 + cnt
	local inv3 = 5
	if cnt3 == 1 then			--存在宝宝套
		if cnt2 == 1 then		--单弹道+宝宝套
			if id == 1 then			--冷知识：宝宝套两个方向的弹道实际上不对称！不过我才懒得做适配……
				return 45
			elseif id == cnt1 then
				return 135
			else
				return 90 - (cnt-1)/2 * inv3 + (id-2) * inv3			--考虑以5度为间隔，关于90度镜像阵列。
			end
		else		--巫师帽宝宝套，双弹道多发。
			if id - 1 > cnt then
				return 45 - (cnt-1)/2 * inv2 + (id - cnt - 1) * inv2
			else
				return 135 - (cnt-1)/2 *inv2 + (id - 1) * inv2
			end
		end
	else
		local grp = math.floor((id-1)/cnt)	--id号攻击属于的弹道数（0到cnt2-1）
		if cnt2 ~= 1 then
			return (grp + 1) * dir - (cnt-1)/2 * inv1 + (id-1 - grp * cnt) * inv1
		else
			return (grp + 1) * dir - (cnt-1)/2 * inv2 + (id-1 - grp * cnt) * inv2
		end
	end
end

function funct.trychangegrid(x)
	if x == nil or x.CollisionClass == nil then
		return
	end
	x.CollisionClass = EntityGridCollisionClass.GRIDCOLL_NONE
end

function funct.getdisenemies(enemies,pos,rang)
	local ret = nil
	local ran = rang
	if ran == nil then
		ran = 1000
	end
	for _,ent in ipairs(enemies) do
		if ent ~= nil and (ent.Position - pos):Length()< ran then
			ran = (ent.Position - pos):Length()
			ret = ent
		end
	end
	return ret
end

function funct.getrandenemies(enemies)
	if #enemies == 0 then
		return nil
	else
		return enemies[math.random(#enemies)]
	end
end

function funct.getmultishots(player,allowrand)
	local cnt1 = 1
	if player:HasCollectible(153) or player:HasCollectible(2) or player:GetPlayerType() == 14 or player:GetPlayerType() == 33 or player:GetEffects():HasNullEffect(NullItemID.ID_REVERSE_HANGED_MAN) then	--四眼、三眼、店长、里店长的特效：眼泪固定加1发，二者不叠加。有趣的是，对于眼泪而言，三、四眼和多个20/20叠加不完全一致，但科技的激光、妈刀等等却并非如此，说明程序员偷懒了（
		cnt1 = cnt1 + 1
	end
	local list = {	--硫磺火不再叠加，肺特殊处理，水球不叠加
		68,			--科技
		52,			--博士
		114,		--妈刀
		168,		--史诗
		395,		--科X
		579,		--英灵剑
	}
	for i = 1,#list do
		cnt1 = cnt1 + math.max(0,player:GetCollectibleNum(list[i]) - 1)
	end
	local inner_eye_effe = player:GetCollectibleNum(2)
	local mutant_effe = player:GetCollectibleNum(153)
	local perfect_eye_effe = player:GetCollectibleNum(245)
	if player:GetEffects():HasNullEffect(NullItemID.ID_REVERSE_HANGED_MAN) then inner_eye_effe = inner_eye_effe + 1 end
	if inner_eye_effe > 0 or mutant_effe > 0 then perfect_eye_effe = perfect_eye_effe - 1 end
	cnt1 = cnt1 + math.max(0,mutant_effe * 2) + math.max(0,inner_eye_effe) + math.max(0,perfect_eye_effe) + math.max(0,player:GetCollectibleNum(358))	--二、三、四眼与巫师帽
	if player:HasPlayerForm(PlayerForm.PLAYERFORM_BABY) and math.max(0,player:GetCollectibleNum(358)) < 2 then		--宝宝套：直接加2发
		cnt1 = cnt1 + 2
	end
	if allowrand == true then
		if player:HasPlayerForm(PlayerForm.PLAYERFORM_BOOK_WORM) and math.max(0,player:GetCollectibleNum(358)) < 2 then		--书套：随机加1发
			if math.random(4) > 3 then
				cnt1 = cnt1 + 1
			end
		end
	end
	return cnt1
end

function funct.check_rand(luck,maxum,zeroum,threshold)		--幸运；上限（0-100）；下限；幸运阈值
	local rand = math.random(10000)/10000
	if rand * 100 < math.exp(math.min(luck/5,threshold/5))/math.exp(threshold/5) * (maxum - zeroum) + zeroum then
		return true
	else
		return false
	end
end

function funct.getQingshots(player,allowrand)
	local ret = funct.getmultishots(player,allowed)
	if ret == nil then
		return 1
	end
	return ret
end

function funct.check(ent)
	return ent ~= nil and ent:Exists() and (not ent:IsDead())
end

local solid_list = {
	[2] = true,
	[3] = true,
	[4] = true,
	[5] = true,
	[6] = true,
	[11] = true,
	[12] = true,
	[13] = true,
	[14] = true,
	[21] = true,
	[22] = true,
	[24] = true,
	[25] = true,
	[26] = true,
	[27] = true,
}

local can_sul_destroy = {
	[2] = true,
	[3] = true,
	[4] = true,
	[5] = true,
	[6] = true,
	[22] = true,
	[25] = true,
	[26] = true,
	[27] = true,
}

local can_rock_destroy = {
	[2] = true,
	[3] = true,
	[4] = true,
	[5] = true,
	[6] = true,
	[22] = true,
	[25] = true,
	[26] = true,
	[27] = true,
}

local cannot_open_door = {
	[-10] = true,
	[-7] = true,
	[-1] = true,
}

function funct.issolid(grid)
	if grid == nil then return false end
	if solid_list[grid:GetType()] then
		return grid.CollisionClass ~= 0
	end
	return false
end

function funct.try_destroy_grid(grid,mode)
	if grid == nil then return false end
	local can_destroy = can_sul_destroy
	if mode == 2 then can_destroy = can_rock_destroy end
	if funct.issolid(grid) and can_destroy[grid:GetType()] then
		grid:Destroy(true)
		if grid:GetType() == 5 then 
			Game():BombExplosionEffects(grid.Position,100,BitSet128(0,0))
		end
		return true
	end
	--print(grid:GetSprite():GetFilename())
	if grid:GetType() == 16 then		--试图开门
		if math.random(1000) > 800 then
			local door = grid:ToDoor()
			if door and door:CanBlowOpen() and door:IsOpen() == false and door:IsLocked() == false and cannot_open_door[door.TargetRoomIndex] ~= true then
				door:TryBlowOpen(false,nil)
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_ROCK_CRUMBLE,math.random(1000)/1000 * 0.2 + 0.9,math.random(1000)/1000 * 0.1 + 0.95,false,0,2)
				return true
			end
		end
	end
	return false
end

function funct.iswall(grident)
	if grident == nil then return false end
	if grident:GetType() == 15 then
		return grident.CollisionClass ~= 0
	end
	return false
end

function funct.copy(tbl)
    local ret = {}
    for key, val in pairs(tbl) do
        ret[key] = val
    end
    return ret
end

function funct.deepCopy(tb)
    if tb == nil then
        return nil
    end
    local copy = {}
    for k, v in pairs(tb) do
        if type(v) == 'table' then
            copy[k] = funct.deepCopy(v)
        else
            copy[k] = v
        end
    end
    setmetatable(copy, funct.deepCopy(getmetatable(tb)))
    return copy
end

function funct.realdeepCopy(tb)			--我觉得以撒的存储系统有问题。所有的key值都被映射掉了，还得自己重写。
    if tb == nil then
        return nil
    end
    local copy = {}
    for k, v in pairs(tb) do
        if type(v) == 'table' then
			if v.___rid == nil then 
				v.___rid = k
			end
            copy[v.___rid] = funct.realdeepCopy(v)
        else
            copy[k] = v
        end
    end
    setmetatable(copy, funct.realdeepCopy(getmetatable(tb)))
    return copy
end

function funct.realrealdeepCopy(tb)			--新的问题：数字会被保存为字符，二者似乎还会相互覆盖
    if tb == nil then
        return nil
    end
    local copy = {}
    for k, v in pairs(tb) do
		if type(v) == 'table' then
			v.___rid = v.___rid or k
			copy[v.___rid] = funct.realrealdeepCopy(v)
		else
			if type(k) == 'number' then
				copy["___nid_number_"..tostring(k)] = {___rid = k,___nid = true,___val = v,}
			else
				copy[k] = v
			end
		end
    end
    setmetatable(copy, funct.realrealdeepCopy(getmetatable(tb)))
    return copy
end

function funct.irealrealdeepCopy(tb)
    if tb == nil then
        return nil
    end
    local copy = {}
    for k, v in pairs(tb) do
		if type(v) == 'table' then
			if v.___nid then
				copy[v.___rid] = v.___val
			else
				v.___rid = v.___rid or k
				copy[v.___rid] = funct.irealrealdeepCopy(v)
			end
		else
			copy[k] = v
		end
    end
    setmetatable(copy, funct.irealrealdeepCopy(getmetatable(tb)))
    return copy
end

function funct.launch_Missile(position, velocity, dmg, targ, params)
    local q1 = Isaac.Spawn(EntityType.ENTITY_EFFECT, ID_EFFECT_MeusFetus, 0, position, velocity, nil)
    local d = q1:GetData()
    local s = q1:GetSprite()
    s:Play("Blink", true)

    d.Boss = targ
    q1.Parent = targ
    d.BossMissile = true
    d.RocketsFired = 0
	d.Damage = dmg
	
    d.MissileParams = funct.copy(params)
	return q1
end

function funct.fire_nil(position,velocity,params)		--可以传入的是cooldown和player，其他参数将在之后添加。
	if params == nil then params = {} end
	if position == nil or velocity == nil then
		return nil
	end
	local q1 = Isaac.Spawn(EntityType.ENTITY_EFFECT, ID_EFFECT_MeusNIL, 0, position, velocity, nil)
	local d = q1:GetData()
    local s = q1:GetSprite()
    s:Play("Idle", true)
	
	if params.cooldown then
		d.removecd = params.cooldown
	else
		d.removecd = 60
	end
	if params.player then
		d.player = params.player
	end
	d.Params = funct.copy(params)
	return q1
end

function funct.fire_knife(position,velocity,dmg,targ,params)	--params可以传入：cooldown，player，tearflags，Color,Explosive
	local q1 = Isaac.Spawn(EntityType.ENTITY_EFFECT, ID_EFFECT_MeusNIL, 0, position, velocity, nil)
	local d = q1:GetData()
    local s = q1:GetSprite()
    s:Play("Idle", true)
	
	q1.Parent = targ
	if params.cooldown then
		d.removecd = params.cooldown
	else
		d.removecd = 120
	end
	if params.player then
		d.player = params.player
	end
	d.Damage = dmg
    d.Params = funct.copy(params)
	
	local q2 = Isaac.Spawn(EntityType.ENTITY_KNIFE, 0, 0, Vector(2000,0),velocity:Normalized(), nil):ToKnife()
	local s = q2:GetSprite()
	s:Play("Idle")
	q2.Parent = q1
	q1.Child = q2
	q2.CollisionDamage = dmg
	q2.RotationOffset = velocity:GetAngleDegrees()
	if params.player then
		q2:GetData().player = params.player
	end
	if params.Explosive and params.Explosive > 0 then
		q2:GetData().Explosive_cnt = params.Explosive
	end
	if params.tearflags then
		q2.TearFlags = params.tearflags
	end
	if params.Color then
		q2:SetColor(params.Color,3,99,false,false)
	end
	return q2
end

function funct.fire_lung_Laser(params)	--params传入：player/Direction/Position/delang/Length/loop_func/multi_cnt/multi_shot/cool_down
	if params.player == nil then
		params.player = Game():GetPlayer(0)
	end
	if params.Direction == nil or params.Position == nil then
		return
	end
	if params.delang == nil then
		params.delang = 1
	end
	if params.Length == nil then
		params.Length = 30
	end
	if params.length == nil then
		params.length = 0
	end
	local player = params.player
	local actu_Dis = params.Length + math.random(10 * params.length + 1)/5 - params.length
	if actu_Dis < 5 then
		actu_Dis = 5
	end
	local q1 = player:FireTechLaser(params.Position,1,params.Direction,false,true)
	q1:SetMaxDistance(actu_Dis)
	if params.loop_func and params.multi_cnt and params.multi_cnt > 0 then
		if params.multi_shot == nil then
			params.multi_shot = 3
		end
		if params.cool_down == nil then
			params.cool_down = 3
		end
		params.multi_cnt = params.multi_cnt - 1
		params.Position = params.Position + params.Direction * actu_Dis
		local rand_cnt1 = math.random(params.multi_shot) + 1
		local ang = params.Direction:GetAngleDegrees() - rand_cnt1 * params.delang / 2
		for i = 1,rand_cnt1 do
			params.Direction = funct.MakeVector(ang + i * params.delang)
			local trans = funct.copy(params)
			addeffe(params.loop_func,trans,params.cool_down)
		end
	end
end

function funct.fire_Sword(position,velocity,dmg,targ,params)
	if true then
		local q1 = funct.fire_knife(position,velocity,dmg,targ,params)
		local s = q1:GetSprite()
		if params.Tech then
			s:Load("gfx/to_be_tech sword.anm2", true)
		else
			s:Load("gfx/to_be_spirit sword.anm2", true)
		end
		if params.Qing then
			s:Load("gfx/008.2335_NormalSword.anm2", true)
		end
		if params.RotationOffset then
			q1.RotationOffset = params.RotationOffset
		end
		if params.del_RotationOffset then
			q1.RotationOffset = q1.RotationOffset + params.del_RotationOffset
		end
		if q1.RotationOffset > 180 then q1.RotationOffset = q1.RotationOffset - 360 end
		if q1.RotationOffset < -180 then q1.RotationOffset = q1.RotationOffset + 360 end
		local initial_sz = 80
		if params.Attack then
			s:Play("AttackRight",true)
			if q1.RotationOffset < -90.0001 or q1.RotationOffset > 90.0001 then
				s:Play("AttackRight2",true)
			end
			initial_sz = 30
		else
			s:Play("SpinRight",true)
			if q1.RotationOffset < -90.0001 or q1.RotationOffset > 90.0001 then
				s:Play("SpinRight2",true)
			end
		end
		local tosetsize = {size1 = initial_sz,size2 = Vector(1,1),size3 = 5,scale = Vector(1,1)}
		
		if params.size and params.size2 and params.size1 then
			tosetsize.size1 = params.size
			tosetsize.size2 = params.size1
			tosetsize.size3 = params.size2
		end
		if params and params.list and params.list.pol and params.list.pol ~= 0 then
			local pol = params.list.pol
			tosetsize.size1 = tosetsize.size1 * (1 + pol)
			tosetsize.size2 = Vector(tosetsize.size2.X * 2,tosetsize.size2.Y * 2)
			tosetsize.size3 = tosetsize.size3 * (1 + pol)
			tosetsize.scale = Vector(2,(1 + pol))
		end
		if params and params.list and ((params.list.soy and params.list.soy ~= 0) or (params.list.soy2 and params.list.soy2 ~= 0))  then
			local rang = 1
			if (params.list.soy and params.list.soy ~= 0) then
				rang = 0.25
			end
			if (params.list.soy2 and params.list.soy2 ~= 0) then
				rang = 0.35
			end
			local cho_counter = params.list.cho_counter
			tosetsize.size1 = tosetsize.size1 * rang
			tosetsize.scale = tosetsize.scale * rang
		end
		if params and params.list and params.list.hae and params.list.hae ~= 0 then
			local hae = params.list.hae
			tosetsize.size1 = tosetsize.size1 * (1 + hae * 0.4)
			tosetsize.scale = tosetsize.scale * (1 + hae * 0.4)
		end
		
		if tosetsize then
			q1:SetSize(tosetsize.size1,tosetsize.size2,tosetsize.size3)
			s.Scale = tosetsize.scale
		end
		return q1
	end
end

function funct.tear_damage_to_fetus_scale(tear,player)
	local dmg = tear.CollisionDamage
	local scale = 3
	if dmg < 1 then scale = 1
	elseif dmg < 2.5 then scale = 2
	elseif dmg < 6 then scale = 3
	elseif dmg < 20 then scale = 4
	else scale = 5 end
	if player:HasCollectible(149) then scale = math.max(1,scale - 2) end
	if player:HasCollectible(659) or player:HasCollectible(336) or player:HasCollectible(309) then scale = math.min(5,scale + 1) end
	return tostring(scale)
end

function funct.fire_fetus(q,player,pos,vel,CanBeEye,CanTriggerStreakEnd,params)
	if params == nil then params = {} end
	if CanTriggerStreakEnd == nil then CanTriggerStreakEnd = true end
	if CanBeEye == nil then CanBeEye = true end
	if player == nil then player = Game():GetPlayer(0) end
	if pos == nil then pos = player.Position + player.Velocity end
	if vel == nil then vel = player.Velocity end
	if q == nil then q = player:FireTear(pos,vel,CanBeEye,true,CanTriggerStreakEnd) end
	q.TearFlags = q.TearFlags | BitSet128(0,1<<(114-64))
	local s = q:GetSprite()
	local d = q:GetData()
	s:Load("gfx/my_fetus tear.anm2",true)
	s:Play("Rotate"..funct.tear_damage_to_fetus_scale(q,player),true)
	if params.should_not_sound == nil then
		sound_tracker.PlayStackedSound(SoundEffect.SOUND_PLOP,1,1,false,0,2)
	end
	q.Variant = 50
	if params.velocity_control == nil then
		q.Velocity = q.Velocity:Length() * funct.MakeVector(q.Velocity:GetAngleDegrees() + math.random(31) - 16) * 0.8 + funct.MakeVector(math.random(36000)/100) * q.Velocity:Length() * 0.2
	end
	d.is_fetus = true
	if player:HasCollectible(395) then
		--local tech_x = 
	end
end

function funct.replace_dagger_graph(ent,replace_name)
	if replace_name == nil or ent == nil then return end
	local s = ent:GetSprite()
	local r_name = "gfx/daggers/"..replace_name..".png"
	for i = 0,2 do
		s:ReplaceSpritesheet(i,r_name)
	end
	s:ReplaceSpritesheet(4,r_name)
	s:LoadGraphics()
end

function funct.get_qing_list(player)
	if player == nil then player = Game():GetPlayer(0) end
	local tab = {		--重要道具数量
		brimstone = player:GetCollectibleNum(118),
		tech = player:GetCollectibleNum(68),
		techX = player:GetCollectibleNum(395),
		knife = player:GetCollectibleNum(114),
		lung = player:GetCollectibleNum(229),
		dr = player:GetCollectibleNum(52),
		epic = player:GetCollectibleNum(168),
		sword = player:GetCollectibleNum(579),
		ludo = player:GetCollectibleNum(329),
		pol = player:GetCollectibleNum(169),
		cho = player:GetCollectibleNum(69),
		soy = player:GetCollectibleNum(330),
		soy2 = player:GetCollectibleNum(561),
		para = player:GetCollectibleNum(461),
		damo = player:GetCollectibleNum(577) + player:GetCollectibleNum(656),
		ice = player:GetCollectibleNum(596),
		dual = player:GetCollectibleNum(498) + player:GetCollectibleNum(304),
		redfire = player:GetCollectibleNum(616),
		bluefire = player:GetCollectibleNum(495),
		loki = player:GetCollectibleNum(87),
		momeye = player:GetCollectibleNum(55),
		wiz = player:GetCollectibleNum(358),
		eye = player:GetCollectibleNum(558),
		coal = player:GetCollectibleNum(132),
		pro = player:GetCollectibleNum(261),
		hae = player:GetCollectibleNum(531),
		sec = player:GetCollectibleNum(678),
		ipec = player:GetCollectibleNum(149),
		deadeye = player:GetCollectibleNum(373),
		wavereye = player:GetCollectibleNum(enums.Items.Wavering_Eyes),
		finger = player:GetCollectibleNum(467),
		spear = player:GetCollectibleNum(400),
		backstab = player:GetCollectibleNum(506) + player:GetCollectibleNum(enums.Items.Assassin_s_Eye),
		divi = player:GetCollectibleNum(453) + player:GetCollectibleNum(224) + player:GetCollectibleNum(104),
		godhead = player:GetCollectibleNum(331) + player:GetCollectibleNum(enums.Items.Gospel),
		repel_effect = math.max(-10,(player:GetCollectibleNum(4) + player:GetCollectibleNum(309) + player:GetCollectibleNum(359)) * 4 - player:GetCollectibleNum(330) * 6 - 3 + player.TearRange/200),
		tri = player:GetCollectibleNum(533),
		bone = player:GetCollectibleNum(453) + player:GetCollectibleNum(544) + player:GetCollectibleNum(549) + player:GetCollectibleNum(541) + player:GetCollectibleNum(542) + player:GetCollectibleNum(548) + player:GetCollectibleNum(683),
		bloody = player:GetCollectibleNum(157) + player:GetCollectibleNum(695) + player:GetCollectibleNum(411) + player:GetCollectibleNum(614) + player:GetCollectibleNum(724) + player:GetCollectibleNum(214) + player:GetCollectibleNum(254) + player:GetCollectibleNum(531) + player:GetCollectibleNum(475) * 3,
		holy = player:GetCollectibleNum(313) + player:GetCollectibleNum(178) + player:GetCollectibleNum(184) + player:GetCollectibleNum(374),
		eye_ball = player:GetCollectibleNum(558) + player:GetCollectibleNum(529) * 2 + player:GetCollectibleNum(261) + player:GetCollectibleNum(410) + player:GetCollectibleNum(462),
		dea = player:GetCollectibleNum(237) + player:GetCollectibleNum(446),
		pencil = player:GetCollectibleNum(444),
		poision = player:GetCollectibleNum(103) + player:GetCollectibleNum(305) + player:GetCollectibleNum(393),
		slow = player:GetCollectibleNum(89),
		freeze = player:GetCollectibleNum(110),
		charm = player:GetCollectibleNum(200),
		confuse = player:GetCollectibleNum(201),
		godflesh = player:GetCollectibleNum(398),
		glaucoma = player:GetCollectibleNum(460),
		sulfur = player:GetCollectibleNum(463),
		lemon = player:GetCollectibleNum(56) + player:GetCollectibleNum(578),
		ledo = player:GetCollectibleNum(617),
		rotten_tomato = player:GetCollectibleNum(618),
		link_knife = player:GetCollectibleNum(enums.Items.Touchstone),
		rift = player:GetCollectibleNum(606),
		tar = player:GetCollectibleNum(231),
		horn = player:GetCollectibleNum(503),
		onlaser = player:GetCollectibleNum(524) + player:GetCollectibleNum(68) + player:GetCollectibleNum(152) + player:GetCollectibleNum(244) + player:GetCollectibleNum(494),
		should_on_laser = player:GetCollectibleNum(524),
		ladd = player:GetCollectibleNum(494),
		keeper_head = player:GetCollectibleNum(429),
		greed_head = player:GetCollectibleNum(450),
		holy_light = player:GetCollectibleNum(374),
		rock = player:GetCollectibleNum(592),
		euthanasia = player:GetCollectibleNum(496),
		nipton = player:GetCollectibleNum(597) + player:GetCollectibleNum(308),
		fist = player:GetCollectibleNum(637),
		fear = player:GetCollectibleNum(259) + player:GetCollectibleNum(230),
		larger = player:GetCollectibleNum(659) + player:GetCollectibleNum(336) + player:GetCollectibleNum(309),
		tech9 = player:GetCollectibleNum(enums.Items.Tech_9),
		saga = player:GetCollectibleNum(enums.Items.Squiresaga),
	}
	return tab
end

function funct.fire_dowhatknife(variant,position,velocity,dmg,dowhatstring1,dowhatstring2,params)		--pos，vel，dmg，targ，params
	dowhatstring2 = dowhatstring1
	params = params or {}
	params.list = params.list or {}
	
	local var = StabberKnife
	if variant ~= nil then
		var = variant
	end
	if position == nil or velocity == nil or dowhatstring1 == nil then	--直接解除
		return
	end
	local player = nil
	if params.player then
		player = params.player
	end
	local source = params.source
	local q1 = nil
	local coold = 8
	if params.cooldown then
		coold = params.cooldown
	end
	if params and params.list and params.list.sec and params.list.sec > 0 and (not params.no_sec) then
		if params.epic and params.epic == true then
			params.sec_effect2 = true		--史诗、剖腹产有特殊配合。
			dmg = dmg * 0.75
		else
			coold = coold * (3 + math.floor((params.list.sec - 1))) + 20
			params.sec_effect = true
		end
	end
	if params and params.list and params.list.ludo and params.list.ludo > 0 and (not params.ignore_ludo) then
		coold = coold * (2 + math.floor((params.list.ludo - 1)/3))
		params.continueafter = true
	end

	if source == nil then
		local t_pos = position - velocity * 3
		if dowhatstring1 == "IdleUp" then t_pos = position end
		q1 = funct.fire_nil(t_pos,velocity,{cooldown = coold})
		source = q1
		source:GetData().Params = params
	end
	local q1 = Isaac.Spawn(8,var,0,Vector(2000,0),velocity,player):ToKnife()		--q1被重新赋值了！！
	local s2 = q1:GetSprite()
	local d2 = q1:GetData()
	q1.Parent = source
	source.Child = q1
	q1.RotationOffset = velocity:GetAngleDegrees()
	if player then
		d2.player = player
		d2.tearflags = player.TearFlags
	end
	if params.tearflags then
		d2.tearflags = d2.tearflags | params.tearflags
		if params.tearflags & BitSet128(1<<2,0) == BitSet128(1<<2,0) and dowhatstring1 == "IdleUp" then		--弯勺
			source:GetData().Params.Homing = true
			source:GetData().Params.HomingSpeed = 12
		end
	end
	if params and params.list then			--特效控制
		if params.list.divi and params.list.divi ~= 0 and params.list.ignore_divi == nil then		--分裂
			d2.tearflags = d2.tearflags | BitSet128(1<<6,0)
			d2.divi_list = {}
			if player:GetCollectibleNum(453) > 0 then 
				for i = 1,math.random(3) + 1 do
					table.insert(d2.divi_list,{dir = math.random(3600)/10})
				end
			end
			if player:GetCollectibleNum(224) > 0 then 
				for i = 1,2 do
					table.insert(d2.divi_list,{dir = 90 + 180 * i})
				end
			end
			if player:GetCollectibleNum(104) > 0 then
				local adder = (math.random(2) - 1) * 45
				for i = 1,4 do
					table.insert(d2.divi_list,{dir = 90 * i + adder})
				end
			end
		end
		if params.list.para and params.list.para ~= 0 then		--中猫套
			d2.tearflags = d2.tearflags | BitSet128(1<<49,0)
		end
		if params.list.deadeye and params.list.deadeye > 0 then
			d2.deadeye = 1
		end
		if params.list.wavereye and params.list.wavereye > 0 then
			d2.wavereye = 1
		end
		if params.list.poision and params.list.poision > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<4,0)
		end
		if params.list.slow and params.list.slow > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<3,0)
		end
		if params.list.freeze and params.list.freeze > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<5,0)
		end
		if params.list.charm and params.list.charm > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<13,0)
		end
		if params.list.confuse and params.list.confuse > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<14,0)
		end
		if params.list.godflesh and params.list.godflesh > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<43,0)
		end
		if params.list.glaucoma and params.list.glaucoma > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<47,0)
		end
		if params.list.ice and params.list.ice > 0 then
			d2.tearflags = d2.tearflags | BitSet128(0,1<<(65-64))
		end
		if params.list.ledo and params.list.ledo > 0 then
			d2.tearflags = d2.tearflags | BitSet128(0,1<<(66-64))
		end
		if params.list.rotten_tomato and params.list.rotten_tomato > 0 then
			d2.tearflags = d2.tearflags | BitSet128(0,1<<(67-64))
		end
		if params.list.rift and params.list.rift > 0 then
			d2.tearflags = d2.tearflags | BitSet128(0,1<<(76-64))
		end
		if params.list.tar and params.list.tar > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<32,0)
		end
		if params.list.horn and params.list.horn > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<56,0)
		end
		if params.list.should_on_laser and params.list.should_on_laser > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<57,0)
			d2.zero_stack = params.list.should_on_laser * 2 + 3
		end
		if params.list.ladd and params.list.ladd > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<55,0)
		end
		if params.list.keeper_head and params.list.keeper_head > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<44,0)
		end
		if params.list.holy_light and params.list.holy_light > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<39,0)
		end
		if params.list.fear and params.list.fear > 0 then
			d2.tearflags = d2.tearflags | BitSet128(1<<20,0)
		end
		if params.list.fist and params.list.fist > 0 then
			d2.tearflags = d2.tearflags | BitSet128(0,1<<(64-64))
		end
	end
	if params and params.room then
		d2.nowroom = params.room
	else
		d2.nowroom = Game():GetLevel():GetCurrentRoomIndex()
	end
	if params and params.knife2 and params.knife2 > 0 then
		if source ~= nil then
			source:AddVelocity(velocity:Normalized() * 10)
			if source:GetData().Params == nil then
				source:GetData().Params = {}
			end
			source:GetData().Params.Accerate = -1
		end
		d2.record_dir_for_knife_and_sword = velocity:GetAngleDegrees()
		d2.delta_dir_for_knife_and_sword = 0
		d2.record_knife2_delay = params.knife2_delay
	end
	if params and params.Explosive == nil and params.list then
		params.Explosive = params.list.ipec
	end
	
	if params and params.shouldrotate then
		params.shouldrotate = true
	end
	if params and params.follow_hae then
		params.follow_hae = true
		d2.hae_counter = 1
	end
	
	if params and params.Explosive and params.Explosive > 0 then
		d2.Explosive_cnt = params.Explosive
		params.bomb_knife_flag = BitSet128(0,0)
		local bfl = player:GetBombFlags()
		for i = 1,#bomb_effe_list do
			local list_1 = bomb_effe_map[i]
			if funct.bitset_flag(bfl,bomb_effe_list[i]) and funct.check_rand(player.Luck,list_1[1],0,list_1[2]) == true then
				params.bomb_knife_flag = params.bomb_knife_flag | funct.MakeBitSet(bomb_effe_list[i])
			end
		end
	end
	if params and params.repel and params.repel:Length() > 0.005 and params.list and params.list.repel_effect and params.list.repel_effect > 0 then		--附加的击退效果。
		params.repel = params.repel * (1 + params.list.repel_effect/10)
	end
	
	if params.color then
		local fadeout = false
		if params.color_fadeout then
			fadeout = params.color_fadeout
		end
		local duration = coold + 2
		if params.color_dur then
			duration = params.color_dur
		end
		q1:SetColor(params.color,duration,99,fadeout,false)
	end
	
	local tosetsize = {size1 = 5,size2 = Vector(1,1),size3 = 5,scale = Vector(1,1)}		--大小控制
	
	if params.size and params.size2 and params.size1 then
		tosetsize.size1 = params.size
		tosetsize.size2 = params.size1
		tosetsize.size3 = params.size2
	end
	if params.size_scale then
		tosetsize.scale = params.size_scale
	end
	if dowhatstring1 == "IdleUp" then tosetsize.size2.Y = tosetsize.size2.Y * 0.85 end		--稍微过长了
	if params and params.list then
		if params.list.knife and params.list.knife ~= 0 then
			local knife = params.list.knife
			tosetsize.size1 = tosetsize.size1 * (2 + knife)
			tosetsize.size2 = Vector(0.3,2)
			tosetsize.size3 = tosetsize.size3 * (1 + knife)
		end
		if params.list.pol and params.list.pol ~= 0 then
			local pol = params.list.pol
			tosetsize.size1 = tosetsize.size1 * (1 + pol)
			tosetsize.size2 = Vector(tosetsize.size2.X * 2,tosetsize.size2.Y * 2)
			tosetsize.size3 = tosetsize.size3 * (1 + pol)
			tosetsize.scale = Vector(2,(1 + pol))
		end
		if params.list.larger and params.list.larger ~= 0 then
			local cnt = params.list.larger
			tosetsize.size1 = tosetsize.size1 * (1 + cnt * 0.15)
			tosetsize.scale = tosetsize.scale * (1 + cnt * 0.15)
		end
		if params.list.cho and params.list.cho ~= 0 and params.list.cho_counter then
			local cho_counter = params.list.cho_counter
			tosetsize.size1 = tosetsize.size1 * (0.25 + cho_counter)
			tosetsize.scale = tosetsize.scale * (0.15 + cho_counter)
		end
		if ((params.list.soy and params.list.soy ~= 0) or (params.list.soy2 and params.list.soy2 ~= 0))  then
			local rang = 1
			if (params.list.soy and params.list.soy ~= 0) then
				rang = 0.25
			end
			if (params.list.soy2 and params.list.soy2 ~= 0) then
				rang = 0.35
			end
			local cho_counter = params.list.cho_counter
			tosetsize.size1 = tosetsize.size1 * rang
			tosetsize.scale = tosetsize.scale * rang
		end
		if params.list.hae and params.list.hae ~= 0 then
			local hae = params.list.hae
			tosetsize.size1 = tosetsize.size1 * (1 + hae * 0.4)
			tosetsize.size3 = tosetsize.size3 
			tosetsize.scale = tosetsize.scale * (1 + hae * 0.4)
		end
	end
	
	if tosetsize then
		q1:SetSize(tosetsize.size1,tosetsize.size2,tosetsize.size3)
		s2.Scale = tosetsize.scale
	end
	
	local replace_name = nil
	local replace_name_cnt = 0
	if params.tech and params.tech == true then		--换皮肤
		replace_name = "tech_Stabknife"
		replace_name_cnt = replace_name_cnt + 1
	end
	if params and params.list then
		if params.list.spear and params.list.spear > 0 then
			replace_name = "Spear_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.finger and params.list.finger > 0 then
			replace_name = "Finger_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.bone and params.list.bone > 1 then
			replace_name = "bone_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.bloody and params.list.bloody > 1 then
			replace_name = "Bloody_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.eye_ball and params.list.eye_ball > 1 then
			replace_name = "Eye_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.dea and params.list.dea > 0 then
			replace_name = "Death_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.rock and params.list.rock > 0 then
			replace_name = "Rock_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.nipton and params.list.nipton > 0 then
			replace_name = "Nipton_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.tri and params.list.tri > 0 then
			replace_name = "Tri_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if (params.list.sulfur and params.list.sulfur > 0) or (params.list.lemon and params.list.lemon > 0) then
			replace_name = "Sulfur_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.damo and params.list.damo > 0 then
			replace_name = "Damo_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.holy and params.list.holy > 1 then
			replace_name = "Holy_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.ice and params.list.ice > 0 then
			replace_name = "Ice_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.dual and params.list.dual > 0 then
			if player:GetData().Dual_cnt == nil then
				player:GetData().Dual_cnt = 0
			end
			if player:GetData().Dual_cnt == 1 then
				replace_name = "Yang_Stabknife"
			else
				replace_name = "Yin_Stabknife"
			end
			replace_name_cnt = replace_name_cnt + 1
			dmg = dmg * 0.75		--伤害*0.75，被阴阳切换的敌人受到额外的爆炸伤害。
			d2.Dual_cnt = player:GetData().Dual_cnt		--1对应阳。
			player:GetData().Dual_cnt = 1 - player:GetData().Dual_cnt
		end
		if params.list.godhead and params.list.godhead > 0 then	
			replace_name = "godh_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		if params.list.saga and params.list.saga > 0 then
			replace_name = "Saga_Stabknife"
			replace_name_cnt = replace_name_cnt + 1
		end
		
		if params.list.redfire and params.list.redfire > 0 then		--两种辣椒的特效。
			if math.random(1200)/1000 * (math.exp(11/5) + 2) < math.exp(math.max(-3/5,math.min(11/5,player.Luck/5))) + 2.01 then
				dmg = dmg * 1.7
				replace_name = "RedFire_Stabknife"
				replace_name_cnt = replace_name_cnt + 1
				d2.fire_sound_effect = true
			end
		end
		if params.list.bluefire and params.list.bluefire > 0 then
			if math.random(1200)/1000 * (math.exp(11/5) + 2) < math.exp(math.max(-3/5,math.min(11/5,player.Luck/5))) + 2.01 then
				dmg = dmg * 2.5
				replace_name = "BlueFire_Stabknife"
				replace_name_cnt = replace_name_cnt + 1
				d2.fire_sound_effect = true
			end
		end
	end
	
	if replace_name_cnt > 8 then			--最终状态
		if player:GetData().mega_yinyang_stack_counter == nil then player:GetData().mega_yinyang_stack_counter = 0 end
		player:GetData().mega_yinyang_stack_counter = player:GetData().mega_yinyang_stack_counter % 3 + 1
		replace_name = "yinyang_Stabknife_"..tostring(player:GetData().mega_yinyang_stack_counter)
	end
	
	funct.replace_dagger_graph(q1,replace_name)			--修正贴图
		
	if params.Entitycollision then		--似乎没啥用
		q1.EntityCollisionClass = params.Entitycollision
	end
	
	q1.CollisionDamage = dmg
	local ang = velocity:GetAngleDegrees() + 360
	s2:Play(dowhatstring1,true)
	
	d2.damage = dmg
	d2.params = funct.copy(params)
	d2.TimeOut = coold		--调用了自动删除装置。
	return q1
end

function funct.thor_attack(player,list)		--飞雷神！！具有三种攻击方式。目前只做了一种的说。
	local room = Game():GetRoom()
	if player == nil or player:GetData().thor_target == nil then
		return
	end
	if list.backstab == nil or list.backstab == 0 then
		local targ = player:GetData().thor_target
		local loop_cnt = 10
		if (targ.Position - player.Position):Length() < 100 then
			loop_cnt = 5
		end
		if (targ.Position - player.Position):Length() < 40 then
			loop_cnt = 3
		end
		player:GetData().is_setting_color = true
		player:SetColor(Color(-1,-1,-1,1,0,0,0),loop_cnt,99,false,true)
		local dir = (targ.Position - player.Position):Normalized()
		local dmg = player.Damage/10
		for i = 1,loop_cnt do				
			addeffe(function(params)
				local player = params.player
				local position = params.position
				if player == nil or position == nil then
					return
				end
				local dirang = (player.Velocity + dir * 10):GetAngleDegrees()
				local length = (player.Velocity + dir * 10):Length()
				local q1 = funct.fire_dowhatknife(nil,player.Position + dir * 30 + player.Velocity + funct.MakeVector(dirang + 90) * 60 + funct.MakeVector(dirang) * (-20),funct.MakeVector(dirang - 30) * length,dmg,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = dir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,tech = player:HasCollectible(68),list = funct.copy(list),thor_effe = true,no_sec = true,})
				local q2 = funct.fire_dowhatknife(nil,player.Position + dir * 30 + player.Velocity + funct.MakeVector(dirang - 90) * 60 + funct.MakeVector(dirang) * (-20),funct.MakeVector(dirang + 30) * length,dmg,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = dir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,tech = player:HasCollectible(68),list = funct.copy(list),thor_effe = true,no_sec = true,})
				player.Position = position
				player.Velocity = Vector(0,0)
				player:AddControlsCooldown(1)
				end,{player = player,position = player.Position + i/loop_cnt * (targ.Position - player.Position)},i-1)
		end
		if player.CanFly == false then
			Attribute_holder.try_hold_and_rewind_attribute(player,"GridCollisionClass",GridCollisionClass.COLLISION_WALL,60)
		end
		addeffe(function(para)
			player:SetColor(Color(1,1,1,0.5,1,1,1),15,30,true,true)
			player.Position = room:GetClampedPosition(player.Position,10)
			end,{player = player},loop_cnt)
		addeffe(function(para)
			player:GetData().is_setting_color = false
			end,{player = player},loop_cnt + 15)
		if 25 + loop_cnt - player:GetDamageCooldown() > 0 then
			Attribute_holder.try_hold_and_rewind_attribute(player,"ENTITY_FLAG_NO_DAMAGE_BLINK",true,25 + loop_cnt - player:GetDamageCooldown(),{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) else ent:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end end,})
		end
		player:SetMinDamageCooldown(25 + loop_cnt)
	else
		local targ = player:GetData().thor_target
		local q1 = Isaac.Spawn(1000,MeusLink,0,player.Position/2 + targ.Position/2,Vector(0,0),player)
		local s1 = q1:GetSprite()
		local dir = (targ.Position - player.Position)
		local ang = dir:GetAngleDegrees()
		local leg = dir:Length() + 30
		s1.Rotation = ang - 90
		s1.Scale = Vector(leg/45,1/6)
		player.Position = player.Position + funct.MakeVector(ang) * (leg)
		player.Velocity = Vector(0,0)
		local dmg = player.Damage/3
		if list.sec then dmg = dmg * 0.3 end
		for i = 1, 16 do
			local q1 = funct.fire_dowhatknife(nil,player.Position,funct.MakeVector(ang + i * 360/16) * 20 * player.ShotSpeed,dmg,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,epic = player:HasCollectible(168),Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = player:HasCollectible(68),})
		end
		if player.CanFly == false then
			Attribute_holder.try_hold_and_rewind_attribute(player,"GridCollisionClass",GridCollisionClass.COLLISION_WALL,60)
		end
		if 30 - player:GetDamageCooldown() > 0 then
			Attribute_holder.try_hold_and_rewind_attribute(player,"ENTITY_FLAG_NO_DAMAGE_BLINK",true,30 - player:GetDamageCooldown(),{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) else ent:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end end,})
		end
		player:SetMinDamageCooldown(30)
	end
end

function funct.kill_thenm_all(player,pos,dmg,list)
	local room = Game():GetRoom()
	local q1 = Isaac.Spawn(1000,MeusLink,0,player.Position,Vector(0,0),player)
	local s1 = q1:GetSprite()
	
	local dir = pos - player.Position
	if player:GetData().last_attack_pos then
		 dir = player:GetData().last_attack_pos - player.Position
		 player:GetData().last_attack_pos = nil
	else
		--player:GetData().last_attack_pos = player.Position
	end
	if dir:Length() < 0.5 then
		dir = funct.MakeVector(math.random(36000)/100) * 1000
	end
	s1.Rotation = dir:GetAngleDegrees() - 90
	s1.Scale = Vector(dir:Length(),1/10)
	player.Position = room:GetClampedPosition(player.Position + dir:Normalized() * (dir:Length() + 50),10)
	if 20 - player:GetDamageCooldown() > 0 then
		Attribute_holder.try_hold_and_rewind_attribute(player,"ENTITY_FLAG_NO_DAMAGE_BLINK",true,20 - player:GetDamageCooldown(),{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) else ent:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end end,})
	end
	player:SetMinDamageCooldown(20)
	local n_entity = Isaac.GetRoomEntities()
	local n_enemy = funct.getenemies(n_entity)
	for i = 1,#n_enemy do 
		if (n_enemy[i].Position - pos):Length() < 30 then
			n_enemy[i]:TakeDamage(dmg,0,EntityRef(player),0)
		end
	end
end

function funct.kill_thenm_all2(player,pos,dmg,params,max_hit,max_range)
	local target_enemy = {}
	local n_entity = Isaac.GetRoomEntities()
	local n_enemy = funct.getenemies(n_entity)
	if max_range == nil then
		max_range = 100
	end
	for i = 1,#n_enemy do 
		if (n_enemy[i].Position - pos):Length() < max_range then
			target_enemy[#target_enemy + 1] = n_enemy[i]
		end
	end
	if max_hit == nil then
		max_hit = 5
	end
	if #target_enemy < max_hit and #target_enemy > 0 then
		for i = #target_enemy,max_hit + 2 do 
			target_enemy[#target_enemy + 1] = target_enemy[math.random(#target_enemy)]
		end
	end
	if #target_enemy > 0 then
		Attribute_holder.try_hold_and_rewind_attribute(player,"Visible",false,#target_enemy * 1.5 + 2)
		if #target_enemy * 2 + 30 - player:GetDamageCooldown() > 0 then
			Attribute_holder.try_hold_and_rewind_attribute(player,"ENTITY_FLAG_NO_DAMAGE_BLINK",true,#target_enemy * 2 + 30 - player:GetDamageCooldown(),{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) else ent:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK) end end,})
		end
		player:SetMinDamageCooldown(#target_enemy * 2 + 30)
		if player.CanFly == false then
			Attribute_holder.try_hold_and_rewind_attribute(player,"GridCollisionClass",GridCollisionClass.COLLISION_WALL,#target_enemy * 2 + 30)
		end
		player:GetData().bone_Position = player.Position
		player:AddControlsCooldown(#target_enemy * 2 + 10)
		for i = 1,#target_enemy do
			addeffe(function(params)
				local q1 = Isaac.Spawn(1000,MeusLink,0,params.player:GetData().bone_Position/2 + params.target_enemy.Position/2,Vector(0,0),player)
				local s1 = q1:GetSprite()
				local dir = (params.target_enemy.Position - params.player:GetData().bone_Position)
				local ang = dir:GetAngleDegrees() + math.random(60000)/1000 - 30
				local leg = dir:Length() + 30
				s1.Rotation = ang - 90
				s1.Scale = Vector(leg/90,1/10)
				params.player:GetData().bone_Position = params.player:GetData().bone_Position + funct.MakeVector(ang) * (leg)
				if params.target_enemy:Exists() then
					params.target_enemy:TakeDamage(dmg,0,EntityRef(player),0)
				end
			end,{target_enemy = target_enemy[i],player = player},i * 2)
		end
	end
end

function funct.PrintTable( tbl , level, filteDefault)
	if tbl == nil then print(tbl) return end
	local msg = ""
	filteDefault = filteDefault or true --默认过滤关键字（DeleteMe, _class_type）
	level = level or 1
	local indent_str = ""
	for i = 1, level do
		indent_str = indent_str.."  "
	end

	print(indent_str .. "{")
	for k,v in pairs(tbl) do
		if filteDefault then
			if k ~= "_class_type" and k ~= "DeleteMe" and type(v) ~= "boolean" then
				local item_str = string.format("%s%s = %s", indent_str .. " ",tostring(k), tostring(v))
				print(item_str)
				if type(v) == "table" then
					funct.PrintTable(v, level + 1)
				end
			elseif type(v) == "boolean" then
				local item_str = indent_str.." "..tostring(k).." = "
				if v == true then
					item_str = item_str.."True"
				else
					item_str = item_str.."False"
				end
				print(item_str)
			end
		else
			local item_str = string.format("%s%s = %s", indent_str .. " ",tostring(k), tostring(v))
			print(item_str)
			if type(v) == "table" then
				funct.PrintTable(v, level + 1)
			end
		end
	end
	print(indent_str .. "}")
end
function funct.get_random_pickup()
	local rand = math.random(1000)
	if rand < 400 then
		if rand < 300 then 
			return Vector(20,1)
		elseif rand < 350 then
			return Vector(20,4)
		elseif rand < 370 then
			return Vector(20,2)
		elseif rand < 380 then
			return Vector(20,3)
		elseif rand < 385 then
			return Vector(20,5)
		else 
			return Vector(20,7)
		end
	elseif rand < 600 then
		return Vector(10,0)
	elseif rand < 700 then
		return Vector(30,0)
	elseif rand < 800 then
		if rand < 780 then 
			return Vector(40,1)
		elseif rand < 790 then
			return Vector(40,2)
		elseif rand < 797 then
			return Vector(40,4)
		else 
			return Vector(40,7)
		end
	elseif rand < 830 then
		return Vector(90,0)
	elseif rand < 900 then
		return Vector(80,0)
	elseif rand < 970 then
		return Vector(300,0)
	else
		return Vector(42,0)
	end
end

function funct.getsmallenemies(eny)
	local enemies = {}
    for _, ent in ipairs(eny) do
        if ent:IsBoss() == false  then
            enemies[#enemies + 1] = ent
        end
    end
	return enemies
end

local glazed_players = {
	"Isaac",
	"Maggy",
	"Cain",
	"Judas",
	"BlueBaby",
	"Eve",
	"Samson",
	"Azazel",
	"Lazarus",
	"Eden",
	"Lost",
	--"Lazarus2",	--11
	--"BlackJudas",--12
	"Lilith",
	"Keeper",
	"Apollyon",
	"Forgotten",
	--"The Soul",--17
	"Bethany",
	"Esau",
	"Jacob",
}

function funct.getplayer_glazed(player)
	local raw_pt = player:GetPlayerType()
	if raw_pt >= 0 then
		if raw_pt > 20 and raw_pt < 41 then
			if raw_pt == 38 then raw_pt = 29 end
			if raw_pt == 39 then raw_pt = 37 end
			if raw_pt == 40 then raw_pt = 35 end
			return glazed_players[raw_pt - 20]
		end
		if raw_pt < 21 then
			if raw_pt == 11 then raw_pt = 8 end
			if raw_pt == 12 then raw_pt = 3 end
			if raw_pt == 17 then raw_pt = 15 end
			if raw_pt > 17 then raw_pt = raw_pt - 1 end
			if raw_pt > 12 then raw_pt = raw_pt - 2 end
			return glazed_players[raw_pt + 1]
		end
		return player:GetName()
	else
		return ""
	end
end

function funct.get_player_name(player)
	local raw_pt = player:GetPlayerType()
	if raw_pt >= 0 then
		if raw_pt > 20 and raw_pt < 41 then
			if raw_pt == 38 then raw_pt = 29 end
			if raw_pt == 39 then raw_pt = 37 end
			if raw_pt == 40 then return nil end
			return glazed_players[raw_pt - 20]
		end
		if raw_pt < 21 then
			if raw_pt == 11 then raw_pt = 8 end
			if raw_pt == 12 then raw_pt = 3 end
			if raw_pt == 17 then return nil end
			if raw_pt > 17 then raw_pt = raw_pt - 1 end
			if raw_pt > 12 then raw_pt = raw_pt - 2 end
			return glazed_players[raw_pt + 1]
		end
		return player:GetName()
	else
		return ""
	end
end

function funct.get_players_name()
	local tbl = {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local name = funct.get_player_name(player)
		if name ~= nil then
			table.insert(tbl,#tbl + 1,name)
		end
	end
	if #tbl > 2 then
		local ret = ""
		for i = 1,#tbl - 2 do
			ret = ret .. tbl[i] .. ","
		end
		return ret..tbl[#tbl - 1].." and "..tbl[#tbl]
	else
		if #tbl == 2 then
			return tbl[1].." and "..tbl[2]
		elseif #tbl == 1 then
			return tbl[1]
		end
	end
end

function funct.get_players_counter()
	local tbl = {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local name = funct.get_player_name(player)
		if name ~= nil then
			table.insert(tbl,#tbl + 1,name)
		end
	end
	return #tbl
end

local player_mxdelay_mul = {
	[PlayerType.PLAYER_EVE_B] = 2/3,
}

local weapon_mxdelay_mul = {
	[WeaponType.WEAPON_TEARS] = function (player)
		local ret = 1
		if player:HasCollectible(CollectibleType.COLLECTIBLE_IPECAC) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_IPECAC) then ret = ret * 1/3 end
		return ret
	 end,
	[WeaponType.WEAPON_BRIMSTONE] = 1/3,
	[WeaponType.WEAPON_LASER] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_IPECAC) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_IPECAC) then ret = ret * 1/3 end
		return 1
	 end,
	[WeaponType.WEAPON_KNIFE] = 1,
	[WeaponType.WEAPON_BOMBS] = 0.4,
	[WeaponType.WEAPON_ROCKETS] = 1,
	[WeaponType.WEAPON_MONSTROS_LUNGS] = 10/43,
	[WeaponType.WEAPON_LUDOVICO_TECHNIQUE] = 1,
	[WeaponType.WEAPON_TECH_X] = 1,
	[WeaponType.WEAPON_BONE] = 0.5,
	[WeaponType.WEAPON_SPIRIT_SWORD] = 1,
	[WeaponType.WEAPON_FETUS] = 1,
	[WeaponType.WEAPON_UMBILICAL_WHIP] = 1,
 }
 
local item_mxdelay_mul = {
	[CollectibleType.COLLECTIBLE_TECHNOLOGY_2] = 2/3,
	[CollectibleType.COLLECTIBLE_EVES_MASCARA] = 2/3,
	[CollectibleType.COLLECTIBLE_MUTANT_SPIDER] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_20_20) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_20_20) then return 1 end
		return 0.42
	 end,
	[CollectibleType.COLLECTIBLE_INNER_EYE] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_20_20) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_20_20) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_POLYPHEMUS) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_POLYPHEMUS) then return 1 end
		return 0.51
	 end,
	[CollectibleType.COLLECTIBLE_POLYPHEMUS] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_20_20) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_20_20) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) then return 1 end
		return 0.42
	 end,
	[CollectibleType.COLLECTIBLE_SOY_MILK] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_ALMOND_MILK) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_ALMOND_MILK) then return 1 end
		return 5.5
	 end,
	[CollectibleType.COLLECTIBLE_ALMOND_MILK] = 4,
	[CollectibleType.COLLECTIBLE_EYE_DROPS] = 1.2,
}

local null_item_mxdelay_mul = {
	[NullItemID.ID_REVERSE_CHARIOT] = 4,
	[NullItemID.ID_REVERSE_HANGED_MAN] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_INNER_EYE) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_INNER_EYE) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_20_20) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_20_20) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_MUTANT_SPIDER) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_POLYPHEMUS) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_POLYPHEMUS) then return 1 end
		return 0.51
	 end,
}

--溢泪症有点小问题。圣地和启明星需要处理
--l local player = Game():GetPlayer(0);for i = 1,16 do if player:HasWeaponType(i) == true then print(i) end end
--l local player = Game():GetPlayer(0);local effects = player:GetEffects();for i = 1,999 do if effects:HasCollectibleEffect(i) then print(i) end end;
--l local player = Game():GetPlayer(0);local effects = player:GetEffects();for i = 1,999 do if effects:HasNullEffect(i) then print(i) end end;
--l local player = Game():GetPlayer(0);local effects = player:GetEffects();effects:RemoveCollectibleEffect(283)
--l local player = Game():GetPlayer(0);local effects = player:GetEffects();effects:AddNullEffect(29)
function funct.get_mxdelay_multiplier(player)
	local total_multiplier = player_mxdelay_mul[player:GetPlayerType()] or 1
	if type(total_multiplier) == "function" then total_multiplier = total_multiplier(player) end
	local weap = 1
	for i = 1,16 do if player:HasWeaponType(i) == true then	weap = i end end
	local multiplier1 = weapon_mxdelay_mul[weap] or 1
	if type(multiplier1) == "function" then multiplier1 = multiplier1(player) end
	total_multiplier = total_multiplier * multiplier1
	local effects = player:GetEffects()
	for collectible, multiplier in pairs(item_mxdelay_mul) do
		if player:HasCollectible(collectible) or effects:HasCollectibleEffect(collectible) then
			if type(multiplier) == "function" then multiplier = multiplier(player) end
			total_multiplier = total_multiplier * multiplier
		end
	end
	for collectible, multiplier in pairs(null_item_mxdelay_mul) do
		if effects:HasNullEffect(collectible) then
			if type(multiplier) == "function" then multiplier = multiplier(player) end
			total_multiplier = total_multiplier * multiplier
		end
	end
	--血泪需要最后计算
	if player:HasCollectible(CollectibleType.COLLECTIBLE_HAEMOLACRIA) or effects:HasCollectibleEffect(CollectibleType.COLLECTIBLE_HAEMOLACRIA) then
		if player:HasCollectible(CollectibleType.COLLECTIBLE_BRIMSTONE) or effects:HasCollectibleEffect(CollectibleType.COLLECTIBLE_BRIMSTONE) then
			total_multiplier = 1/(total_multiplier + 2)
		else
			total_multiplier = 1/(total_multiplier * 2/3 + 2)
		end
	end
	return total_multiplier
end

local player_dmg_mul = {
	[PlayerType.PLAYER_ISAAC] = 1,
	[PlayerType.PLAYER_MAGDALENA] = 1,
	[PlayerType.PLAYER_CAIN] = 1,
	[PlayerType.PLAYER_JUDAS] = 1,
	[PlayerType.PLAYER_XXX] = 1.05,
	[PlayerType.PLAYER_EVE] = function (player)
	if player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_WHORE_OF_BABYLON) then return 1 end
	return 0.75
	end,
	[PlayerType.PLAYER_SAMSON] = 1,
	[PlayerType.PLAYER_AZAZEL] = 1.5,
	[PlayerType.PLAYER_LAZARUS] = 1,
	[PlayerType.PLAYER_THELOST] = 1,
	[PlayerType.PLAYER_LAZARUS2] = 1.4,
	[PlayerType.PLAYER_BLACKJUDAS] = 2,
	[PlayerType.PLAYER_LILITH] = 1,
	[PlayerType.PLAYER_KEEPER] = 1.2,
	[PlayerType.PLAYER_APOLLYON] = 1,
	[PlayerType.PLAYER_THEFORGOTTEN] = 1.5,
	[PlayerType.PLAYER_THESOUL] = 1,
	[PlayerType.PLAYER_BETHANY] = 1,
	[PlayerType.PLAYER_JACOB] = 1,
	[PlayerType.PLAYER_ESAU] = 1,
	-- Tainted characters
	[PlayerType.PLAYER_ISAAC_B] = 1,
	[PlayerType.PLAYER_MAGDALENA_B] = 0.75,
	[PlayerType.PLAYER_CAIN_B] = 1,
	[PlayerType.PLAYER_JUDAS_B] = 1,
	[PlayerType.PLAYER_XXX_B] = 1,
	[PlayerType.PLAYER_EVE_B] = 1.2,
	[PlayerType.PLAYER_SAMSON_B] = 1,
	[PlayerType.PLAYER_AZAZEL_B] = 1.5,
	[PlayerType.PLAYER_LAZARUS_B] = 1,
	[PlayerType.PLAYER_EDEN_B] = 1,
	[PlayerType.PLAYER_THELOST_B] = 1.3,
	[PlayerType.PLAYER_LILITH_B] = 1,
	[PlayerType.PLAYER_KEEPER_B] = 1,
	[PlayerType.PLAYER_APOLLYON_B] = 1,
	[PlayerType.PLAYER_THEFORGOTTEN_B] = 1.5,
	[PlayerType.PLAYER_BETHANY_B] = 0.75,
	[PlayerType.PLAYER_JACOB_B] = 1,
	[PlayerType.PLAYER_LAZARUS2_B] = 1.5,
 }

local item_dmg_mul = {
	[CollectibleType.COLLECTIBLE_MAXS_HEAD] = 1.5,
	[CollectibleType.COLLECTIBLE_MAGIC_MUSHROOM] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MAXS_HEAD) then return 1 end
		return 1.5
	end,
	[CollectibleType.COLLECTIBLE_BLOOD_MARTYR] = function (player)
		if not player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_BOOK_OF_BELIAL) then return 1 end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MAXS_HEAD) or player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_MAGIC_MUSHROOM) then return 1 end
		return 1.5
	end,
	[CollectibleType.COLLECTIBLE_POLYPHEMUS] = 2,
	[CollectibleType.COLLECTIBLE_SACRED_HEART] = 2.3,
	[CollectibleType.COLLECTIBLE_EVES_MASCARA] = 2,
	[CollectibleType.COLLECTIBLE_ODD_MUSHROOM_RATE] = 0.9,
	[CollectibleType.COLLECTIBLE_20_20] = 0.75,
	[CollectibleType.COLLECTIBLE_EVES_MASCARA] = 2,
	[CollectibleType.COLLECTIBLE_SOY_MILK] = function (player)
		if player:HasCollectible(CollectibleType.COLLECTIBLE_ALMOND_MILK) then return 1 end
		return 0.2
	end,
	[CollectibleType.COLLECTIBLE_CROWN_OF_LIGHT] = function (player)
		if player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_CROWN_OF_LIGHT) then return 2 end
		return 1
	end,
	[CollectibleType.COLLECTIBLE_ALMOND_MILK] = 0.33,
	[CollectibleType.COLLECTIBLE_IMMACULATE_HEART] = 1.2,
	[CollectibleType.COLLECTIBLE_MEGA_MUSH] = function (player)
		if not player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_MEGA_MUSH) then return 1 end
		return 4
	  end,
}
--需要计算魅魔的攻击倍率

function funct.get_damage_multiplier(player)
	local total_multiplier = player_dmg_mul[player:GetPlayerType()] or 1
	if type(total_multiplier) == "function" then total_multiplier = total_multiplier(player) end
	
	local effects = player:GetEffects()

	for collectible, multiplier in pairs(item_dmg_mul) do
		if player:HasCollectible(collectible) or effects:HasCollectibleEffect(collectible) then
			if type(multiplier) == "function" then multiplier = multiplier(player) end
			total_multiplier = total_multiplier * multiplier
		end
	end

	return total_multiplier
end

local soul_player = {
  [PlayerType.PLAYER_ISAAC] = false,
  [PlayerType.PLAYER_MAGDALENA] = false,
  [PlayerType.PLAYER_CAIN] = false,
  [PlayerType.PLAYER_JUDAS] = false,
  [PlayerType.PLAYER_XXX] = true,
  [PlayerType.PLAYER_EVE] = false,
  [PlayerType.PLAYER_SAMSON] = false,
  [PlayerType.PLAYER_AZAZEL] = false,
  [PlayerType.PLAYER_LAZARUS] = false,
  [PlayerType.PLAYER_THELOST] = true,
  [PlayerType.PLAYER_LAZARUS2] = false,
  [PlayerType.PLAYER_BLACKJUDAS] = true,
  [PlayerType.PLAYER_LILITH] = false,
  [PlayerType.PLAYER_KEEPER] = false,
  [PlayerType.PLAYER_APOLLYON] = false,
  [PlayerType.PLAYER_THEFORGOTTEN] = false,
  [PlayerType.PLAYER_THESOUL] = true,
  [PlayerType.PLAYER_BETHANY] = false,
  [PlayerType.PLAYER_JACOB] = false,
  [PlayerType.PLAYER_ESAU] = false,

  -- Tainted characters
  [PlayerType.PLAYER_ISAAC_B] = false,
  [PlayerType.PLAYER_MAGDALENA_B] = false,
  [PlayerType.PLAYER_CAIN_B] = false,
  [PlayerType.PLAYER_JUDAS_B] = false,
  [PlayerType.PLAYER_XXX_B] = true,
  [PlayerType.PLAYER_EVE_B] = false,
  [PlayerType.PLAYER_SAMSON_B] = false,
  [PlayerType.PLAYER_AZAZEL_B] = false,
  [PlayerType.PLAYER_LAZARUS_B] = false,
  [PlayerType.PLAYER_EDEN_B] = false,
  [PlayerType.PLAYER_THELOST_B] = true,
  [PlayerType.PLAYER_LILITH_B] = false,
  [PlayerType.PLAYER_KEEPER_B] = false,
  [PlayerType.PLAYER_APOLLYON_B] = false,
  [PlayerType.PLAYER_THEFORGOTTEN_B] = true,
  [PlayerType.PLAYER_BETHANY_B] = true,
  [PlayerType.PLAYER_JACOB_B] = false,
  [PlayerType.PLAYER_LAZARUS2_B] = false,
}

function funct.is_soul_player(player)
	local tp = player:GetPlayerType()
	if soul_player[tp] ~= nil then
		return soul_player[tp]
	else
		return false
	end
end

local Copy_of_player_name = {
  [PlayerType.PLAYER_ISAAC] = "ISAAC",
  [PlayerType.PLAYER_MAGDALENA] = "MAGDALENE",
  [PlayerType.PLAYER_CAIN] = "CAIN",
  [PlayerType.PLAYER_JUDAS] = "JUDAS",
  [PlayerType.PLAYER_XXX] = "BLUEBABY",
  [PlayerType.PLAYER_EVE] = "EVE",
  [PlayerType.PLAYER_SAMSON] = "SAMSON",
  [PlayerType.PLAYER_AZAZEL] = "AZAZEL",
  [PlayerType.PLAYER_LAZARUS] = "LAZARUS",
  [PlayerType.PLAYER_EDEN] = "EDEN",
  [PlayerType.PLAYER_THELOST] = "THE_LOST",
  [PlayerType.PLAYER_LAZARUS2] = "LAZARUS2",
  [PlayerType.PLAYER_BLACKJUDAS] = "BLACK_JUDAS",
  [PlayerType.PLAYER_LILITH] = "LILITH",
  [PlayerType.PLAYER_KEEPER] = "KEEPER",
  [PlayerType.PLAYER_APOLLYON] = "APOLLYON",
  [PlayerType.PLAYER_THEFORGOTTEN] = "THE_FORGOTTEN",
  [PlayerType.PLAYER_THESOUL] = "THE_SOUL",
  [PlayerType.PLAYER_BETHANY] = "BETHANY",
  [PlayerType.PLAYER_JACOB] = "JACOB",
  [PlayerType.PLAYER_ESAU] = "ESAU",

  -- Tainted characters
  [PlayerType.PLAYER_ISAAC_B] = "ISAAC_B",
  [PlayerType.PLAYER_MAGDALENA_B] = "MAGDALENE_B",
  [PlayerType.PLAYER_CAIN_B] = "CAIN_B",
  [PlayerType.PLAYER_JUDAS_B] = "JUDAS_B",
  [PlayerType.PLAYER_XXX_B] = "BLUEBABY_B",
  [PlayerType.PLAYER_EVE_B] = "EVE_B",
  [PlayerType.PLAYER_SAMSON_B] = "SAMSON_B",
  [PlayerType.PLAYER_AZAZEL_B] = "AZAZEL_B",
  [PlayerType.PLAYER_LAZARUS_B] = "LAZARUS_B",
  [PlayerType.PLAYER_EDEN_B] = "EDEN_B",
  [PlayerType.PLAYER_THELOST_B] = "THE_LOST_B",
  [PlayerType.PLAYER_LILITH_B] = "LILITH_B",
  [PlayerType.PLAYER_KEEPER_B] = "KEEPER_B",
  [PlayerType.PLAYER_APOLLYON_B] = "APOLLYON_B",
  [PlayerType.PLAYER_THEFORGOTTEN_B] = "THE_FORGOTTEN_B",
  [PlayerType.PLAYER_BETHANY_B] = "BETHANY_B",
  [PlayerType.PLAYER_JACOB_B] = "JACOB_B",
  [PlayerType.PLAYER_LAZARUS2_B] = "LAZARUS_B",
}

function funct.get_birth_right_name(player)
	local tp = player:GetPlayerType()
	local ret = Copy_of_player_name[tp] or ""
	return ret
end

function funct.move_in_sq(pos,col,raw)
	local i = pos//col
	local j = pos - i*col
	local ret = {}
	if i > 0 then
		table.insert(ret,#ret+1,{id = (i-1)*col+j,dir = 3,})
	end
	if j > 0 then
		table.insert(ret,#ret+1,{id = i*col+j-1,dir = 2,})
	end
	if i < col - 1 then
		table.insert(ret,#ret+1,{id = (i+1)*col+j,dir = 1,})
	end
	if j < raw - 1 then
		table.insert(ret,#ret+1,{id = i*col+j+1,dir = 0,})
	end
	return ret
end

function funct.move_in_rou(pos,col,raw)
	local i = pos//col
	local j = pos - i*col
	local ret = {}
	if i > 0 then
		table.insert(ret,#ret+1,(i-1)*col+j)
		if j > 0 then
			table.insert(ret,#ret+1,(i-1)*col+j-1)
		end
		if j < raw - 1 then
			table.insert(ret,#ret+1,(i-1)*col+j+1)
		end
	end
	if j > 0 then
		table.insert(ret,#ret+1,i*col+j-1)
	end
	if j < raw - 1 then
		table.insert(ret,#ret+1,i*col+j+1)
	end
	if i < col - 1 then
		table.insert(ret,#ret+1,(i+1)*col+j)
		if j > 0 then
			table.insert(ret,#ret+1,(i+1)*col+j-1)
		end
		if j < raw - 1 then
			table.insert(ret,#ret+1,(i+1)*col+j+1)
		end
	end
	return ret
end

function funct.GetfamiliarDir(ent, dir, allow_king)
	if (allow_king == nil) then
        allow_king = true
    end 

    local player = ent.Player
    if (allow_king) then
        if (player:HasCollectible(CollectibleType.COLLECTIBLE_KING_BABY) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_KING_BABY) > 0) then
            local n_entity = Isaac.GetRoomEntities()
			local n_enemy = funct.getenemies(n_entity)
            if (#n_enemy > 0) then
                local dr = (n_enemy[1].Position - ent.Position):Normalized()
				local dis = (n_enemy[1].Position - ent.Position):Length()
				for i = 2,#n_enemy do
					if (n_enemy[i].Position - ent.Position):Length() < dis then
						dis = (n_enemy[i].Position - ent.Position):Length()
						dr = (n_enemy[i].Position - ent.Position):Normalized()
					end
				end
				ent:GetData().should_attack = true
                return dr
            end
			ent:GetData().should_attack = false
        end
    end
    if (dir ~= Direction.NO_DIRECTION) then
		if (dir == Direction.LEFT) then
			return Vector(-1,0)
		elseif (dir == Direction.UP) then
			return Vector(0,-1)
		elseif (dir == Direction.RIGHT) then
			return Vector(1,0)
		elseif (dir == Direction.DOWN) then
			return Vector(0,1)
		end
    end
    return Vector(0,0)
end

local dir_name = {
	[Direction.NO_DIRECTION] = "Down",
	[Direction.LEFT] = "Side",
	[Direction.UP] = "Up",
	[Direction.RIGHT] = "Side",
	[Direction.DOWN] = "Down"
}

function funct.GetDirName(dir)
	return dir_name[dir]
end

local Dir_name = {
	[Direction.NO_DIRECTION] = "Up",
	[Direction.LEFT] = "Left",
	[Direction.UP] = "Up",
	[Direction.RIGHT] = "Right",
	[Direction.DOWN] = "Down",
}

function funct.Get_dir_name(dir)
	return Dir_name[dir]
end

function funct.Get_direction_by_angle(angle)		--特殊的转法
    angle = angle % 360
    local dir = Direction.NO_DIRECTION
    if (math.abs(angle - 0) < 45 or math.abs(angle - 360) < 45) then
        dir = Direction.UP
    elseif (math.abs(angle - 270) < 45) then
        dir = Direction.LEFT
    elseif (math.abs(angle - 180) < 45) then
        dir = Direction.DOWN
    elseif (math.abs(angle - 90) < 45) then
        dir = Direction.RIGHT
    end
    return dir
end

local Dir_ang = {
	Left = 270,
	Up = 0,
	Right = 90,
	Down = 180,
}

function funct.Get_Angle_by_Degree_Name(dir)
	return Dir_ang[dir]
end

function funct.Direction_Plus(dir1,dir2)
	if type(dir1) == "string" then dir1 = funct.Get_Angle_by_Degree_Name(dir1) end 
	if type(dir2) == "string" then dir2 = funct.Get_Angle_by_Degree_Name(dir2) end 
	return funct.Get_dir_name(funct.Get_direction_by_angle(dir1 + dir2))
end

function funct.GetDirectionByAngle(angle)
    angle = angle % 360
    local dir = Direction.NO_DIRECTION
    if (math.abs(angle - 0) < 45 or math.abs(angle - 360) < 45) then
        dir = Direction.RIGHT
    elseif (math.abs(angle - 270) < 45) then
        dir = Direction.UP
    elseif (math.abs(angle - 180) < 45) then
        dir = Direction.LEFT
    elseif (math.abs(angle - 90) < 45) then
        dir = Direction.DOWN
    end
    return dir
end

local RoomType_to_IconIDs = {
	nil,
    "Shop",
    nil,
    "TreasureRoom",
    "Boss",
    "Miniboss",
    "SecretRoom",
    "SuperSecretRoom",
    "Arcade",
    "CurseRoom",
    "AmbushRoom",
    "Library",
    "SacrificeRoom",
    nil,
    "AngelRoom",
    nil,
    "BossAmbushRoom",
    "IsaacsRoom",
    "BarrenRoom",
    "ChestRoom",
    "DiceRoom",
    nil, -- black market
    nil,-- "GreedExit",
	"Planetarium",
	nil, -- Teleporter
	nil, -- Teleporter_Exit
	nil, -- doesnt exist
	nil, -- doesnt exist
	"UltraSecretRoom"
}

function funct.GetNameByRoomType(name)
	return RoomType_to_IconIDs[name]
end

function funct.IsAmbushBoss()		--其实忽略了紫色勋章饰品。不过应该没太大问题。
	local ls = Game():GetLevel():GetStage()
	if ls == LevelStage.STAGE1_2 then
		return true
	elseif ls == LevelStage.STAGE2_2 then
		return true
	elseif ls == LevelStage.STAGE3_2 then
		return true
	elseif ls == LevelStage.STAGE4_2 then
		return true
	else
		return false
	end
end

function funct.is_movable_enemy(ent,not_allow_boss)			--不可移动30、60、53、221、231、300、305、306、809、307、856、861、298		--特殊39.22、35.0、35.2、816、213、219、228、285、287		--水生311、825	--钻地244、58、59、56、255、276、829、881	--爬墙240	--会跳34、38、86、54、869、29、85、94、215、250	--值得实验882	--85号蜘蛛禁了
	if (ent.Type == 30) or (ent.Type == 85) or (ent.Type == 60) or (ent.Type == 39 and ent.Variant == 22) or (ent.Type == 35 and (ent.Variant == 0 or ent.Variant == 2)) or (ent.Type == 53) or (ent.Type == 231) or (ent.Type == 306) or (ent.Type == 298) or (ent.Type == 244) or (ent.Type == 816) or (ent.Type == 58) or (ent.Type == 59) or (ent.Type == 56) or (ent.Type == 213) or (ent.Type == 219) or (ent.Type == 240) or (ent.Type == 221) or (ent.Type == 228) or (ent.Type == 255) or (ent.Type == 276) or (ent.Type == 285) or (ent.Type == 287) or (ent.Type == 300) or (ent.Type == 805) or (ent.Type == 309) or (ent.Type == 307) or (ent.Type == 311) or (ent.Type == 825) or (ent.Type == 856) or (ent.Type == 861) or (ent.Type == 829) or (ent.Type == 881) or (ent.Type == 996) then
		return false
	end
	if not_allow_boss and not_allow_boss == true then		--不可移动36、45、78、84、101、262、266、263、270、274、275、273、906、911、914 --特殊407、412、403、411、406、903、912、951		--爬墙900 	--钻地62、269、401	 --会跳20、43、68、65、69、100、74-76、102、264、265、267、268、404、406
		if (ent.Type == 45) or (ent.Type == 62) or (ent.Type == 407) or (ent.Type == 406) or (ent.Type == 411) or (ent.Type == 403) or (ent.Type == 900) or (ent.Type == 412) or (ent.Type == 903) or (ent.Type == 906) or (ent.Type == 911) or (ent.Type == 912) or (ent.Type == 914) or (ent.Type == 951) or (ent.Type == 950) or (ent.Type == 78) or (ent.Type == 84) or (ent.Type == 101) or (ent.Type == 262) or (ent.Type == 269) or (ent.Type == 401) or (ent.Type == 273) or (ent.Type == 275) or (ent.Type == 274) or (ent.Type == 270) or (ent.Type == 263) or (ent.Type == 266) then
			return false
		end
	end
	return true
end

local ignoreFlags = DamageFlag.DAMAGE_DEVIL | DamageFlag.DAMAGE_IV_BAG | DamageFlag.DAMAGE_FAKE | DamageFlag.DAMAGE_CURSED_DOOR | DamageFlag.DAMAGE_NO_PENALTIES

function funct.is_damage_from_enemy(ent, amt, flag, source, cooldown)
	if amt > 0 and ((source and source.Type ~= EntityType.ENTITY_SLOT and source.Type ~= EntityType.ENTITY_PLAYER) or not source) and (flag & ignoreFlags) == 0	then
		return true
	else
		return false
	end
end

local FullRedHeartPlayers = {
    [PlayerType.PLAYER_KEEPER] = true,
    [PlayerType.PLAYER_BETHANY] = true,
    [PlayerType.PLAYER_KEEPER_B] = true,
}

local FullBoneHeartPlayers = {
    [PlayerType.PLAYER_THEFORGOTTEN] = true,
}

local KeeperPlayers = {
    [PlayerType.PLAYER_KEEPER] = true,
    [PlayerType.PLAYER_KEEPER_B] = true,
}

local LostPlayers = {
    [PlayerType.PLAYER_THELOST] = true,
    [PlayerType.PLAYER_THELOST_B] = true,
}

local FullCoinHeartPlayers = {
    [PlayerType.PLAYER_KEEPER] = true,
    [PlayerType.PLAYER_KEEPER_B] = true,
}

local FullSoulHeartPlayers = {
    [PlayerType.PLAYER_BETHANY_B] = true,
    [PlayerType.PLAYER_BLACKJUDAS] = true,		--其实黑犹大应该算黑心
    [PlayerType.PLAYER_BLUEBABY] = true,
    [PlayerType.PLAYER_BLUEBABY_B] = true,
    [PlayerType.PLAYER_THEFORGOTTEN_B] = true,
}

function funct.is_player_keeper(player)
	return KeeperPlayers[player:GetPlayerType()] ~= nil
end

function funct.is_player_lost(player)
	return LostPlayers[player:GetPlayerType()] ~= nil
end

function funct.is_player_only_bone_hearts(player)
	return FullBoneHeartPlayers[player:GetPlayerType()] ~= nil
end

function funct.is_player_only_coin_hearts(player)
	return FullCoinHeartPlayers[player:GetPlayerType()] ~= nil
end

function funct.is_player_only_red_hearts(player)
	return FullRedHeartPlayers[player:GetPlayerType()] ~= nil
end

function funct.is_player_only_soul_hearts(player)
	if FullSoulHeartPlayers[player:GetPlayerType()] ~= nil then
		return true 
	else
		if player:HasCollectible(enums.Items.Darkness) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Darkness) > 0 then
			return true
		end
	end
	return false
end

function funct.add_soul_heart(player,num)
	if (player:HasCollectible(CollectibleType.COLLECTIBLE_ALABASTER_BOX, true)) then		--草，这种可能性都考虑到了
        local alabasterCharges = {}
        for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   
            if (player:GetActiveItem(slot) == CollectibleType.COLLECTIBLE_ALABASTER_BOX) then
                alabasterCharges[slot] = player:GetActiveCharge (slot) + player:GetBatteryCharge (slot)
                if (num > 0) then
                    player:SetActiveCharge(12, slot)
                else
                    player:SetActiveCharge(0, slot)
                end
            end
        end
        player:AddSoulHearts(num)
        for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   
            if (player:GetActiveItem(slot) == CollectibleType.COLLECTIBLE_ALABASTER_BOX) then
                player:SetActiveCharge(alabasterCharges[slot], slot)
            end
        end
    else
        player:AddSoulHearts(num)
    end
end

local LostPlayers = {
    [PlayerType.PLAYER_THESOUL] = true,
    [PlayerType.PLAYER_THELOST] = true,
    [PlayerType.PLAYER_THELOST_B] = true,
    [PlayerType.PLAYER_THESOUL_B] = true,
}

function funct.get_death_animation_to_play(player)
	local tp = player:GetPlayerType()
	if LostPlayers[tp] ~= nil then
		return "LostDeath"
	end
    if (player:GetEffects():HasNullEffect(NullItemID.ID_LOST_CURSE)) then
        return "LostDeath";
    end
	return "Death"
end

function funct.have_player(pt)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:GetPlayerType() == pt then
			return true
		end
	end
	return false
end

function funct.have_player_has_collectible(col)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(col) then
			return true
		end
	end
	return false
end

local DifficultPlayers = {
    [PlayerType.PLAYER_KEEPER] = true,
    [PlayerType.PLAYER_KEEPER_B] = true,
    [PlayerType.PLAYER_THELOST] = true,
    [PlayerType.PLAYER_THELOST_B] = true,
}

function funct.is_player_lost(player)
	if player:GetPlayerType() == PlayerType.PLAYER_THELOST or player:GetPlayerType() == PlayerType.PLAYER_THELOST_B then return true end
	local effect = player:GetEffects()
	if (effect:HasNullEffect(NullItemID.ID_LOST_CURSE)) then
		return true
	end
end

function funct.is_player_has_mantle(player)
	return player:GetEffects():HasCollectibleEffect(CollectibleType.COLLECTIBLE_HOLY_MANTLE)
end

function funct.is_player_difficult(player)
	return DifficultPlayers[player:GetPlayerType()] ~= nil
end

function funct.to_find_spawner(ent)
	local ret = ent
	if ent:GetData() and ent:GetData().to_find_spawner_marked == nil then
		ent:GetData().to_find_spawner_marked = true				--防止无限loop
		if ent:GetData().to_find_spawner_minder then
			ret = ent:GetData().to_find_spawner_minder
		else
			if ent.SpawnerEntity then
				ret = funct.to_find_spawner(ent.SpawnerEntity)
			end
		end
		ent:GetData().to_find_spawner_minder = ret
		ent:GetData().to_find_spawner_marked = nil
	end
	return ret
end

function funct.is_poop_player(player)
	return player:GetPlayerType() == 25
end

function funct.has_poop_player()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if funct.is_poop_player(player) then
			return true
		end
	end
	return false
end

function funct.has_difficult_player()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if funct.is_player_difficult(player) then
			return true
		end
	end
	return false
end

function funct.randomTable(_table, rng) 
	if rng then rng = funct.rng_for_sake(rng) end
	if type(_table)~= "table" then
        return {}
    end
	local tab = {}
    for i = 1,#_table do
		local id
		if rng then 
			id = (rng:RandomInt(#_table) + 1)
		else 
			id = math.random(#_table) 
		end
		tab[i] = _table[id]
		table.remove(_table,id)
	end
	return tab
end

function funct.is_double_player()		--似乎只有双子才会导致特殊的ui。
	local check_1 = false
	local check_2 = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local pt = player:GetPlayerType()
		if pt == PlayerType.PLAYER_JACOB then
			check_1 = true
		elseif pt == PlayerType.PLAYER_ESAU then
			check_2 = true
		end
	end
	return (check_1 and check_2)
end

function funct.check_empty_table(tbl)
	if type(tbl) ~= "table" then return false end
	if (#tbl == 0) then return true end	
	return false
end

function funct.remove_others_option_pickup(ent,should_effect)
	if should_effect == nil then should_effect = true end
	ent:GetData().OptionsPickupIndex_should_remove = true
	local n_entity = Isaac.GetRoomEntities()
	for u,v in pairs(n_entity) do
		if v.Type == 5 then
			local pickup = v:ToPickup()
			if pickup and pickup.OptionsPickupIndex == ent.OptionsPickupIndex and pickup:GetData().OptionsPickupIndex_should_remove ~= true then
				if should_effect then
					Isaac.Spawn(1000,15,0,pickup.Position,Vector(0,0),nil)
				end
				pickup:Remove()
			end
		end
	end
end

local questionMarkSprite = Sprite()
questionMarkSprite:Load("gfx/005.100_collectible.anm2", true)
questionMarkSprite:ReplaceSpritesheet(1, "gfx/items/collectibles/questionmark.png")
questionMarkSprite:LoadGraphics()

function funct.IsAltChoice(pickup)
	if pickup:GetData() == nil then
		return false
	end
	
	if EID and EID:getEntityData(pickup, "EID_IsAltChoice") ~= nil then
		return EID:getEntityData(pickup, "EID_IsAltChoice")
	end

	if not REPENTANCE or g.game:GetLevel():GetStageType() < 4 or g.game:GetRoom():GetType() ~= RoomType.ROOM_TREASURE then
		pickup:GetData()["EID_IsAltChoice"] = false
		return false
	end

	local entitySprite = pickup:GetSprite()
	local name = entitySprite:GetAnimation()

	if name ~= "Idle" and name ~= "ShopIdle" then
		-- Collectible can be ignored. its definetly not hidden
		pickup:GetData()["EID_IsAltChoice"] = false
		return false
	end
	
	questionMarkSprite:SetFrame(name, entitySprite:GetFrame())
	-- check some point in entitySprite
	for i = -70, 0, 2 do
		local qcolor = questionMarkSprite:GetTexel(Vector(0, i), g.ZeroV, 1, 1)
		local ecolor = entitySprite:GetTexel(Vector(0, i), g.ZeroV, 1, 1)
		if qcolor.Red ~= ecolor.Red or qcolor.Green ~= ecolor.Green or qcolor.Blue ~= ecolor.Blue then
			-- it is not same with question mark sprite
			pickup:GetData()["EID_IsAltChoice"] = false
			return false
		end
	end
	--this may be a question mark, however, we will check it again to ensure it
	for j = -3, 3, 2 do
		for i = -71, 0, 2 do
			local qcolor = questionMarkSprite:GetTexel(Vector(j, i), g.ZeroV, 1, 1)
			local ecolor = entitySprite:GetTexel(Vector(j, i), g.ZeroV, 1, 1)
			if qcolor.Red ~= ecolor.Red or qcolor.Green ~= ecolor.Green or qcolor.Blue ~= ecolor.Blue then
				pickup:GetData()["EID_IsAltChoice"] = false
				return false
			end
		end
	end
	pickup:GetData()["EID_IsAltChoice"] = true
	return true
end

function funct.isBlindPickup(pickup)
	return (g.game:GetLevel():GetCurses() & LevelCurse.CURSE_OF_BLIND ~= 0 and not pickup.Touched) or (not pickup.Touched and funct.IsAltChoice(pickup)) or (g.game.Challenge == Challenge.CHALLENGE_APRILS_FOOL)
end

function funct.GetScreenSize()
	local game = Game()
	local room = game:GetRoom()
	local pos = room:WorldToScreenPosition(Vector(0,0)) - room:GetRenderScrollOffset() - game.ScreenShakeOffset
	local rx = pos.X + 60 * 26 / 40
	local ry = pos.Y + 140 * (26 / 40)
	return Vector(rx*2 + 13*26, ry*2 + 7*26)
end

function funct.GetScreenCenter()
	return funct.GetScreenSize() / 2
end

local itemlist = nil
function funct.GetItemList()
	if itemlist == nil then
		itemlist = {}
		local config = Isaac:GetItemConfig()
		local collectibles = config:GetCollectibles()
		local size = collectibles.Size
		for i= 1, size do
			local collectible = config:GetCollectible(i)
			if collectible then
				table.insert(itemlist,#itemlist + 1,i)
			end
		end
	end
	return itemlist
end

function funct.get_heart_info(player)
	local ret = {}
	local mx_heart = player:GetMaxHearts()
	ret["mx_heart"] = mx_heart
	local gd_heart = player:GetGoldenHearts()
	ret["gd_heart"] = gd_heart
	local rt_heart = player:GetRottenHearts()
	ret["rt_heart"] = rt_heart
	local et_heart = player:GetEternalHearts()
	ret["et_heart"] = et_heart
	local bl_heart = funct.Count_Flags(player:GetBlackHearts())
	ret["bl_heart"] = bl_heart
	local rd_heart = player:GetHearts()
	ret["rd_heart"] = rd_heart
	local sl_heart = player:GetSoulHearts()
	ret["sl_heart"] = sl_heart
	local lim_heart = player:GetHeartLimit()
	ret["lim_heart"] = lim_heart
	local bone_heart = player:GetBoneHearts()
	ret["bone_heart"] = bone_heart
	return ret
end

function funct.get_basic_counter(player)
	local ret = {}
	local bomb_counter = player:GetNumBombs()
	table.insert(ret,#ret + 1,{counter = bomb_counter,name = "bomb",})
	local gbomb = 0
	if player:HasGoldenBomb() then gbomb = 1 end
	table.insert(ret,#ret + 1,{counter = gbomb,name = "gbomb",})
	local key_counter = player:GetNumKeys()
	table.insert(ret,#ret + 1,{counter = key_counter,name = "key",})
	local gkey = 0
	if player:HasGoldenKey() then gkey = 1 end
	table.insert(ret,#ret + 1,{counter = gkey,name = "gkey",})
	local coin_counter = player:GetNumCoins()
	table.insert(ret,#ret + 1,{counter = coin_counter,name = "coin",})
	local mx_heart = player:GetMaxHearts()
	table.insert(ret,#ret + 1,{counter = mx_heart,name = "mx_heart",})
	local gd_heart = player:GetGoldenHearts()
	table.insert(ret,#ret + 1,{counter = gd_heart,name = "gd_heart",})
	local rt_heart = player:GetRottenHearts()
	table.insert(ret,#ret + 1,{counter = rt_heart,name = "rt_heart",})
	local et_heart = player:GetEternalHearts()
	table.insert(ret,#ret + 1,{counter = et_heart,name = "et_heart",})
	local bl_heart = funct.Count_Flags(player:GetBlackHearts())
	table.insert(ret,#ret + 1,{counter = bl_heart,name = "bl_heart",})
	local rd_heart = player:GetHearts()
	if funct.is_player_keeper(player) then rd_heart = math.ceil(rd_heart * 0.5) end
	table.insert(ret,#ret + 1,{counter = rd_heart,name = "rd_heart",})
	local sl_heart = player:GetSoulHearts()
	table.insert(ret,#ret + 1,{counter = sl_heart,name = "sl_heart",})
	local lim_heart = player:GetHeartLimit()
	table.insert(ret,#ret + 1,{counter = lim_heart,name = "lim_heart",})
	local bone_heart = player:GetBoneHearts()
	table.insert(ret,#ret + 1,{counter = bone_heart,name = "bn_heart",})
	return ret
end

function funct.get_absolute_heart(player)
	local ret = player:GetBoneHearts() + player:GetSoulHearts() + player:GetEternalHearts() + player:GetHearts()
	if funct.is_player_difficult(player) then ret = ret / 2 end
	return ret
end

function funct.GetOffsetedGridIndex(index, offset)
	local room = Game():GetRoom()
    local roomWidth = room:GetGridWidth()
    local roomHeight = room:GetGridHeight()
    local roomSize = room:GetGridSize()
	local xoff = 0
	local yoff = 0
	if (offset == Direction.LEFT) then
		xoff = -1
	elseif (offset == Direction.UP) then
		yoff = -1
	elseif (offset == Direction.RIGHT) then
		xoff = 1
	elseif (offset == Direction.DOWN) then
		yoff = 1
	end
	local indexX = index % roomWidth
	local indexY = math.floor(index / roomWidth)
	if (indexX + xoff >= 0 and indexX + xoff < roomWidth and indexY + yoff >= 0 and indexY + yoff < roomHeight) then
		return index + yoff * roomWidth + xoff
	end
	return -1
end

function funct.reverse_the_dir(dir)
	if dir and dir >= 0 and dir < 4 then
		return (dir + 2)% 4
	end
	return -1
end

function funct.CanPassGrid(index,flying) 
	local room = Game():GetRoom()
	local grid = room:GetGridEntity(index)
	if (grid == nil) then
		return true
	end
	if (flying) then
		return grid.CollisionClass ~= GridCollisionClass.COLLISION_WALL
	else
		return grid.CollisionClass ~= GridCollisionClass.COLLISION_PIT and grid.CollisionClass ~= GridCollisionClass.COLLISION_WALL and not (grid:GetType() == 3 and grid:GetVariant() == 10)
	end
end

local reversed_map = {
	[enums.Cards.Adjustment] = enums.Cards.Adjustment_r,
	[enums.Cards.Lure] = enums.Cards.Lure_r,
	[enums.Cards.Art] = enums.Cards.Art_r,
	[enums.Cards.Aeon] = enums.Cards.Aeon_r,
	[enums.Cards.Universe] = enums.Cards.Universe_r,
	[enums.Cards.Adjustment_r] = enums.Cards.Adjustment,
	[enums.Cards.Lure_r] = enums.Cards.Lure,
	[enums.Cards.Art_r] = enums.Cards.Art,
	[enums.Cards.Aeon_r] = enums.Cards.Aeon,
	[enums.Cards.Universe_r] = enums.Cards.Universe,
}

function funct.get_reversed_card(card)
	if card > 0 and card < 23 then
		return card + 55
	elseif card > 55 and card < 78 then
		return card - 55
	elseif reversed_map[card] then
		return reversed_map[card]
	end
	return 0
end

function funct.check_bottom_down(bt,ctrlid)
	return Input.IsButtonTriggered(bt,ctrlid) or Input.IsButtonPressed(bt,ctrlid)
end

function funct.get_repel_params(ent)
	return 1/math.max(0.9,math.log(ent.Mass)/math.log(5) * 0.5 + 0.5)
end

function funct.get_string_real_length(str)
	local i = 1
	local ret = 0
	while(i <= #str) do
		local c = string.sub(str,i,i)
		local b = string.byte(c)
		if b > 128 then
			i = i + 3
		else
			i = i + 1
		end
		ret = ret + 1
	end
	return ret
end

local languagemap = {
	["en"] = "English",
	["jp"] = "Japanese",
	["kr"] = "Korean",
	["zh"] = "Chinese",
	["ru"] = "Russian",
	["de"] = "German",
	["es"] = "Spanish",
}

function funct.get_language_map(str)
	return languagemap[str]
end

function funct.check_name_data(name)
	local language = funct.get_language_map(Options.Language)
	if language and displaying_data[language] then
		return displaying_data[language][name] or name
	else
		return name
	end
end

function funct.spilt_string(str)
	local tbl = {}
	local i = 1
	while(i <= #str) do
		local c = string.sub(str,i,i)
		local b = string.byte(c)
		if b > 128 then
			c = string.sub(str,i,i+2)
			i = i + 3
		else
			i = i + 1
		end
		table.insert(tbl,c)
	end
	return tbl
end

function funct.get_string_display_length(str)
	local ret = 0
	local i = 1
	while(i <= #str) do
		local c = string.sub(str,i,i)
		local b = string.byte(c)
		if b > 128 then
			c = string.sub(str,i,i+2)
			i = i + 3
			ret = ret + 4.5
		else
			i = i + 1
			ret = ret + 1.8
		end
	end
	return ret
end

function funct.random_shuffle_string(str,rng)
	rng = funct.rng_for_sake(rng)
	local ret = funct.randomTable(funct.spilt_string(str),rng)
	return ret
end

function funct.get_mul_string(wd,mul)
	local ret = ""
	mul = mul or 10
	for i = 1,mul do
		ret = ret .. wd
	end
	return ret
end

function funct.collect_table_to_string(tbl,p1,p2,step)
	if tbl == nil then tbl = {} end
	if step == nil then step = 1 end
	if p2 == nil then p2 = #tbl end
	if p1 == nil then p1 = 1 end
	if step == 0 then step = 1 end
	if step < 0 then step = -step end
	if p1 > p2 then 
		local tmp = p1
		p1 = p2
		p2 = tmp
	end
	local ret = ""
	for i = p1,p2,step do
		if type(tbl[i]) == "string" then
			ret = ret..tbl[i]
		end
	end
	return ret
end

function funct.cut_string_by_mark(str)
	local i = 1
	local ipos = 0
	local ret = {}
	local cutid = {}
	while i < #str do
		i = string.find(str,"|",i)
		if i == nil then break end
		table.insert(ret,string.sub(str,ipos + 1,i - 1))
		table.insert(cutid,i)
		ipos = i
		i = i + 1
	end
	if ipos ~= #str then table.insert(ret,string.sub(str,ipos + 1,#str)) end
	return ret,cutid
end

function funct.reverse_table(tbl)
	if type(tbl) ~= "table" then return tbl end
	local ret = {}
	for i = 1,#tbl do
		table.insert(ret,tbl[#tbl + 1 - i])
	end
	return ret
end

function funct.reverse_string(str)
	return funct.collect_table_to_string(funct.reverse_table(funct.spilt_string(str)))
end

function funct.cut_string_by_id(str,cutid)
	local ipos = 0
	local ret = {}
	for i = 1,#cutid do
		table.insert(ret,string.sub(str,ipos + 1,cutid[i] - i))
		ipos = cutid[i] - i
	end
	if ipos + 1 ~= #str then table.insert(ret,string.sub(str,ipos + 1,#str)) end
	return ret
end

function funct.random_work_on_the_raw_string(data,rng)
	rng = funct.rng_for_sake(rng)
	local res,cid = funct.cut_string_by_mark(data)
	return funct.cut_string_by_id(funct.collect_table_to_string(funct.random_shuffle_string(funct.collect_table_to_string(res),rng)),cid)
end

function funct.KColor_2_Color(kcol)
	return Color(kcol.R,kcol.G,kcol.B,kcol.A,kcol.RO,kcol.GO,kcol.BO)
end

function funct.Color_2_KColor(col)
	return KColor(col.R,col.G,col.B,col.A,col.RO,col.GO,col.BO)
end

function funct.get_word_render_offset(word)
	local b = string.byte(word)
	if b > 128 then
		return Vector(-4,-8)
	else
		return Vector(-2,-8)
	end
end

function funct.get_word_damage(word)
	local b = string.byte(word)
	if b > 128 then
		return 2.5
	else
		return 1.5
	end
end

function funct.get_level_stat_of_spwq()
	local ls = Game():GetLevel():GetStage()
	return 2 / math.sqrt(ls + 3) 
end

function funct.PrintColor(col)
	print(col.R.." "..col.G.." "..col.B.." "..col.A.." "..col.RO.." "..col.GO.." "..col.BO)
end

function funct.GetChampPosition(pos,margin)
	return Vector(math.floor(pos.X/margin + 0.5) * margin,math.floor(pos.Y/margin + 0.5) * margin)
end

function funct.my_morph(ent,tp,var,sbt,keepprice,keepseed,ignoremodifier)
	ent:ToPickup():Morph(tp,var,sbt,keepprice,keepseed,ignoremodifier)
end

function funct.special_morph(ent,item,keepprice,keepseed,ignoremodifier)
	--print("morph")
	if keepprice == nil then keepprice = true end
	if keepseed == nil then keepseed = true end
	if ignoremodifier == nil then ignoremodifier = true end
	ent:ToPickup():Morph(5,item.Variant,item.SubType,true,true,true)
	if item.special_to_turn then 
		local should_hold,holdname = item.special_to_turn(ent,true)
		if should_hold then
			if consistance_holder == nil then consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder") end		--权宜之计
			consistance_holder.try_hold_entity(ent,holdname,{keep_level = true,})
		end
		if item.load_EID and EID then
			item.load_EID(ent)
		end
	end
	--print("end morph")
end

function funct.special_turn(ent,item,inout)
	if item.special_to_turn then 
		local should_hold,holdname = item.special_to_turn(ent,inout)
		if should_hold then
			if consistance_holder == nil then consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder") end		--权宜之计
			consistance_holder.try_hold_entity(ent,holdname,{keep_level = true,})
		end
		if item.load_EID and EID then
			item.load_EID(ent)
		end
	end
end

function funct.setCanShoot(player, canshoot)
    local oldchallenge = Game().Challenge
    Game().Challenge = canshoot and 0 or 6
    player:UpdateCanShoot()
    Game().Challenge = oldchallenge
end

function funct.checkrounded(v1,v2,t1,t2,r)
	if math.abs(v1 + r - v2) < math.abs(v1 - v2) then v1 = v1 + r end
	if math.abs(v1 - r - v2) < math.abs(v1 - v2) then v1 = v1 - r end
	return v1 * t1 + v2 * t2
end

function funct.check_for_the_same(v1,v2)
	local ret = false
	if v1 and v2 then
		local d1 = v1:GetData()
		local d2 = v2:GetData()
		if d1 and d2 then
			d1.check_for_the_same = true
			if d2.check_for_the_same then ret = true end
			d1.check_for_the_same = nil
		end
	end
	return ret
end

function funct.spawn_item_dust(player,pos,colid,color1,color2,ignore_question_mark)
	ignore_question_mark = ignore_question_mark or false
	player = player or Game():GetPlayer(0)
	pos = pos or player.Position
	colid = colid or 33
	color1 = color1 or Color(1,1,1,1)
	color2 = color2 or Color(0.2,0.2,0.2,0.3,-0.8,-0.8,-0.8)
	local coll = Isaac.GetItemConfig():GetCollectible(colid)
	if coll then
		local q = Isaac.Spawn(1000,EffectVariant.CRACK_THE_SKY,0,pos,Vector(0,0),player)
		local q2 = Isaac.Spawn(1000,11,0,pos,Vector(0,0),player)
		local s = q:GetSprite()
		s.Color = color1
		local s2 = q2:GetSprite()
		s2:Load("gfx/dropping_collectible.anm2",true)
		s2:Play("Idle",true)
		if Game():GetLevel():GetCurses() & LevelCurse.CURSE_OF_BLIND == LevelCurse.CURSE_OF_BLIND and not ignore_question_mark then
			s2:ReplaceSpritesheet(0,"gfx/items/collectibles/questionmark.png")
		else
			s2:ReplaceSpritesheet(0,coll.GfxFileName)
		end
		s2:LoadGraphics()
		q2:AddEntityFlags(EntityFlag.FLAG_RENDER_FLOOR)
		s2.Color = color2
		return q
	end
end

function funct.get_random_item_that_player_has(player,rng,ignore_quest)
	ignore_quest = ignore_quest or false
	if rng then rng = funct.rng_for_sake(rng) end
	local pool = {}
	local wei = 0
	local itemConfig = Isaac.GetItemConfig()
	local sz = itemConfig:GetCollectibles().Size
	if player then
		for id = 1,sz do
			local collectible = itemConfig:GetCollectible(id)
			if (collectible and player:HasCollectible(id)) and (ignore_quest or collectible.Tags & ItemConfig.TAG_QUEST ~= ItemConfig.TAG_QUEST) then
				if player:GetCollectibleNum(id,true) > 0 then
					table.insert(pool,{id = id,weigh = player:GetCollectibleNum(id,true)})
					wei = wei + player:GetCollectibleNum(id,true)
				end
			end
		end
	else
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			for id = 1,sz do
				local collectible = itemConfig:GetCollectible(id)
				if (collectible and player:HasCollectible(id)) and (ignore_quest or collectible.Tags & ItemConfig.TAG_QUEST ~= ItemConfig.TAG_QUEST) then
					if player:GetCollectibleNum(id,true) > 0 then
						table.insert(pool,{id = id,weigh = player:GetCollectibleNum(id,true)})
						wei = wei + player:GetCollectibleNum(id,true)
					end
				end
			end
		end
	end
	local target = -1
	if #pool > 0 then
		wei = rng:RandomInt(wei) + 1
		for i = 1,#pool do
			wei = wei - pool[i].weigh
			if wei <= 0 then
				target = pool[i].id
				break
			end
		end
	end
	return target
end

function funct.check_should_count(colid,player)
	local ret = false
	if player then ret = player:HasCollectible(colid) or player:GetEffects():GetCollectibleEffectNum(colid) > 0
	else 
		for playerNum = 1, Game():GetNumPlayers() do
			local t_player = Game():GetPlayer(playerNum - 1)
			if t_player:HasCollectible(colid) or t_player:GetEffects():GetCollectibleEffectNum(colid) > 0 then
				ret = true
				player = t_player
				break
			end
		end
	end
	return ret,player
end

function funct.random_in_table(tbl)
	if type(tbl) ~= "table" then return tbl end
	if #tbl == 0 then return nil end
	local rnd = math.random(#tbl)
	return tbl[rnd]
end

local pill_effect_list = {
	[PillEffect.PILLEFFECT_BAD_GAS] = 0,
	[PillEffect.PILLEFFECT_BAD_TRIP] = -1,
	[PillEffect.PILLEFFECT_BALLS_OF_STEEL] = 1,
	[PillEffect.PILLEFFECT_BOMBS_ARE_KEYS] = 0,
	[PillEffect.PILLEFFECT_EXPLOSIVE_DIARRHEA] = 0,
	[PillEffect.PILLEFFECT_FULL_HEALTH] = 1,
	[PillEffect.PILLEFFECT_HEALTH_DOWN] = -1,
	[PillEffect.PILLEFFECT_HEALTH_UP] = 1,
	[PillEffect.PILLEFFECT_I_FOUND_PILLS] = 0,
	[PillEffect.PILLEFFECT_PUBERTY] = 0,
	[PillEffect.PILLEFFECT_PRETTY_FLY] = 2,
	[PillEffect.PILLEFFECT_RANGE_DOWN] = -1,
	[PillEffect.PILLEFFECT_RANGE_UP] = 3,
	[PillEffect.PILLEFFECT_SPEED_DOWN] = -1,
	[PillEffect.PILLEFFECT_SPEED_UP] = 3,
	[PillEffect.PILLEFFECT_TEARS_DOWN] = -1,
	[PillEffect.PILLEFFECT_TEARS_UP] = 3,
	[PillEffect.PILLEFFECT_LUCK_DOWN] = -1,
	[PillEffect.PILLEFFECT_LUCK_UP] = 3,
	[PillEffect.PILLEFFECT_TELEPILLS] = 0,
	[PillEffect.PILLEFFECT_48HOUR_ENERGY] = 4,
	[PillEffect.PILLEFFECT_HEMATEMESIS] = 1,
	[PillEffect.PILLEFFECT_PARALYSIS] = -1,
	[PillEffect.PILLEFFECT_SEE_FOREVER] = 2,
	[PillEffect.PILLEFFECT_PHEROMONES] = 5,
	[PillEffect.PILLEFFECT_AMNESIA] = -1,
	[PillEffect.PILLEFFECT_LEMON_PARTY] = 5,
	[PillEffect.PILLEFFECT_WIZARD] = -1,
	[PillEffect.PILLEFFECT_PERCS] = 2,
	[PillEffect.PILLEFFECT_ADDICTED] = -1,
	[PillEffect.PILLEFFECT_RELAX] = 0,
	[PillEffect.PILLEFFECT_QUESTIONMARK] = 0,
	[PillEffect.PILLEFFECT_LARGER] = 0,
	[PillEffect.PILLEFFECT_SMALLER] = 0,
	[PillEffect.PILLEFFECT_INFESTED_EXCLAMATION] = 5,
	[PillEffect.PILLEFFECT_INFESTED_QUESTION] = 5,
	[PillEffect.PILLEFFECT_POWER] = 5,
	[PillEffect.PILLEFFECT_RETRO_VISION] = -1,
	[PillEffect.PILLEFFECT_FRIENDS_TILL_THE_END] = 5,
	[PillEffect.PILLEFFECT_X_LAX] = 0,
	[PillEffect.PILLEFFECT_SOMETHINGS_WRONG] = 0,
	[PillEffect.PILLEFFECT_IM_DROWSY] = 0,
	[PillEffect.PILLEFFECT_IM_EXCITED] = 0,
	[PillEffect.PILLEFFECT_GULP] = 2,
	[PillEffect.PILLEFFECT_HORF] = 5,
	[PillEffect.PILLEFFECT_SUNSHINE] = 5,
	[PillEffect.PILLEFFECT_VURP] = 2,
	[PillEffect.PILLEFFECT_SHOT_SPEED_DOWN] = 0,
	[PillEffect.PILLEFFECT_SHOT_SPEED_UP] = 0,
	[PillEffect.PILLEFFECT_EXPERIMENTAL] = 0,
}

function funct.is_bad_pill(pill)
	return pill_effect_list[pill or 0] < 0
end

function funct.get_stats_counter(player)
	local ret = 0
	ret = ret + player.Damage * 30 / (player.MaxFireDelay + 1) + player.TearRange / 40 + math.max(0,player.ShotSpeed - 2) * 20 + player.Luck * 3.5 + player:GetCollectibleCount() * 5
	return ret
end

function funct.check_spawner_player(ent)
	local ret = ent.SpawnerEntity
	if ret then
		if ret.Type == 3 and ret:ToFamiliar() and ret:ToFamiliar().Player then ret = ret:ToFamiliar().Player end
		if ret.Type == 1 and ret:ToPlayer() then ret = ret:ToPlayer() end
	end
	return ret
end

local check_info_found_soul = {
	["lim_heart"] = -1,
	["sl_heart"] = -1,
}

function funct.is_found_soul(ent)
	if ent == nil or ent:ToPlayer() == nil then return false end
	ent = ent:ToPlayer()
	local ret = true
	local s = ent:GetSprite()
	if s:GetFilename() ~= "gfx/001.001_Player2.anm2" then return false end		--不知道为什么是大写的
	local info = funct.get_heart_info(ent)
	for u,v in pairs(info) do
		if (check_info_found_soul[u] or 0) ~= -1 and (check_info_found_soul[u] or 0) ~= v then		--似乎还是会误认某些2P宝
			return false
		end
	end
	if info.sl_heart >= 2 then return false end
	return ret
end

function funct.should_spawn_wisp(player,flags)
	 return player:HasCollectible(CollectibleType.COLLECTIBLE_BOOK_OF_VIRTUES) and (flags == nil or (flags & UseFlag.USE_NOANIM <= 0 or flags & UseFlag.USE_ALLOWWISPSPAWN > 0))
end

function funct.get_wisps(t_player,subtype)
	if player == nil then
		local n_entity = Isaac.GetRoomEntities()
		local n_wisps = funct.getothers(n_entity,3,FamiliarVariant.WISP,subtype)
		return n_wisps
	else
		local n_entity = Isaac.GetRoomEntities()
		local n_wisps = funct.getothers(n_entity,3,FamiliarVariant.WISP,subtype,function(ent)
			if ent:ToFamiliar() then
				local player = ent:ToFamiliar().player
				if player and ent:ToFamiliar().player and funct.check_for_the_same(player,t_player) then
					return true
				end
			end
			return false
			end)
		return n_wisps
	end
end

function funct.get_acceptible_level()
	local stage = Game():GetLevel():GetStage()
	if (Game():GetLevel():GetCurses() & LevelCurse.CURSE_OF_LABYRINTH == LevelCurse.CURSE_OF_LABYRINTH) then
		stage = stage + 1
	end
	return stage
end

function funct.copy_sprite(s,s2)
	s2 = s2 or Sprite()
	if s2:GetFilename() ~= s:GetFilename() then s2:Load(s:GetFilename(),true) end
	s2:SetFrame(s:GetAnimation(),s:GetFrame())
	s2:SetOverlayFrame(s:GetOverlayAnimation(),s:GetOverlayFrame())
	--for i = 0,15 do
	--	s2:ReplaceSpritesheet(i,)
	--end
	s2.Color = Color(s.Color.R,s.Color.G,s.Color.B,s.Color.A,s.Color.RO,s.Color.GO,s.Color.BO)
	s2.Scale = s.Scale
	s2.FlipX = s.FlipX
	s2.FlipY = s.FlipY
	s2.Offset = s.Offset
	s2.PlaybackSpeed = s.PlaybackSpeed
	s2.Rotation = s.Rotation
	return s2
end

function funct.get_near_grid_info(pos,dir)
	local ret = {}
	dir = dir or 120
	if dir < 0 then dir = - dir end
	if pos ~= nil then
		dir = math.ceil(dir/40)
		local room = Game():GetRoom()
		local orig_idx = room:GetGridIndex(pos)
		local orig_pos = room:GetGridPosition(orig_idx)
		local dx = 1
		local dy = room:GetGridIndex(orig_pos + Vector(0,40)) - orig_idx
		local lr = orig_idx - dx * dir - dy * dir
		for i = 1,dir * 2 do
			for j = 1,dir * 2 do
				local grididx = lr + dx * (i - 1) + dy * (j - 1)
				if grididx >= 0 then
					local grid = room:GetGridEntity(grididx)
					if grid then
						table.insert(ret,{grid = grid,idx = grididx,})
					end
				end
			end
		end
	end
	return ret
end

function funct.check_slot_with_item(player,colid,dont_check_charge)
	player = player or Game():GetPlayer(0)
	local col = Isaac:GetItemConfig():GetCollectible(colid)
	if col == nil then return -1 end
	charge = col.MaxCharges
	for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do 
		 if (player:GetActiveItem(slot) == colid) then
			if dont_check_charge or player:GetActiveCharge(slot) >= charge then
				return slot
			end
		end
	end
	return -1
end

function funct.check_player(ent)
	if ent:ToPlayer() then return ent:ToPlayer() end
	if ent:ToFamiliar() then
		ent = ent:ToFamiliar()
		if ent.Player then return ent.Player end
	end
	
end

return funct