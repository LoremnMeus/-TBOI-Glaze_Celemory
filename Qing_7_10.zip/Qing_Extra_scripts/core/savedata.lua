local json = require("json")
local g = require("Qing_Extra_scripts.core.globals")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local Achievement_Display_holder = require("Qing_Extra_scripts.others.Achievement_Display_holder")
local players = enums.Players
local costumes = enums.Costumes

local SaveData = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
}
local modReference

local SAVE_STATE = {}
local Continue = false
SaveData.PERSISTENT_PLAYER_DATA = {}
SAVE_STATE.ELSES = {}
SaveData.elses = {}
lst = {}
local should_load = nil
rw = false
SaveData.UnlockData = {		--需要解锁的内容都存储在这里。
	wq = {},
	Spwq = {},
	Glaze = {},
	Others = {},
}

local UnlocksTemplate = {			--角色成就
	MomsHeart = {Unlock = false, Hard = false},
	Isaac = {Unlock = false, Hard = false},
	Satan = {Unlock = false, Hard = false},
	BlueBaby = {Unlock = false, Hard = false},
	Lamb = {Unlock = false, Hard = false},
	BossRush = {Unlock = false, Hard = false},
	Hush = {Unlock = false, Hard = false},
	MegaSatan = {Unlock = false, Hard = false},
	Delirium = {Unlock = false, Hard = false},
	Mother = {Unlock = false, Hard = false},
	Beast = {Unlock = false, Hard = false},
	GreedMode = {Unlock = false, Hard = false},
	FullCompletion = {Unlock = false, Hard = false},
}

function SaveData.CreateUnlocksTemplate()
	local UnlockTab = {}
	for i, v in pairs(UnlocksTemplate) do
		UnlockTab[i] = {Unlock = false, Hard = false}
	end
	return UnlockTab
end

function SaveData.CreateDoneTemplate()
	local UnlockTab = {}
	for i, v in pairs(UnlocksTemplate) do
		UnlockTab[i] = {Unlock = true, Hard = true}
	end
	return UnlockTab
end

local glaze_players = {				--最终成就
	Isaac = {Unlock = false, Tainted = false},
	Maggy = {Unlock = false, Tainted = false},
	Cain = {Unlock = false, Tainted = false},
	Judas = {Unlock = false, Tainted = false},
	BlueBaby = {Unlock = false, Tainted = false},
	Eve = {Unlock = false, Tainted = false},
	Samson = {Unlock = false, Tainted = false},
	Azazel = {Unlock = false, Tainted = false},
	Lazarus = {Unlock = false, Tainted = false},
	Eden = {Unlock = false, Tainted = false},
	Lost = {Unlock = false, Tainted = false},
	--Lazarus2 = {Unlock = false, Tainted = false},	
	--BlackJudas = {Unlock = false, Tainted = false},
	Lilith = {Unlock = false, Tainted = false},
	Keeper = {Unlock = false, Tainted = false},
	Apollyon = {Unlock = false, Tainted = false},
	Forgotten = {Unlock = false, Tainted = false},
	Bethany = {Unlock = false, Tainted = false},
	Jacob_and_Esau = {Unlock = false, Tainted = false},
}

function SaveData.get_Glaze_init()
	local UnlockTab = {}
	for i, v in pairs(glaze_players) do
		UnlockTab[i] = {Unlock = false, Tainted = false}
	end
	return UnlockTab
end

function SaveData.get_Glaze_Done()
	local UnlockTab = {}
	for i, v in pairs(glaze_players) do
		UnlockTab[i] = {Unlock = true, Tainted = true}
	end
	return UnlockTab
end

local others_achievements = {		--其他成就
	Ending1 = {Unlock = false, Tainted = false},	
	Ending2 = {Unlock = false, Tainted = false},	
	Ending3 = {Unlock = false, Tainted = false},
	Crown_of_the_Glaze = {Unlock = false, Tainted = false},
	Crushed = {Unlock = false, Tainted = false},		--被车撞到！
	Thoth = {Unlock = false, Tainted = false},
	Law = {Unlock = false, Tainted = false},
	Voice = {Unlock = false, Tainted = false},
	Vision = {Unlock = false, Tainted = false},
	Coin = {Unlock = false, Tainted = false},
	Future = {Unlock = false, Tainted = false},
}

function SaveData.get_others_achievements_init()
	local UnlockTab = {}
	for i, v in pairs(others_achievements) do
		UnlockTab[i] = {Unlock = false, Tainted = false}
	end
	return UnlockTab
end

function SaveData.get_others_achievements_Done()
	local UnlockTab = {}
	for i, v in pairs(others_achievements) do
		UnlockTab[i] = {Unlock = true, Tainted = true}
	end
	return UnlockTab
end

function SaveData.SaveModData()
	SAVE_STATE.PERSISTENT_PLAYER_DATA = SaveData.PERSISTENT_PLAYER_DATA
	SAVE_STATE.wq = SaveData.UnlockData.wq
	SAVE_STATE.Spwq = SaveData.UnlockData.Spwq
	SAVE_STATE.Glaze = SaveData.UnlockData.Glaze
	SAVE_STATE.Others = SaveData.UnlockData.Others
	SAVE_STATE.ELSES = auxi.realrealdeepCopy(SaveData.elses)
	modReference:SaveData(json.encode(SAVE_STATE))
end

function SaveData.GetData(plyr, plyrFailsafe)
	local player = type(plyr) == "table" and plyrFailsafe or plyr
	local data = player:GetData()
	
	if data.__Index then
		return SaveData.PERSISTENT_PLAYER_DATA[data.__Index]
	elseif player.Parent then
		return {}
	else
		Isaac.DebugString("[WARNING] - No Player Index set for [" .. player:GetPlayerType() .. "." .. player:GetName() .. "]")
	
		local pData = {
			__INDEX = #SaveData.PERSISTENT_PLAYER_DATA + 1,
			__META = {
				Index = player.ControllerIndex,
				PlayerType = player:GetPlayerType(),
			},
		}
		table.insert(SaveData.PERSISTENT_PLAYER_DATA, pData)
		data.__Index = #SaveData.PERSISTENT_PLAYER_DATA
		
		return SaveData.PERSISTENT_PLAYER_DATA[data.__Index]
	end
end

function SaveData.LoadModData()
	if Isaac.HasModData(modReference) then
		SAVE_STATE = json.decode(modReference:LoadData())		--载入。
		SaveData.PERSISTENT_PLAYER_DATA = SAVE_STATE.PERSISTENT_PLAYER_DATA or {}
		SaveData.UnlockData.wq = SAVE_STATE.wq
		SaveData.UnlockData.Spwq = SAVE_STATE.Spwq
		SaveData.UnlockData.Glaze = SAVE_STATE.Glaze
		SaveData.UnlockData.Others = SAVE_STATE.Others
		SaveData.elses = auxi.irealrealdeepCopy(SAVE_STATE.ELSES)
		SaveData.CheckAchievementAll()
	else
		SaveData.PERSISTENT_PLAYER_DATA = {}
	end
end

table.insert(SaveData.pre_ToCall,#SaveData.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)		--在这个瞬间。
	local TotPlayers = #Isaac.FindByType(EntityType.ENTITY_PLAYER)
	if TotPlayers == 0 then
		SaveData.LoadModData()
		
		if g.game:GetFrameCount() == 0 then		--游戏开始阶段，进行道具的安排。
			Continue = false
			SaveData.PERSISTENT_PLAYER_DATA = {}
			SaveData.SaveModData()
		else
			Continue = true
		end
	end
	
	if player.Parent then return end		--第二角色到此为止。
	
	local pType = player:GetPlayerType()
	
	if Continue then
		for i, plyr in ipairs(SaveData.PERSISTENT_PLAYER_DATA) do		--存储每个角色
			if player.ControllerIndex == plyr.__META.Index and pType == plyr.__META.PlayerType then
				player:GetData().__Index = i
				return
			end
		end
	end
	
	local pData = {
		__INDEX = #SaveData.PERSISTENT_PLAYER_DATA + 1,
		__META = {
			Index = player.ControllerIndex,
			PlayerType = pType,
		}
	}
	
	table.insert(SaveData.PERSISTENT_PLAYER_DATA, pData)
	player:GetData().__Index = #SaveData.PERSISTENT_PLAYER_DATA
end,
})

table.insert(SaveData.ToCall,#SaveData.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local idx = player:GetData().__Index		--似乎需要这样修复
	if idx ~= nil then
		if SaveData.PERSISTENT_PLAYER_DATA[idx] ~= nil and SaveData.PERSISTENT_PLAYER_DATA[idx].__INDEX == idx then
			if SaveData.PERSISTENT_PLAYER_DATA[idx].__META.Index == player.ControllerIndex then
				local pt = player:GetPlayerType()
				if SaveData.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType ~= pt then
					SaveData.PERSISTENT_PLAYER_DATA[idx].__META.PlayerType = pt
				end
			end
		end
	end
end,
})

table.insert(SaveData.ToCall,#SaveData.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function()		--新下层
	SaveData.SaveModData()
end,
})

table.insert(SaveData.post_ToCall,#SaveData.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldSave)		--离开游戏
	SaveData.SaveModData()
end,
})

function SaveData.LockAll()
	SaveData.UnlockData.wq = SaveData.CreateUnlocksTemplate()
	SaveData.UnlockData.Spwq = SaveData.CreateUnlocksTemplate()
	SaveData.UnlockData.Glaze = SaveData.get_Glaze_init()
	SaveData.UnlockData.Others = SaveData.get_others_achievements_init()
	Achievement_Display_holder.PlayAchievement("gfx/ui/Some achievements/achievement_All_Locked.png")
end

function SaveData.CheckAchievement(sd1,tmp)
	for u,v in pairs(tmp) do
		if sd1[u] == nil then sd1[u] = {Unlock = false, Tainted = false};print(u) end
	end
end

function SaveData.CheckAchievementAll()
	local tmp = SaveData.CreateUnlocksTemplate()
	SaveData.CheckAchievement(SaveData.UnlockData.wq,tmp)
	SaveData.CheckAchievement(SaveData.UnlockData.Spwq,tmp)
	tmp = SaveData.get_Glaze_init()
	SaveData.CheckAchievement(SaveData.UnlockData.Glaze,tmp)
	tmp = SaveData.get_others_achievements_init()
	SaveData.CheckAchievement(SaveData.UnlockData.Others,tmp)
end

function SaveData.UnLockAll()
	SaveData.UnlockData.wq = SaveData.CreateDoneTemplate()
	SaveData.UnlockData.Spwq = SaveData.CreateDoneTemplate()
	SaveData.UnlockData.Glaze = SaveData.get_Glaze_Done()
	SaveData.UnlockData.Others = SaveData.get_others_achievements_Done()
	Achievement_Display_holder.PlayAchievement("gfx/ui/Some achievements/achievement_All_Unlocked.png")
end

--针对沙漏的修复
table.insert(SaveData.ToCall,#SaveData.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function()
	if should_load ~= nil then
		should_load = nil
		SaveData.elses = auxi.realrealdeepCopy(lst)
		delay_buffer.addeffe(function(params)
			SaveData.elses.should_counter_Pageant_Cross_dresser = true
		end,{},5)
	end
	if lst ~= nil then
		local should_save = true
		local level = Game():GetLevel()
		if level:GetStage() == LevelStage.STAGE1_2 and (level:GetStageType() == StageType.STAGETYPE_REPENTANCE or level:GetStageType() == StageType.STAGETYPE_REPENTANCE_B) then
			local desc = level:GetCurrentRoomDesc()
			if desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 10000 and desc.Data.Variant <= 10500 then		--镜子房间，不进行存储。
				should_save = false
			end
		end
		if should_save then
			--print("save")
			lst = auxi.irealrealdeepCopy(SaveData.elses)
		end
	end
end,
})

table.insert(SaveData.ToCall,#SaveData.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS,
Function = function(_, item, rng, player, flags, slot, data)
	if lst ~= nil then
		should_load = true
	end
end,
})

function SaveData.Init(mod)
	modReference = mod
	SaveData.LoadModData()
end


return SaveData