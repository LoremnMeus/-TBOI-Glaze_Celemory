local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")

local modReference
local manager = {
	items = {},
	functs = {},
}

function manager.Init(mod)
	modReference = mod
	table.insert(manager.items,#manager.items + 1,require("Qing_Extra_scripts.grids.grid_doors"))
	table.insert(manager.items,#manager.items + 1,require("Qing_Extra_scripts.grids.grid_entity"))
	manager.MakeItems()
end

function manager.MakeItems()	--没有传入参数。
	for i = 1,#manager.items do
		if manager.items[i].Tofun then		--对外接口。
			for j = 1,#manager.items[i].Tofun do
				if manager.items[i].Tofun[j].name then
					manager.functs[manager.items[i].Tofun[j].name] = manager.items[i].Tofun[j].Function
				end
			end
		end
	end
end

return manager
