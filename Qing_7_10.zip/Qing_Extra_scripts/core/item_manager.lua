local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")

local modReference
local Item_manager = {
	items = {},
	params = {
		should_evaluate_on_update = false,				--这个参数只会被开启。
		should_evaluate_on_update_once = false,
		},
}

function Item_manager.OnPostUpdate()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if Item_manager.params.should_evaluate_on_update or Item_manager.params.should_evaluate_on_update_once or player:GetData().should_evaluate_on_update or player:GetData().should_evaluate_on_update_once then
			player:EvaluateItems()
			player:GetData().should_evaluate_on_update_once = nil
		end
	end
	if Item_manager.params.should_evaluate_on_update_once then
		Item_manager.params.should_evaluate_on_update_once = false
	end
end

function Item_manager.Init(mod)
	modReference = mod
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Darkness"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Touchstone"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_My_Hat"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Assassin_s_Eye"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Tech_9"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Giant_Punch"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Memory"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Gold_Rush"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Air_Flight"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Super_Bombs"))			--10
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Crown_of_the_Glaze"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Black_Map"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_The_Watcher"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Blaststone"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Brimstream"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Glaze_Cap"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Pageant_Cross_dresser"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Little_Duck"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Glaze_Item"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_TianYi"))				--20
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Mental_Hypnosis"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Colorblindness"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_My_Best_Friend"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Field"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Suture_Needle"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Abecarnil"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Barbital"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Cyanide"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Dexamethasone"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Ephedrine"))		--30
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Ginsenoside"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Heroisch"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Fenfluramine"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Oxytocin"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Poision_Sildenafil"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_More_Options"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Fate_s_Draw"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Ingestion_to_Night"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_My_Emblem"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_D773"))					--40
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Devil_s_Heart"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Air_Terror"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Book_of_Future"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Hyper_Velocity"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Wavering_Eyes"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Star_Pendulum"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Book_of_Thoth"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Aphasia"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Book_of_The_Law"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Book_of_Voice"))			--50
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Book_of_Vision"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Nazca"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Cloundy"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Iliaster"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Moment"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Lofty"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Theseus_s_Sign"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Heart_Change"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Cable_Jar"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Tiramisu"))				--60
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Live_Broadcast"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Drama_of_sorrow_and_joy"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Tzolkin"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Pareidolia"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Gospel"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Squiresaga"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Alchemy_Pot"))
	table.insert(Item_manager.items,#Item_manager.items + 1,require("Qing_Extra_scripts.items.Item_Tears_of_Pearl"))
	--Item_manager.MakeItems()
	modReference:AddCallback(ModCallbacks.MC_POST_UPDATE,Item_manager.OnPostUpdate)
end

function Item_manager.MakeItems()	--没有传入参数。
	for i = 1,#Item_manager.items do
		if Item_manager.items[i].ToCall then
			for j = 1,#(Item_manager.items[i].ToCall) do
				if Item_manager.items[i].ToCall[j] ~= nil and Item_manager.items[i].ToCall[j].Function ~= nil and Item_manager.items[i].ToCall[j].CallBack ~= nil then
					if Item_manager.items[i].ToCall[j].params == nil then
						modReference:AddCallback(Item_manager.items[i].ToCall[j].CallBack,Item_manager.items[i].ToCall[j].Function)
					else
						modReference:AddCallback(Item_manager.items[i].ToCall[j].CallBack,Item_manager.items[i].ToCall[j].Function,Item_manager.items[i].ToCall[j].params)
					end
				end
			end
		end
	end
end

return Item_manager
