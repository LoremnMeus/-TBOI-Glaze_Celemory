local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")

local modReference
local Enemy_manager = {
	items = {},
}

function Enemy_manager.Init(mod)
	modReference = mod
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.Boss_Princess_Glaze"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_check_board"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_check_piece"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_staff_strike"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_framony"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_hreeze"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_wildwind"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_bum_emperor"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_bum_guard"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_bum_spear"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_bum_arrow"))
	table.insert(Enemy_manager.items,#Enemy_manager.items + 1,require("Qing_Extra_scripts.Enemies.enemy_shadollee"))
	--Enemy_manager.MakeEnemies()
end

function Enemy_manager.MakeEnemies()	--没有传入参数。
	for i = 1,#Enemy_manager.items do
		if Enemy_manager.items[i].ToCall then
			for j = 1,#(Enemy_manager.items[i].ToCall) do
				if Enemy_manager.items[i].ToCall[j] ~= nil and Enemy_manager.items[i].ToCall[j].Function ~= nil and Enemy_manager.items[i].ToCall[j].CallBack ~= nil then
					if Enemy_manager.items[i].ToCall[j].params == nil then
						modReference:AddCallback(Enemy_manager.items[i].ToCall[j].CallBack,Enemy_manager.items[i].ToCall[j].Function)
					else
						modReference:AddCallback(Enemy_manager.items[i].ToCall[j].CallBack,Enemy_manager.items[i].ToCall[j].Function,Enemy_manager.items[i].ToCall[j].params)
					end
				end
			end
		end
	end
end

return Enemy_manager
