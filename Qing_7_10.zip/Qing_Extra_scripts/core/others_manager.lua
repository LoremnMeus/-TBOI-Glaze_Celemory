local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")

local modReference
local Others_manager = {
	items = {},
	params = {},
}

function Others_manager.Init(mod)
	modReference = mod
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.core.savedata"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.core.achievement_tracker"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.core.unlock_manager"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Input_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Console_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Dropping_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Attribute_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Charging_Bar_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Costume_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Consistance_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Tarot_Cloth_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.option_index_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Record_holder"))
	--table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Damage_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Achievement_Display_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Screen_Filter"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Selection_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.others.Imitate_item_holder"))
	table.insert(Others_manager.items,#Others_manager.items + 1,require("Qing_Extra_scripts.translations.zh"))
	Others_manager.MakeItems()
end

function Others_manager.MakeItems()	--没有传入参数。
	for i = 1,#Others_manager.items do
		if Others_manager.items[i].Init then
			Others_manager.items[i].Init(modReference)
		end
	end
end

return Others_manager
