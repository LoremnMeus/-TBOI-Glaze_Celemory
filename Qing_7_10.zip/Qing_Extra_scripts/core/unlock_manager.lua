local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local tracker = require("Qing_Extra_scripts.core.achievement_tracker")
local enums = require("Qing_Extra_scripts.core.enums")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local players = enums.Players
local items = enums.Items
local trinkets = enums.Trinkets
local cards = enums.Cards
local ModConfigSettings = ModConfig.ModConfigSettings

local modReference 
local Manager = {	
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
}

local itemToUnlock = {
	[items.Darkness] = {Unlock = "MegaSatan",name = "wq",},
	[items.Touchstone] = {Unlock = "Lamb",name = "wq",},
	[items.Glaze_Mushroom] = {Unlock = "BlueBaby",name = "wq"},
	[items.Tech_9] = {Unlock = "Hush",name = "wq",},
	[items.Assassin_s_Eye] = {Unlock = "BossRush",name = "wq",},
	[items.Mental_Hypnosis] = {Unlock = "Delirium",name = "wq",},
	[items.Pageant_Cross_dresser] = {Unlock = "Isaac",name = "wq"},
	[items.More_Options___] = {Unlock = "Satan",name = "wq"},
	[items.Ingestion_to_Night] = {Unlock = "Beast",name = "wq"},
	[items.Black_Map] = {Unlock = "Mother",name = "wq",},
	[items.Gold_Rush] = {Unlock = "GreedMode",name = "wq",},
	
	--[items.Air_Terror] = {Unlock = "MegaSatan",name = "Spwq",},
	[items.Air_Flight] = {Unlock = "Lamb",name = "Spwq"},
	[items.The_Watcher] = {Unlock = "BlueBaby",name = "Spwq"},
	[items.Giant_Punch] = {Unlock = "BossRush",name = "Spwq"},
	[items.Memory] = {Unlock = "Delirium",name = "Spwq"},
	[items.Field] = {Unlock = "Isaac",name = "Spwq"},
	[items.Little_Duck] = {Unlock = "Satan",name = "wq"},
	[items.My_Best_Friend] = {Unlock = "Beast",name = "Spwq"},
	[items.Super_Bombs] = {Unlock = "Mother",name = "Spwq"},
	[items.Fate_s_Draw] = {Unlock = "GreedMode",name = "Spwq"},
	[items.Brimstream] = {Unlock = "GreedMode",name = "Spwq",Hard = true,},
	[items.Blaststone] = {Unlock = "GreedMode",name = "Spwq",Hard = true,},
	
	[items.It_s_a_trick] = {Special = function()
		return save.UnlockData.Glaze["Lost"].Unlock == true end,},
		
	[items.Crown_of_the_glaze] = {Special = function()
		return save.UnlockData.Others["Crown_of_the_Glaze"].Unlock == true end,},
	
	[items.Tianyi] = {Unlock = "Satan",name = "Spwq"},		--下面的成就属于Ending2的内容。
	[items.Colorblindness] = {Unlock = "Satan",name = "Spwq"},
	[items.Devil_s_Heart] = {Unlock = "Satan",name = "Spwq"},
	[items.Suture_Needle] = {Unlock = "Satan",name = "Spwq"},
	[items.D773] = {Unlock = "Satan",name = "Spwq"},
	[items.Hyper_Velocity] = {Unlock = "Satan",name = "Spwq"},
	[items.Wavering_Eyes] = {Unlock = "Satan",name = "Spwq"},
	[items.Pendulum_Star] = {Unlock = "Satan",name = "Spwq"},
	[items.Aphasia] = {Unlock = "Satan",name = "Spwq"},
	[items.Nazca] = {Unlock = "Satan",name = "Spwq"},
	[items.Cloundy] = {Unlock = "Satan",name = "Spwq"},
	
	[items.Book_of_Thoth] = {Special = function()
		return save.UnlockData.Others["Thoth"].Unlock == true end},
	[items.Book_of_The_Law] = {Special = function()
		return save.UnlockData.Others["Law"].Unlock == true end},
	[items.Book_of_Vision] = {Special = function()
		return save.UnlockData.Others["Vision"].Unlock == true end},
	[items.Book_of_Voice] = {Special = function()
		return save.UnlockData.Others["Voice"].Unlock == true end},
	[items.Book_of_Future] = {Special = function()
		return save.UnlockData.Others["Future"].Unlock == true end},
	
	[items.My_Hat] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.My_Emblem] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	
	[items.A_Shard_Of_Coin] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.A_Shard_Of_Glaze] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.A_Shard_Of_Lava] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.A_Shard_Of_Meat] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.A_Shard_Of_Rock] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
	[items.A_Shard_Of_Blood] = {Special = function()
		return save.UnlockData.Others["Ending1"].Unlock == true end,},
}

local trinketToUnlock = {
--[[
	[trinkets.DadsCharm] = {Unlock = "MomsHeart"},
	--]]
}

local cardtoUnlock = {
	[cards.Glaze_dice_shard] = {
	Special = function()
		return save.UnlockData.Glaze["Isaac"].Unlock == true
	end,rune = false,tarot = false,special_transform = 49,},
	[cards.Qing_s_Soul] = {Unlock = "Hush",name = "Spwq",rune = true,tarot = false,},
	[cards.Round_trip_Rail_Ticket] = {Special = function() return save.UnlockData.Others["Crushed"].Unlock == true end,rune = false,tarot = false,},
	[cards.One_way_Rail_Ticket] = {Special = function() return false end,rune = false,tarot = false,},		--不会直接出现。
	[cards.Adjustment] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Lure] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Art] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Aeon] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Universe] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Adjustment_r] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Lure_r] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Art_r] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Aeon_r] = {Special = function() return false end,rune = false,tarot = false,},
	[cards.Universe_r] = {Special = function() return false end,rune = false,tarot = false,},
}

--这里会处理所有不应该生成的内容。
table.insert(Manager.pre_ToCall,#Manager.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	local TotPlayers = #Isaac.FindByType(EntityType.ENTITY_PLAYER)
	
	if TotPlayers == 0 then
		if save.UnlockData.wq.MomsHeart == nil then			--初始化过程
			save.UnlockData.wq = save.CreateUnlocksTemplate()
			save.UnlockData.Spwq = save.CreateUnlocksTemplate()
			save.UnlockData.Glaze = save.get_Glaze_init()
			save.UnlockData.Others = save.get_others_achievements_init()
		end
		
		if g.game:GetFrameCount() > 0 then return end
		
		for item, tab in pairs(itemToUnlock) do
			local Prefix = tab.Tainted and "SP" or ""
			local Unlocked = false
			local name = tab.name
			if name == nil then name = "wq" end
			if tab.Special then
				Unlocked = tab.Special()
			else
				if tab.Hard then
					Unlocked = save.UnlockData[name][tab.Unlock].Hard
				else
					Unlocked = save.UnlockData[name][tab.Unlock].Unlock
				end
			end
			
			if ModConfigSettings.Items_allow == false then
				Unlocked = false
			end
			
			if not Unlocked then
				g.ItemPool:RemoveCollectible(item)
			end
		end
		for trinket, tab in pairs(trinketToUnlock) do
			local Prefix = tab.Tainted and "SP" or ""
			local Unlocked = false
			local name = tab.name
			if name == nil then name = "wq" end
			if tab.Special then
				Unlocked = tab.Special()
			else
				if tab.Hard then
					Unlocked = save.UnlockData[name][tab.Unlock].Hard
				else
					Unlocked = save.UnlockData[name][tab.Unlock].Unlock
				end
			end
			if ModConfigSettings.Items_allow == false then
				Unlocked = false
			end
			if not Unlocked then
				g.ItemPool:RemoveTrinket(trinket)
			end
		end
	end
end,
})

--[[
table.insert(Manager.ToCall,#Manager.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = nil,
Function = function(_,pickup)
	if pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE or pickup.Variant == PickupVariant.PICKUP_TRINKET then
		local tab
		if pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE then
			tab = itemToUnlock[pickup.SubType]
		else
			tab = trinketToUnlock[pickup.SubType]
		end
		
		if (not tab) then return end
		
		local name = tab.name
		if name == nil then name = "wq" end
		local Unlocked = false
		
		if tab.Special then
			Unlocked = tab.Special()
		else
			if tab.Hard then
				Unlocked = save.UnlockData[name][tab.Unlock].Hard
			else
				Unlocked = save.UnlockData[name][tab.Unlock].Unlock
			end
		end
		
		if not Unlocked then
			if pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE and pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE then
				local roomPool = g.ItemPool:GetPoolForRoom(g.game:GetRoom():GetType(), g.game:GetLevel():GetCurrentRoomDesc().SpawnSeed)
				if roomPool == -1 then roomPool = 0 end
				local targetItem = g.ItemPool:GetCollectible(roomPool, true, pickup.InitSeed)
				g.ItemPool:RemoveCollectible(pickup.SubType)
				pickup:Morph(pickup.Type, pickup.Variant, targetItem, true, true, true)
			elseif pickup.Variant == PickupVariant.PICKUP_TRINKET and pickup.Variant == PickupVariant.PICKUP_TRINKET then
				g.ItemPool:RemoveTrinket(pickup.SubType)
				pickup:Morph(pickup.Type, pickup.Variant, g.ItemPool:GetTrinket(), true, true, true)
			end
		end
	end
end,
})
--]]

table.insert(Manager.pre_ToCall,#Manager.pre_ToCall + 1,{CallBack = ModCallbacks.MC_GET_CARD, params = nil,
Function = function(_,rng,card,playing,rune,onlyrune)
	if cardtoUnlock[card] then
		local v = cardtoUnlock[card]

		local name = v.name
		if name == nil then name = "wq" end
		local Unlocked = false
		if v.Special then
			Unlocked = v.Special()
		else
			if v.Hard then
				Unlocked = save.UnlockData[name][v.Unlock].Hard
			else
				Unlocked = save.UnlockData[name][v.Unlock].Unlock
			end
		end
		if Unlocked and ModConfigSettings.Pickup_allow then
			return card
		else
			if v.special_transform then
				return v.special_transform
			else
				rng = auxi.rng_for_sake(rng)
				rng:Next()		--让随机数前进一步
				return Game():GetItemPool():GetCard(rng:GetSeed(), playing, rune, onlyrune)
			end
		end
	end
end,
})

--[[
function Manager.postPlayerUpdate(_,player)
	if false then
	for item, tab in pairs(itemToUnlock) do
		local HasIt = player:HasCollectible(item)
		
		if HasIt then
			local Prefix = tab.Tainted and "SP" or ""
			local Unlocked = false
			
			if tab.Special then
				Unlocked = tab.Special()
			else
				Unlocked = save.UnlockData[Prefix .. "WQ"][tab.Unlock].Unlock
			end
			
			if not Unlocked then
				local targetItem = g.ItemPool:GetCollectible(ItemPoolType.POOL_TREASURE, true, player.InitSeed)
				player:RemoveCollectible(item)
				player:AddCollectible(targetItem, g.ItemConfig:GetCollectible(targetItem).MaxCharges)		--还是可能使伊甸拥有2个主动，结果顶掉一个。
			end
		end
	end
	for trinket, tab in pairs(trinketToUnlock) do
		local HasIt = player:HasTrinket(trinket)
		
		if HasIt then
			local Prefix = tab.Tainted and "SP" or ""
			local Unlocked = false
			
			if tab.Special then
				Unlocked = tab.Special()
			else
				Unlocked = save.UnlockData[Prefix .. "WQ"][tab.Unlock].Unlock
			end
			
			if not Unlocked then
				local targetTrinket = g.ItemPool:GetTrinket()
				player:TryRemoveTrinket(trinket)
				player:AddTrinket(targetTrinket)
			end
		end
	end
	for i = 0, 3 do
		if player:GetCard(i) == cards.SoulofJob
		and (not save.UnlockData.PlayerJob_B.SoulPath)
		then
			local Counter = 10000
			local TargetCard = g.ItemPool:GetCard(player.InitSeed + Counter, false, true, true)
		
			while TargetCard == cards.SoulofJob do
				Counter = Counter + 10000
				TargetCard = g.ItemPool:GetCard(player.InitSeed + Counter, false, true, true)
			end
			
			player:SetCard(i, TargetCard)
		elseif player:GetCard(i) == cards.AncientFragment then
			local hasSisyphus = false
			for p = 0, g.game:GetNumPlayers() - 1 do
				if Isaac.GetPlayer(p):HasCollectible(items.Sisyphus) then
					hasSisyphus = true
					break
				end
			end
			
			if hasSisyphus then return end
			
			local Counter = 10000
			local TargetCard = g.ItemPool:GetCard(player.InitSeed + Counter, false, false, false)
			
			while TargetCard == cards.AncientFragment do
				Counter = Counter + 10000
				TargetCard = g.ItemPool:GetCard(player.InitSeed + Counter, false, false, false)
			end
			
			player:SetCard(i, TargetCard)
		end
	end
	end
end
--]]

function Manager.Init(mod)
	modReference = mod
	--modReference:AddCallback(ModCallbacks.MC_POST_PLAYER_INIT, Manager.postPlayerInit)
	--modReference:AddCallback(ModCallbacks.MC_POST_PICKUP_INIT, Manager.postPickupInit)
	--modReference:AddCallback(ModCallbacks.MC_GET_CARD, Manager.postgetcard)
	--modReference:AddCallback(ModCallbacks.MC_POST_PLAYER_UPDATE, Manager.postPlayerUpdate)		--我的建议是，如果玩家因为某种方式获得了此道具，那么由他们去。
end

return Manager