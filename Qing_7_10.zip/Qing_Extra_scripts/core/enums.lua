local enums = {}

enums.Players = {
	wq = Isaac.GetPlayerTypeByName("W.Qing"),
	Spwq = Isaac.GetPlayerTypeByName("SP.W.Qing", true),
	Tecro = Isaac.GetPlayerTypeByName("Tecro"),
	Tecrorun = Isaac.GetPlayerTypeByName("Tecrorun", true),
}

enums.Items = {
	Darkness = Isaac.GetItemIdByName("Darkness"),
	Touchstone = Isaac.GetItemIdByName("Touchstone"),
	My_Hat = Isaac.GetItemIdByName("My Hat"),
	Tech_9 = Isaac.GetItemIdByName("Tech 9"),
	Assassin_s_Eye = Isaac.GetItemIdByName("Assassin's Eye"),
	A_Shard_Of_Coin = Isaac.GetItemIdByName("A Shard of Coin"),
	A_Shard_Of_Glaze = Isaac.GetItemIdByName("A Shard of Glaze"),
	A_Shard_Of_Lava = Isaac.GetItemIdByName("A Shard of Lava"),
	A_Shard_Of_Meat = Isaac.GetItemIdByName("A Shard of Meat"),
	A_Shard_Of_Rock = Isaac.GetItemIdByName("A Shard of Rock"),
	Mental_Hypnosis = Isaac.GetItemIdByName("Mental Hypnosis"),
	Gold_Rush = Isaac.GetItemIdByName("Gold Rush"),
	Black_Map = Isaac.GetItemIdByName("Black Map"),
	Air_Flight = Isaac.GetItemIdByName("Air Flight"),
	The_Watcher = Isaac.GetItemIdByName("The Watcher"),
	Giant_Punch = Isaac.GetItemIdByName("Giant Punch"),
	Memory = Isaac.GetItemIdByName("Memory"),
	My_Best_Friend = Isaac.GetItemIdByName("My Best Friend"),
	Super_Bombs = Isaac.GetItemIdByName("Super Bombs"),
	Brimstream = Isaac.GetItemIdByName("Brimstream"),
	Crown_of_the_glaze = Isaac.GetItemIdByName("Crown of the Glaze"),
	Blaststone = Isaac.GetItemIdByName("Blaststone"),
	Little_Duck = Isaac.GetItemIdByName("Little Duck"),
	A_Shard_Of_Blood = Isaac.GetItemIdByName("A Shard of Blood"),
	Alchemy_Pot = Isaac.GetItemIdByName("Alchemy Pot"),
	Air_Terror = Isaac.GetItemIdByName("Air Terror"),
	Glaze_Mushroom = Isaac.GetItemIdByName("Glaze Mushroom"),
	Pageant_Cross_dresser = Isaac.GetItemIdByName("Pageant Cross-dresser"),
	It_s_a_trick = Isaac.GetItemIdByName("It's a trick!!"),
	Tianyi = Isaac.GetItemIdByName("Apocalypse"),
	Colorblindness = Isaac.GetItemIdByName("Colorblindness"),
	Field = Isaac.GetItemIdByName("Field"),
	Suture_Needle = Isaac.GetItemIdByName("Suture Needle"),
	More_Options___ = Isaac.GetItemIdByName("More Options??!"),
	Fate_s_Draw = Isaac.GetItemIdByName("Fate's Draw"),
	My_Emblem = Isaac.GetItemIdByName("My Emblem"),
	Ingestion_to_Night = Isaac.GetItemIdByName("Ingestion to Night"),
	D773 = Isaac.GetItemIdByName("D773"),
	Devil_s_Heart = Isaac.GetItemIdByName("Devil's Heart"),
	DVF = Isaac.GetItemIdByName("DVF"),
	Book_of_Future = Isaac.GetItemIdByName("Book of Future"),
	Hyper_Velocity = Isaac.GetItemIdByName("Hyper Velocity"),
	Wavering_Eyes = Isaac.GetItemIdByName("Wavering Eyes"),
	Pendulum_Star = Isaac.GetItemIdByName("Pendulum Star"),
	Book_of_Thoth = Isaac.GetItemIdByName("Book of Thoth"),
	Book_of_The_Law = Isaac.GetItemIdByName("Book of The Law"),
	Book_of_Vision = Isaac.GetItemIdByName("Book of Vision"),
	Book_of_Voice = Isaac.GetItemIdByName("Book of Voice"),
	Aphasia = Isaac.GetItemIdByName("Aphasia"),
	Nazca = Isaac.GetItemIdByName("Nazca"),
	Cloundy = Isaac.GetItemIdByName("Cloundy"),
	Skiel = Isaac.GetItemIdByName("Skiel"),
	Wisel = Isaac.GetItemIdByName("Wisel"),
	Granel = Isaac.GetItemIdByName("Granel"),
	Spectralsword = Isaac.GetItemIdByName("Spectralsword"),
	Squiresaga = Isaac.GetItemIdByName("Squiresaga"),
	Moment = Isaac.GetItemIdByName("Moment"),
	Lofty = Isaac.GetItemIdByName("Lofty"),
	Theseus_s_Sign = Isaac.GetItemIdByName("Theseus's Sign"),
	Heart_Change = Isaac.GetItemIdByName("Heart Change"),
	Cable_Jar = Isaac.GetItemIdByName("Cable Jar"),
	Gospel = Isaac.GetItemIdByName("Gospel"),
	Tiramisu = Isaac.GetItemIdByName("Tiramisu"),
	Live_Broadcast = Isaac.GetItemIdByName("Live Broadcast"),
	Drama_of_sorrow_and_joy = Isaac.GetItemIdByName("Drama of sorrow and joy"),
	Tzolkin = Isaac.GetItemIdByName("Tzolkin"),
	Pareidolia = Isaac.GetItemIdByName("Pareidolia"),
	Tears_of_Pearl = Isaac.GetItemIdByName("Tears of Pearl"),
	
	Abecarnil = Isaac.GetItemIdByName("Abecarnul"),
	Barbital = Isaac.GetItemIdByName("Barbital"),
	Cyanide = Isaac.GetItemIdByName("Cyanide"),
	Dexamethasone = Isaac.GetItemIdByName("Dexamethasone"),
	Ephedrine = Isaac.GetItemIdByName("Ephedrine"),
	Fenfluramine = Isaac.GetItemIdByName("Fenfluramine"),
	Ginsenoside = Isaac.GetItemIdByName("Ginsenoside"),
	Heroisch = Isaac.GetItemIdByName("Heroisch"),
	Oxytocin = Isaac.GetItemIdByName("Oxytocin"),
	Sildenafil = Isaac.GetItemIdByName("Sildenafil"),
	
	Reversal_Film = Isaac.GetItemIdByName("Reversal Film"),
}

enums.Trinkets = {
	-- = Isaac.GetTrinketIdByName(""),
}

enums.Callbacks = {
	POST_GAIN_COLLECTIBLE = "POST_GAIN_COLLECTIBLE",
	POST_LOSE_COLLECTIBLE = "POST_LOSE_COLLECTIBLE",
	POST_CHANGE_COLLECTIBLE = "POST_CHANGE_COLLECTIBLE",
	POST_PICKUP_COLLETIBILE = "POST_PICKUP_COLLETIBILE",
	POST_PICKUP_TRINKET = "POST_PICKUP_TRINKET",
	PRE_GET_TELEPORT = "PRE_GET_TELEPORT",
	PRE_QINGS_KNIFE_COLLISION = "PRE_QINGS_KNIFE_COLLISION",
	POST_CHANGE_BASIC = "POST_CHANGE_BASIC",
	PRE_DESCRIPT_ITEM = "PRE_DESCRIPT_ITEM",
	POST_DESCRIPT_ITEM = "POST_DESCRIPT_ITEM",
	PRE_TELL_FORTUNE = "PRE_TELL_FORTUNE",
	PRE_NEW_LEVEL = "PRE_NEW_LEVEL",
	PRE_GAME_STARTED = "PRE_GAME_STARTED",
}

enums.Slots = {
	Bard_beggar = {Type = 996,Variant = Isaac.GetEntityVariantByName("Bard Beggar"),},
}

enums.Cards = {
	Glaze_dice_shard = Isaac.GetCardIdByName("Glazed Dice Shard"),
	Qing_s_Soul = Isaac.GetCardIdByName("Qing's Soul"),
	Round_trip_Rail_Ticket = Isaac.GetCardIdByName("Round trip Rail Ticket"),
	One_way_Rail_Ticket = Isaac.GetCardIdByName("One way Rail Ticket"),
	Adjustment = Isaac.GetCardIdByName("Adjustment"),
	Lure = Isaac.GetCardIdByName("Lure"),
	Art = Isaac.GetCardIdByName("Art"),
	Aeon = Isaac.GetCardIdByName("The Aeon"),
	Universe = Isaac.GetCardIdByName("The Universe"),
	Adjustment_r = Isaac.GetCardIdByName("Adjustment r"),
	Lure_r = Isaac.GetCardIdByName("Lure r"),
	Art_r = Isaac.GetCardIdByName("Art r"),
	Aeon_r = Isaac.GetCardIdByName("The Aeon r"),
	Universe_r = Isaac.GetCardIdByName("The Universe r"),
}

enums.SoundEffect = {
	Machine = Isaac.GetSoundIdByName("Machine"),
	Betray = Isaac.GetSoundIdByName("Betray"),
}

enums.Costumes = {
	SPWQinghair = Isaac.GetCostumeIdByPath("gfx/characters/SPWQingHair.anm2"),
	Qingrobes = Isaac.GetCostumeIdByPath("gfx/characters/Qingrobes.anm2"),
	Devil_s_Heart_Head = Isaac.GetCostumeIdByPath("gfx/characters/Devil_s_Heart_Head.anm2"),
	D_s_H_2 = Isaac.GetCostumeIdByPath("gfx/characters/D_s_H_2.anm2"),
	D_s_H_3 = Isaac.GetCostumeIdByPath("gfx/characters/D_s_H_3.anm2"),
	D_s_H_4 = Isaac.GetCostumeIdByPath("gfx/characters/D_s_H_4.anm2"),
	Heart_Change_1 = Isaac.GetCostumeIdByPath("gfx/characters/angel_and_devil_1.anm2"),
	Heart_Change_2 = Isaac.GetCostumeIdByPath("gfx/characters/angel_and_devil_2.anm2"),
	Heart_Change_3 = Isaac.GetCostumeIdByPath("gfx/characters/angel_and_devil_3.anm2"),
	Heart_Change_4 = Isaac.GetCostumeIdByPath("gfx/characters/angel_and_devil_4.anm2"),
	Despia_1 = Isaac.GetCostumeIdByPath("gfx/characters/Despia_Head_1.anm2"),
	Despia_2 = Isaac.GetCostumeIdByPath("gfx/characters/Despia_Head_2.anm2"),
	Despia_3 = Isaac.GetCostumeIdByPath("gfx/characters/Despia_Head_3.anm2"),
	Tecrohair = Isaac.GetCostumeIdByPath("gfx/characters/Tecro_Head.anm2"),
	Tecroface = Isaac.GetCostumeIdByPath("gfx/characters/Tecro_Face.anm2"),
	Pareidolia_1 = Isaac.GetCostumeIdByPath("gfx/characters/Pareidolia_Head2.anm2"),
}

enums.Familiars = {
	QingsAirs = Isaac.GetEntityVariantByName("QingsAir"),
	Brimstream = Isaac.GetEntityVariantByName("Brimstream"),
	Tiandian = Isaac.GetEntityVariantByName("Tiandian"),
	Emblem = Isaac.GetEntityVariantByName("My Emblem"),
	Air_Terror = Isaac.GetEntityVariantByName("Air Terror"),
	Glaze_Chest_Key = Isaac.GetEntityVariantByName("Glaze Chest Key"),
	Glaze_Chest_Key2 = Isaac.GetEntityVariantByName("Glaze Chest Key2"),
	Star_Pendulum = Isaac.GetEntityVariantByName("Star Pendulum"),
	Nazca = Isaac.GetEntityVariantByName("Nazca"),
	Cloundy = Isaac.GetEntityVariantByName("Cloundy"),
}

enums.Enemies = {
	Princess_Glaze = Isaac.GetEntityVariantByName("Princess Glaze"),
	chess_piece = Isaac.GetEntityVariantByName("Chess Piece"),
	chess_board = Isaac.GetEntityVariantByName("Chess Board"),
	framony = Isaac.GetEntityVariantByName("Framony"),
	Staff_Strike = Isaac.GetEntityVariantByName("staff strike"),
	Hreeze = Isaac.GetEntityVariantByName("Hreeze"),
	wildwind = Isaac.GetEntityVariantByName("Wildwind"),
	chimella = Isaac.GetEntityVariantByName("chimella"),
	Bum_Emperor = Isaac.GetEntityVariantByName("Bum Emperor"),
	Bum_Guard = Isaac.GetEntityVariantByName("Bum Guard"),
	Bum_spear = Isaac.GetEntityVariantByName("Bum spear"),
	Bum_arrow = Isaac.GetEntityVariantByName("Bum arrow"),
}

enums.Entities = {
	QingsAirs = Isaac.GetEntityVariantByName("QingsAir"),
	MeusLink = Isaac.GetEntityVariantByName("MeusLink"),
	QingsMarks = Isaac.GetEntityVariantByName("QingsMark"),
	StabberKnife = Isaac.GetEntityVariantByName("StabberKnife"),
	MeusSword = Isaac.GetEntityVariantByName("MeusSword"),
	ID_EFFECT_MeusFetus = Isaac.GetEntityVariantByName("MeusFetus"),
	ID_EFFECT_MeusRocket = Isaac.GetEntityVariantByName("MeusRocket"),
	ID_EFFECT_MeusNIL = Isaac.GetEntityVariantByName("MeusNil"),
	Qing_Bar = Isaac.GetEntityVariantByName("Qing Bar"),
	Blaststone = Isaac.GetEntityVariantByName("Blaststone"),
	Brimstream = Isaac.GetEntityVariantByName("Brimstream"),
	little_duck = Isaac.GetEntityVariantByName("littleduck"),
	Tiandian = Isaac.GetEntityVariantByName("Tiandian"),
	trans_field_door = Isaac.GetEntityVariantByName("trans field door"),
	Harmony = Isaac.GetEntityVariantByName("Harmony"),
	Glaze_Chest_Key = Isaac.GetEntityVariantByName("Glaze Chest Key"),
	Glaze_Chest_Key2 = Isaac.GetEntityVariantByName("Glaze Chest Key2"),
	Sleep_on_Bed = Isaac.GetEntityVariantByName("Isaac on bed"),
	Feeding_gift = Isaac.GetEntityVariantByName("Feeding Gift"),
	Tecro_Spear = Isaac.GetEntityVariantByName("Tecro Spear"),
	Shadollee = Isaac.GetEntityVariantByName("Shadollee"),
}

enums.Pickups = {
	Glaze_heart = {Variant = Isaac.GetEntityVariantByName("Glaze_heart"),SubType = 2350,wei = 50,heavy = 2,},
	Glaze_heart_half = {Variant = Isaac.GetEntityVariantByName("Glaze_heart_half"),SubType = 2351,wei = 70,heavy = 1,},
	Glaze_key = {Variant = Isaac.GetEntityVariantByName("Glaze_key"),SubType = 2352,wei = 80,heavy = 2,},
	Glaze_bomb = {Variant = Isaac.GetEntityVariantByName("Glaze_bomb"),SubType = 2355,wei = 90,heavy = 2,},
	--Glaze_coin = {Variant = Isaac.GetEntityVariantByName("Glaze_coin"),SubType = 2354,wei = 160,heavy = 1,},
	---[[
	Glaze_coin = {Variant = 20,SubType = 4,wei = 160,heavy = 1,special_to_turn = function(ent,turnin)
		local d = ent:GetData()
		if d._Data == nil then d._Data = {} end
		if turnin == true then
			d._Data.is_glaze_coin = true
		else
			d._Data.is_glaze_coin = false
		end
		local s = ent:GetSprite()
		s:Load("gfx/glaze_coin.anm2",true)
		s:Play("Appear",true)
		return true,"Glaze_Coin"
	end,special_to_check = function(ent)
		return ent:GetData()._Data and ent:GetData()._Data.is_glaze_coin == true
	end,load_EID = function(ent)
		if EID then
			if EID.UserConfig.Language == "zh_cn" or EID.UserConfig.Language == "auto" then
				ent:GetData().EID_Description = {Name = "琉璃之硬币",Description = "#缓缓吸引周围的掉落物#20%概率给予5块钱",}
			end
		end
	end,
	},
	---]]
	Glaze_grabbag = {Variant = Isaac.GetEntityVariantByName("Glaze_grabbag"),SubType = 2353,wei = 30,heavy = 3,},
	Glaze_battery = {Variant = Isaac.GetEntityVariantByName("Glaze_battery"),SubType = 2356,wei = 40,heavy = 2,},
	Glaze_chest = {Variant = Isaac.GetEntityVariantByName("Glaze_chest"),SubType = 2357,wei = 1,heavy = 8,},
	Glaze_big_poop = {Variant = Isaac.GetEntityVariantByName("Glaze_big_poop"),SubType = 2358,wei = 0,heavy = 1,},
	Glaze_dice_shard = {Variant = 300,SubType = Isaac.GetCardIdByName("Glazed Dice Shard"),wei = 10,heavy = 5,},
}

enums.Challenges = {
	Fusion_Destiny = Isaac.GetChallengeIdByName("Fusion Destiny"),
	Fans_Service = Isaac.GetChallengeIdByName("Fans Service"),
	Fake_Image = Isaac.GetChallengeIdByName("Fake Image"),
	Heterothermal_Concentric = Isaac.GetChallengeIdByName("Heterothermal Concentric"),
	Feels_Like_Dead_Ashes = Isaac.GetChallengeIdByName("Feels Like Dead Ashes"),
	Louvre_puzzle = Isaac.GetChallengeIdByName("Louvre Puzzle"),
	Unstable_State = Isaac.GetChallengeIdByName("Unstable State"),
	Invisible = Isaac.GetChallengeIdByName("Invisible"),
	Safe_Driving = Isaac.GetChallengeIdByName("Safe Driving"),
	Cookie_Clicker = Isaac.GetChallengeIdByName("Cookie Clicker"),
	Pointing = Isaac.GetChallengeIdByName("Pointing and Disappointing"),
}


enums.AchievementGraphics = {		--未绘制的成就，以及未设计的成就。
	wq = {
		--MomsHeart = "achievement_",
		MegaSatan = "achievement_Darkness",
		Lamb = "achievement_Touchstone",		--重新确认
		BlueBaby = "achievement_Glazed_Cap",
		Hush = "achievement_Tech_9",
		BossRush = "achievement_Assassin_s_Eye",
		Delirium = "achievement_Mental_Hypnosis",
		Isaac = "achievement_Pageant_Cross_Dresser",
		Satan = "achievement_More_Options___",
		Beast = "achievement_Ingestion_to_Night",
		Mother = "achievement_Black_Map",
		GreedMode = "achievement_Gold_Rush",
		Greedier = "achievement_glass_door2",
		Tainted = "achievement_tainted_WQ",
		--FullCompletion = "achievement_resistance",
	},
	Spwq = {
		--MegaSatan = "achievement_Air_Terror",
		Lamb = "achievement_Air_Flight",
		BlueBaby = "achievement_The_Watcher",
		Hush = "achievement_Soul_of_WQ",
		BossRush = "achievement_Giant_Punch",
		Delirium = "achievement_Memory",
		Isaac = "achievement_Field",
		Satan = "achievement_Little_Duck",
		Beast = "achievement_My_Best_Friend",		--重新确认。
		Mother = "achievement_Super_Bombs",
		GreedMode = "achievement_Fate_s_Draw",
		Greedier = "achievement_Brimstream",
		--FullCompletion = "achievement_Shooting_Underground",
	},
	glaze = {
		Isaac = "achievement_Glaze_Dice_Shard",
		Maggy = "achievement_Glaze_Heart",
		Cain = "achievement_Glaze_Key",
		Judas = "achievement_Glaze_Champion",
		BlueBaby = "achievement_Glaze_Poop",
		Eve = "achievement_Glaze_Bomb",
		Samson = "achievement_Glaze_Chest",
		Azazel = "achievement_Glaze_Brimstone",
		Lazarus = "achievement_Glaze_Pill",
		Eden = "achievement_Glaze_Grabbag",
		Lost = "achievement_Glaze_Item",
		Lilith = "achievement_Glaze_Machine",
		Keeper = "achievement_Glaze_Coin",
		Apollyon = "achievement_Glaze_Fly",
		Forgotten = "achievement_Glaze_Wing",
		Bethany = "achievement_Glaze_Battery",
		Jacob_and_Esau = "achievement_Glaze_Curse",
		
		Isaac_t = "achievement_Feels_Like_Dead_Ash",
		Maggy_t = "achievement_Fans_Service",
		Cain_t = "achievement_Fusion_Destiny",
		Judas_t = "achievement_Dark_Burier",
		BlueBaby_t = "achievement_Global_Pandemic",
		Eve_t = "achievement_Dissipative_Mode",
		Samson_t = "achievement_Kill_a_thousand",
		Azazel_t = "achievement_",
		Lazarus_t = "achievement_Fake_Image",
		Eden_t = "achievement_Unstable",
		Lost_t = "achievement_Lost_Sleeps_Well",
		Lilith_t = "achievement_",
		Keeper_t = "achievement_Louver_Problem",
		Apollyon_t = "achievement_",
		Forgotten_t = "achievement_Gotta_Kick_Them_All",
		Bethany_t = "achievement_",
		Jacob_and_Esau_t = "achievement_Heterothermal_Concentric",
	},
	others = {
		Ending1 = {
			"achievement_My_Emblem",
			"achievement_My_Hat",
		},
		Ending2 = {},
		Ending3 = {},
		Crush = {"achievement_Hyper_Velocity"},
		Thoth = {"achievement_Book_of_Thoth"},
		Future = {"achievement_Book_of_Future"},
	},
}

return enums
