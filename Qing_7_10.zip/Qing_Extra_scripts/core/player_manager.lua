local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")

local modReference
local player_manager = {
	items = {},
}

function player_manager.Init(mod)
	modReference = mod
	table.insert(player_manager.items,#player_manager.items + 1,require("Qing_Extra_scripts.player.player_wq"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Qing_Extra_scripts.player.player_Spwq"))
	table.insert(player_manager.items,#player_manager.items + 1,require("Qing_Extra_scripts.player.player_Tecro"))
end

return player_manager
