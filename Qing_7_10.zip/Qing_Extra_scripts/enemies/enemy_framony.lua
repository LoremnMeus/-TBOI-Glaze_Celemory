local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local board = require("Qing_Extra_scripts.Enemies.enemy_check_board")
local piece = require("Qing_Extra_scripts.Enemies.enemy_check_piece")
local staff = require("Qing_Extra_scripts.Enemies.enemy_staff_strike")
local option_index_holder = require("Qing_Extra_scripts.others.Option_Index_holder")

local item = {
	ToCall = {},
	post_ToCall = {},
	enemy = enums.Enemies.framony,
	targ_place = {
		[0] = {
			Vector(80,40),Vector(80,-40),Vector(40,80),Vector(-40,80),Vector(-80,40),Vector(-80,-40),Vector(40,-80),Vector(-40,-80),
		},
		[1] = {
			{
			Vector(40,40),Vector(40,80),Vector(40,0),Vector(40,-40),Vector(40,-80),
			},
			{
			Vector(-40,40),Vector(-40,80),Vector(-40,0),Vector(-40,-40),Vector(-40,-80),
			},
			{
			Vector(40,40),Vector(80,40),Vector(0,40),Vector(-40,40),Vector(-80,40),
			},
			{
			Vector(40,-40),Vector(80,-40),Vector(0,-40),Vector(-40,-40),Vector(-80,-40),
			},
		},
		[2] = {
			{
			Vector(40,40),Vector(40,-40),Vector(-40,-40),Vector(-40,40),
			},
			{
			Vector(80,80),Vector(80,-80),Vector(-80,-80),Vector(-80,80),
			},
			{
			Vector(80,0),Vector(0,80),Vector(-80,0),Vector(0,-80),
			},
			{
			Vector(40,0),Vector(0,40),Vector(-40,0),Vector(0,-40),
			},
		},
		[3] = {
			{
			Vector(40,40),Vector(40,-40),Vector(-40,-40),Vector(-40,40),
			},
			{
			Vector(80,0),Vector(0,80),Vector(-80,0),Vector(0,-80),
			},
		},
		[4] = {
			{
			Vector(40,40),Vector(40,80),Vector(40,0),Vector(40,-40),Vector(40,-80),Vector(40,-120),Vector(40,120),
			},
			{
			Vector(-40,40),Vector(-40,80),Vector(-40,0),Vector(-40,-40),Vector(-40,-80),Vector(-40,-120),Vector(-40,120),
			},
			{
			Vector(40,40),Vector(80,40),Vector(0,40),Vector(-40,40),Vector(-80,40),Vector(-120,40),Vector(120,40),
			},
			{
			Vector(40,-40),Vector(80,-40),Vector(0,-40),Vector(-40,-40),Vector(-80,-40),Vector(-120,-40),Vector(120,-40),
			},
			{
			Vector(40,40),Vector(40,-40),Vector(-40,-40),Vector(-40,40),Vector(-80,80),Vector(-80,-80),Vector(80,-80),Vector(80,80),
			},
			{
			Vector(80,80),Vector(80,-80),Vector(-80,-80),Vector(-80,80),Vector(-80,0),Vector(80,0),Vector(0,-80),Vector(0,80),
			},
			{
			Vector(80,0),Vector(0,80),Vector(-80,0),Vector(0,-80),Vector(-40,0),Vector(0,-40),
			},
			{
			Vector(40,0),Vector(0,40),Vector(-40,0),Vector(0,-40),Vector(-80,0),Vector(0,-80),
			},
		},
	},
	tosay = {word = {},},
	Talking_Pos_Offset =  Vector(30,-50),
}

local function add_flip(npc)
	local v = npc.Velocity
    if v.X < -0.0005 then
        npc:GetSprite().FlipX = true
    elseif v.X > 0.0005 then
        npc:GetSprite().FlipX = false
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = 996,	--初始化
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.State == nil then
			d.State = 0
		end
		d.Should_Move = false
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_PLAYEROBJECTS
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		if desc.Data.Variant >= 23752 and desc.Data.Variant <= 23762 then
			s:Play("Idle",true)
		else
			s:Play("Speak",true)
			if d.tosay == nil then d.tosay = {} end
			if d.tosay.word == nil then d.tosay.word = {} end
			table.insert(d.tosay.word,{name = "奇怪……我好像不应该出现在这里…",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "算了，那么就就此一战吧！",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			ent.MaxHitPoints = 1996
			ent.HitPoints = 1996
			d.attack_now = true
		end
		ent:AddEntityFlags(EntityFlag.FLAG_NO_STATUS_EFFECTS)
		local is_wq = auxi.have_player(enums.Players.wq)
		local is_spwq = auxi.have_player(enums.Players.Spwq)
		if is_spwq or is_wq then
			if d.tosay == nil then d.tosay = {} end
			if d.tosay.word == nil then d.tosay.word = {} end
			if is_wq then
				table.insert(d.tosay.word,{name = "小青？？是你？？？",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "不对！",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "只是一个很相似的人罢了。",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "....",})
				table.insert(d.tosay.word,{name = "",})
			elseif is_spwq then
				table.insert(d.tosay.word,{name = "小青？？你！！你怎么....",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "不对。小青已经....",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "哎....",})
				table.insert(d.tosay.word,{name = "",})
			end
			d.qing_appear = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--速度、位移调整
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.Should_Move and d.Should_Move == true then
		else
			if ent.Velocity:Length() > 0.05 then
				ent.Velocity = Vector(0,0)
			end
		end
		add_flip(ent)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--行为、战斗控制
Function = function(_,ent)
	local room = Game():GetRoom()
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		if d.State == nil then
			d.State = 0
		end
		
		if s:IsFinished("Appearing") then
			s:Play("Idle",true)
		end
		if s:IsPlaying("Idle") then			--检索阶段。	
			if d.wait_until then
				local should_start = false
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					if (player.Position - ent.Position):Length() < 150 then
						should_start = true
					end
				end
				if ent.HitPoints / ent.MaxHitPoints < 0.8 then
					d.wait_until = false
					d.attack_now = true
					d.normal = false
				end
				if should_start then
					s:Play("Speak",true)
					if d.tosay == nil then d.tosay = {} end
					if d.tosay.word == nil then d.tosay.word = {} end
					if d.qing_appear ~= true then
						table.insert(d.tosay.word,{name = "孩子，你已经不能继续前进了。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "回头吧，现在后悔，你还来得及。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "………",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					end
					table.insert(d.tosay.word,{name = "从来的门出去，在我变卦之前！",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "………………………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "……………………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "…………………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "………………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "……………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "…………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "………",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "……",})
					table.insert(d.tosay.word,{name = "",})
					table.insert(d.tosay.word,{name = "…",})
					table.insert(d.tosay.word,{name = "",should_do = function(params)
					if (MusicManager():GetCurrentMusicID() ~= 22) then
						local music = MusicManager()
						music:Play(22, 1)
						music:UpdateVolume()
					end
					end,param = {self = ent}})
					d.wait_until = false
					d.attack_now = true
				end
			else
				if d.attack_now then d.attack_now = false end
				if board.now_hold == nil or board.now_hold:Exists() == false then
					s:Play("Attack",true)
					d.State = 0		--math.random(5)
				end
				local rand = math.random(1000)
				local find_s = {{name = "attack_plan_A1",weight = 10,},}
				if board.now_hold and board.now_hold:Exists() then
					local n_ent = Isaac.GetRoomEntities()
					local n_piece = auxi.getothers(n_ent,996,enums.Enemies.chess_piece)
					--print(#n_piece)
					if item.lst ~= nil then
						table.insert(find_s,{name = item.lst.name,weight = math.ceil(0.5 * item.lst.weight),})
					end
					if #n_piece < 15 then		--特殊的召唤模式
						table.insert(find_s,{name = "attack_plan_A2",weight = 1,})
						table.insert(find_s,{name = "attack_plan_A3",weight = 1,})
						table.insert(find_s,{name = "attack_plan_A4",weight = 1,})
					end
					if #n_piece > 10 then		--高级buff
						table.insert(find_s,{name = "attack_plan_C",weight = 5,})
					end
					if #n_piece < 10 then		--简易召唤
						table.insert(find_s,{name = "attack_plan_D1",weight = 7,})
					end
					if #n_piece == 0 then
						table.insert(find_s,{name = "attack_plan_A5",weight = 9,})		--中场召唤
					end
					if #n_piece > 3 then		--加buff
						table.insert(find_s,{name = "attack_plan_D2",weight = 4,})
					end
					if #n_piece > 4 then
						table.insert(find_s,{name = "attack_plan_B",weight = 4,})		--杖击
					end
					if #n_piece > 10 then
						table.insert(find_s,{name = "attack_plan_B",weight = 4,})
						if d.normal ~= true then
							table.insert(find_s,{name = "attack_plan_B2",weight = 4,})
						end
					end
					if #n_piece > 20 then
						table.insert(find_s,{name = "attack_plan_B",weight = 2,})
						if d.normal ~= true then
							table.insert(find_s,{name = "attack_plan_B2",weight = 4,})
						end
					end
					if d.normal == true then
						table.insert(find_s,{name = "attack_plan_None",weight = math.max(1,(#n_piece) - 5)})
					end
				end
				
				local stag = find_s[1]
				local tot_wei = 0
				for u,v in pairs(find_s) do
					tot_wei = tot_wei + v.weight
				end
				tot_wei = math.random(tot_wei)
				for i = 1,#find_s do
					tot_wei = tot_wei - find_s[i].weight
					if tot_wei <= 0 then
						stag = find_s[i]
						break
					end
				end
				item.lst = stag
				
				if stag.name == "attack_plan_A1" then
					s:Play("Attack",true)
					d.Should_Move = false
					d.State = 0
				elseif stag.name == "attack_plan_A2" then
					s:Play("Attack",true)
					d.Should_Move = false
					d.State = 1
				elseif stag.name == "attack_plan_A3" then
					s:Play("Attack",true)
					d.Should_Move = false
					d.State = 2
				elseif stag.name == "attack_plan_A4" then
					s:Play("Attack",true)
					d.Should_Move = false
					d.State = 3
				elseif stag.name == "attack_plan_A5" then
					s:Play("Attack",true)
					d.Should_Move = false
					d.State = 4
				elseif stag.name == "attack_plan_B" then
					s:Play("Attack2",true)
					d.Should_Move = false
					d.State = 0
				elseif stag.name == "attack_plan_B2" then
					s:Play("Attack2",true)
					d.Should_Move = false
					d.State = 1
				elseif stag.name == "attack_plan_C" then
					s:Play("Attack3",true)
					d.Should_Move = false
					d.State = 0
				elseif stag.name == "attack_plan_D1" then
					s:Play("Attack4",true)
					d.Should_Move = false
					d.State = 0
				elseif stag.name == "attack_plan_D2" then
					s:Play("Attack4",true)
					d.Should_Move = false
					d.State = 1
				elseif stag.name == "attack_plan_None" then
					if d.tosay == nil then d.tosay = {} end
					if d.tosay.word == nil then d.tosay.word = {} end
					local rnd = math.random(15)
					if rnd == 1 then
						table.insert(d.tosay.word,{name = "对了，你听说过撒旦先生吗？",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "主人说有空的话一定要拜访下他。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "顺便带点治疗骨质疏松的药物",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 2 then
						table.insert(d.tosay.word,{name = "主人？他可是世界上最一流的炼金术师！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "说起来，你们也许还见过面呢！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 3 then
						table.insert(d.tosay.word,{name = "如果觉得力有不支的话，还是尽早从后门离开比较好哦！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "我会把你大败而归的消息告诉主人的。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 4 then
						table.insert(d.tosay.word,{name = "下棋？你说……",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "啊…………哈哈哈哈，其实我不会下国际象棋的啦！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 5 then
						table.insert(d.tosay.word,{name = "简单模式，不会为难你的。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "那么，试试这招！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 6 then
						table.insert(d.tosay.word,{name = "为什么我面无表情？",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "请不要问出这么失礼的话！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 7 then
						table.insert(d.tosay.word,{name = "其实你没有必要和我战斗。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "只要你能自己采集到石头的碎片的话。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 8 then
						table.insert(d.tosay.word,{name = "莱诺阿先生似乎也来到了这个地下室里。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "不知道哪里能见到他呢。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 9 then
						table.insert(d.tosay.word,{name = "友情提示，不要喝小缪做的药",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "尤其是在你选择了困难角色的情况下。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 10 then
						table.insert(d.tosay.word,{name = "呵呵....",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 11 then
						table.insert(d.tosay.word,{name = "哈欠....",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "好困....",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 12 then
						table.insert(d.tosay.word,{name = "你身上有种…奇怪的气味。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "不好闻！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 13 then
						table.insert(d.tosay.word,{name = "主人在哪？大概还是在不可见之界限里摸鱼吧…",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "你想见她？别想了！",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "我不会把你拉过去的，所以这话你听听就好。",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					elseif rnd == 14 then
						table.insert(d.tosay.word,{name = "你说你见过吟游诗人？",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "嗯……",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "也许这是他的又一个远房亲戚？",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					else
						table.insert(d.tosay.word,{name = "说起来，主人好像要求我放点水来着呢…",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "所以不妨听我讲讲故事？",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "不想听么？好吧好吧……",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
						table.insert(d.tosay.word,{name = "",})
					end
					s:Play("Speak",true)
					d.Should_Move = false
				end
			end
		end
		
		if s:IsPlaying("Speak") and s:GetFrame() == 2 then
			if d.tosay == nil then d.tosay = {} end
			if d.tosay.word == nil then d.tosay.word = {} end
			local word = d.tosay.word
			if #word == 0 then
				if d.quit_after_speak then
					s:Play("Leave",true)
				else
					s:Play("Idle",true)
				end
			else
				gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-#(word[1].name),0),Vector(0,-50),word[1].name,#(word[1].name) * 3 + 20,1,1,1,1,0)
				if word[1].should_do and word[1].param then
					word[1].should_do(word[1].param)
				end
				table.remove(word,1)
			end
		end
		local htptmul = 1
		if d.normal then htptmul = 0.4 end
		if s:IsPlaying("Attack") then
			if s:IsEventTriggered("Ask") then
				if board.now_hold == nil or board.now_hold:Exists() == false then
					board.start_(ent.Position)
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
						local door = room:GetDoor(slot)
						if (door) then
							door:Close()
						end
					end
				end
			end
			if s:IsEventTriggered("Call") then
				if board.now_hold == nil or board.now_hold:Exists() == false then
				else
					if d.State == nil then d.State = 0 end
					if d.State == 1 then		--一排车
						local rnd = math.random(#item.targ_place[1])
						for i = 1,#item.targ_place[1][rnd] do
							local q = piece.spawn(board.find_pos(ent.Position + item.targ_place[1][rnd][i]),Vector(0,0),2,ent,nil,htptmul)
						end
					elseif d.State == 2 then	--一片相
						local rnd = math.random(#item.targ_place[2])
						for i = 1,#item.targ_place[2][rnd] do
							local q = piece.spawn(board.find_pos(ent.Position + item.targ_place[2][rnd][i]),Vector(0,0),3,ent,nil,htptmul)
						end
					elseif d.State == 3 then	--四个卒
						local rnd = math.random(#item.targ_place[3])
						for i = 1,#item.targ_place[3][rnd] do
							local q = piece.spawn(board.find_pos(player.Position + item.targ_place[3][rnd][i]),Vector(0,0),5,ent,nil,htptmul)
						end
					elseif d.State == 4 then	--广域召唤术
						local rnd = math.random(#item.targ_place[4])
						for i = 1,#item.targ_place[4][rnd] do
							local q = piece.spawn(board.find_pos(ent.Position + item.targ_place[4][rnd][i]),Vector(0,0),math.random(5),ent,nil,htptmul)
						end
					else		--随机特招
						local rnd = math.random(5)
						local cnt = math.random(3)
						--print(rnd)
						for i = 1,cnt do
							local q = piece.spawn(board.find_pos(ent.Position + item.targ_place[0][math.random(#item.targ_place[0])]),Vector(0,0),rnd,ent,nil,htptmul)
						end
					end
				end
			end	
		end
		
		if s:IsPlaying("Attack4") then
			if s:IsEventTriggered("Call") then
				if board.now_hold == nil or board.now_hold:Exists() == false then
				else
					if d.State == nil then d.State = 0 end
					if d.State == 1 then		--挂个buff
						local n_ent = Isaac.GetRoomEntities()
						local n_piece = auxi.getothers(n_ent,996,enums.Enemies.chess_piece)
						for i = 1,#n_piece do
							n_piece[i].MaxHitPoints = n_piece[i].MaxHitPoints + 50
							n_piece[i].HitPoints = n_piece[i].MaxHitPoints
							Isaac.Spawn(1000,49,0,n_piece[i].Position + Vector(0,-20) + n_piece[i].Velocity,Vector(0,0),ent)
							n_piece[i]:SetColor(Color(1.0, 0.0, 0.0, 1.0, 0, 0, 0),50,50,true,true)
						end
						sound_tracker.PlayStackedSound(129,1,1,false,0,2)
					else		--简易召唤
						local cnt = math.random(2)
						--print(rnd)
						for i = 1,cnt do
							local rnd = math.random(5)
							local q = piece.spawn(board.find_pos(ent.Position + item.targ_place[0][math.random(#item.targ_place[0])]),Vector(0,0),rnd,ent,nil,htptmul)
						end
					end
				end
			end	
		end
		
		if s:IsPlaying("Attack2") then
			if s:IsEventTriggered("Call") then
				if d.State == 1 then
					local rnd = math.random(7)
					for i = 1,rnd do
						delay_buffer.addeffe(function(params)
							local rd = math.random(2) - 1
							staff.spawn(player.Position,player.Velocity,rd,ent,player)
						end,{},(i - 1)*10)
					end
					d.fc = rnd * 10 + 15
				else
					local rnd = math.random(5)
					for i = 1,rnd do
						delay_buffer.addeffe(function(params)
							local rd = 0
							staff.spawn(player.Position,player.Velocity,rd,ent,player)
						end,{},(i - 1)*20)
					end
					d.fc = rnd * 20 + 15
				end
			end
			if s:GetFrame() == 32 then
				if d.fc == nil then d.fc = 0 end
				if d.fc > 0 then
					d.fc = d.fc - 1
					s:SetFrame(31)
				end
			end
		end
		
		if s:IsPlaying("Attack3") then		--加buff
			if s:IsEventTriggered("Call") == true then
				local n_ent = Isaac.GetRoomEntities()
				local n_piece = auxi.getothers(n_ent,996,enums.Enemies.chess_piece)
				for i = 1,#n_piece do
					if n_piece[i]:GetData().invi == nil then n_piece[i]:GetData().invi = 0 end
					n_piece[i]:GetData().invi = n_piece[i]:GetData().invi + 150
					n_piece[i]:SetColor(Color(1,1,1,1,0.5,0.5,0.5),150,10,true,false)
					piece.alt(n_piece[i])
				end
			end
		end
		
		if s:IsFinished("Attack") then
			s:Play("Idle",true)
		end
		if s:IsFinished("Leave") then
			ent:Remove()
		end
		if s:IsFinished("Attack2") then
			s:Play("Idle",true)
		end
		if s:IsFinished("Attack3") then
			s:Play("Idle",true)
		end
		if s:IsFinished("Attack4") then
			s:Play("Idle",true)
		end
		
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 996,	--自己写个减伤
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if s:IsPlaying("Speak") then 
			if d.attack_now then
				d.tosay.word = {}
				if (MusicManager():GetCurrentMusicID() ~= 22) then
					local music = MusicManager()
					music:Play(22, 1)
					music:UpdateVolume()
				end
				s:Play("Idle",true)
			end
			return false
		end
		if s:IsPlaying("Leave") or s:IsFinished("Leave") then
			return false
		end
		
		if flag & DamageFlag.DAMAGE_CLONES == 0 then
			local mtct = piece.multi_counter
			if mtct == nil then mtct = 0 end
			if mtct >= 0 and mtct <= 5 then		--棋子数量多和少都会引发百分比减伤。5个棋子时达到最小减伤。
				amt = amt * (0.25 + mtct * 0.15)
			else
				amt = amt * math.max(0.05,1 - (mtct - 5) * 0.07)
			end
			ent:TakeDamage(amt,flag | DamageFlag.DAMAGE_CLONES,EntityRef(player),cooldown)
			return false
		end
		
		if d.now_hitpoint ~= nil and d.now_hitpoint == ent.HitPoints then
			if d.have_take_damage == nil then
				d.have_take_damage = 0
			end
		else
			d.now_hitpoint = ent.HitPoints
			d.have_take_damage = 0
		end
		d.have_take_damage = d.have_take_damage + amt
		
		if amt > 50000 then
			if d.tosay == nil then d.tosay = {} end
			if d.tosay.word == nil then d.tosay.word = {} end
			table.insert(d.tosay.word,{name = "什么玩意啊！这个攻击力！",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "老娘不奉陪了！",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "再见再见！！",})
			table.insert(d.tosay.word,{name = "",})
			table.insert(d.tosay.word,{name = "",})
			s:Play("Speak",true)
			d.quit_after_speak = true
			ent.HitPoints = 1
			return false
		end
		
		--print(amt.." "..d.have_take_damage.." "..ent.HitPoints)
		if d.have_take_damage >= ent.HitPoints - 1 then
			--print("pre_leave")
			if d.normal and d.normal == true then
				if d.tosay == nil then d.tosay = {} end
				d.tosay.word = {}
				table.insert(d.tosay.word,{name = "你的实力很强大。",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "主人肯定会很高兴的。",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "那么，我承认，这次的胜者是你。",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "作为打扰的补偿，胜者可以从以下五个奖励中选择其一带走。",})
				table.insert(d.tosay.word,{name = "",should_do = function(params)
						local room = Game():GetRoom()
						local pos = Vector(200,200)
						if params.self then pos = params.self.Position end
						local to_award = {}
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 0,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 100,SubType = 619,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 100,SubType = 173,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 100,SubType = 156,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 100,SubType = 206,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 100,SubType = 233,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 23,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 24,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 25,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 26,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 31,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 43,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 78,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = 80,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 300,SubType = enums.Cards.Glaze_dice_shard,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 40,SubType = 7,Type = 5,wei = 3,})
						table.insert(to_award,{Variant = 57,SubType = 0,Type = 5,wei = 3,})
						table.insert(to_award,{Variant = 90,SubType = 4,Type = 5,wei = 1,})
						table.insert(to_award,{Variant = 70,SubType = 14,Type = 5,wei = 2,})
						table.insert(to_award,{Variant = 70,SubType = 2062,Type = 5,wei = 3,})
						local wei = 0
						for i = 1,#to_award do
							wei = wei + to_award[i].wei
						end
						local only = math.random(5)
						local ndx = option_index_holder.find_a_new_index()
						for i = 1,5 do
							local rng = math.random(wei)
							local ent = {Variant = 100,SubType = 0,Type = 5,wei = 10,}
							if only == i then
								ent = {Variant = 300,SubType = 42,Type = 5,wei = 10,}
							else
								for i = 1,#to_award do
									rng = rng - to_award[i].wei
									if rng <= 0 then
										ent.Variant = to_award[i].Variant
										ent.Type = to_award[i].Type
										ent.SubType = to_award[i].SubType
										if to_award[i].Special then 
											ent = to_award[i].Special()
										end
										table.remove(to_award,i)
										break
									end
								end
							end
							local q = Isaac.Spawn(ent.Type,ent.Variant,ent.SubType,room:FindFreePickupSpawnPosition(pos + Vector(-240 + i * 80,100),10,true),Vector(0,0),nil):ToPickup()
							q.OptionsPickupIndex = ndx
						end
					end,param = {self = ent},
				})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "另，祝。今日好运。",})
				s:Play("Speak",true)
				d.quit_after_speak = true
			else
				d.leave_safely = true
				ent.HitPoints = 1
				if d.tosay == nil then d.tosay = {} end
				d.tosay.word = {}
				s:Play("Speak",true)
				table.insert(d.tosay.word,{name = "你是胜者。",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "我不清楚你用了什么把戏",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "愿你得到你应得的",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "",})
				table.insert(d.tosay.word,{name = "死亡。",should_do = function(params)
					if params.self then
						local room = Game():GetRoom()
						local q = Isaac.Spawn(5,300,42,room:FindFreePickupSpawnPosition(params.self.Position,10,true),Vector(0,0),nil):ToPickup()
					end
				end,param = {self = ent},})
				d.quit_after_speak = true
			end
			return false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 23752 and desc.Data.Variant <= 23762 and (stage == LevelStage.STAGE2_1 or stage == LevelStage.STAGE2_2) and stageType >= StageType.STAGETYPE_REPENTANCE and room:IsFirstVisit() and save.elses.has_seen_framony ~= true then
		local q = Isaac.Spawn(996,item.enemy,0,Vector(320,250),Vector(0,0),nil)
		room:SetWallColor(Color(0.5, 0.5, 0.5, 1, -0.1, -0.1, -0.1))
		if (MusicManager():GetCurrentMusicID() ~= 116) then
			local music = MusicManager()
			music:Play(116, 1)
			music:UpdateVolume()
		end
		local d = q:GetData()
		d.wait_until = true
		q.MaxHitPoints = 500
		q.HitPoints = 500
		d.normal = true
		save.elses.has_seen_framony = true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.has_seen_framony = false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	save.elses.has_seen_framony = false
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,	--防止某些奇怪情况
Function = function(_,ent,col,low)
	if (ent.Variant == 45 or ent.Variant == 9) and col.Variant == item.enemy and col.Type == 996 then
		return false
	end
end,
})

--l local q = Isaac.Spawn(996,23751,0,Vector(400,300),Vector(0,0),nil);local s = q:GetSprite();s:ReplaceSpritesheet(0, "gfx/enemies/pawn_pieces.png");s:LoadGraphics();print(q.Mass);

return item