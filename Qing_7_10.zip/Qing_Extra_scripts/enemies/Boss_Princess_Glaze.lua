local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	Talking_Pos_Offset = Vector(30,-50),
	Words = {
		en = {
			welcome = {
				Normal = {
					Pr = {
						"Hello",
						"I'm Princess The Glaze",
						"The Load of a Kingdom",
						"",
					},
					Pl = {
						[4] = "...",
						[5] = "Would you ... let me go ?"
					},
					words = 5,
				},
				WQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 4,
				},
				SPWQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 4,
				},
				Girl = {
					Pr = {
						"Sorry that I have to refuse your request..",
					},
					Pl = {
						"ohh....",
					},
					words = 1,
				},
			},
			refuse = {
				Normal = {
					Pr = {
						"Of course..NO!!!",
					},
					Pl = {
						"",
					},
					words = 1,
				},
				Girl = {
					Pr = {
						"Sorry that I have to refuse your request..",
					},
					Pl = {
						"ohh....",
					},
					words = 1,
				},
				WQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 1,
				},
				SPWQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 1,
				},
			},
			battle = {
				Tear = "",
				Brim = "",
			},
			temp = {
				
			},
		},
		zh = {
			welcome = {
				Normal = {
					Pr = {
						"你好。沉迷于幻想中的孩子。",
						"吾名，琉璃。",
						"为一国之王子。",
						"来此欲寻仇人。",
					},
					Pl = {
						[3] = "...",
						[4] = "那你为啥要挡我的在面前？",
						[5] = "能让我绕过去么？",
					},
					words = 5,
				},
				WQing = {
					Pr = {
						"哈哈哈哈！！！！",
						"万青，我可终于找到你了！！",
						"真是踏破铁鞋无觅处，得来全不费工夫！",
						"为什么不能是我？",
						"哦？",
						"在这个世界线上，我可是无敌的存在！",
						"",
						"你的同伴？我才懒得管他们！就让他们好好歇歇吧..",
						"就以一生的轮回为周期好了哦..",
					},
					Pl = {
						"！",
						"",
						"怎么是你！！琉璃！",
						"我还以为...我的同伴们会拖住你..",
						"确实..一路上我见到了他的下属们..",
						"但..",
						"可恶!",
						"",
						"",
						"怎么可能！你肯定存在着弱点！",
					},
					words = 10,
				},
				SPWQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 1,
				},
				Girl = {
					Pr = {
						"Sorry that I have to refuse your request..",
					},
					Pl = {
						"ohh....",
					},
					words = 1,
				},
			},
			refuse = {
				Normal = {
					Pr = {
						"你认为呢？",
					},
					Pl = {
						"果然还是不行啊..",
					},
					words = 1,
				},
				WQing = {
					Pr = {
						"这样的东西...是没有的哦！！",
					},
					Pl = {
						"该死...",
					},
					words = 1,
				},
				SPWQing = {
					Pr = {
						"...",
					},
					Pl = {
						"...",
					},
					words = 1,
				},
				Girl = {
					Pr = {
						"非常抱歉，女士。前方是禁止区域。",
					},
					Pl = {
						"啊....",
					},
					words = 1,
				},
			},
			battle = {
				Normal = {
					"那么..不试着放马攻过来么？",
					"我最喜欢做的事，",
					"就是在敌人最擅长的方面上击败他们！",
					"来吧！展现你的攻势吧！",
					"5",
					"4",
					"3",
					"2",
					"1",
					"0!",
				},
				Wait = {
					"怎么？失去信心了？",
					"居然放弃了抵抗么..",
					"那就由我来送你归西！",
				},
				Tear = {
					"哦？你打算就用这脆弱的眼泪战胜我么？",
					"可笑的尝试！",
					"就让我来向你展示！",
					"眼泪射击的极限好了！",
					Eye = {
						"有点恶心哦..",
						"勉强也模仿试试好了..",
					},
					Diamond = {
						"钻石么..",
						"我倒是想起了我的那个好友。",
						"相信在地狱的他一定也会欢迎你吧！",
					},
				},
				Brim =  {
					"硫磺的味道...",
					"勉强算是不错的攻势吧！但是..",
					"试试这个！",
					"如何？我可是琉璃的化身！",
					"无效！任何企图穿透我的攻击都会为我所用！",
				},
				Bomb = {
					"决定使用炸弹了？",
					"你不会真的以为，真实伤害会对我造成什么影响吧？",
					"别发呆了！我的身体可是无敌的存在！",
				},
				Knife = {
					"小孩子可不要玩菜刀哦！",
					"喂！说你呢！听到没有？",
					"还不快把刀收起来！",
					"如果不愿意的话，那就我来帮你！",
				},
				Epic = {
					"",
				},
				Tech = {
					"",
				},
				TechX = {
					"",
				},
				Fetus = {
					"",
				},
				Dr = {
					"发射炸弹？好有趣的能力。",
					"就让我来试试看好了哦..",
				},
				Sword = {
					"如此脆弱的玩具剑！",
					"不要以为只凭借情怀就能战胜一切啊！",
				},
				StabKnife = {
					"贫弱贫弱贫弱！",
					"不论再刺多少下，也永远不能影响我！",
				},
				Rain = {
					"雨水的力量么..",
					"我也有一些控制的心得呢！",
					"要不要试试看啊！",
				},
				Damo = {
					"",
				},
				Frame = {
					"火焰..",
					"我已经不是当年的我了！",
					"不要以为同样的招式可以生效两次！",
				},
				Unknown = {
					"唔..是未确认过的诡计么...",
					"虽然不能立刻模仿，但我也有你不能学习的一手！",
					"那就比比看啊！",
				},
				Console = {
					"作弊的味道...",
					"说你呢！你在做些什么！",
					"只要这么做的话...",
					Debug_10 = {
						"停下来！",
						"哼！！",
						command = {
							"Game:Attack(Player,per minute)",
						},
					},
					Debug_3 = {
						"停下来！",
						"哼！！",
						command = {
							"Game:AddHealth(Princess The Glaze,1000 lifepoints)",
						},
					},
					Try_Open = {
						"现在！控制台禁止！",
					},
					Friend = {
						"原来是主人！失敬失敬！",
						"我不会干扰您的工作的。",
					},
				},
			},
			temp = {
				Normal = {
					Pr = {
						"真是遗憾啊",
						"",
						"我的对战还没有做完呢！",
						"",
						"所以你只能到达这里了哦！",
						"",
						"不过至少，我能解锁你的成就，对吧？",
						"",
					},
					Pl = {
						"",
					},
					words = 5,
				},
			},
		},
	},
	Should_Stop_Player = 0,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player)
	if item.Should_Stop_Player and item.Should_Stop_Player > 0 then
		player:AddControlsCooldown(1)
		item.Should_Stop_Player = item.Should_Stop_Player - 1
	end
end,})

function item.Check(ent)
	if true then
		local d = ent:GetData()
		local language = Options.Language
		if item.Words[language] == nil then
			language = "en"
		end
		d.battle_word = item.Words[language].battle.Tear
		d.Speaking_Battleid = 1
		d.battle_delay = (#d.battle_word) or 3
		return 1
	end	
end

local function add_velocity_and_flip(npc, velocity)
    npc:AddVelocity(velocity)
    if velocity.X < 0 then
        npc:GetSprite().FlipX = true
    else
        npc:GetSprite().FlipX = false
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = 996,	--初始化
Function = function(_,ent)
	if ent.Variant == enums.Enemies.Princess_Glaze then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.State == nil then
			d.State = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,		--速度、位移调整
Function = function(_,cmd,params)
	--print(cmd)
	--print(params)
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--速度、位移调整
Function = function(_,ent)
	if ent.Variant == enums.Enemies.Princess_Glaze then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		if d.Should_Speed_down and d.Should_Speed_down == true then
			if ent.Velocity:Length() > 0.05 then
				ent.Velocity = ent.Velocity * 0.95
			end
		end
		if d.Should_Still and d.Should_Still == true then
			if ent.Velocity:Length() > 0.05 then
				ent.Velocity = Vector(0,0)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--行为、战斗控制
Function = function(_,ent)
	if ent.Variant == enums.Enemies.Princess_Glaze then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		if d.State == nil then
			d.State = 0
		end
		if d.State == 0 then		--出场阶段，以及一些欢迎的话。
			if s:IsFinished("Appear") then
				s:Play("Idle_Speaking")
			end
			if s:IsPlaying("Idle_Speaking") then
				--player:AddControlsCooldown(2)
				item.Should_Stop_Player = 100
				if s:IsEventTriggered("Speak") then
					if d.Speaking_Welcomeid == nil then
						d.Speaking_Welcomeid = 1
						local language = Options.Language
						if item.Words[language] == nil then
							language = "en"
						end
						if player:GetName() == "SP.W.Qing" then
							d.tosay = item.Words[language].welcome.SPWQing
						elseif player:GetName() == "W.Qing" then
							d.tosay = item.Words[language].welcome.WQing
						elseif player:GetName() == "SP.W.Qing" then
							d.tosay = item.Words[language].welcome.Normal
						else
							d.tosay = item.Words[language].welcome.Normal
						end
					end
					if d.tosay and d.tosay.Pr and d.tosay.words >= d.Speaking_Welcomeid then
						if d.tosay.Pr[d.Speaking_Welcomeid] and d.tosay.Pr[d.Speaking_Welcomeid] ~= "" then
							gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay.Pr[d.Speaking_Welcomeid])/2,0),Vector(0,-50),d.tosay.Pr[d.Speaking_Welcomeid],#d.tosay.Pr[d.Speaking_Welcomeid] * 3 + 20)
						end
					end
				elseif s:IsEventTriggered("Speak2") then
					if d.tosay and d.tosay.Pl and d.tosay.words > d.Speaking_Welcomeid then
						if d.tosay.Pl[d.Speaking_Welcomeid] and d.tosay.Pl[d.Speaking_Welcomeid] ~= "" then
							gui.draw_ch_with_time_to_dispair(player.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay.Pl[d.Speaking_Welcomeid])/2,0),Vector(0,-50),d.tosay.Pl[d.Speaking_Welcomeid],#d.tosay.Pl[d.Speaking_Welcomeid] * 3 + 20)
						end
						d.Speaking_Welcomeid = d.Speaking_Welcomeid + 1
					else
						if d.tosay and d.tosay.Pl and d.tosay.words == d.Speaking_Welcomeid then
							if d.tosay.Pl[d.Speaking_Welcomeid] and d.tosay.Pl[d.Speaking_Welcomeid] ~= "" then
								gui.draw_ch_with_time_to_dispair(player.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay.Pl[d.Speaking_Welcomeid])/2,0),Vector(0,-50),d.tosay.Pl[d.Speaking_Welcomeid],#d.tosay.Pl[d.Speaking_Welcomeid]* 3 + 20)
							end
						end
						d.Speaking_Welcomeid = 1
						d.pre_state = 0		--提示符号
						d.State = 1
					end
				end
			end
			d.Should_Still = true
		end
	
		if d.State == 1 then		--进入战斗阶段。
			if s:IsPlaying("Idle_Speaking") and d.pre_state and d.pre_state == 0then
				--player:AddControlsCooldown(2)
				item.Should_Stop_Player = 100
			end
			if s:IsPlaying("Idle_Speaking") and s:GetFrame() == 29 and d.pre_state and d.pre_state == 0 then
				s:Play("Idle_Shake_Head")
				d.pre_state = 1
			end
			if s:IsPlaying("Idle_Shake_Head") then
				--player:AddControlsCooldown(2)
				item.Should_Stop_Player = 100
				if s:IsEventTriggered("Speak") then
					local language = Options.Language
					if item.Words[language] == nil then
						language = "en"
					end
					if player:GetName() == "SP.W.Qing" then
						d.tosay = item.Words[language].refuse.SPWQing
					elseif player:GetName() == "W.Qing" then
						d.tosay = item.Words[language].refuse.WQing
					elseif player:GetName() == "SP.W.Qing" then
						d.tosay = item.Words[language].refuse.Normal
					else
						d.tosay = item.Words[language].refuse.Normal
					end
					if d.tosay and d.tosay.Pr then
						if d.tosay.Pr[1] and d.tosay.Pr[1] ~= "" then
							gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay.Pr[1])/2,0),Vector(0,-50),d.tosay.Pr[1],#d.tosay.Pr[1] * 3 + 20)
						end
					end
				elseif s:IsEventTriggered("Speak2") then
					if d.tosay and d.tosay.Pl then
						if d.tosay.Pl[1] and d.tosay.Pl[1] ~= "" then
							gui.draw_ch_with_time_to_dispair(player.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay.Pl[1])/2,0),Vector(0,-50),d.tosay.Pl[1],#d.tosay.Pl[1] * 3 + 20)
						end
					end
				end
			end
			if s:IsFinished("Idle_Shake_Head")then
				local scr = gui.GetScreenSize()
				local q1 = Isaac.Spawn(1000,enums.Entities.ID_EFFECT_MeusNIL,0,Vector(scr.X/2,scr.Y * 0.75),Vector(0,0),nil) --Isaac.WorldToRenderPosition(gui.GetScreenSize())
				q1:GetData().removecd = 102
				local s2 = q1:GetSprite()
				s2:Load("gfx/ui/boss/to_versusscreen.anm2")
				s2:SetOverlayRenderPriority(true)
				s2:ReplaceSpritesheet(7,"gfx/ui/boss/Bossname_Princess_glaze.png")
				s2:ReplaceSpritesheet(4,"gfx/ui/boss/portrait_Princess_glaze.png")
				s2:LoadGraphics()
				s2:Play("Scene")
				s:Play("Idle")
				d.battle_screen = q1
				local language = Options.Language
				if item.Words[language] == nil then
					language = "en"
				end
				d.battle_word = item.Words[language].battle.Normal
				d.Speaking_Battleid = 1
			end
			if s:IsPlaying("Idle") and d.battle_state == nil then
				if d.battle_screen and d.battle_screen:Exists() == true then
					hud:SetVisible(false)
					--player:AddControlsCooldown(2)
					item.Should_Stop_Player = 100
				end
			end
			--l if Game():GetPlayer(0):player:AddControlsCooldown(2);AreControlsEnabled() then print("yes") end 
			if d.battle_state == nil or d.battle_state == 0 then		--单独监视
				d.Should_Still = true
			else
				d.Should_Still = false
			end
			
			if d.battle_screen and d.battle_screen:Exists() == false then
				item.Should_Stop_Player = 0
				if hud:IsVisible() == false then
					hud:SetVisible(true)
				end
				if d.battle_state == nil or d.battle_state == 0 then
					if (s:IsPlaying("Idle") or s:IsPlaying("Idle_Speaking"))and s:IsEventTriggered("End") then
						if d.battle_state == nil then
							d.battle_state = 0			--0代表等待对方出招。
							d.battle_delay = (#d.battle_word) or 3
							d.Speaking_Battleid = 1
							s:Play("Idle_Speaking",true)
							d.start_trigger_end = true
						end
					end
				elseif d.battle_state == 1 then
					if s:IsPlaying("Attack1") and s:IsEventTriggered("Fire") then
						if math.random(1000) > 900 then
							local dir = (player.Position - ent.Position):Normalized()
							ent:AddVelocity(dir * 10)
							d.Should_Speed_down = true
						end
						local rand_ang = math.random(36000)/100
						local rand = math.random(4) + 6
						for i = 1,rand do
							local q1 = Isaac.Spawn(9, 6, 0, ent.Position, Vector(0,0), ent):ToProjectile()
							q1:AddProjectileFlags(1<<13)
							q1:SetColor(Color(1,1,1,0.5,0,0,0),-1,0,false,true)
							q1.FallingAccel = -0.08
							--q1.Scale = 5
							q1:SetSize(30,Vector(1,1),1)
							local s2 = q1:GetSprite()
							s2.Offset = Vector(0,-30)
							s2.Scale = Vector(3,3)
							delay_buffer.addeffe(function(params)
								params.ent.Velocity = params.velocity
							end,{velocity = auxi.MakeVector(i * 360/rand + rand_ang) * 5,ent = q1,},15)
							delay_buffer.addeffe(function(params)
								if params.ent:Exists() then
									local rnd = math.random(3) + 4
									for i = 1, rnd do
										local q1 = Isaac.Spawn(9, 6, 0, params.ent.Position, auxi.MakeVector(i * 360/rnd) * 3 , ent):ToProjectile()
										q1:AddProjectileFlags(1<<13)
										q1:SetColor(Color(1,1,1,0.3,0,0,0),-1,0,false,true)
										q1.FallingAccel = -0.08
										q1:SetSize(5,Vector(1,1),1)
										local s2 = q1:GetSprite()
										s2.Offset = Vector(0,0)
										s2.Scale = Vector(0.75,0.75)
									end
								end
							end,{ent = q1,},90)
						end
					end
				end
				if s:IsEventTriggered("End") and d.start_trigger_end and d.start_trigger_end == true then		--结算一次。
					if d.battle_delay and d.battle_delay > 0 then
						d.battle_delay = d.battle_delay - 1
					end
					if d.battle_delay <= 0 then
						d.battle_state = item.Check(ent)
						if d.battle_state ~= 0 then
							local rand = math.random(1000)
							if rand < 300 then		--3种攻击模式。
								s:Play("Attack1",true)	
							elseif rand < 600 then
								s:Play("Attack1",true)
							else 
								s:Play("Attack1",true)
							end
						else
							s:Play("Idle_Speaking",true)
						end
					end
				end
				
				if s:IsEventTriggered("Speak") then		--说话。
					if d.battle_word and d.Speaking_Battleid then
						if d.Speaking_Battleid <= (#d.battle_word) then
							gui.draw_ch_dis_pos(ent.Position + item.Talking_Pos_Offset,Vector(0,-50),d.battle_word[d.Speaking_Battleid],3,20)
							d.Speaking_Battleid = d.Speaking_Battleid + 1
						else
							d.Speaking_Battleid = 1
						end
					end
				end	
			end
			
			--l q1 = Isaac.Spawn(9, 6, 0, Vector(200,200), Vector(0,0), nil):ToProjectile();q1:SetSize(1,Vector(1,1),30);s1 = q1:GetSprite();s1.Offset = Vector(0,-60);s1.Scale = Vector(5,5);q1.FallingAccel = -0.1;print(q1.FallingAccel)
		end
	end
end,
})

--[[
9.0：普通投掷物（红色）
9.1：骨头
9.2: 火焰
3: 便便
4: 发光（眼泪）
5: 玉米粒
6: 光亮（白色）
7；金币
8：Grid（投掷地形）
9：石头
10:
11:	哥布林
12: 史蒂芬
13：羽毛扫
14: 巨大岩浆球
15: 腐烂以撒
16: 眼球
--]]

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 996,
Function = function(_,ent, amt, flag, source, cooldown)
	if ent.Variant == enums.Enemies.Princess_Glaze then
		print(amt)
		print(flag)
		if source == nil then print("nil")
		else print(source.Type);print(source.Variant); end
		print(cooldown)
	end
end,
})

return item