local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	enemy = enums.Enemies.chess_board,
	find_place = {},
	find_place_ent = {},
	now_hold = nil,
}

function item.start_(pos)
	if item.now_hold == nil or item.now_hold:Exists() == false then
		local q = Isaac.Spawn(1000,item.enemy,0,Vector(0,-100),Vector(0,0),nil);
		if pos ~= nil then
			q:GetData().spawn_pos = pos
		end
	end
end

function item.check_pos(pos)
	local room = Game():GetRoom()
	local idx = room:GetGridIndex(pos)
	return ((item.find_place[idx] == true or (item.find_place[idx] and item.find_place[idx]>0)) and (item.find_place_ent[idx] == false))
end

function item.assign_pos(ppos,pos)
	local room = Game():GetRoom()
	local idx1 = room:GetGridIndex(ppos)
	local idx2 = room:GetGridIndex(pos)
	item.find_place_ent[idx1] = false
	item.find_place_ent[idx2] = true
end

function item.find_pos(pos)
	local room = Game():GetRoom()
	return room:GetGridPosition(room:GetGridIndex(pos))
end

local function add_velocity_and_flip(npc, velocity)
    npc:AddVelocity(velocity)
    if velocity.X < 0 then
        npc:GetSprite().FlipX = true
    else
        npc:GetSprite().FlipX = false
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_INIT, params = item.enemy,	--初始化（这是一个effect！！)
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if(item.now_hold ~= nil and item.now_hold:Exists()) then
			ent:Remove()
		else
			item.now_hold = ent
			for i = 1,500 do
				item.find_place[i] = 0
				item.find_place_ent[i] = false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = item.enemy,
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		local room = Game():GetRoom()
		local r = room:GetBottomRightPos()
		local r_id = room:GetGridIndex(r)
		for i = 1,r_id do
			if room:GetGridCollision(i) == GridCollisionClass.COLLISION_NONE and room:IsPositionInRoom(room:GetGridPosition(i),10) then
				if item.find_place[i] == nil then
					item.find_place[i] = 0
				end
				local dt_lg = 1
				if d.spawn_pos then
					dt_lg = 100/((room:GetGridPosition(i) - d.spawn_pos):Length()+1) + 1
				end
				if item.find_place[i] < 100 then
					item.find_place[i] = item.find_place[i] + dt_lg
				end
				
				if item.find_place[i] > 100 then
					item.find_place[i] = 100
				end
			else
				if item.find_place[i] == nil then
					item.find_place[i] = 0
				end
				if item.find_place[i] >= 1 then
					item.find_place[i] = item.find_place[i] - 1
				end
				if item.find_place[i] < 0 then
					item.find_place[i] = 0
				end
			end
			--item.find_place_ent[i] = false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_RENDER, params = item.enemy,
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local room = Game():GetRoom()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		for i = 1,500 do 
			if item.find_place[i] and item.find_place[i] > 0 then
				local wd_pos = room:GetGridPosition(i)
				if room:IsPositionInRoom(wd_pos,10) then
					local s2 = Sprite();
					s2:Load(s:GetFilename())
					local dx = i - (i //2) * 2
					if room:GetRoomShape() >= 6 and (i//28) - (i//28)//2 * 2 == 1 then dx = 1 - dx end
					if dx == 1 then
						s2:Play("Idle1")
					else
						s2:Play("Idle2")
					end
					s2:SetFrame(math.floor(item.find_place[i]))
					s2:RenderLayer(0,room:WorldToScreenPosition(wd_pos))
				end
			end
		end
	end
end,
})

--l local player = Game():GetPlayer(0);local room = Game():GetRoom();local pos_idx = room:GetGridIndex(player.Position);print(pos_idx);if room:GetGridCollision(pos_idx) == GridCollisionClass.COLLISION_NONE then print("Yes!") end;
--l local room = Game():GetRoom();player = Game():GetPlayer(0);local pos_idx = room:GetGridIndex(player.Position);print(room:GetGridPosition(pos_idx));print(player.Position);
--l local q = Isaac.Spawn(1000,23750,0,Vector(0,-100),Vector(0,0),nil);local s = q:GetSprite();s:ReplaceSpritesheet(0, "gfx/enemies/pawn_pieces.png");s:LoadGraphics();print(q.Mass);
	
return item