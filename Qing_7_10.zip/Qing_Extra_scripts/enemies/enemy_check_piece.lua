local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local board = require("Qing_Extra_scripts.Enemies.enemy_check_board")

local item = {
	ToCall = {},
	enemy = enums.Enemies.chess_piece,
	targ_place = {
		[2] = {
			Vector(40,0),Vector(-40,0),Vector(0,40),Vector(0,-40),
		},
		[3] = {
			Vector(40,40),Vector(-40,40),Vector(40,-40),Vector(-40,-40),
		},
		[4] = {
		Vector(80,40),Vector(80,-40),Vector(40,80),Vector(-40,80),Vector(-80,40),Vector(-80,-40),Vector(40,-80),Vector(-40,-80),
		},
		[5] = {
		Vector(40,0),Vector(-40,0),Vector(40,40),Vector(40,-40),Vector(-40,40),Vector(-40,-40),Vector(0,40),Vector(0,-40),
		},
	},
	multi_counter = 0,
}

local function add_flip(npc)
	local v = npc.Velocity
    if v.X < -0.0005 then
        npc:GetSprite().FlipX = true
    elseif v.X > 0.0005 then
        npc:GetSprite().FlipX = false
    end
end

function item.alt(ent)
	
end

function item.spawn(pos,vel,st,ent,hitpt,hitptmul,vel_add,vel_buff)
	if vel == nil then vel = Vector(0,0) end
	if st == nil then st = 0 end
	if board.check_pos(pos) == false then return nil end
	local q = Isaac.Spawn(996,item.enemy,0,pos,vel,ent)
	local d = q:GetData()
	d.type = st
	d.Spawner = ent
	local s = q:GetSprite()
	if st == 1 then
		s:ReplaceSpritesheet(0,"gfx/enemies/queen_pieces.png")
		d.vel_buffer = 0.1
		s:LoadGraphics()
	elseif st == 2 then
		s:ReplaceSpritesheet(0,"gfx/enemies/vehicle_pieces.png")
		d.vel_buffer = 0.2
		s:LoadGraphics()
	elseif st == 3 then
		s:ReplaceSpritesheet(0,"gfx/enemies/bishop_pieces.png")
		d.vel_buffer = 0.15
		s:LoadGraphics()
	elseif st == 4 then
		s:ReplaceSpritesheet(0,"gfx/enemies/knight_pieces.png")
		d.vel_buffer = 0.07
		d.vel_adder = 1
		d.range = 5
		s:LoadGraphics()
		q.MaxHitPoints = q.MaxHitPoints * 1.5
		q.HitPoints = q.HitPoints * 1.5
	elseif st == 5 then
		s:ReplaceSpritesheet(0,"gfx/enemies/pawn_pieces.png")
		d.vel_buffer = 0.4
		d.vel_adder = 2
		d.range = 5
		s:LoadGraphics()
	end
	if hitpt then 
		q.MaxHitPoints = hitpt
		q.HitPoints = hitpt
	end
	if hitptmul then
		q.MaxHitPoints = q.MaxHitPoints * hitptmul
		q.HitPoints = q.HitPoints * hitptmul
	end
	if vel_add then
		d.vel_adder = vel_add
	end
	if vel_buff then
		d.vel_buffer = vel_buff
	end
	return q
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = 996,	--初始化
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.State == nil then
			d.State = 0
		end
		d.invi = 0
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_PLAYEROBJECTS
		ent.GridCollisionClass = GridCollisionClass.COLLISION_NONE
		s:Play("Appearing",true)
		board.start_()
		item.multi_counter = item.multi_counter + 1
		ent:AddEntityFlags(EntityFlag.FLAG_NO_STATUS_EFFECTS)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 996,	--自己写个减伤
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if flag & DamageFlag.DAMAGE_CLONES == 0 then
			if d.invi and d.invi > 0 then
				return false
			end
			--ent:TakeDamage(amt,flag | DamageFlag.DAMAGE_CLONES,EntityRef(player),cooldown)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = 996,	--死亡
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = 996,	--移除
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		item.multi_counter = item.multi_counter - 1
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = 45,	--防止某些奇怪情况
Function = function(_,ent,col,low)
	if col.Variant == item.enemy and col.Type == 996 then
		if col:GetData().Spawner ~= nil and col:GetData().Spawner:Exists() then
			local spk = col:GetData().Spawner
			local tospeak = "That's useless! Eraser won't affect my pieces."
			if Options.Language == "zh" then
				tospeak = "别以为这种诡计可以生效啊喂！！！"
			end
			gui.draw_ch_with_time_to_dispair(spk.Position + Vector(math.random(60) - 30,50) + Vector(-(#tospeak)/2,0),Vector(0,-50),tospeak,#tospeak * 3 + 20)
		end
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--速度、位移调整
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.Should_Move and d.Should_Move == true then
			if d.target_pos == nil then d.target_pos = ent.Position end
			local delta_pos = ent.Position - d.target_pos
			if d.range == nil then d.range = 5 end
			if delta_pos:Length() < d.range then
				s:Play("Down",true)
				ent.Velocity = Vector(0,0)
				d.Should_Move = false
			else
				s:SetFrame(20)
				if d.vel_buffer == nil then d.vel_buffer = 1/15 end
				if d.vel_adder == nil then d.vel_adder = 0 end
				ent.Velocity = - delta_pos / delta_pos:Length()*(delta_pos:Length()* d.vel_buffer + d.vel_adder)	--:Normalized()
			end
		else
			if ent.Velocity:Length() > 0.05 then
				ent.Velocity = Vector(0,0)
			end
		end
		add_flip(ent)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,		--行为、战斗控制
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		if d.State == nil then
			d.State = 0
		end
		if d.type == nil then
			d.type = 0		--0对应国王，1对应王后，2对应车，3对应相，4对应马，5对应卒。
		end
		if d.invi and d.invi > 0 then
			d.invi = d.invi - 1
		end
		
		if s:IsFinished("Appearing") then
			s:Play("Idle",true)
		end
		
		if s:IsPlaying("Idle") then			--检索阶段。
			local rand = math.random(1000)
			if rand > 800 then
				s:Play("Attack",true)
			end
		end
		
		if s:IsPlaying("Attack") then
			if s:IsEventTriggered("Float") then
				local tg_pos = ent.Position
				if d.type == 0 then
					tg_pos = board.find_pos(player.Position)
					local dt_pos = (tg_pos - ent.Position):Normalized() * 20
					local mx_stp = math.ceil((tg_pos - ent.Position):Length() / 20 )
					for i = 1,mx_stp do
						if board.check_pos(i * dt_pos + ent.Position) == false then 
							tg_pos = board.find_pos((i-1) * dt_pos + ent.Position)
							break
						end
					end
				elseif d.type == 1 or d.type == 2 or d.type == 3 then
					if d.type ~= 3 then
						for i = 1,#item.targ_place[2] do
							for j = 1,10 do
							local pos = board.find_pos(ent.Position + j * item.targ_place[2][i])
								if board.check_pos(pos) == true then
									--print(444)
									if (tg_pos - player.Position):Length() > (pos - player.Position):Length() or math.random(1000) > 950 then
										tg_pos = pos
									end
								end
							end
						end
					end
					if d.type ~= 2 then
						for i = 1,#item.targ_place[3] do
							for j = 1,10 do
								local pos = board.find_pos(ent.Position + j * item.targ_place[3][i])
								if board.check_pos(pos) == true then
									--print(444)
									if (tg_pos - player.Position):Length() > (pos - player.Position):Length() or math.random(1000) > 950 then
										tg_pos = pos
									end
								end
							end
						end
					end
				elseif d.type == 4 or d.type == 5 then
					for i = 1,#item.targ_place[d.type] do
						local pos = board.find_pos(ent.Position + item.targ_place[d.type][i])
						if board.check_pos(pos) == true then
							--print(555)
							if (tg_pos - player.Position):Length() > (pos - player.Position):Length() or math.random(1000) > 900 then
								tg_pos = pos
							end
						end
					end
				end
				d.target_pos = tg_pos
				d.Should_Move = true
			end	
		end
		
		if s:IsPlaying("Down") then
			d.Should_Move = false
		end
		
		if s:IsFinished("Attack") or s:IsFinished("Down") then
			s:Play("Idle",true)
		end
		
	end
end,
})

--l local q = Isaac.Spawn(996,23751,0,Vector(400,300),Vector(0,0),nil);local s = q:GetSprite();s:ReplaceSpritesheet(0, "gfx/enemies/pawn_pieces.png");s:LoadGraphics();print(q.Mass);
	
return item