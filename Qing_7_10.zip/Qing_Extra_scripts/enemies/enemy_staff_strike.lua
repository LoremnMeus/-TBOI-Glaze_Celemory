local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	entity = enums.Enemies.Staff_Strike,
}

local function add_flip(npc)
	local v = npc.Velocity
    if v.X < -0.0005 then
        npc:GetSprite().FlipX = true
    elseif v.X > 0.0005 then
        npc:GetSprite().FlipX = false
    end
end

function item.spawn(pos,vel,st,ent,targ)
	if vel == nil then vel = Vector(0,0) end
	if st == nil then st = 0 end
	local q = Isaac.Spawn(1000,item.entity,0,pos,vel,ent)
	local d = q:GetData()
	d.type = st
	d.Spawner = ent
	d.target = targ
	local s = q:GetSprite()
	if st == 1 then
		s:Play("Idle2",true)
	end
	return q
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_INIT, params = item.entity,	--初始化
Function = function(_,ent)
	if ent.Variant == item.entity then
		local s = ent:GetSprite()
		local d = ent:GetData()
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		s:Play("Idle",true)
	end
end,
})
--[[
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = 45,	--防止某些奇怪情况
Function = function(_,ent,col,low)
	if col.Variant == item.entity and col.Type == 996 then
		if col:GetData().Spawner ~= nil and col:GetData().Spawner:Exists() then
			local spk = col:GetData().Spawner
			local tospeak = "That's useless! Eraser won't affect my staff."
			if Options.Language == "zh" then
				tospeak = "别以为这种诡计可以生效啊喂！！！"
			end
			gui.draw_ch_with_time_to_dispair(spk.Position + Vector(math.random(60) - 30,50) + Vector(-(#tospeak)/2,0),Vector(0,-50),tospeak,#tospeak * 3 + 20)
		end
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 996,	--不可受伤。
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Variant == item.entity then
		return false
	end
end,
})
--]]
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = item.entity,		--速度、位移调整
Function = function(_,ent)
	if ent.Variant == item.entity then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if s:WasEventTriggered("Fall") == false then
			if d.target and d.target:Exists() == true then
				ent.Velocity = d.target.Velocity 
				ent.Position = d.target.Position
			else
				ent.Velocity = Vector(0,0)
			end
		else
			ent.Velocity = Vector(0,0)
		end
		if s:IsEventTriggered("Down") then
			Game():ShakeScreen(10)
			ent.CollisionDamage = 1
			ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_PLAYEROBJECTS
			local rnd = math.random(1000)
			if rnd > 400 then
				local rd = math.random(3)
				for i = 1,rd do
					local q = Isaac.Spawn(1000, 72, 0, ent.Position, Vector(0,0), ent):ToEffect()
					q.Rotation = math.random(360)
				end
			elseif rnd > 300 then
				Isaac.Spawn(1000, 61, 1, ent.Position, Vector(0,0), ent):ToEffect()
			end
		end
		if s:IsEventTriggered("Leave") then
			ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		end
		if s:IsFinished("Idle") or s:IsFinished("Idle2") then
			ent:Remove()
		end
	end
end,
})
	
return item