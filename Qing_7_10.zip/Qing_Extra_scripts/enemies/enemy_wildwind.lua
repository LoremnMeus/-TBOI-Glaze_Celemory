local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	enemy = enums.Enemies.wildwind,
	winds = {},
	now_hold = nil,
	power = 0,
	wind_cnt = 0,
	render_mode = 1,
}

function item.start_(pos)
	if item.now_hold == nil or item.now_hold:Exists() == false then
		local q = Isaac.Spawn(1000,item.enemy,0,Vector(0,-100),Vector(0,0),nil)
		if pos ~= nil then
			q:GetData().spawn_pos = pos
		end
	end
	return item.now_hold
end

function item.change_control(mode,params)
	if item.now_hold == nil or item.now_hold:Exists() == false then
		item.start_()
	end
	local q = item.now_hold
	local d = q:GetData()
	if mode == nil then mode = 1 end
	if params == nil then params = {} end
	if mode == 1 then		--普通的风向
		d.start_pos = nil 
		if params.dir then
			if params.dir == 0 then
				params.ang = 270
			elseif params.dir == 1 then
				params.ang = 0
			elseif params.dir == 2 then
				params.ang = 90
			elseif params.dir == 3 then
				params.ang = 180
			end
		end
		if params.ang ~= nil then
			d.ang = params.ang
		end
		d.pos_rev_del = 0
		d.follow_ent = nil
	elseif mode == 2 then	--环绕式风向
		d.start_pos = params.pos
		d.pos_rev_del = params.pos_rev_del
		d.ang = 0
		d.follow_ent = nil
	elseif mode == 3 then	--跟随的环绕式风向
		d.follow_ent = params.ent
		d.pos_rev_del = params.pos_rev_del
		d.ang = 0
	end
	item.render_mode = mode
	if params.pos_rev_del and params.pos_rev_del == 0 or params.pos_rev_del == 180 then 
		item.render_mode = 1
	end
	if params.power then
		d.power = params.power
	end
	if params.delta_pos then
		d.delta_pos = params.delta_pos
	end
end

local function add_velocity_and_flip(npc, velocity)
    npc:AddVelocity(velocity)
    if velocity.X < 0 then
        npc:GetSprite().FlipX = true
    else
        npc:GetSprite().FlipX = false
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_INIT, params = item.enemy,	--初始化
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if(item.now_hold ~= nil and item.now_hold:Exists()) then
			ent:Remove()
		else
			item.now_hold = ent
		end
		d.power = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = item.enemy,
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		if d.power == nil then d.power = 1 end		--风力就是熏风小姐距离此房间的距离。0是最大值，26是最小值。		 0似乎有一些问题，现在从1开始好了
		if d.ang == nil then d.ang = 0 end
		local p = d.power
		local ang = d.ang
		for i = 1,math.ceil((26 - p)/4) + math.max(0,math.ceil((6 - p) * 0.8)) + math.max(0,(3 - p) * 5) do
			if item.render_mode == 1 then
				if math.random(1000) > 500 + p * 20 then
					local s = Sprite()
					s:Load("gfx/enemies/wildwind.anm2",true)
					local toplay = "Idle1"
					if math.random(1000) > p * 35 or p < 3 then
						toplay = "Idle2"
						if math.random(1000) > 600 + p * 50 or p == 1 then 
							toplay = "Idle3"
						end
					end
					s:Play(toplay,true)
					s.Scale = Vector(math.random(1000)/1000 * 0.5 + 0.5,math.random(1000)/1000 * 0.1 + 0.95)
					s.Rotation = ang
					local rnd = math.random(1000)/1000 * 0.5 + 0.1 + p / 30 * 0.4
					s.Color = Color(math.random(1000)/1000 * 0.1 + 0.95,math.random(1000)/1000 * 0.1 + 0.95,math.random(1000)/1000 * 0.1 + 0.95,rnd)
					local tbl = {sprite = s,pos = room:GetRandomPosition(10) + Vector(math.random(60) - 30,math.random(60) - 30),sgid = desc.SafeGridIndex,}
					if d.follow_ent and d.follow_ent:Exists() then
						d.start_pos = d.follow_ent.Position + d.follow_ent.Velocity
					end
					if d.start_pos then
						s.Rotation = (d.start_pos - tbl.pos):GetAngleDegrees() + 90
						if d.pos_rev_del then
							s.Rotation = s.Rotation + d.pos_rev_del
						end
					end
					table.insert(item.winds,#item.winds + 1,tbl)
				end
			end
			for i = 1,3 + math.max(0,math.ceil((10 - p)/5)) do
				if math.random(1000) > 300 + p * 15 then
					local s = Sprite()
					s:Load("gfx/enemies/wildwind.anm2",true)
					s:ReplaceSpritesheet(0,"gfx/enemies/wild_wind2.png")
					s:LoadGraphics()
					local toplay = "Idle4"
					if math.random(1000) > 300 + p * 30 or p < 5 then
						toplay = "Idle5"
					end
					s:Play(toplay,true)
					s.Scale = Vector(math.random(1000)/1000 * 0.1 + 0.95,math.random(1000)/1000 * 0.1 + 0.95)
					s.Rotation = ang
					local rnd = math.random(1000)/1000 * 0.5 + 0.1 + p / 30 * 0.4
					s.Color = Color(math.random(1000)/1000 * 0.1 + 0.95,math.random(1000)/1000 * 0.1 + 0.95,math.random(1000)/1000 * 0.1 + 0.95,rnd)
					local tbl = {sprite = s,pos = room:GetRandomPosition(10) + Vector(math.random(60) - 30,math.random(60) - 30),sgid = desc.SafeGridIndex,}
					if d.follow_ent and d.follow_ent:Exists() then
						d.start_pos = d.follow_ent.Position + d.follow_ent.Velocity
					end
					if d.delta_pos and d.start_pos then
						d.start_pos = d.start_pos + d.delta_pos
					end
					if d.start_pos then
						s.Rotation = (d.start_pos - tbl.pos):GetAngleDegrees() + 90
						if d.pos_rev_del then
							s.Rotation = s.Rotation + d.pos_rev_del
						end
					end
					if d.follow_ent and d.follow_ent:Exists() then
						tbl.Special = function(params)
							if params and params.sprite and params.follow_ent and params.follow_ent:Exists() then
								params.sprite.Rotation = (params.follow_ent.Position + params.follow_ent.Velocity - tbl.pos):GetAngleDegrees() + 90
								if params.pos_rev_del then
									params.sprite.Rotation = params.sprite.Rotation + params.pos_rev_del
								end
							end
						end
						tbl.follow_ent = d.follow_ent
						if d.pos_rev_del then
							tbl.pos_rev_del = d.pos_rev_del
						end
					end
					table.insert(item.winds,#item.winds + 1,tbl)
				end
			end
			local n_entity = Isaac.GetRoomEntities()
			--local cnt = 0
			--local to_print = ""
			if item.wind_cnt == 0 then
				item.wind_cnt = 4
				for i = 1, #n_entity do
					local tent = n_entity[i]
					if (tent.Type == 1000 and (tent.Variant == EffectVariant.BACKDROP_DECORATION or tent.Variant == item.enemy or tent.Variant == EffectVariant.XRAY_WALL or tent.Variant == EffectVariant.SPEAR_OF_DESTINY)) then		--背景板不会被吹走
					elseif (tent.Type == 996 and tent.Variant == enums.Enemies.Hreeze) then
					elseif (tent.Type == 33) or (tent.Type == 17) or (tent.Type == 86) or (tent.Type == 5 and tent:ToPickup():IsShopItem() == true) or (tent.Type == 6) or (tent.Type == 7) or (tent.Type == 8) then
					elseif (tent.SpawnerEntity and tent.SpawnerEntity.Type == 996 and tent.SpawnerEntity.Variant == enums.Enemies.Hreeze) then
					elseif (tent:GetData().dont_over_write_velocity) then
					else
						--cnt = cnt + 1
						local ang = d.ang 
						if d.start_pos then
							ang = (-tent.Position + d.start_pos):GetAngleDegrees() + 90
							if d.pos_rev_del then
								ang = ang + d.pos_rev_del
							end
						end
						--to_print = to_print .. " " .. tostring(tent.Type) .. "_" .. tostring(tent.Variant)
						tent.Velocity = tent.Velocity + auxi.MakeVector(ang + 90) * (30 - d.power)/150
					end
				end
				--print(to_print)
			else
				item.wind_cnt = item.wind_cnt - 1
			end
			--print(cnt)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_RENDER, params = item.enemy,
Function = function(_,ent)
	if ent.Variant == item.enemy then
		local s1 = ent:GetSprite()
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		local d = ent:GetData()
		local player = Game():GetPlayer(0)
		local hud = Game():GetHUD()
		for u,v in pairs(item.winds) do
			local s = v.sprite
			if s:IsFinished("Idle1") or s:IsFinished("Idle2") or s:IsFinished("Idle3") or s:IsFinished("Idle4") or s:IsFinished("Idle5") or desc.SafeGridIndex ~= v.sgid then
				table.remove(item.winds,u)
			else
				s:Render(Isaac.WorldToScreen(v.pos),Vector(0,0),Vector(0,0))
				s:Update()
				if v.Special then
					v.Special(v)
				end
			end
		end
	end
end,
})

--l local player = Game():GetPlayer(0);local room = Game():GetRoom();local pos_idx = room:GetGridIndex(player.Position);print(pos_idx);if room:GetGridCollision(pos_idx) == GridCollisionClass.COLLISION_NONE then print("Yes!") end;
--l local room = Game():GetRoom();player = Game():GetPlayer(0);local pos_idx = room:GetGridIndex(player.Position);print(room:GetGridPosition(pos_idx));print(player.Position);
--l local q = Isaac.Spawn(1000,23765,0,Vector(0,-100),Vector(0,0),nil);local d = q:GetData();local q2 = Isaac.Spawn(996,23763,0,Vector(200,200),Vector(0,0),nil);d.follow_ent = q2;d.power = 10;
	
return item