local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local slot_manager = require("Qing_Extra_scripts.core.slot_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")

local item = {
	ToCall = {},
	entity = enums.Slots.Bard_beggar,
	Tosay = {
		zh = {
			{
				"英雄来到了遍布恶龙的王国！",
				"拔下石中宝剑，战胜三百恶魔！",
				"成为天命的主人！",
				"那么今天的故事就讲到这里~",
			},{
				"于是 达拉崩吧斑得贝迪卜多比鲁翁~",
				"砍向 昆图库塔卡提考特苏瓦西拉松~",
				"然后 昆图库塔卡提考特苏瓦西拉松~",
				"咬了 达拉崩吧斑得贝迪卜多比鲁翁~",
				"最后 达拉崩吧斑得贝迪卜多比鲁翁~",
				"他战胜了 昆图库塔卡提考特苏瓦西拉松~",
				"救出了 公主米娅莫拉苏娜丹妮谢莉红~",
				"回到了 蒙达鲁克硫斯伯古比奇巴勒城~",
			},
			{
				"发动~暴走魔法阵~~",
				"通常召唤阿莱斯特~",
				"效果检索召唤魔术~",
			},
			{
				"不要为了破碎的镜子悲伤！",
				"它们注定活在另一个世界~",
			},
			{
				"镜子的那一边有什么？",
				"是那五色的琉璃，虚幻的象征！",
				"美丽，而又不切实际~",
				"破裂的风暴中，只有覆盖在上面的油膜才是真实的存在~",
			},
			{
				"如果镜子的命运就是破碎",
				"那么我希望它爆裂得五彩斑斓~",
				"经过彩色火焰的烘焙",
				"琉璃将变得无坚不摧~",
			},
			{
				"硬币也不是坚不可摧",
				"贪婪的意志足以将其磨灭~",
				"但其中蕴含的价值依然存在",
				"哼！没有人能战胜它们！其名为资本主义！",
			},
			{
				"名为资本的恶魔正在摧毁大地",
				"藏匿于表面是银行的恐怖骗局~",
				"任何人倘若敢于狠心销毁账号",
				"他能收获到的只有破碎的人格~",
			},
			{
				"听说那遥远的危险矿洞",
				"有位少女在那里守护~",
				"如果想要拿到胜利的钥匙",
				"就千万不要踩上棋盘的边缘~",
			},
			{
				"王后手持宝剑威临四方",
				"主教事事妙算先机独占~",
				"战车不惧危难拼死冲锋",
				"骑士步伐坚定实力高卓~",
				"就算是临时招募的小卒",
				"也足以困得你焦头烂额~",
			},
			{
				"没有人能够永恒，除非他由石头做成",
				"但伟大的魔像也有它的惧怕之物~",
				"用黎明的智慧照耀那道阴暗",
				"正是精诚所至金石为开~",
			},
			{
				"血肉的天国向上苍张开双翼",
				"铺满白骨的地面，密布触手的天穹~",
				"没人能逃过血肉的魔爪",
				"没错，他的名字是德西·莱诺阿~",
			},
			{
				"当流星正面朝你飞来",
				"莫要逃避，转身正面迎击。",
				"小行星带总是有所预示",
				"譬如这次，仿佛天国即将降临~",
			},
			{
				"炼金术的最终奥义",
				"名为不可触摸之结界",
				"在那视线之外的帝国",
				"连声音也无法传达",
			},
			{
				"味觉理所当然彻底失灵",
				"嗅觉宛如夜空中的阵风",
				"听觉消失无影无踪",
				"心灵仿佛沉寂在无空的世界",
			},
			{
				"苍白的视界无限地延展",
				"苍白的呼啸剧烈地颤抖~",
				"不可闻，所知者天下万物",
				"不可视，所在者诸世众生~",
			},
			{
				"不可视之界限悬浮在第十三层以外",
				"欲到达此地，唯有得到主人首肯~",
				"或是找寻名为噩梦的呢祝师",
				"从噩梦里寻觅踪影~",
			},
			{
				"白色的风暴向外延展",
				"突破世界的藩篱~",
				"激发愤怒的火焰",
				"点燃生命的怒吼~",
				"这样的狂风该如何来阻止？",
			},
			{
				"啊啊啊，那就是嗝屁猫警长！",
				"森林公民向您致敬！",
				"向您致敬！！",
				"致敬！！！！",
			},
			{
				"地下室里的道具总是在增加？",
				"那再正常不过了~",
			},
			{
				"嗨，Judas！",
				"莫要哭泣~",
				"找一首哀伤的歌!",
				"然后把它唱得更快乐~",
			},
			{
				"爱你孤身走暗巷",
				"爱你不跪的模样~",
				"爱你对峙过绝望",
				"不肯哭一场~",
			},
			{
				"是谁带来~远古的呼唤~",
				"是谁留下~千年的期盼~",
				"难道说还有无言的歌~",
				"还是那久久不能忘怀的眷恋~",
			},
			{
				"我用尽一生一世来将你供养",
				"只期盼你停住流转的目光~",
				"请赐予我无限爱与被爱的力量",
				"让我能安心在菩提下静静的观想~",
			},
			Special_words = {
				[1] = {
					"孩子，初次见面",
					"在下是一名吟游诗人，正在这无人打扰之地寻找灵感~",
					"什么？你说你见过我？",
					"也许你说的是我的远房亲戚",
					"他们的连锁服务已经开到全球各地了~",
					"如果愿意付一点小费的话，我就来为你献唱一曲。",
					"当然，不愿意的话，我也不会强求的。",
				},
				[2] = {
					"又见面了，孩子。",
					"想要我为你献上一曲么？",
				},
			},
			Special_items = {
				[4] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
				},
				[38] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
				},
				[62] = {
					"吸血鬼并不惧怕阳光",
					"石质面具之后是对鲜血的渴望~",
					"但在慵懒的冬日早晨",
					"红色的番茄汁也能果腹!",
				},
				[81] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
				},
				[118] = {
					"硫磺是如此的不幸",
					"染上了恶魔的颜色~",
					"净化的力量也不能触及",
					"从血脉中染红的死亡因子",
				},
				[144] = {
					"啊，这是我的一个远房亲戚！",
					"看起来他并不是很喜欢你富有的样子。",
				},
				[145] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
				},
				[229] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
				[242] = {
					"鬼面象征着内心的耻辱",
					"但很少有人愿意戴上",
					"悲哀，痛苦亦或是绝望",
					"噩梦，你的名字是无名~",
				},
				[278] = {
					"啊，这是我另一个远房亲戚！",
					"我还以为我们早已阴阳两隔了呢！",
				},
				[281] = {
					"嘿！",
					"不要一直把宝宝塞给我！",
					"照顾他们很费时间！",
				},
				[293] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
					"恶魔？差不了多少的。",
				},
				[304] = {
					"我想你很乐意我拿走它，对吧？",
				},
				[385] = {
					"哇塞，我远房亲戚的老大居然成了你的下属！",
					"你可真是有魄力的孩子！",
				},
				[388] = {
					"哦，你找到了我的远房亲戚！",
					"他在我们的商业圈中总是处于关键地位。",
				},
				[395] = {
					"谢谢你。",
					"我可以买一份新的平板了。",
				},
				[441] = {
					"哦，如此可爱的小猫咪！",
					"我会好好善待它的。",
					"恶魔？差不了多少的。",
				},
				[452] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
				[614] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
				[618] = {
					"吸血鬼并不惧怕阳光",
					"石质面具之后是对鲜血的渴望~",
					"但在慵懒的冬日早晨",
					"红色的番茄汁也能果腹!",
				},
				[628] = {
					"......",
					"(优美而无奈的琴声)",
				},
				[633] = {
					"这件物品不属于你我~",
					"或许存在即为合理。",
				},
				[641] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
				[657] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
				[724] = {
					"咆哮在肺脏中爆炸",
					"血管如同脆化的橡胶",
					"绵软的手臂，苍白的面颊~",
					"无力地看着血液迸发",
					"————你我共同的命运",
				},
			},
		},
	},
	Talking_Pos_Offset = Vector(0,0),
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = item.entity.Type,	--初始化
Function = function(_,ent)
	if ent.Variant == item.entity.Variant then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local room = Game():GetRoom()
		if d.State == nil then
			d.State = 0
		end
		d.Should_Move = false
		d.set_position = room:FindFreeTilePosition(ent.Position,10)
		ent:AddEntityFlags(EntityFlag.FLAG_NO_STATUS_EFFECTS)
		s:Play("Idle0",true)
	end
end,
})

local function add_flip(npc)
	local v = npc.Velocity
    if v.X < -0.0005 then
        npc:GetSprite().FlipX = true
    elseif v.X > 0.0005 then
        npc:GetSprite().FlipX = false
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = item.entity.Type,		--速度、位移调整
Function = function(_,ent)
	local room = Game():GetRoom()
	if ent.Variant == item.entity.Variant then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if d.Should_Move and d.Should_Move == true then
		elseif d.set_position and (ent.Position - d.set_position):Length() > 1 then
			ent.Velocity = -(ent.Position - d.set_position)/5
		else
			if ent.Velocity:Length() > 0.005 then
				ent.Velocity = Vector(0,0)
			end
		end
		if d.control_flip and d.control_flip == true then
			s.FlipX = d.control_flip_method
		else
			add_flip(ent)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = item.entity.Type,		--经过了重写，现在所有的NPC都是怪物了。
Function = function(_,ent)
	local room = Game():GetRoom()
	if ent.Variant == item.entity.Variant then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if s:IsPlaying("Idle") then
			if d.should_kill and d.should_kill == true then
				s:Play("Teleport",true)
			end
			if d.tosay == nil or #d.tosay == 0 then
				d.should_prize = false
			elseif d.should_prize and d.should_prize == true then
				s:Play("Prize",true)
			end
			
		end
		if s:IsPlaying("Teleport") then
			if s:IsEventTriggered("Jump") then
				ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
			end
		end
		if s:IsPlaying("Prize") then
			if s:IsEventTriggered("Sing") then
				if d.tosay and d.tosay[1] then
					gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-(#d.tosay[1])/2,0),Vector(0,-50),d.tosay[1],#d.tosay[1] * 3 + 20)
					table.remove(d.tosay,1)
				end
			end
		end
		if s:IsFinished("Prize") then
			if d.always_sing and d.always_sing == true then
				s:Play("Prize",true)
			else
				s:Play("Idle",true)
			end
		end
		if s:IsFinished("PayPrize") then
			s:Play("Prize",true)
		end
		if s:IsFinished("Teleport") then
			ent:Remove()
		end
		if s:IsFinished("Appearing") then
			if save.elses.times_meet_beggar == nil then
				save.elses.times_meet_beggar = 0
			end
			local language = Options.Language
			if item.Tosay[language] == nil then
				language = "zh"
			end
			local to_say = item.Tosay[language].Special_words[1]
			if save.elses.times_meet_beggar == 0 then
				to_say = item.Tosay[language].Special_words[1]
			else
				to_say = item.Tosay[language].Special_words[2]
			end
			if d.tosay == nil then d.tosay = {} end
			for j = 1,#to_say do
				table.insert(d.tosay,to_say[j])
			end
			d.should_kill = false
			d.should_prize = true
			s:Play("Prize",true)
			save.elses.times_meet_beggar = save.elses.times_meet_beggar + 1
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = item.entity.Type,
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Variant == item.entity.Variant then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local level = Game():GetLevel()
		if flag & DamageFlag.DAMAGE_CLONES == 0 then
			if flag & DamageFlag.DAMAGE_EXPLOSION == DamageFlag.DAMAGE_EXPLOSION then
				d.should_kill = true
				level:SetStateFlag(LevelStateFlag.STATE_BUM_KILLED,true)
				return false
			else
				return false
			end
		end
	end
end,
})

local function addtosay(ent,num,clm,rng)
	rng = auxi.rng_for_sake(rng)
	if num == nil then num = 1 end
	if clm == nil then clm = 1 end
	local d = ent:GetData()
	if d.tosay == nil then
		d.tosay = {}
	end
	local language = Options.Language
	if item.Tosay[language] == nil then
		language = "zh"
	end
	for i = 1,num do
		local rnd = rng:RandomInt(#item.Tosay[language]) + 1
		for j = 1,#item.Tosay[language][rnd] do
			table.insert(d.tosay,item.Tosay[language][rnd][j])
		end
	end
end

local function try_prize(player,rng,ent)
	local s = ent:GetSprite()
	local coin = player:GetNumCoins()
	local bomb = player:GetNumBombs()
	local key = player:GetNumKeys()
	local heart = player:GetHearts()
	local soulheart = player:GetSoulHearts()
	local boneheart = player:GetBoneHearts()
	local blackheart = player:GetBlackHearts()
	local eternalheart = player:GetEternalHearts ()
	local items = player:GetCollectibleCount ()
	local rnd = rng:RandomInt(20)
	if player:HasGoldenBomb() then		--优先食用金钥匙和金炸弹。
		s:ReplaceSpritesheet(2, "gfx/items/slots/item_to_pay_goldenbomb.png")
		s:LoadGraphics()
		player:RemoveGoldenBomb()
		addtosay(ent,3,1,rng)
		return true
	elseif player:HasGoldenKey() then
		s:ReplaceSpritesheet(2, "gfx/items/slots/item_to_pay_goldenkey.png")
		s:LoadGraphics()
		addtosay(ent,3,1,rng)
		player:RemoveGoldenKey()
		return true
	end
	local togive = {}
	if bomb > 0 then
		if bomb > 10 then
			table.insert(togive,{name = "10bomb",wei = 10 * math.ceil(bomb/20),})
		end
		table.insert(togive,{name = "1bomb",wei = 3 * math.ceil(bomb/20),})
	end
	if key > 0 then
		if key > 10 then		--暂时没有图呢
			--table.insert(togive,{name = "10key",wei = 10* math.ceil(key/20),})
		end
		table.insert(togive,{name = "1key",wei = 2 * math.ceil(key/20),})
	end
	if coin > 0 then
		if coin > 25 then
			table.insert(togive,{name = "25coin",wei = 25 * math.ceil(coin/20),})
		end
		table.insert(togive,{name = "1coin",wei = 1 * math.ceil(coin/10),})
	end
	if heart + soulheart + boneheart > 1 then
		if heart > 2 then
			table.insert(togive,{name = "heart",wei = 2 * math.ceil(heart/3),})
		end
		if soulheart > 2 then
			table.insert(togive,{name = "soulheart",wei = 5 * math.ceil(soulheart/3),})
			if blackheart > 0 then
				table.insert(togive,{name = "blackheart",wei = 9 * math.ceil(soulheart/3),})
			end
		end
		if boneheart > 0 then
			table.insert(togive,{name = "boneheart",wei = 7 * math.ceil(boneheart/3),})
		end
		if eternalheart > 0 then
			table.insert(togive,{name = "eternalheart",wei = 8,})
		end
	end
	--table.insert(togive,{name = "collectible",wei = math.ceil(items),})
	if #togive > 0 then
		local stag = togive[1]
		local tot_wei = 0
		for u,v in pairs(togive) do
			tot_wei = tot_wei + v.wei
		end
		tot_wei = rng:RandomInt(tot_wei) + 1
		for i = 1,#togive do
			tot_wei = tot_wei - togive[i].wei
			if tot_wei <= 0 then
				stag = togive[i]
				break
			end
		end
		
		if stag.name == "collectible" then
			local pool = {}
			local itemConfig = Isaac.GetItemConfig()
			local sz = itemConfig:GetCollectibles().Size
			local wei = 0
			for id = 1,sz do
				local collectible = itemConfig:GetCollectible(id)
				if (collectible and player:HasCollectible(id)) then
					if player:GetCollectibleNum(id,true) > 0 then
						table.insert(pool,{id = id,weigh = player:GetCollectibleNum(id,true)})
						wei = wei + player:GetCollectibleNum(id,true)
					end
				end
			end
			if #pool > 0 then
				local tg_item = pool[1].id
				wei = rng:RandomInt(wei) + 1
				for i = 1,#pool do
					wei = wei - pool[i].weigh
					if wei <= 0 then
						tg_item = pool[i].id
						break
					end
				end
				item_name = itemConfig:GetCollectible(tg_item).GfxFileName
				s:ReplaceSpritesheet(2,item_name)
				s:LoadGraphics()
				
				local d = ent:GetData()
				if d.tosay == nil then
					d.tosay = {}
				end
				local language = Options.Language
				if item.Tosay[language] == nil then
					language = "zh"
				end
				if d.has_say == nil then
					d.has_say = {}
				end
				if d.has_say[tg_item] ~= true then
					if item.Tosay[language].Special_items and item.Tosay[language].Special_items[tg_item] then
						for j = 1,#item.Tosay[language].Special_items[tg_item] do
							table.insert(d.tosay,item.Tosay[language].Special_items[tg_item][j])
						end
					end
					d.has_say[tg_item] = true
				end
				addtosay(ent,1,1,rng)
				player:RemoveCollectible(tg_item)
				return true
			else
				return false
			end
		elseif stag.name == "1bomb" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_bomb.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 65 then
				addtosay(ent,1,1,rng)
			end
			player:AddBombs(-1)
			return true
		elseif stag.name == "10bomb" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_10bombs.png")
			s:LoadGraphics()
			addtosay(ent,1,1,rng)
			player:AddBombs(-10)
			return true
		elseif stag.name == "1key" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_key.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 80 then
				addtosay(ent,1,1,rng)
			end
			player:AddKeys(-1)
			return true
		elseif stag.name == "1coin" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_coin.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 90 then
				addtosay(ent,1,1,rng)
			end
			player:AddCoins(-1)
			return true
		elseif stag.name == "25coin" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_25coin.png")
			s:LoadGraphics()
			addtosay(ent,1,1,rng)
			player:AddCoins(-25)
			return true
		elseif stag.name == "heart" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_heart.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 80 then
				addtosay(ent,1,1,rng)
			end
			player:AddHearts(-2)
			return true
		elseif stag.name == "soulheart" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_soulheart.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 50 then
				addtosay(ent,1,1,rng)
			end
			player:AddSoulHearts(-2)
			return true
		elseif stag.name == "blackheart" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_blackheart.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 30 then
				addtosay(ent,1,1,rng)
			end
			local success = false
			for i = 1,18 do
				if blackheart & (1<<(i)) == (1<<(i)) then
					player:RemoveBlackHeart(i * 2)
					player:AddSoulHearts(-2)
					success = true
					break
				end
			end
			if success == true then
				return true
			else
				return false
			end
		elseif stag.name == "boneheart" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_boneheart.png")
			s:LoadGraphics()
			if rng:RandomInt(100) > 10 then
				addtosay(ent,1,1,rng)
			end
			if rng:RandomInt(100) > 60 then
				addtosay(ent,1,1,rng)
			end
			player:AddBoneHearts(-1)
			return true
		elseif stag.name == "eternalheart" then
			s:ReplaceSpritesheet(2,"gfx/items/slots/item_to_pay_eternalheart.png")
			s:LoadGraphics()
			addtosay(ent,1,1,rng)
			if rng:RandomInt(100) > 30 then
				addtosay(ent,1,1,rng)
			end
			player:AddEternalHearts(-1)
			return true
		end
	end
	return false
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_NPC_COLLISION, params = item.entity.Type,
Function = function(_,ent,col,low)
	if ent.Variant == item.entity.Variant then
		local s = ent:GetSprite()
		local d = ent:GetData()
		local player = col:ToPlayer()
		if col.Type == 1 and player then
			if s:IsPlaying("Idle") and d.should_prize ~= true then
				local should_prize = try_prize(player,ent:GetDropRNG(),ent)
				if should_prize then
					s:Play("PayPrize",true)
					d.should_prize = true
				end
			end
			if s:IsPlaying("Idle0") then
				s:Play("Appearing",true)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local seed = Game():GetSeeds():GetStageSeed(stage)
	if room:GetType() == RoomType.ROOM_SECRET_EXIT and room:IsFirstVisit() then
		local rng = RNG()
		rng:SetSeed(seed,0)
		local rnd = rng:RandomInt(100)
		--print(rnd)
		if rnd > 64 then
			local q = Isaac.Spawn(item.entity.Type,item.entity.Variant,0,room:GetRandomPosition(10),Vector(0,0),nil)
		end
	end
end,
})


return item