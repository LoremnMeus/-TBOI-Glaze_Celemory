local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local modReference
local item = {
	ToCall = {},
	should_charm = false,
	ShouldAddCharm = {
		item = {},
		card = {},
		pill = {},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = nil,
Function = function(_,ent)
	if Game().Challenge == enums.Challenges.Fans_Service and ent:IsVulnerableEnemy() and ent.Type ~= EntityType.ENTITY_MEGA_SATAN and ent.Type ~= EntityType.ENTITY_MEGA_SATAN_2 and ent.Type ~= EntityType.ENTITY_RAG_MEGA then
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if roomType == RoomType.ROOM_BOSS and levelStage == LevelStage.STAGE6 then
			ent:ClearEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
		elseif roomType == RoomType.ROOM_BOSS and (room:IsFirstVisit()) and item.should_charm ~= true then
			ent:ClearEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
		else
			local should_add_flag = false
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if (player.Position - ent.Position):Length() < 100 then
					should_add_flag = true
				end
			end
			if should_add_flag == true or item.should_charm then
				ent:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,itemtype,rng)
	if Game().Challenge == enums.Challenges.Fans_Service then
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if item.ShouldAddCharm.item[itemtype] ~= nil then
			if roomType == RoomType.ROOM_BOSS and levelStage == LevelStage.STAGE6 then
			else
				item.should_charm = true
				local n_entity = Isaac.GetRoomEntities()
				for u,ent in pairs(n_entity) do
					if ent:IsVulnerableEnemy() and ent.Type ~= EntityType.ENTITY_MEGA_SATAN and ent.Type ~= EntityType.ENTITY_MEGA_SATAN_2 and ent.Type ~= EntityType.ENTITY_RAG_MEGA then
						ent:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_PILL, params = nil,
Function = function(_,pilltype)
	if Game().Challenge == enums.Challenges.Fans_Service then
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if item.ShouldAddCharm.pill[pilltype] ~= nil then
			item.should_charm = true
			local n_entity = Isaac.GetRoomEntities()
			for u,ent in pairs(n_entity) do
				if ent:IsVulnerableEnemy() and ent.Type ~= EntityType.ENTITY_MEGA_SATAN and ent.Type ~= EntityType.ENTITY_MEGA_SATAN_2 and ent.Type ~= EntityType.ENTITY_RAG_MEGA then
					ent:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = nil,
Function = function(_,cardtype,player,useflags)
	if Game().Challenge == enums.Challenges.Fans_Service then
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if item.ShouldAddCharm.card[cardtype] ~= nil then
			if roomType == RoomType.ROOM_BOSS and levelStage == LevelStage.STAGE6 then
			else
				item.should_charm = true
				local n_entity = Isaac.GetRoomEntities()
				for u,ent in pairs(n_entity) do
					if ent:IsVulnerableEnemy() and ent.Type ~= EntityType.ENTITY_MEGA_SATAN and ent.Type ~= EntityType.ENTITY_MEGA_SATAN_2 and ent.Type ~= EntityType.ENTITY_RAG_MEGA then
						ent:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if Game().Challenge == enums.Challenges.Fans_Service then
		local s = player:GetSprite()
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if s:IsPlaying("TeleportUp") then
			item.should_charm = true
			local n_entity = Isaac.GetRoomEntities()
			for u,ent in pairs(n_entity) do
				if ent:IsVulnerableEnemy() and ent.Type ~= EntityType.ENTITY_MEGA_SATAN and ent.Type ~= EntityType.ENTITY_MEGA_SATAN_2 and ent.Type ~= EntityType.ENTITY_RAG_MEGA then
					ent:AddEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,
Function = function(_,ent, amt, flag, source, cooldown)
	if Game().Challenge == enums.Challenges.Fans_Service and ent:IsVulnerableEnemy() and ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM) then
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	if Game().Challenge == enums.Challenges.Fans_Service then
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local levelStage = level:GetStage()
		local roomType = room:GetType()
		if roomType == RoomType.ROOM_BOSS and levelStage == LevelStage.STAGE6 then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:GetData().Fans_Service_ring and player:GetData().Fans_Service_ring:Exists() then
					player:GetData().Fans_Service_ring.removecd = 0
				end
			end
		elseif roomType == RoomType.ROOM_BOSS and (room:IsFirstVisit()) and item.should_charm ~= true then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:GetData().Fans_Service_ring and player:GetData().Fans_Service_ring:Exists() then
					player:GetData().Fans_Service_ring.removecd = 0
				end
			end
		else
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:GetData().Fans_Service_ring == nil or player:GetData().Fans_Service_ring:Exists() == false then
					local q1 = Isaac.Spawn(1000,enums.Entities.ID_EFFECT_MeusNIL,0,player.Position,player.Velocity,player)
					player:GetData().Fans_Service_ring = q1
					local d = player:GetData().Fans_Service_ring:GetData()
					local s = player:GetData().Fans_Service_ring:GetSprite()
					d.removecd = -1
					d.ignore_follower_distance = true
					d.follower = player
					s:Load("gfx/fans_services_ring.anm2", true)
					s:Play("Idle")
					q1.SpriteOffset = Vector(0,-20)
					q1.DepthOffset = -50
				end
			end
		end
		item.should_charm = false
		local room = Game():GetRoom()
		local player = Game():GetPlayer(0)
		local n_entity = Isaac.GetRoomEntities()
		local n_entity = Isaac.GetRoomEntities()
		for u,ent in pairs(n_entity) do
			if ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY | EntityFlag.FLAG_PERSISTENT | EntityFlag.FLAG_CHARM) then
				ent.MaxHitPoints = ent.MaxHitPoints * 1.02
				ent.HitPoints = math.min(ent.HitPoints + 5,ent.MaxHitPoints)
				local pos = room:GetRandomPosition(10)
				local cnt = 5
				while cnt > 0 and (pos - player.Position):Length() < 50 do
					pos = room:GetRandomPosition(10)
				end
				ent.Position = pos		--(room:GetCenterPos(),math.max((player.Position - room:GetCenterPos()):Length() * 0.9),30)
			end
		end
	end
end,
})

return item
