local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")

local modReference
local item = {
	ToCall = {},
	challange = enums.Challenges.Safe_Driving,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	if Game().Challenge == item.challange then
		local room = Game():GetRoom()
		local s = player:GetSprite()
		local d = player:GetData()
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			if d["fire_delay_counter"] == nil then d["fire_delay_counter"] = 0 end
			if (d["fire_delay_counter"] > 5) then
				if d["Safe_Driving_sprite"] == nil then 
					d["Safe_Driving_sprite"] = Sprite()
					d["Safe_Driving_sprite"]:Load("gfx/chargebar_Safe_Driving.anm2",true)
					d["Safe_Driving_sprite"]:Play("Charging",true)
				end
				if d["fire_delay_counter"] > 100 then
					if d["Safe_Driving_sprite"]:IsPlaying("Charging") or d["Safe_Driving_sprite"]:IsFinished("Charging") then
						d["Safe_Driving_sprite"]:Play("StartCharged",true)
					elseif d["Safe_Driving_sprite"]:IsFinished("StartCharged") then
						d["Safe_Driving_sprite"]:Play("Charged",true)
						d["Ingestion2n_active"] = true
					end
					if Game():GetFrameCount() % 2 == 1 then
						d["Safe_Driving_sprite"]:Update()
					end
				else
					d["Safe_Driving_sprite"]:SetFrame("Charging",math.ceil(d["fire_delay_counter"]))
				end
				local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Safe_Driving",true)
				if type(pos) == "number" then pos = item.BarRenderOffset end
				d["Safe_Driving_sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
			else
				if d["Safe_Driving_sprite"] == nil then
					d["Safe_Driving_sprite"] = Sprite()
					d["Safe_Driving_sprite"]:Load("gfx/chargebar_Safe_Driving.anm2",true)
					d["Safe_Driving_sprite"]:SetFrame("Disappear",8)
				end
				if d["Safe_Driving_sprite"]:IsPlaying("Disappear") == false and d["Safe_Driving_sprite"]:IsFinished("Disappear") == false then
					d["Safe_Driving_sprite"]:Play("Disappear",true)
				end
				if d["Safe_Driving_sprite"]:IsPlaying("Disappear") == true then
					local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Safe_Driving",true)
					if type(pos) == "number" then pos = item.BarRenderOffset end
					d["Safe_Driving_sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					if Game():GetFrameCount() % 2 == 1 then
						d["Safe_Driving_sprite"]:Update()
					end
				else
					Charging_Bar_holder.remove_charge_bar(player,"Safe_Driving")
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if Game().Challenge == item.challange then
		local d = player:GetData()
		if d.fire_delay_counter == nil then d.fire_delay_counter = 0 end
		d.fire_delay_counter = d.fire_delay_counter + 1
		if d.fire_delay_counter >= 100 then
			local gdir = auxi.ggdir(player,true,true)
			if gdir:Length() < 0.05 then
			else
				local room = Game():GetRoom()
				local q = Isaac.Spawn(996,enums.Entities.Harmony,0,room:GetClampedPosition(player.Position - gdir * 600,5) - gdir * 500,Vector(10,0),nil)
				local d2 = q:GetData()
				local s2 = q:GetSprite()
				s2:Play("Carin",true)
				q:SetSize(28,Vector(1,5),1)
				q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ALL 
				d2.del_velocity = gdir
				d2.velocity_cnt = 30
				d2.player = player
				d.fire_delay_counter = 0
			end
		end
	end
end,
})

return item
