local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local modReference
local item = {
	ToCall = {},
	challange = enums.Challenges.Heterothermal_Concentric,
	p1 = nil,
	p2 = nil,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if Game().Challenge == item.challange then
		if cacheFlag == CacheFlag.CACHE_FLYING then
			if player.CanFly == false then
				player.CanFly = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	if Game().Challenge == item.challange then
		if player:GetPlayerType() == 19 then
			if item.p1 == nil or item.p1:Exists() == false or item.p1:IsDead() then
				item.p1 = player
			end
		end
		if player:GetPlayerType() == 20 then
			if item.p2 == nil or item.p2:Exists() == false or item.p2:IsDead() then
				item.p2 = player
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	if Game().Challenge == item.challange then
		if item.p2 ~= nil and item.p2:Exists() == true and not item.p2:IsDead() and item.p1 ~= nil and item.p1:Exists() == true and not item.p1:IsDead() then
			if Game():GetFrameCount() % 5 == 1 then
				local p1 = item.p1
				local p2 = item.p2
				if Game():GetFrameCount() % 10 == 1 then
					p2 = item.p1
					p1 = item.p2
				end
				local dir = p1.Position - p2.Position
				local flg = p1.TearFlags | p2.TearFlags | BitSet128(1,0)
				if dir:Length() > 50 then
					local q = p1:FireTechLaser(p1.Position,LaserOffset.LASER_TECH1_OFFSET,-dir,false,true):ToLaser()
					q.Parent = p1
					q:SetMaxDistance(dir:Length() - 15)
					q.DepthOffset = -100
					q.TearFlags = flg
				end
			end
		end
	end
end,
})

return item
