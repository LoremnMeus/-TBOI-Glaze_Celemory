local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local modReference
local item = {
	ToCall = {},
	challange = enums.Challenges.Louvre_puzzle,
	pause_counter = 0,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = nil,
Function = function(_,ent)
	if Game().Challenge == item.challange then
		if ent.Type == 5 and ent.Variant == 100 and (ent.SubType ~= 0) then
			local collectible = Isaac.GetItemConfig():GetCollectible(ent.SubType)
				local del_pos = 1000
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					del_pos = math.min((player.Position - ent.Position):Length(),del_pos)
				end
				local d = ent:GetData()
				local s = ent:GetSprite()
				if d.morph_counter == nil then d.morph_counter = 0 end
				if item.pause_counter <= 0 then
					d.morph_counter = d.morph_counter + 1
				end
				if d.morph_counter > del_pos * 0.1 then
					d.morph_counter = 0
					local roomPool = g.ItemPool:GetPoolForRoom(g.game:GetRoom():GetType(), g.game:GetLevel():GetCurrentRoomDesc().SpawnSeed)
					if roomPool == -1 then roomPool = ItemPoolType.POOL_TREASURE end
					local targetItem = g.ItemPool:GetCollectible(roomPool, true, ent.InitSeed)
					ent.SubType = targetItem
					ent.Touched = false
					local target_collectible = Isaac.GetItemConfig():GetCollectible(targetItem)
					ent.Charge = target_collectible.MaxCharges
					if auxi.isBlindPickup(ent) == false then
						s:ReplaceSpritesheet(1, target_collectible.GfxFileName)
						s:LoadGraphics()
					end
				end
			--end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_,ent)
	if Game().Challenge == item.challange then
		if item.pause_counter > 0 then
			item.pause_counter = item.pause_counter - 1
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = nil,
Function = function(_,ent)
	if Game().Challenge == item.challange then
		if ent.Type == 5 and ent.Variant == 100 and (ent.SubType == CollectibleType.COLLECTIBLE_BREAKFAST) then
			return false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	if Game().Challenge == item.challange then
		delay_buffer.addeffe(function(params)
			local player = Game():GetPlayer(0)
			player:UseActiveItem(CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE, UseFlag.USE_NOANIM)
		end,{},1,false,false,true)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		if Game().Challenge == item.challange then
			local player = Game():GetPlayer(0)
			player:SetPocketActiveItem(CollectibleType.COLLECTIBLE_PAUSE)
			g.ItemPool:RemoveCollectible(enums.Items.Memory)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_, collid, rng, player, flags, slot, data)
	if Game().Challenge == item.challange then
		if collid == CollectibleType.COLLECTIBLE_PAUSE then
			item.pause_counter = item.pause_counter + 60
		end
	end
end,
})

return item
