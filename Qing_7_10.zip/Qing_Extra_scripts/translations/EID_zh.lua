local enums = require("Qing_Extra_scripts.core.enums")
local Items = enums.Items
local Cards = enums.Cards
local Trinkets = enums.Trinkets
local Players = enums.Players
local Pickups = enums.Pickups

local EIDInfo = {}

EIDInfo.Collectibles = {
    [Items.Darkness] = {Name = "暗之六面",Description = "#+1黑心#!!! 永远失去所有心之容器，并转化为对应数量的黑心#失去黑心时恐惧敌人10s #↑ 角色的攻击增加黑心数*0.8，攻击倍率增加黑心数*0.003 #绝对恐惧眼泪 #↑ 每有一个受到恐惧的敌人，增加少量攻击力 #随着角色的黑心数量增加，敌人有概率随机恐惧 ",},
	[Items.Touchstone] = {Name = "无名刃：弑金",Description = "#角色有概率发出小刀作为刺击 #!!! 小刀的攻击范围很小，但伤害很高 #小刀有概率变化为飞刀",},	-- #{{Collectible"..tostring(enums.Items.My_Best_Friend).."}}持有时，在瞬移完成后，若上一个瞬移标记仍然存在，则将那个标记重新作为攻击目标
	[Items.My_Hat] = {Name = "青的帽子",Description = "#阻挡来自脑袋上的眼泪攻击 #站在跳起来的敌人的身体下方来造成致命一击！#!!! 被践踏压制",},
	[Items.Tech_9] = {Name = "科技9",Description = "#子弹有概率转化为激光圈或是激光",},
	[Items.Assassin_s_Eye] = {Name = "刺杀者之眼",Description = "#角色的眼泪学会刺杀 #眼泪的刺杀可以多次进行",},
	[Items.A_Shard_Of_Coin] = {Name = "铸币之余",Description = "#有谶曰：金玉所成，必先自晦 #剧情道具 #在主线中，拾取此道具后将立刻与乞丐国王再战，胜利会获得硬币作为奖励，也可以选择利用传送卡离开"},
	[Items.A_Shard_Of_Glaze] = {Name = "琉璃之残",Description = "#有谶曰：晦明五色，必损于光 #剧情道具"},
	[Items.A_Shard_Of_Lava] = {Name = "流焰之华",Description = "#有谶曰：光结岩熔，必逢碎体 #剧情道具"},
	[Items.A_Shard_Of_Meat] = {Name = "鲜肉之渣",Description = "#有谶曰：体遍万物，必破心神 #剧情道具"},
	[Items.A_Shard_Of_Rock] = {Name = "岩田之蚀",Description = "#有谶曰：神归至诚，必开飞金 #剧情道具"},
	[Items.Mental_Hypnosis] = {Name = "精神控制",Description = "#获取后只有下层才会生效#按照要求顺序进入本层的特殊房间以得到奖励，否则将受到小惩罚#不显示在地图上的特殊房间不计入其中 "},
	[Items.Gold_Rush] = {Name = "淘金热",Description = "#愚者的黄金将概率替换地形#清理房间后，每有一个未被摧毁的黄金都有50%概率生成黄金蜘蛛"},
	[Items.Air_Flight] = {Name = "飞行控制者",Description = "#自动攻击敌人的小跟班 #小跟班和里万青的攻击方式类似，但角色不能控制攻击目标"},
	[Items.The_Watcher] = {Name = "监视",Description = "#移速不会低于1.3 #接近角色的敌人将会被监视和射击#!!! 一定要保持移动！"},
	[Items.Giant_Punch] = {Name = "巨大化",Description = "#↑ 总血量低于生命上限时，角色变大，攻击翻倍#↓ 总血量高于生命上限时，角色变小，攻击减半"},
	[Items.Memory] = {Name = "回忆",Description = "#!!! 一次性道具 # 使用后，移除道具池中所有未见过的道具，将其替换为角色已拥有的道具",BookOfVirtues = "记忆魂火 #每获得一个重复的道具让它可以变得更加强大，熄灭时回忆效果消失 #进入新房间后会魂火自动回复到满状态"},--记忆魂火，每获得一个重复的道具让它可以变得更加强大，熄灭时回忆效果消失。
	[Items.My_Best_Friend] = {Name = "小青最好的朋友",Description = "#向金箱子中加入若干与头相关的道具"},
	[Items.Super_Bombs] = {Name = "超级炸弹",Description = "#↑ +5超大炸弹！#超大炸弹有10%概率替换普通炸弹掉落"},
	[Items.Brimstream] = {Name = "硫磺激流",Description = "#伴随着硫磺火柱的火箭跟班！#被炸到的敌人对硫磺火脆弱 #进入房间后的1s内不会爆炸"},
	[Items.Black_Map] = {Name = "黑地图",Description = "#显示所有地图 #!!! 距离角色2个或以上的被进入房间将从地图上消失"},
	[Items.Blaststone] = {Name = "硫磺爆射",Description = "#双击发射出恐怖的硫磺火球 #火球可以吸引敌人，随后爆发出硫磺火"},
	[Items.Little_Duck] = {Name = "小黄鸭",Description = "#在未清理的房间内随机生成3只小黄鸭，向内部注入眼泪可以使他们爆开！"},
	[Items.A_Shard_Of_Blood] = {Name = "血之代偿",Description = "#有谶曰：血祭于身，身必受血 #剧情道具"},
	[Items.Alchemy_Pot] = {Name = "炼金术的掌中锅",Description = "#可以随身携带的炼金术道具 #投入3个道具以精准制作1个道具"},--炼成魂火
	[Items.Air_Terror] = {Name = "飞行界域者",Description = "#自动巡航的小跟班 #发射特殊弹药阻碍敌人进攻 #!!! 未完成"},
	[Items.Crown_of_the_glaze] = {Name = "琉璃的冠冕",Description = "#!!! 角色受伤时，额外受到半格心伤害#↑ +2攻击#↑ 射程1.5倍并+3#↑ 幸运2倍并+2 #受伤后本层内随机获得一个攻击特效 #琉璃掉落、敌人出现概率大幅上升 #琉璃基础掉落均获得额外效果"},
	[Items.Glaze_Mushroom] = {Name = "琉璃的蘑菇",Description = "#↑ +1血上限 #向boss房道具池内增加一个大蘑菇"},
	[Items.Pageant_Cross_dresser] = {Name = "盛装男娘",Description = "#↑ 每1个皮肤+0.05幸运#↑ 随机获得10个皮肤"},
	[Items.It_s_a_trick] = {Name = "鸭架",Description = "#↑ 射速+0.7"},--5%概率获得那个道具的魂火，否则什么也不生成。
	[Items.Tianyi] = {Name = "世末天依",Description = "#拾取时按顺序歌唱一句歌词 #随着音乐的进展，获得： #1句以上：1个蓄力发射启示光波的宝宝 #3句以上：射速+0.5 #7句以上：一个天使宝宝 #15句以上：+1攻击 #30句以上：一对感化的双生宝 #一曲终了：给予你审判世界的权利 #未完全完成"},
	[Items.Colorblindness] = {Name = "傲慢或是偏见",Description = "#!!! 失去红绿色感 #眼泪按照视野变成红、绿色 #红色使角色伤害+1、分裂、具有烂番茄效果#绿色使角色射速+0.5、带毒、带毒液 #受伤会恢复10%的色感，但增益的属性也随着减少"},
	[Items.Field] = {Name = "逆反力场",Description = "#不移动时眼泪在力场中穿梭 #对所有友方眼泪均生效 #↑ 延迟-1"},
	[Items.Suture_Needle] = {Name = "缝合针",Description = "#将房间中所有怪兽缝合成一个大怪物，血量为怪兽总血量的80%，模仿被缝合的怪物快速行动 #对小鬼、地鼠等特殊怪兽无效#对关键Boss无效",BookOfVirtues = "合成魂火 #只会存在一个，每次缝合敌人都会变大并提升碰撞伤害 #对缝合怪兽的碰撞伤害翻倍"},--合成魂火，不会被缝合的敌人所伤害。
	[Items.More_Options___] = {Name = "更多更多选择！",Description = "#具有价格的掉落物二选一 #!!! 需要购买的掉落物价格可能变得更高"},
	[Items.Abecarnil] = {Name = "长生",Description = "#剧情道具 #每过15-角色血量/6s，一格随机的血向更高级的形态进化。进化跨越的步数是随机的 #进化顺序：空->碎心->魂心->空的骨心->血上限 #游戏时间越长，进化的速度就越快 #没有血可以进化时，角色死亡"},
	[Items.Barbital] = {Name = "分痕",Description = "#剧情道具 #每下一层，交换碎心数目和血量数目 #从4个碎心开始游戏 #对店长而言，不是4个而是1个碎心开始游戏"},
	[Items.Cyanide] = {Name = "圣明",Description = "#剧情道具 #下层后，尝试用血量消除所有诅咒 #成功消除诅咒的场合，每消去一种诅咒适用如下效果之一 #本层获得攻击+0.5，射速+0.5，幸运+0.5，移速+0.1，射程+0.5，获得一个攻击特效 #诅咒出现的概率提升100%以上。出现两个以上的诅咒，不会超过5个 #成功消除诅咒的场合，下次消除诅咒时额外需要半格血量，否则则减少半格血量"},
	[Items.Dexamethasone] = {Name = "独运",Description = "#剧情道具 #总是以失去恶魔房的状态进入下层 #每次受到伤害，有20%的概率恢复失去的恶魔房"},
	[Items.Ephedrine] = {Name = "点金",Description = "#剧情道具 #拾取时血不足3颗的时候，补充血量直至3颗，补满金心 #基础掉落转化为金心的概率上升15% #每失去一颗金心，掉落的基础转化成金心的概率提升5%。下层后这个概率降低10%"},
	[Items.Fenfluramine] = {Name = "血源",Description = "#剧情道具 #生成的红心会优先飞向敌人而不是角色。它们可以治愈敌人一定比例的生命值 #角色可以拾取红心，即使没有空的血量上限。那样做的场合，红心将对角色造成半格心的伤害 #击杀敌人有50%概率掉落若干额外的红心 #!!! 未完成！"},
	[Items.Ginsenoside] = {Name = "不死",Description = "#剧情道具 #角色死亡后总是会在3s内复活 #全属性缓缓下降直到下限，受伤会加快这个进程，下层后重置"},
	[Items.Heroisch] = {Name = "硕化",Description = "#剧情道具 #每次受伤体型增大7% #体型越大，免疫子弹攻击的概率越高。在400%时达到100% #体型大于1000%的时候，免疫敌人的伤害 #体型过大的场合，下层后会恢复 #!!! 未完成"},
	[Items.Oxytocin] = {Name = "玄化",Description = "#剧情道具 #玄化的角色可以随意穿透地形。但依然会受到地形伤害 #每个房间获得3个额外的斗篷 #玄化的角色攻击不能命中或伤害敌人 #受伤，或是失去斗篷后的5s内，角色失去玄化效果"},
	[Items.Sildenafil] = {Name = "异幻",Description = "#剧情道具 #下层时随机显示部分地图轮廓 #房间需要反复清理，只有第一次清理存在掉落物 #清理房间后随机显示一格地图轮廓 #!!! 未完成"},
	[Items.Fate_s_Draw] = {Name = "注定一抽",Description = "#持有塔罗牌时，可以看准时机使用任意一张卡 #叠加时，增加成功找到机会的概率"},
	[Items.My_Emblem] = {Name = "小青的纹章",Description = "#添加3个纹章宝宝 #纹章宝宝对接触的敌人造成伤害，每造成一次伤害可以吸收一颗子弹 #宝宝们会随着子弹发射组织进攻"},
	[Items.Ingestion_to_Night] = {Name = "夜之摄取",Description = "#按住蓄力来潜入黑暗，蓄力完成后发动黑暗中的斩击，并弹反所有弹幕。#↑ 在黑暗中30%概率免疫攻击#↑ 飞行 #↑ +1攻击 #!!! 黑暗笼罩房间 #稍微提升{{Card20}}的生成率。使用{{Card20}}会暂时驱逐黑暗。#驱逐黑暗后，稍微提升{{Card75}}的生成率，使用{{Card75}}会增强黑暗"},
	[Items.D773] = {Name = "D773",Description = "#重置你的皮肤 #重置房间内所有主动道具",BookOfVirtues = "微笑魂火 #消失后重置房间内一个随机基础" },--微笑魂火，消失后重置房间内一个随机基础。
	[Items.DVF] = {Name = "D-V-F",Description = "#这是以后会用到的※神※秘※妙※妙※工※具※，请不要随意拾取",},
	[Items.Devil_s_Heart] = {Name = "恶魔的心智",Description = "#使用主动来发射不造成伤害的恶魔标记 #角色死亡时，若被标记的敌人依然存活，复活在那个位置，并将其秒杀。随后失去一定量的随机道具。",BookOfVirtues = "永生魂火 #每个魂火可以替代一个道具被抵消"},--永生魂火，每个魂火可以替代一个道具被抵消。
	[Items.Book_of_Future] = {Name = "未来之书",Description = "#从道具池中移除总质量达到50或以上的随机道具（从4级开始），生成一个四选一道具",BookOfVirtues = "一个被移除的道具对应魂火"},--一个被移除的道具对应魂火。
	[Items.Hyper_Velocity] = {Name = "和谐号",Description = "#召唤一列动车撞向敌人 #!!! 小心撞车！!",BookOfVirtues ="和平魂火 #角色受到2格心或以上的伤害时，熄灭全部和平魂火，那个伤害被抵消"},--和平魂火，角色受到1格心或以上的伤害时，熄灭全部魂火，那个伤害被抵消。
	[Items.Wavering_Eyes] = {Name = "摇摆之眼",Description = "#随着眼泪连续命中敌人发动：#↓ 2的倍数次：眼泪晃动幅度提升 #↑ 3的倍数次：射速上升 #↑ 5次：获得{{Collectible572}}效果 #↑ 8次：获得{{Collectible3}}效果 #↑ 13次：获得{{Trinket26}}效果 #↑ 21次：获得{{Collectible221}}效果#!!! 4次失误后重置计数器"},
	[Items.Pendulum_Star] = {Name = "回荡之星",Description = "#一对不断晃动的跟班，对敌人造成伤害"},
	[Items.Book_of_Thoth] = {Name = "透特之书",Description = "#塔罗牌均被替换为透特塔罗牌 #塔罗牌出现概率大幅上升 #使用卡牌也可以获得充能 #使用后，根据两次使用主动期间使用的塔罗牌种类：#0张卡：二选一的两张卡 #1至2种：随机一张记录的卡 #3至5种：一张随机卡及其倒卡 #6至8种：六选三的随机卡 #9至13种：三张与其倒卡二选一的卡 #14至22种：记录数量一半的记录过的卡 #23种至45种：生成道具{{Collectible"..tostring(enums.Items.Fate_s_Draw).."}} #46种：生成道具{{Collectible628}}",BookOfVirtues = "塔罗魂火 #熄灭时生成一张塔罗牌"}, --塔罗魂火。发射有概率生成塔罗牌的眼泪。熄灭时生成一张塔罗牌。
	[Items.Book_of_The_Law] = {Name = "法之书",Description = "#使用后，下一次生成的道具来自当前房间的道具池",BookOfVirtues = "黑暗魂火 #熄灭时使用一次法之书"}, --黑暗魂火，熄灭时使用一次法之书。
	[Items.Book_of_Vision] = {Name = "觅之书",Description = "#使用后，当前房间内资源获取、消耗量翻倍 #金雷、金钥匙对应3个普通基础",BookOfVirtues = "眼之魂火 #获得资源时，自动消耗此魂火并将其+1"},--眼之魂火，获得资源时，自动消耗此魂火并将其+1。
	[Items.Book_of_Voice] = {Name = "假象之书",Description = "#作为底座道具被移除时，生成四选一道具 #移除的方式包括但不限于：{{Collectible477}}、{{Card41}} 、多选一、在商店被刷新等 #使用后，失去随机基础，并让此书被移除时生成的道具数量+1 #满充能时自动使用此道具 #携带此书通过3层，可以在下层后生成1张{{Card41}}",BookOfVirtues = "回声魂火 #每个魂火在清理完房间后有25%概率消耗主动道具的一格充能，被破坏的时候掉落多选一掉落物 #数量由其消耗的充能数决定"}, --回声魂火，每个魂火在清理完房间后有50%概率消耗主动道具的一格充能，被破坏的时候掉落多选一基础，数量由其消耗的充能数决定。
	[Items.Aphasia] = {Name = "失语症",Description = "#!!! 失去表述文字的能力 #无法表述的文字散落在地上 #收集文字，每个文字可以让一发眼泪增加伤害 #不会影响EID",},
	[Items.Nazca] = {Name = "纳兹卡巨画",Description = "#从角色的身下开始绘制地缚图线 #踩到的敌人受到伤害 #站立在地缚图线上获得属性加成，对队友也会生效",},
	[Items.Cloundy] = {Name = "云玩大佬",Description = "#自动吞噬敌人并转化为基础掉落的小跟班 #也会吞噬基础掉落并转化为敌人 #为你提供有益的游戏指导",},
	[Items.Skiel] = {Name = "痛苦因子",Description = "#长按蓄力，否则清空蓄力值 #蓄力完成后自动向身后发射因子网 #三因子同时出现和消失，互相配合",}, -- #多次连续发动会减慢蓄力速度
	[Items.Wisel] = {Name = "绝望因子",Description = "#反复点击以蓄力，否则逐渐减少蓄力值 #蓄力完成后，向前方发射冲击波纹 #三因子同时出现和消失，互相配合",}, -- #多次连续发动会降低点击速度阈值，提升蓄力速度
	[Items.Granel] = {Name = "泯灭因子",Description = "#长按蓄力，点按加快蓄力，否则缓缓减少蓄力值 #蓄力完成后向四角喷射火焰 #三因子同时出现和消失，互相配合",}, -- #多次连续发动会加快蓄力速度 #移动时将会抵消蓄力条
	[Items.Spectralsword] = {Name = "妖刀·逢魔",Description = "#请不要随便窥探别人的武器，谢谢。",},
	[Items.Squiresaga] = {Name = "妖刻·白隙",Description = "#斩开事物的间隙 #在间隙中调整它们的属性 #按下"..EID.ButtonToIconMap[ButtonAction.ACTION_DROP].."结束属性操作 #按下"..EID.ButtonToIconMap[ButtonAction.ACTION_PILLCARD].."与"..EID.ButtonToIconMap[ButtonAction.ACTION_MAP].."在项内切换",BookOfVirtues = "不生成魂火",},
	[Items.Moment] = {Name = "妖星·一瞬",Description = "#回收利用一切攻击方式的剩余能量，对敌人造成伤害并转化为属性提升 #提升达到一定值后，会泄露提升的属性防止过载 #!!! 过量的能量吸收会导致零点反转",},
	[Items.Lofty] = {Name = "崇高之阵",Description = "#阻挡每个房间第一次受到的伤害，并出释放冲击波消除弹幕 #在冲击波碰撞的敌人处再次释放冲击波 #冲击波未被消耗时，可以蓄力释放小型冲击波",},
	[Items.Theseus_s_Sign] = {Name = "忒修斯之印",Description = "#↑ 受到4次任意伤害后生成一个随机道具，下次生成道具所需的伤害次数+1 #!!! 恢复5点生命后随机失去一个道具，下次失去道具所需的恢复量+1",},
	[Items.Heart_Change] = {Name = "心变",Description = "#↑ 持有双翅的时候飞行 #进入天使房会折断恶魔的翅膀，生成1个黑心 #进入恶魔房会折断天使的翅膀，生成1个白心 #双翅均折断后，下层会生成天使、恶魔房道具各一个，然后恢复双翅",},
	[Items.Cable_Jar] = {Name = "雷灵集束",Description = "#受伤后，发射雷束激光 #激光的数量与消耗的主动充能有关 #拾取电击后生成的充能球来补充主动充能",},
	[Items.Gospel] = {Name = "福音",Description = "#额外抛掷福音眼泪 #没有按照轨迹移动会逐渐污染福音眼泪 #未被污染的眼泪落下后不会立即消失，而是逐渐吸引周围敌人，随后有概率爆发光束 #被污染的眼泪有概率立刻发射光束攻击敌人，否则会在落下后立即爆炸，不会伤害角色",},
	[Items.Tiramisu] = {Name = "提拉米苏",Description = "#↑ +1血上限 #↑ 属性提升的场合，额外提供40%逐渐减少的属性增幅量",},
	[Items.Live_Broadcast] = {Name = "直播姬",Description = "#游戏进入直播模式 #可以实时与弹幕互动 #人气值足够会有老板送来礼物，提升属性 #这个道具之后还会继续丰富内容",},
	[Items.Drama_of_sorrow_and_joy] = {Name = "悲欢之凶剧",Description = "#概率发射出面具眼泪，面具分为：#喜剧：面具眼泪跟随角色控制俯冲攻击并产生不伤害角色的爆炸 #悲剧：面具眼泪飞向最远处的敌人并引发不伤害角色的爆炸 #被敌人伤害后，交换悲喜面具 #!!! 在一个房间内切换13次面具将在本局永久带上面具",},
	[Items.Tzolkin] = {Name = "卓尔金神历",Description = "#每次使用永久获得：#↑+0.2幸运 #↑+0.2攻击 #↑+0.1射速 #↑+0.5射程 #↑+0.05移速 #失去此主动后，降低使用主动提升的属性。#!!! 使用虚空等方式消耗不算持有",BookOfVirtues = "红龙魂火 #只要此魂火没有全部熄灭，就不会接受失去主动的负面效果"}, --红龙魂火，只要此魂火没有全部熄灭，就不会接受失去主动的负面效果
	[Items.Pareidolia] = {Name = "妖心·盈月",Description = "#从右眼中伸出可控制的眼泪链条 #与眼类型道具存在配合效果#不受射速和攻击的影响",},
	[Items.Reversal_Film] = {Name = "反转片？",Description = "#剧情道具 #将它贴在某个门上 #立刻将你传送回到初始房间",},
	[Items.Tears_of_Pearl] = {Name = "鲛人之泪",Description = "#概率发射珍珠眼泪 #珍珠眼泪落地后吸收周围的飞弹 #可以踢动地上的珍珠",},
}

EIDInfo.Trinkets = {
}

EIDInfo.Cards = {
	[Cards.Glaze_dice_shard] = {
        Name = "琉璃的骰子碎片",
        Description = "#将所有掉落物转化为它们的琉璃版本 #将房间内所有道具变成与他们同色的随机道具#!!! 一个道具可能有多种颜色",
		Frame = 0,
    },
	[Cards.Qing_s_Soul] = {
        Name = "小青的灵魂石",
        Description = "连续发射若干把帅气飞刀",
		Frame = 1,
    },
	[Cards.Round_trip_Rail_Ticket] = {
        Name = "双行火车票",
        Description = "召唤一辆列车。坐上列车可以前往天国(物理)",
		Frame = 2,
    },
	[Cards.One_way_Rail_Ticket] = {
        Name = "单程票",
        Description = "再次召唤列车",
		Frame = 3,
    },
	[Cards.Adjustment] = {
		Name = "VIII - 调节",
		Description = "#平衡你的金币、钥匙与炸弹",
		tarotClothBuffs = "根据此次平衡改变的基础数量，获得属性提升",
	},
	[Cards.Lure] = {
		Name = "XI - 欲望",
		Description = "#本房间内，略微加速所有敌人，他们受到的伤害提升固定值5点。",
		tarotClothBuffs = "固定值提升至10点",
	},
	[Cards.Art] = {
		Name = "XIV - 艺术",
		Description = "#使用后，30s内，击杀生命值在10%以下的敌人会随机奖励掉落物。对boss无效。",
		tarotClothBuffs = "效果时间翻倍",
	},
	[Cards.Aeon] = {
		Name = "XX - 永恒",
		Description = "#金币是奇数时，生成一个忏悔机 #金币是偶数时，给予一个白心",
		tarotClothBuffs = "没有效果",
	},
	[Cards.Universe] = {
		Name = "XXI - 宇宙",
		Description = "#移除身上等级最高的道具，生成一个星座或星象道具。",
		tarotClothBuffs = "生成一个二选一的星象道具",
	},	
	[Cards.Adjustment_r] = {
		Name = "VIII - 调节?",
		Description = "#将你的全部基础掉落转化为属性。",
		tarotClothBuffs = "50%概率再次掉落此卡",
	},
	[Cards.Lure_r] = {
		Name = "XI - 欲望?",
		Description = "#本房间内全属性暂时下降。本房间内受伤后，随机掉落魂心、红心#店长会掉落硬币",
		tarotClothBuffs = "大幅下降你的全属性，基础掉落概率更高，受伤后也会掉落其他基础",
	},
	[Cards.Art_r] = {
		Name = "XIV - 艺术?",
		Description = "#本房间内，引爆所有消失的实体。每次爆炸会变得更加猛烈#离开时引爆房间内所有实体",
		tarotClothBuffs = "爆炸不会伤害到使用者",
	},
	[Cards.Aeon_r] = {
		Name = "XX - 永恒?",
		Description = "#全属性大幅上升。每当下列一项触发时，上升量减少#1.获得、失去基础掉落或生命值#2.获得、失去饰品或是道具#若此上升量未降低至0，每次清理房间，都会缓缓提升全属性",
		tarotClothBuffs = "提升属性上升量",
	},
	[Cards.Universe_r] = {
		Name = "XXI - 宇宙?",
		Description = "#第一次使用时，随机失去一个道具。此后的本局游戏，每次使用此卡，都会生成这个道具 #使用后，下层开始时，生成此卡。",
		tarotClothBuffs = "刷新失去的道具的状态，但是每次使用都会重新失去道具用于交换",
	},
}

EIDInfo.Birthrights = {
    [Players.wq] = {
        Description = "#迎接第二次的觉醒！#瞬移攻击得到极大提升！",
        PlayerName = "万青"
    },
    [Players.Spwq] = {
        Description = "#浮游炮的产生速度大幅上升了",
        PlayerName = "？？？的万青"
    },
    [Players.Tecro] = {
        Description = "#？？？",
        PlayerName = "泰克罗"
    },
    [Players.Tecrorun] = {
        Description = "#？？？",
        PlayerName = "泰克罗罗恩"
    },
}

EIDInfo.CollectibleTransformations = {
    [Items.Darkness] = "9",
    [Items.Glaze_Mushroom] = "2",
    [Items.Mental_Hypnosis] = "5",
	[Items.Tianyi] = "4",
    [Items.Devil_s_Heart] = "9",
    [Items.Book_of_Future] = "12",
    [Items.Book_of_Thoth] = "12",
    [Items.Book_of_The_Law] = "12",
    [Items.Book_of_Vision] = "12",
    [Items.Book_of_Voice] = "12",
}

EIDInfo.Pickups = {}

table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_heart.Variant,SubType = Pickups.Glaze_heart.SubType,Name = "琉璃之心",Description = "#拾取时，随机模仿一颗已有的心"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_heart_half.Variant,SubType = Pickups.Glaze_heart_half.SubType,Name = "琉璃之半心",Description = "#拾取时，随机模仿半颗已有的心"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_key.Variant,SubType = Pickups.Glaze_key.SubType,Name = "琉璃之匙",Description = "#拾取时，点亮一个随机地图"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_bomb.Variant,SubType = Pickups.Glaze_bomb.SubType,Name = "琉璃之炸弹",Description = "#拾取时，下个使用的炸弹会消除飞弹"})
--table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_coin.Variant,SubType = Pickups.Glaze_coin.SubType,Name = "琉璃之硬币",Description = "#缓缓吸引周围的掉落物#20%概率给予5块钱"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_grabbag.Variant,SubType = Pickups.Glaze_grabbag.SubType,Name = "琉璃之福袋",Description = "#打开后，消耗你的基础掉落物生成琉璃化掉落物 #没有基础掉落的场合生成琉璃的便便"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_battery.Variant,SubType = Pickups.Glaze_battery.SubType,Name = "琉璃之电池",Description = "#消耗主动的所有充能 #在接下来的房间清理中，获得充能的速度更快"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_chest.Variant,SubType = Pickups.Glaze_chest.SubType,Name = "琉璃之宝箱",Description = "#本层随机方位出现一把钥匙跟班 #只能用钥匙跟班打开 #不会出现在红隐"})
table.insert(EIDInfo.Pickups,{Variant = Pickups.Glaze_big_poop.Variant,SubType = Pickups.Glaze_big_poop.SubType,Name = "琉璃之便便",Description = "#受伤后随机使用1个便便 #堆叠上限：1"})

EIDInfo.PlayerSync = {
	[enums.Players.wq] = {
		--[CollectibleType.COLLECTIBLE_MY_REFLECTION] = {Description = "瞬移方式改为镜面闪击",},
		[CollectibleType.COLLECTIBLE_DR_FETUS] = {Description = "攻击方式变化#小刀碰撞敌人和炸弹时引发爆炸",},
		[CollectibleType.COLLECTIBLE_LEMON_MISHAP] = {Description = "小刀变成柠檬水瓶，落地后概率碎裂",},
		[CollectibleType.COLLECTIBLE_TECHNOLOGY] = {Description = "小刀变为科技刀刃",},
		[CollectibleType.COLLECTIBLE_CHOCOLATE_MILK] = {Description = "自动蓄力，随着蓄力增加下一发小刀自动变大#可以在任意时刻攻击",},
		[CollectibleType.COLLECTIBLE_PARASITE] = {Description = "小刀命中敌人后分裂两发小型小刀",},
		[CollectibleType.COLLECTIBLE_MOMS_KNIFE] = {Description = "用小刀狠狠地扎入它们的身体",},
		[CollectibleType.COLLECTIBLE_BRIMSTONE] = {Description = "攻击间隙发射出附着硫磺火的小刀",},
		--[CollectibleType.COLLECTIBLE_LUMP_OF_COAL] = {Description = "小刀伤害随目标距离变大",},
		[CollectibleType.COLLECTIBLE_IPECAC] = {Description = "小刀伤害大幅提升#小刀攻击引发爆炸",},
		[CollectibleType.COLLECTIBLE_TECHNOLOGY_2] = {Description = "额外进行科技刀刃刺击",},
		[CollectibleType.COLLECTIBLE_EPIC_FETUS] = {Description = "发射的小刀插在墙或敌人上，随后导弹瞄准小刀落下",},
		[CollectibleType.COLLECTIBLE_POLYPHEMUS] = {Description = "小刀大幅变大",},
		[CollectibleType.COLLECTIBLE_3_DOLLAR_BILL] = {Description = "每一轮随机你的攻击方式",},
		[CollectibleType.COLLECTIBLE_LOST_CONTACT] = {Description = "可以斩飞弹幕",},
		[CollectibleType.COLLECTIBLE_ANTI_GRAVITY] = {Description = "飞刀悬停在空中",},
		[CollectibleType.COLLECTIBLE_CRICKETS_BODY] = {Description = "小刀命中敌人后四向发射小型小刀",},
		[CollectibleType.COLLECTIBLE_MONSTROS_LUNG] = {Description = "多把小刀爆发攻击面前敌人",},
		[CollectibleType.COLLECTIBLE_TINY_PLANET] = {Description = "飞刀将会旋转",},
		[CollectibleType.COLLECTIBLE_TECH_5] = {Description = "概率发射带有随机科技尾的小刀",},
		[CollectibleType.COLLECTIBLE_MISSING_NO] = {Description = "每一发小刀都是全随机攻击方式",},
		--[CollectibleType.COLLECTIBLE_PROPTOSIS] = {Description = "小刀伤害随目标距离变小",},
		[CollectibleType.COLLECTIBLE_LIBRA] = {Description = "阴阳小刀，阴阳刀都命中敌人后，会产生3轮爆炸",},
		[CollectibleType.COLLECTIBLE_AQUARIUS] = {Description = "海洋小刀，额外有概率留下水迹",},
		[CollectibleType.COLLECTIBLE_CURSED_EYE] = {Description = "可以连续攻击至多5次，但攻击的延迟将累计并在结束后计算#攻击时受伤会传送",},
		--[CollectibleType.COLLECTIBLE_LUDOVICO_TECHNIQUE] = {Description = "",},
		[CollectibleType.COLLECTIBLE_SOY_MILK] = {Description = "小刀也会大幅变小",},
		[CollectibleType.COLLECTIBLE_GODHEAD] = {Description = "飞刀命中敌人后产生惩戒光圈",},
		[CollectibleType.COLLECTIBLE_LAZARUS_RAGS] = {Description = "复活的拉萨路依然拥有小青的帽子",},
		[CollectibleType.COLLECTIBLE_TECH_X] = {Description = "与科技X光圈配合攻击敌人",},
		[CollectibleType.COLLECTIBLE_TRACTOR_BEAM] = {Description = "小刀不受收束光线限制",},
		[CollectibleType.COLLECTIBLE_FRUIT_CAKE] = {Description = "小刀有20%概率变化为随机攻击方式",},
		[CollectibleType.COLLECTIBLE_LEAD_PENCIL] = {Description = "15次出刀后下一次出刀数量增多",},
		[CollectibleType.COLLECTIBLE_COMPOUND_FRACTURE] = {Description = "小刀命中敌人后随机方向发射小型小刀",},
		[CollectibleType.COLLECTIBLE_EYE_OF_BELIAL] = {Description = "小刀穿过敌人后生成额外的跟踪红色飞刀",},
		[CollectibleType.COLLECTIBLE_SULFURIC_ACID] = {Description = "小刀可以破坏石头与门",},
		--[CollectibleType.COLLECTIBLE_FINGER] = {Description = "指尖小刀",},
		--[CollectibleType.COLLECTIBLE_PLAN_C] = {Description = "立即获得血色小刀",},
		[CollectibleType.COLLECTIBLE_JACOBS_LADDER] = {Description = "飞刀也能发动电击攻击敌人",},
		[CollectibleType.COLLECTIBLE_GHOST_PEPPER] = {Description = "有概率生成火焰小刀，伤害三倍",},
		[CollectibleType.COLLECTIBLE_DUALITY] = {Description = "阴阳小刀，阴阳刀都命中敌人后，会产生3轮爆炸",},
		[CollectibleType.COLLECTIBLE_BACKSTABBER] = {Description = "瞬移方式改为影遁闪击",},
		[CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO] = {Description = "落地的飞刀会一直停留，直到向下一把飞刀射出激光",},
		[CollectibleType.COLLECTIBLE_HAEMOLACRIA] = {Description = "发射大型飞刀进行战斗",},
		[CollectibleType.COLLECTIBLE_TRISAGION] = {Description = "雪光小刀",},
		[CollectibleType.COLLECTIBLE_ALMOND_MILK] = {Description = "小刀也会大幅变小",},
		[CollectibleType.COLLECTIBLE_EYE_OF_THE_OCCULT] = {Description = "可以控制小刀的飞行方向",},
		[CollectibleType.COLLECTIBLE_DAMOCLES] = {Description = "达摩小刀，主宰敌人的命运",},
		[CollectibleType.COLLECTIBLE_FREE_LEMONADE] = {Description = "小刀变成柠檬水瓶，落地后概率碎裂",},
		[CollectibleType.COLLECTIBLE_SPIRIT_SWORD] = {Description = "通过转刀与瞬移作战",},
		[CollectibleType.COLLECTIBLE_TERRA] = {Description = "石中小刀，可以破坏石头、石头箱子与门",},
		[CollectibleType.COLLECTIBLE_URANUS] = {Description = "冰锥小刀，冰冻伤害到的敌人",},
		[CollectibleType.COLLECTIBLE_BIRDS_EYE] = {Description = "有概率生成火焰小刀，伤害翻倍",},
		[CollectibleType.COLLECTIBLE_C_SECTION] = {Description = "小刀进行攻击后变为刀灵，操纵飞刀攻击敌人",},
		[enums.Items.Touchstone] = {Description = "使用瞬移技后，若上一个瞬移标记仍然存在，则将那个标记重新作为瞬移目标",},
		[enums.Items.Assassin_s_Eye] = {Description = "瞬移方式改为影遁闪击",},
		--[enums.Items.Air_Flight] = {Description = "瞬移方式改为影遁闪击",},
		--[enums.Items.My_Best_Friend] = {Description = "瞬移方式改为影遁闪击",},
		--[enums.Items.Suture_Needle] = {Description = "瞬移方式改为影遁闪击",},
		--[enums.Items.Spectralsword] = {Description = "瞬移方式改为影遁闪击",},
		--[enums.Items.Squiresaga] = {Description = "瞬移方式改为影遁闪击",},
		[enums.Items.Gospel] = {Description = "飞刀命中敌人后产生惩戒光圈",},
	},
}

return EIDInfo;
