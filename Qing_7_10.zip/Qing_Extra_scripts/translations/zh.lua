local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local displaying_data = require("Qing_Extra_scripts.translations.data")
local Items = enums.Items
local Cards = enums.Cards
local modReference
local item = {
	zh = {},
	en = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	pre_myToCall = {},
	post_myToCall = {},
}

item.zh.Collectibles = {
    [Items.Darkness] = {Name="暗之六面" , Description="湮灭于未知"},
    [Items.Touchstone] = {Name="无名刃：弑金" , Description="最好一击远遁"},
    [Items.My_Hat] = {Name="小青的帽子" , Description="太大了！"},
    [Items.Tech_9] = {Name="科技IX" , Description="被跳过的未来"},
    [Items.Assassin_s_Eye] = {Name="暗杀者之泪" , Description="彗星袭月"},
	[Items.A_Shard_Of_Coin] = {Name = "铸币之余",Description = "金玉所成，必先自晦"},
	[Items.A_Shard_Of_Glaze] = {Name = "琉璃之残",Description = "晦明五色，必损于光"},
	[Items.A_Shard_Of_Lava] = {Name = "流焰之华",Description = "光结岩熔，必逢碎体"},
	[Items.A_Shard_Of_Meat] = {Name = "鲜肉之渣",Description = "体遍万物，必破心神"},
	[Items.A_Shard_Of_Rock] = {Name = "岩田之蚀",Description = "神归至诚，必开飞金"},
	[Items.Mental_Hypnosis] = {Name = "精神控制",Description = "变成我的傀儡吧！"},
	[Items.Gold_Rush] = {Name = "淘金热",Description = "一文不值"},
	[Items.Air_Flight] = {Name = "飞行控制者",Description = "滴..注入成功.."},
	[Items.The_Watcher] = {Name = "监视",Description = "无所遁形"},
	[Items.Giant_Punch] = {Name = "巨大化",Description = "神※拳※粉※碎"},
	[Items.Memory] = {Name = "回忆",Description = "我好像掉进了一个怪圈..."},
	[Items.My_Best_Friend] = {Name = "小青最好的朋友",Description = "那么，你真的有朋友吗？"},
	[Items.Super_Bombs] = {Name = "超级炸弹",Description = "突破！"},
	[Items.Brimstream] = {Name = "硫磺激流",Description = "唯有燃烧"},
	[Items.Black_Map] = {Name = "黑地图",Description = "为了探寻未知"},
	[Items.Blaststone] = {Name = "硫磺爆射",Description = "唯有彭拜"},
	[Items.Little_Duck] = {Name = "小黄鸭",Description = "鸭！鸭！鸭鸭鸭！！"},
	[Items.A_Shard_Of_Blood] = {Name = "血之代偿",Description = "血祭于身，身必受血"},
	[Items.Alchemy_Pot] = {Name = "炼金术的掌中锅",Description = "愿你必有所得",},
	[Items.Air_Terror] = {Name = "飞行界域者",Description = "敌人已锁定！"},
	[Items.Crown_of_the_glaze] = {Name = "琉璃的冠冕",Description = "你感觉身体变得脆弱"},
	[Items.Glaze_Mushroom] = {Name = "琉璃的蘑菇",Description = "我是…嗝……琉璃？"},
	[Items.Pageant_Cross_dresser] = {Name = "盛装男娘",Description = "超级豪华究极无敌涩涩！"},
	[Items.It_s_a_trick] = {Name = function(info,player,ignore_changes)
		if save.elses.glazed_trick == nil then save.elses.glazed_trick = 32 end
		local name = ""
		if item.zh.Collectibles[save.elses.glazed_trick] then 
			if save.elses.glazed_trick ~= Items.It_s_a_trick then
				name = item.zh.Collectibles[save.elses.glazed_trick].Name
				if type(name) == "function" then name = name(info,player,ignore_changes) end		--绝对！不能！无限！loop！
			else
				name = "琉璃之核"		--这是几乎不可能做到的！
			end
		else
			local configitem = Isaac:GetItemConfig():GetCollectible(save.elses.glazed_trick)
			name = auxi.check_name_data(configitem.Name)
		end
		return name.."?"
	end,Description = function(info,player)
		return "这不是我要的！！"
	end,},
	[Items.Tianyi] = {Name = "世末天依",Description = function(v,player,ignore_changes) if ignore_changes == nil then if save.elses.Tianyi == nil then save.elses.Tianyi = 1 end save.elses.Tianyi = (save.elses.Tianyi - 1) % #(v.des) + 1 end return v.des[save.elses.Tianyi] end,
	des = {"蝉时雨 化成淡墨渲染暮色","渗透着 勾勒出足迹与车辙","欢笑声 与漂浮的水汽饱和","隔着窗 同城市一并模糊了","拨弄着 旧吉他 哼着四拍子的歌","回音中 一个人 仿佛颇悠然自得","等凉雨 的温度 将不安燥热中和","寻觅着 风的波折","我仍然在 无人问津的阴雨霉湿之地","和着雨音 唱着没有听众的歌曲",
	"人潮仍是漫无目的地向目的地散去","忙碌着 无为着 继续","等待着谁能够将我的心房轻轻叩击","即使是你 也仅仅驻足了片刻便离去","想着或许 下个路口会有谁与我相遇","哪怕只 一瞬的 奇迹","夏夜空 出现在遥远的记忆","","绽放的 璀璨花火拥着繁星","消失前 做出最温柔的给予",
	"一如那些模糊身影的别离","困惑地 拘束着 如城市池中之鱼","或哽咽 或低泣 都融进了泡沫里","拖曳疲惫身躯 沉入冰冷的池底","注视着 色彩褪去","我仍然在无人问津的阴雨霉湿之地","和着雨音 唱着没有听众的歌曲","人潮仍是漫无目的地向目的地散去","忙碌着 无为着 继续",
	"祈求着谁 能够将我的 心房轻轻叩击","今天的你 是否会留意并尝试去靠近","因为或许 下个路口仍是同样的结局","不存在刹那的奇迹","极夜与永昼","别离与欢聚","脉搏与呼吸","找寻着意义","我仍然在无人问津的阴雨霉湿之地","和着雨音 唱着卖不出去的歌曲","浮游之人也挣扎不已执着存在下去",
	"追逐着 梦想着 继续","请别让我独自匍匐于滂沱世末之雨","和着雨音 唱着见证终结的歌曲","人们终于 结束了寻觅呆滞伫立原地","哭泣着 乞求着 奇迹","用这双手 拨出残缺染了锈迹的弦音","都隐没于淋漓的雨幕无声无息","曲终之时 你是否便会回应我的心音","将颤抖的双手牵起","迎来每个人的结局",},
	},
	[Items.Colorblindness] = {Name = "傲慢或是偏见",Description = "亦或者，两者兼有"},
	[Items.Field] = {Name = "逆反力场",Description = "↑升天↑"},
	[Items.Suture_Needle] = {Name = "缝合针",Description = "变成怪兽也好，受尽歧视也好..."},
	[Items.More_Options___] = {Name = "更多更多选择！",Description = "当然，也要付出一点代价"},
	[Items.Abecarnil] = {Name = "长生",Description = "我们的痛楚刻骨铭心",Rnd_Special = {Name = "艾比卡奴",Description = "在世的恶魔",},},
	[Items.Barbital] = {Name = "分痕",Description = "我们的心灵相互摧残",Rnd_Special = {Name = "巴别妥",Description = "焚灭的心愿",},},
	[Items.Cyanide] = {Name = "圣明",Description = "我们的未来一片旷野",Rnd_Special = {Name = "苋蒂",Description = "神启的祝福",},},
	[Items.Dexamethasone] = {Name = "独运",Description = "我们的信仰往复交战",Rnd_Special = {Name = "地赛密森",Description = "反生的祈福",},},
	[Items.Ephedrine] = {Name = "点金",Description = "我们的财富难分你我",Rnd_Special = {Name = "伊芬町",Description = "巫妖的瑰宝",},},
	[Items.Fenfluramine] = {Name = "血源",Description = "我们的血脉彼此交融",Rnd_Special = {Name = "夫路拉末",Description = "鲜红的悲鸣",},},
	[Items.Ginsenoside] = {Name = "不死",Description = "我们的基因如此纠缠",Rnd_Special = {Name = "色诺斯帝",Description = "永昼的哀歌",},},
	[Items.Heroisch] = {Name = "硕化",Description = "我们的躯壳激烈碰撞",Rnd_Special = {Name = "海诺西",Description = "盖亚的威波",},},
	[Items.Oxytocin] = {Name = "玄变",Description = "我们的灵魂无比灰暗",Rnd_Special = {Name = "奥杜辛",Description = "白夜的祷告",},},
	[Items.Sildenafil] = {Name = "异幻",Description = "我们的智慧一败涂地",Rnd_Special = {Name = "西德那辐",Description = "幽冥的葬列",},},
	[Items.Fate_s_Draw] = {Name = "注定一抽",Description = "只要我牌组里还有卡，我始终相信我的牌组！！"},
	[Items.My_Emblem] = {Name = "小青的纹章",Description = "为它们找个家吧！"},
	[Items.Ingestion_to_Night] = {Name = "夜之摄取",Description = "月黑风高"},
	[Items.D773] = {Name = function(v,player,ignore_changes) if ignore_changes == nil then if save.elses.D773 == nil then save.elses.D773 = 0 end end return "D"..tostring(773 + save.elses.D773) end,Description = function(v) return v.des[math.random(#(v.des))] end,
	des = {"生活就像奥利奥","海拔越高，大脑运转就越快","这就是究极的谜题","人生就是犯罪","小丑鼻子立于时尚之巅","不要把任何事当真，除非那是一个笑话","一条鱼走进酒吧","一只鸭子走进酒吧","猴子抓起香蕉","逃出这个笼子",	"浑身上下都是毛病","无鱼伦比！","扭扭路的牙医杀手","蛋糕满嘴谎言",}},
	[Items.Devil_s_Heart] = {Name = "恶魔的心智",Description = "他们自愿为我而死",Rnd_Special = {Name = "喜悦之种",Description = "永生？呵呵..",},},
	[Items.DVF] = {Name = "D-V-F",Description = "一切代价，在所不惜。",Rnd_Special = {Name = "- - -",Description = "- - -",weigh = 10,},},
	[Items.Book_of_Future] = {Name = "未来之书",Description = "未来因此改变",},
	[Items.Hyper_Velocity] = {Name = "和谐号",Description = "绝绝子，创创死"},
	[Items.Wavering_Eyes] = {Name = "摇晃之眼",Description = "左顾右盼，无处可逃"},
	[Items.Pendulum_Star] = {Name = "回荡之星",Description = "摇晃吧！吾魂之灵摆！"},
	[Items.Book_of_Thoth] = {Name = "透特之书",Description = "愿塔罗启迪你"},
	[Items.Book_of_The_Law] = {Name = "法之书",Description = "它为你而扭曲"},
	[Items.Book_of_Vision] = {Name = "觅之书",Description = "视线所及，再无安宁"},
	[Items.Book_of_Voice] = {Name = "假象之书",Description = "快，毁灭我",Rnd_Special = {Name = "零之书",Description = "一个声音在我耳边低语",weigh = 4,},},
	[Items.Aphasia] = {Name = "失语症",Description = "名可名，非常名",},
	[Items.Nazca] = {Name = "纳兹卡线条",Description = "神明立于尘埃之上",Rnd_Special = {Name = "地缚地上绘",Description = "极星重临大地",weigh = 6,},},
	[Items.Cloundy] = {Name = "云玩大佬",Description = "说什么呢，你才是云玩家！",},
	[Items.Skiel] = {Name = "痛苦因子",Description = "你的过去由我笼罩",},
	[Items.Wisel] = {Name = "绝望因子",Description = "你的现在由我咒缚",},
	[Items.Granel] = {Name = "泯灭因子",Description = "你的未来由我惩戒",},
	[Items.Spectralsword] = {Name = "妖刀 · 逢魔",Description = "刀既出鞘，身死方休",Rnd_Special = {Name = "青",Description = "斩生身兮凭风，合光来兮以扬声",weigh = 10,},},
	[Items.Squiresaga] = {Name = "妖刻 · 白隙",Description = "由我斩尽虚妄",Rnd_Special = {Name = "赤",Description = "觅长生兮不获，流天火兮葬心魂",weigh = 10,},},
	[Items.Moment] = {Name = "妖星 · 一瞬",Description = "轻量化永动转子",Rnd_Special = {Name = "苍",Description = "解万事兮尚忧，心惶惶兮难驻足",weigh = 10,},},
	[Items.Lofty] = {Name = "崇高之阵",Description = "坠入深不见底的绝望深渊吧",},
	[Items.Theseus_s_Sign] = {Name = "忒修斯之印",Description = "我将无我",},
	[Items.Heart_Change] = {Name = "心变",Description = "一念神魔",},
	[Items.Cable_Jar] = {Name = "罐中雷暴",Description = "你有点漏电",},
	[Items.Gospel] = {Name = "福音",Description = "神的国度带着主权临到",},
	[Items.Tiramisu] = {Name = "提拉米苏",Description = "血量上升+道具变得美味",},
	[Items.Live_Broadcast] = {Name = "性感光头在线连败",Description = "成为主播出道吧！",},
	[Items.Drama_of_sorrow_and_joy] = {Name = "悲欢之凶剧",Description = "丑角登场",},
	[Items.Tzolkin] = {Name = "卓尔金神历",Description = "祈祷神历的宿命",},
	[Items.Pareidolia] = {Name = "妖心· 月满",Description = "瞬世回眸",Rnd_Special = {Name = "黄",Description = "操太阴兮蚀痕，问执象兮曾不识",weigh = 10,},},
	[Items.Reversal_Film] = {Name = "反转片",Description = "阴影选择了我",},
	[Items.Tears_of_Pearl] = {Name = "鲛人之泪",Description = "高尚者为我悼哭",},
	[CollectibleType.COLLECTIBLE_BIRTHRIGHT] = {Name = "长子名分",Description = function(info,player)
		local name = player:GetName()
		if name == "W.Qing" then 
			return "血债应由血偿!" 
		elseif name == "SP.W.Qing" then 
			return "额外组件已就位！" 
		elseif name == "Tecro" then 
			return "予我新生？" 
		elseif name == "Tecrorun" then 
			return "她的力量重临于我" 
		else
			local name = auxi.get_birth_right_name(player) 
			if name then 
				local ret = auxi.check_name_data("#"..name.."_BIRTHRIGHT")
				if ret then return ret end
			end 
			return "" 
		end
	end,},
}

item.en.Collectibles = {
	[Items.It_s_a_trick] = {Name = function(info,player,ignore_changes)
		if save.elses.glazed_trick == nil then save.elses.glazed_trick = 32 end
		local name = ""
		if item.zh.Collectibles[save.elses.glazed_trick] then 
			if save.elses.glazed_trick ~= Items.It_s_a_trick then
				name = item.en.Collectibles[save.elses.glazed_trick].Name
				if type(name) == "function" then name = name(info,player,ignore_changes) end		--绝对！不能！无限！loop！
			else
				name = "Glazed Core"		--这是几乎不可能做到的！
			end
		else
			local configitem = Isaac:GetItemConfig():GetCollectible(save.elses.glazed_trick)
			name = auxi.check_name_data(configitem.Name)
		end
		return name.."?"
	end,Description = function(info,player)
		return "You Are Fooled Again!!"
	end,},
	[Items.D773] = {Name = function(v) if save.elses.D773 == nil then save.elses.D773 = 0 end;return "D"..tostring(773 + save.elses.D773) end,Description = function(v) return v.des[math.random(#(v.des))] end,
	des = {"It's like an oreo.","Higher altitude,Higher level brain.","It's the ultimate mystery.","Life's a crime.","A clown nose is the height of fashion.","Never take anything seriously,unless it's a joke.","I'm a clown GUY!","A fish walks into a bar.","A monkey grabs the banana and runs away.","Help me out of this cage!","I'm a twisted individual.","Fishtastic!","The Dentist Killer of wobbly Road","Cake is dry,not moist.And deceitful.","The end result of an evoluved family line of clowns.",}},
	[CollectibleType.COLLECTIBLE_BIRTHRIGHT] = {Name = "Birthright",Description = function(info,player)
		local name = player:GetName()
		if name == "W.Qing" then 
			return "Pain has to pay" 
		elseif name == "SP.W.Qing" then 
			return "Memories.." 
		else
			local name = auxi.get_birth_right_name(player) 
			if name then 
				local ret = auxi.check_name_data("#"..name.."_BIRTHRIGHT")
				if ret then return ret end
			end 
			return "" 
		end
	end,},
}

item.zh.Trinkets = {
}

item.zh.Cards = {
    [Cards.Glaze_dice_shard] = {Name="琉璃的骰子碎片" , Description="我的模仿者在何方？何方？何方？"},
    [Cards.Qing_s_Soul] = {Name="小青的魂石" , Description="安全了，暂时的"},
	[Cards.Round_trip_Rail_Ticket] = {Name = "双行火车票",Description = "提供食宿！",},
	[Cards.One_way_Rail_Ticket] = {Name = "单程票",Description = "送我回家吧！",},
	[Cards.Adjustment] = {Name = "VIII - 调节",Description = "无知之幕正在落下",},
	[Cards.Lure] = {Name = "XI - 欲望",Description = "释放他们内心的猛兽",},
	[Cards.Art] = {Name = "XIV - 艺术",Description = "超绝！豪快！闷绝！优雅！超级！究极超级！",},
	[Cards.Aeon] = {Name = "XX - 永恒",Description = "莫要悲伤，莫要哭泣",},
	[Cards.Universe] = {Name = "XXI - 宇宙",Description = "星汉灿烂",},
	[Cards.Adjustment_r] = {Name = "VIII - 调节?",Description = "与其纷争，莫如没收",},
	[Cards.Lure_r] = {Name = "XI - 欲望?",Description = "顺从你内心的奴隶",},
	[Cards.Art_r] = {Name = "XIV - 艺术?",Description = "艺术，就是爆炸",},
	[Cards.Aeon_r] = {Name = "XX - 永恒?",Description = "瞬间即成永恒",},
	[Cards.Universe_r] = {Name = "XXI - 宇宙?",Description = "不管离开多远，不管时间如何流逝，你永远都是属于我的",},
}

table.insert(item.pre_myToCall,#item.pre_myToCall + 1,{CallBack = enums.Callbacks.PRE_DESCRIPT_ITEM, params = nil,
Function = function(_,player,tp,id,value)
	local target = nil
	local ignore_changes = nil
	local language = Options.Language
	local item = item[language]
	if item == nil then return nil end
	if tp == "Trinket" then
		target = item.Trinkets
	elseif tp == "Item" then
		target = item.Collectibles
	elseif tp == "Card" then
		target = item.Cards
	elseif tp == "UnItem" then
		target = item.Collectibles
		ignore_changes = true
	end
	if target == nil then return nil end
	local info = target[id]
	if info then
		if info.Rnd_Special then
			local rnd_mx = 5
			if info.Rnd_Special.weigh then rnd_mx = info.Rnd_Special.weigh end
			local rnd = math.random(rnd_mx)
			if rnd == 1 then
				info = info.Rnd_Special
			end
		end
		local name = info.Name
		local des = info.Description
		if type(name) == "function" then name = name(info,player,ignore_changes) end
		if type(des) == "function" then des = des(info,player,ignore_changes) end
		return {Name = name,Description = des,}
	end
	return nil
end,
})

function item.Init(mod)
	modReference = mod	
end

return item