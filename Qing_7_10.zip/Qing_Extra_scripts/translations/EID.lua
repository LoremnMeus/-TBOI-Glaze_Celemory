local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local EIDInfo = nil
local languages = {
	["en_us"] = "Qing_Extra_scripts.translations.EID_en",
	["zh_cn"] = "Qing_Extra_scripts.translations.EID_zh",
}

for u,v in pairs(languages) do
	local EIDInfo = include(v)
	local languageCode = u
	for id, col in pairs(EIDInfo.Collectibles) do
		EID:addCollectible(id, col.Description, col.Name,languageCode);
		if (col.BookOfVirtues and EID.descriptions[languageCode].bookOfVirtuesWisps) then
			EID.descriptions[languageCode].bookOfVirtuesWisps[id] = col.BookOfVirtues;
		end
	end

	for id, trinket in pairs(EIDInfo.Trinkets) do
		EID:addTrinket(id, trinket.Description, trinket.Name,languageCode);
	end

	for id, trans in pairs(EIDInfo.CollectibleTransformations) do
		EID:assignTransformation("collectible", id, trans,languageCode)
	end

	for id, br in pairs(EIDInfo.Birthrights) do
		EID:addBirthright(id, br.Description, br.PlayerName,languageCode)
	end

	for id, cd in pairs(EIDInfo.Cards) do
		EID:addCard(id, cd.Description, cd.Name,languageCode)
		if cd.tarotClothBuffs then
			EID.descriptions[languageCode].tarotClothBuffs[id] = cd.tarotClothBuffs
		end
		local s = Sprite()
		s:Load("gfx/ui/EID/qing_cardpill_icons.anm2",true)
		if cd.Frame then EID:addIcon("Card"..id, "Card", cd.Frame, 16, 16, 0, 1, s) end
	end

	for id, pk in pairs(EIDInfo.Pickups) do
		EID:addEntity(5, pk.Variant, pk.SubType, pk.Name, pk.Description, languageCode)
	end
	
	if EIDInfo.PlayerSync then
		local descriptions = EID.descriptions[languageCode]
		for id, info in pairs(EIDInfo.PlayerSync) do
			descriptions["PlayerSync_qing_"..tostring(id)] = {}
			for u,v in pairs(info) do
				descriptions["PlayerSync_qing_"..tostring(id)]["100."..u] = v.Description
			end
		end
	end
	
end

local s = Sprite()
s:Load("gfx/ui/EID/qing_player_icons.anm2", true)
EID:addIcon("Player"..enums.Players.wq, "Players", 0, 12, 12, -1, 1, s);
EID:addIcon("Player"..enums.Players.Spwq, "Players", 1, 12, 12, -1, 1, s);

for u,v in pairs(enums.Players) do
	EID:addDescriptionModifier("qing_player_sync"..tostring(v), function(desc) local ret = auxi.have_player(v) return ret end, function(desc)
        local id = desc.ObjType
        local vr = desc.ObjVariant
        local st = desc.ObjSubType
        if (id == 5) then
            local info = EID:getDescriptionEntry("PlayerSync_qing_"..tostring(v), tostring(vr).."."..tostring(st))
            if (info) then
                info = "#"..info
                local repl = "#{{Player"..v.."}} "
                info = string.gsub(info, "#", repl)
                EID:appendToDescription(desc, info)
            end
        end
        return desc
	end)
end

return EIDInfo