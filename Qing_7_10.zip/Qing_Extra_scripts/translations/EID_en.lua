local enums = require("Qing_Extra_scripts.core.enums")
local Items = enums.Items
local Cards = enums.Cards
local Trinkets = enums.Trinkets
local Players = enums.Players

local EIDInfo = {}

EIDInfo.Entries = {
}

EIDInfo.Transformations = {
}

EIDInfo.Collectibles = {
    [Items.Darkness] = {Name = "Darkness",Description = "#Black Heart + 1 #all Heart Containers convert to Black Hearts #Damage up depending on the number of Black Hearts#Fearing tears#Damage up depending on the enemies feared#Fear enemies whenever a Black Heart is lost",},
	[Items.Touchstone] = {Name = "Touchstone",Description = "Small Chance to throw a stab knife just like W.Q.",},
	[Items.My_Hat] = {Name = "Qing's Hat",Description = "Blocks Damage from above#Deal damage to Enemies that is jump in the air on collision",},
	[Items.Tech_9] = {Name = "Tech IX",Description = "Chances are that tears will transform into Lasers or Tech X Lasers",},
	[Items.Assassin_s_Eye] = {Name = "Assassin's Eye",Description = "Grants assassinate to the Enemies with your Tears",},
	[Items.Mental_Hypnosis] = {Name = "Mental Hypnosis",Description = "#!!! Finish the quests as order to get small gifts,otherwise to get Punishments#!!! Unfinished！"},
	[Items.Gold_Rush] = {Name = "Gold Rush",Description = "#Chances are that The Fool's Gold will replace the normal rock."},
	[Items.Air_Flight] = {Name = "Air Flight",Description = "#A baby automaticly targets enemies."},
	[Items.The_Watcher] = {Name = "The Watcher",Description = "#Speed will no longer lower then 1.3.#!!! KEEP RUNNING!!!!"},
	[Items.Giant_Punch] = {Name = "Giant Punch",Description = "#↑ 2×Dmg and be larger when you are unhealthy.#↓ 0.5×Dmg and be smaller when you are healthy."},
	[Items.Memory] = {Name = "Memory",Description = "#!!! Only Once #!!! Upon use, remove all items you have not seen from itempool.Add several copies of items that you have seen."},
	[Items.My_Best_Friend] = {Name = "My Best Friend",Description = "#!!! ???#!!! !!!"},
	[Items.Super_Bombs] = {Name = "Super Bombs",Description = "#↑ +5Giga Bombs！#Giga Bombs have chance to replace normal bombs."},
	[Items.Brimstream] = {Name = "Brimstream",Description = "#Rocket with brimstone! #Won't explode upon enter the room."},
	[Items.Black_Map] = {Name = "Black Map",Description = "#Reveal all rooms #!!! Rooms that're far enough will dispair from the map once you finish it."},
	[Items.Blaststone] = {Name = "Blaststone",Description = "#Double tap to fire nice brimstone fireball!"},
	[Items.Alchemy_Pot] = {Name = "Alchemy Pot",Description = "#Invest 3 items into Alchemy pot to gain a new one whose ID is fixed by three items."},
	[Items.Crown_of_the_glaze] = {Name = "Crown of the glaze",Description = "#!!! Take half more damage from enemies.#↑ +2Dmg#↑ 1.5×Range+3#↑ 2×Luck+2 #Get random effect this level upon hurt"},
	[Items.Glaze_Mushroom] = {Name = "Glaze Mushroom",Description = "#↑ +1Hp#Add a Magic Mushroom into the boss itempool"},
	[Items.Pageant_Cross_dresser] = {Name = "Pageant Cross-dresser",Description = "#↑ +0.05Luck per costume#↑ Add 10 random costumes"},
	[Items.It_s_a_trick] = {Name = "Wire core hanger",Description = "#↑ 0.7Tears up."},
	[Items.Tianyi] = {Name = "Singer in the last phase",Description = "#An baby shooting light beam"},
	[Items.Colorblindness] = {Name = "Colorblindness",Description = "#!!! Mix the red and green color #Red screen grants +1Dmg,spliting tears and bait tears#Green screen grants +2Range,poision tears and mysterious liquid tears"},
	[Items.Field] = {Name = "Anti-Field",Description = "#Standing Still provides floating up tears to any tears,otherwise tears slowly float down.#↑ +2Tears"},
	[Items.More_Options___] = {Name = "More and more Options!",Description = "#Pedestals or pickups that have price will be duplicated when first enter the room.#!!! Sometimes higher price."},
	[Items.Fate_s_Draw] = {Name = "Fate's Draw",Description = "#Change your card every 0.2 seconds."},
	[Items.My_Emblem] = {Name = "Qing's Emblem",Description = "#Add 3 emblem babies. #Emblem babies deal 10 damage to enemies per second,and then it can absorb 1 projectiles. #Shoot babies with your tears."},
	[Items.Ingestion_to_Night] = {Name = "Ingestion to Night",Description = "#Pressing shooting bottom for 3s and the night will ingest all your enemies.#30% of chance to immune damage when in dark.#↑Flying #!!! Darken the room #slightly raise the chance to spawn the sun.#slightly raise the chance to spawn the sun?"},
	[Items.D773] = {Name = "D773",Description = "Reroll your costumes!"},
	[Items.Devil_s_Heart] = {Name = "Devil's Heart",Description = "#Fire devil's mark with no damage. #Revive at a live enemy's position that is marked by devil when you die.After that,remove several collectibles and kill the enemy."},
	[Items.Book_of_Future] = {Name = "Book of Future",Description = "#Remove items from item pools whose quality adds up to more than 50(start from quality 4 items). Spawn a item that can be choosed from 4 pedestals."},
	[Items.Hyper_Velocity] = {Name = "Hyper Velocity",Description = "#Summon a motor car squashing enemies."},
	[Items.Wavering_Eyes] = {Name = "Wavering Eyes",Description = "#Gain bonus when your tears hit enemies precisely #↓ 2,4,..:Slightly waver your tear. #↑ 3,6..:Tears Up. #↑ 5：Get{{Collectible572}} #↑ 8：Get{{Collectible3}} #↑ 13：Get{{Trinket26}} #↑ 21：Get{{Collectible221}}"},
	[Items.Pendulum_Star] = {Name = "Pendulum Star",Description = "#Two swaying babies."},
	[Items.Book_of_Thoth] = {Name = "Book of Thoth",Description = "#Turn the tarots into Thoth tarot cards. #Pickups turn to cards in 20% chance.#Using cards charges the book. #Gain bonus according to the cards used between two times of using this book."},
	[Items.Book_of_The_Law] = {Name = "Book of The Law",Description = "#The next item you meet comes from the item pool you are now in."},
	[Items.Book_of_Vision] = {Name = "Book of Vision",Description = "#Duplicate the pickups amount you get in this room after use. #!!! It counts the amount you lose as well."},
	[Items.Book_of_Voice] = {Name = "Book of Voice",Description = "#Spawns 4 pedestal item when this pedestal item is removed.You can only choose one. #Remove it by using {{Collectible477}}、{{Card41}} #Upon each use: remove some pickups.Adds the number to spawn pedestal by 1. #Automatically used when fully charged. #Spawn a {{Card41}} when you take this book for 3 levels."},
	[Items.Aphasia] = {Name = "Aphasia",Description = "#!!! Lose your ability to read. #Words scattered around. #Picking up words grants bonus damage for one tear.",},
	[Items.Nazca] = {Name = "Nazca",Description = "#Draw nazca lines in the room #Deal damage to the enemies and grants stats bonus to all players.",},
	[Items.Cloundy] = {Name = "Cloundy",Description = "#Digests enemies and turn them into pickups. #Digests pickups and turn them into enemies. #Its name is Cloundy,not Cloudy",},
	[Items.Skiel] = {Name = "Skiel",Description = "#Long press to accumulate power#Fire factor network when charged",},
	[Items.Wisel] = {Name = "Wisel",Description = "#Press repeatedly to accumulate power,otherwise lose power gradually #Fire Shooting Waves when charged",}, -- #多次连续发动会降低点击速度阈值，提升蓄力速度
	[Items.Granel] = {Name = "Granel",Description = "#Long press to accumulate power,press repeatedly to accelerate power accumulation #Fire flames in four directions when charged",}, -- #多次连续发动会加快蓄力速度
	[Items.Spectralsword] = {Name = "Spectral Sword",Description = "#Don't take my weapon!",},
	[Items.Squiresaga] = {Name = "Squiresaga",Description = "#Cut out the crevice of an entity #Adjust their attributes in the crevice #Press"..EID.ButtonToIconMap[ButtonAction.ACTION_DROP].."to end attribute adjusting#Press"..EID.ButtonToIconMap[ButtonAction.ACTION_PILLCARD].."and"..EID.ButtonToIconMap[ButtonAction.ACTION_MAP].."switch in attributes",BookOfVirtues = "No wisps",},
	[Items.Moment] = {Name = "Moment",Description = "#Recover and utilize the remaining energy of all attack methods.#Convert it into attribute enhancement and damage enemies #!!! Be careful of overload",},
	[Items.Lofty] = {Name = "Lofty",Description = "#Block the first damage to each room and release shock wave #Release shock wave again at the enemies touched by the shock wave #You can charge to shoot small shock wave before you lose release the large shock wave.",},
	[Items.Theseus_s_Sign] = {Name = "Theseus's Sign",Description = "#Spawn a item when takes 4 times of damage.Next time it takes one more time to spawn. #!!! Lose a item when be healed 4 times.Next time it takes one more time to lose.",},
	[Items.Heart_Change] = {Name = "Heart Change",Description = "#↑ Grants flight when two wing exists #Break Devil's wing when entering angel room #Break Angel's wing when entering devil room #Recover both wings when then are broken and spawn 2 item from angel and devil's item pool after entering a new level.",},
	[Items.Cable_Jar] = {Name = "Cable Jar",Description = "#Shoot thunder when take damage #Thunder's strength depends on your active's charge.",},
	[Items.Gospel] = {Name = "Gospel",Description = "#Throw extra gospel tear #Gospel tear will be contaminated if it is moving incorrectly. #Unpolluted gospel tear will attact enemies and have chance to release a ring #Polluted gospel tear have chance to cast a unholy light to enemy, otherwise it will explode.",},
	[Items.Tiramisu] = {Name = "Tiramisu",Description = "#↑ +1Hp #↑ Status gaining will bring about a fading bonus status about 40%.",},
	[Items.Live_Broadcast] = {Name = "Live Broadcast",Description = "#Open your live broadcast. #Bullet chats will fly from one side to another #Some gifts may be sent if some events happen #Only bullet chats in Chinese will be presented.",},
	[Items.Drama_of_sorrow_and_joy] = {Name = "Drama of sorrow and joy",Description = "#Chances to shoot Drama tears#Comedy:Tears follow the character's input and dive attack and cause an explosion which does not damage the character #tragedy:tears fly to the furthest enemy and cause an explosion which does not damage the character #Switch between comedy and tragedy when you take damage#!!! Take 13 times of damage in one room and only fire mask tears forever.",},
	[Items.Tzolkin] = {Name = "Tzolkin",Description = "#Gains:#↑+0.2Luck #↑+0.2Dmg #↑+0.1Tears #↑+0.5Range #↑+0.05Speed #Lose status equal to what you gain when you lose the item",BookOfVirtues = "Tzolkin Wisp#As long as the wisp is not completely extinguished, you will not accept the negative effect"}, --红龙魂火，只要此魂火没有全部熄灭，就不会接受失去主动的负面效果
	[Items.Pareidolia] = {Name = "Pareidolia",Description = "#A controllable tear chain protruded from the right eye.#Sync with eye collectibles.#Isn't affected by tear and dmg.",},
	[Items.Tears_of_Pearl] = {Name = "Tears of Pearl",Description = "#Have chance to shoot pearl tear.#Pearl tear will absorb projectiles when it hit the ground.#Pearl tears can be kick when it hit the ground.",},
}

EIDInfo.Trinkets = {
}

EIDInfo.Cards = {
	[Cards.Glaze_dice_shard] = {
        Name = "Glaze Dice Shard",
        Description = "#Converts all pickups to the glazed type.#Morph all items in the room to the same color item.",
    },
	[Cards.Qing_s_Soul] = {
        Name = "Qing's Soul",
        Description = "Fire several stab knife.",
    },
	[Cards.Round_trip_Rail_Ticket] = {
        Name = "Round trip Rail Ticket",
        Description = "#Summon a train rushing to you.#Spawn a One way rail ticket.",
    },
	[Cards.One_way_Rail_Ticket] = {
        Name = "One way Rail Ticket",
        Description = "#Summon a train rushing to you.",
    },
	[Cards.Adjustment] = {Name = "VIII - Adjustment",Description = "",},
	[Cards.Lure] = {Name = "XI - Lure",Description = "",},
	[Cards.Art] = {Name = "XIV - Art",Description = "",},
	[Cards.Aeon] = {Name = "XX - The Aeon",Description = "",},
	[Cards.Universe] = {Name = "XXI - The Universe",Description = "",},
	[Cards.Adjustment_r] = {Name = "VIII - Adjustment?",Description = "",},
	[Cards.Lure_r] = {Name = "XI - Lure?",Description = "",},
	[Cards.Art_r] = {Name = "XIV - Art?",Description = "",},
	[Cards.Aeon_r] = {Name = "XX - The Aeon?",Description = "",},
	[Cards.Universe_r] = {Name = "XXI - The Universe?",Description = "",},
}

EIDInfo.Birthrights = {
    [Players.wq] = {
        Description = "Be a real assassin!",
        PlayerName = "W.Q."
    },
    [Players.Spwq] = {
        Description = "Extra compound has been established!",
        PlayerName = "W.Qing"
    },
}

EIDInfo.CollectibleTransformations = {
    [Items.Darkness] = "9",
    [Items.Mental_Hypnosis] = "5",
    [Items.Glaze_Mushroom] = "2",
	[Items.Tianyi] = "4",
    [Items.Devil_s_Heart] = "9",
    [Items.Book_of_Future] = "12",
    [Items.Book_of_Thoth] = "12",
    [Items.Book_of_The_Law] = "12",
    [Items.Book_of_Vision] = "12",
    [Items.Book_of_Voice] = "12",
}

EIDInfo.Pickups = {
}

return EIDInfo;
