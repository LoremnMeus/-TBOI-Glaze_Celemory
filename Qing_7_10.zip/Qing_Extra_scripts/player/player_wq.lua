local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local Fusion_Destiny = require("Qing_Extra_scripts.challanges.Fusion_Destiny")
local Wavering_Eyes = require("Qing_Extra_scripts.items.Item_Wavering_Eyes")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local qing_s_knife_holder = require("Qing_Extra_scripts.callbacks.qing_s_knife_holder")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")	
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Players.wq,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_KNIFE_COLLISION, params = nil,
Function = function(_,ent,colli,low)
	if ent:GetData().Explosive_cnt and ent:GetData().Explosive_cnt > 0 then
		local player = ent:GetData().player
		if player == nil then
			if ent:GetData().params then
				player = ent:GetData().params.player
			end
		end
		if player == nil then
			player = Game():GetPlayer(0)
		end
		local dmg = ent.CollisionDamage
		local tearflags = ent:GetData().bomb_knife_flag
		if tearflags == nil and ent:GetData().params and ent:GetData().params.bomb_knife_flag then
			tearflags = ent:GetData().params.bomb_knife_flag
		end
		if tearflags == nil then
			tearflags = BitSet128(0,0)
		end
		local dmgself = true
		if ent:GetData().params and ent:GetData().params.dmgself == true then dmgself = false end
		Game():BombExplosionEffects(colli.Position,dmg * 10,tearflags,player.TearColor,player,0.5,false,dmgself)	
		ent:GetData().Explosive_cnt = ent:GetData().Explosive_cnt - 1
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,collid, itemRng, player, useFlags, activeSlot, customVarData)
	if collid == 283 or collid == 284 or collid == 703 then
		if player:GetName() == "W.Qing" then
			player:AddNullCostume(enums.Costumes.Qingrobes)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	if player:GetName() == "W.Qing" then
		player:AddNullCostume(enums.Costumes.Qingrobes)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.MeusLink,
Function = function(_,ent)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	local s = ent:GetSprite()
	if ent.Variant == enums.Entities.MeusLink then
		if s:IsFinished("Link") or s:IsFinished("Link2") then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:GetName() == "W.Qing" then
		local d = player:GetData()
		if player.FrameCount % 60 == 1 then
			player:AddCacheFlags(CacheFlag.CACHE_FLYING)
			player:GetData().should_evaluate_on_update_once = true
		end
		if player:IsCoopGhost() then 
			d.coopghost = true
		elseif d.coopghost then
			d.coopghost = nil
			player:AddNullCostume(enums.Costumes.Qingrobes)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)		--表万青总算法
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = player:GetData()
	if player:GetName() == "W.Qing" then
		gdir = auxi.ggdir(player,false,ModConfigSettings.allow_mouse_control)
				
		local list = auxi.get_qing_list(player)
		local ctrlidx = player.ControllerIndex
		if player:AreControlsEnabled() and player:IsExtraAnimationFinished() and (auxi.check_bottom_down(ModConfigSettings.thor_key,ctrlidx) or auxi.check_bottom_down(ModConfigSettings.thor_controller,ctrlidx) or (ModConfigSettings.allow_mouse_control and Input.IsMouseBtnPressed(1))) then		--按下alt时，使用瞬移。
			if player:HasCollectible(619) then
				if player:GetData().birth_delay == nil then
					player:GetData().birth_delay = 0
				end
			end
			if d.thor_target ~= nil and d.thor_target:Exists() then
				if player:HasCollectible(619) and player:GetData().birth_delay < 0 then
					auxi.kill_thenm_all(player,d.thor_target.Position,player.Damage * 0.25,list)
					auxi.kill_thenm_all2(player,d.thor_target.Position,player.Damage * 0.75,list,15,200)		--伤害调低点。
					player:GetData().birth_delay = 150
					d.thor_target:Remove()
					d.thor_target = nil
				else
					auxi.thor_attack(player,list)
					local new_thor = nil
					if list.link_knife and list.link_knife > 0 then
						if d.thor_target.Child then
							new_thor = d.thor_target.Child:GetData().link_thor
							if new_thor then
								if new_thor:Exists() == false or new_thor:IsDead() or not new_thor.Child or not new_thor.Child:Exists() or new_thor.Child:IsDead() then 
									new_thor = nil 
								else
									new_thor.Child:GetData().should_renew_charge = true
									new_thor.Child:GetData().should_clear_charge = nil
								end
							end
						end
					end
					d.thor_target:Remove()
					d.thor_target = new_thor
				end
			elseif player:HasCollectible(619) and player:GetData().birth_delay < 0 then -- and player:GetData().Birth_Flag and player:GetData().Birth_Flag == true then
				local n_entity = Isaac.GetRoomEntities()
				local n_enemy = auxi.getenemies(n_entity)
				local posi = room:GetRandomPosition(10)
				local wait = false
				if #n_enemy > 0 then
					if gdir:Length() < 0.05 then
						posi = n_enemy[math.random(#n_enemy)].Position
					else
						posi = player.Position + gdir * 100
						for i = 1,#n_enemy do
							local lg = (n_enemy[i].Position - player.Position):Length()
							local the = (n_enemy[i].Position - player.Position):GetAngleDegrees()
							local cal = math.sin(math.rad(the)) * lg
							if cal > -10 and (player:GetData().birthright_counter == nil or player:GetData().birthright_counter > cal) then
								player:GetData().birthright_counter = cal
								posi = n_enemy[i].Position
								wait = true
							end
							player:GetData().birthright_counter = nil
						end
					end
				else
					if gdir:Length() > 0.05 then
						posi = player.Position + gdir * 100
					end
				end
				auxi.kill_thenm_all(player,posi,0,list)
				if wait == true then
					auxi.kill_thenm_all2(player,posi,player.Damage/2,list,10,150)
					player:GetData().birth_delay = 150
				else
					player:GetData().birth_delay = 30
				end
			end
		end
		
		if player:HasCollectible(619) then
			if player:GetData().birth_delay == nil then
				player:GetData().birth_delay = 0
			end
			player:GetData().birth_delay = player:GetData().birth_delay - 1
		end
		
		if d.firedelay == nil then
			d.firedelay = -1
		end
		if d.firedelay > 1800 then		
			d.firedelay = 1800
		end
		if d.fire_state == nil then
			d.fire_state = 0	--0代表平A
		end
		if gdir:Length() < 0.05 then
			d.fire_state = 0
			if d.fire_delay_puni and d.fire_delay_puni > 0 then		--防止了停止连招来加速攻击的情况。
				d.firedelay = d.firedelay + d.fire_delay_puni
				d.fire_delay_puni = -1
			end
		end
		
		local damage_of_player = player.Damage
		if player:HasCollectible(154) then		--化学蜕变
			if math.random(1000) > 500 then
				damage_of_player = damage_of_player + 1.5
			end
		end
		if player:HasCollectible(254) then		--血块
			if math.random(1000) > 500 then
				damage_of_player = damage_of_player + 1
			end
		end
		if player:HasCollectible(155) then		--小圣心
			if math.random(1000) > 500 then
				damage_of_player = damage_of_player * 1.33
			end
		end
		if player:HasCollectible(731) then		--新道具
			if math.random(1000) > 500 then
				damage_of_player = damage_of_player * 1.285
			end
		end
		local multishot_of_player = auxi.getmultishots(player,true)
		local cho_ccounter = 1		--记录增、减幅
		if player:HasCollectible(69) then --and player:HasWeaponType(13) == false then		--巧克力牛奶的效果：第一击可以不考虑延迟进行攻击，但那一击的伤害下降对应的蓄力的量。		--注意！巧克力牛奶配合诅咒之眼非常优秀！！
			if d.fire_state == 0 and d.firedelay > 0 and gdir:Length() > 0.05 then
				d.damage_of_player = damage_of_player * 1 / (d.firedelay + 2)
				cho_ccounter = 1 / (d.firedelay + 2)
				list.repel_effect = (10 + list.repel_effect) / (d.firedelay + 2) - 10
				d.firedelay = -1
			end
		end
		
		if player:HasCollectible(69) and d.firedelay < 0 and gdir:Length() < 0.05 then		--角色不在攻击的时候，自动蓄力。
			if d.cho_delay == nil then
				d.cho_delay = 0
			end
			if d.cho_delay < player.MaxFireDelay * 10 then
				d.cho_delay = d.cho_delay + 1
			end
			if d.cho_delay > player.MaxFireDelay * 10 then
				d.cho_delay = player.MaxFireDelay * 10
			end
			local delay_cnt = d.cho_delay / player.MaxFireDelay / 10
			if delay_cnt < 0.9999 then
				if player:GetData().is_setting_color == nil or player:GetData().is_setting_color == false then
					player:SetColor(Color(1-(1-0.33) * delay_cnt,1-(1-0.18) * delay_cnt,1-(1-0.18) * delay_cnt,1,0.25 * delay_cnt,0.15 * delay_cnt,0.15 * delay_cnt),2,60,false,false)
				end
			else
				if d.cho_fini == nil or d.cho_fini == false then
					d.cho_fini = true
					player:GetData().is_setting_color = true
					player:SetColor(Color(1,1,1,1,1,1,1),4,99,true,false)
					delay_buffer.addeffe(function(para)
						player:GetData().is_setting_color = false
						end,{player = player},4)
				end
			end
		end
		
		if d.firedelay ~= nil and d.firedelay < 0 and gdir:Length() > 0.05 then		--发动攻击
			if player:HasCollectible(69) then		--巧克力牛奶的效果：可以不考虑延迟进行攻击，但伤害不足。
				if d.damage_of_player and d.damage_of_player ~= nil then
					damage_of_player = d.damage_of_player
					d.damage_of_player = nil
				end
				if d.cho_delay and d.cho_delay > 0 then
					cho_ccounter = 1 + d.cho_delay/(player.MaxFireDelay * 5)
					damage_of_player = damage_of_player *(1+d.cho_delay/(player.MaxFireDelay * 5))
					list.repel_effect = list.repel_effect + cho_ccounter * 2
					d.cho_delay = 0
					d.cho_fini = false
				end
				list.cho_counter = cho_ccounter
			end
			local stabknifevar = nil
			local weap = 1
			for i = 1,16 do 			--奇怪的是，三位一体盾占据了18和19两个端口。但不清楚究竟有什么用。
				if player:HasWeaponType(i) == true then
					weap = i
				end
			end
			if player:HasCollectible(258) then		--编号错误：每一发都是随机攻击。
				weap = math.random(14)
			end
			
			if player:HasCollectible(191) then		--三美刀：每一轮随机攻击方式。覆盖编号丢失。
				if d.doll_weapon_set == nil or (d.fire_state and d.fire_state == 1) then
					d.doll_weapon_set = math.random(14)
				end
				weap = d.doll_weapon_set
			end
			
			local should_attack = true
			if should_attack and should_attack == true then		--发动攻击
				local ggdir = gdir
				local gdir_ang = gdir:GetAngleDegrees()
				local attack_params = {gdir}
				local cnt3 = 0
				if player:HasPlayerForm(PlayerForm.PLAYERFORM_BABY) then
					cnt3 = 1
				end
				for i = 1,multishot_of_player do
					attack_params[i] = auxi.MakeVector(gdir_ang + auxi.getmultishot(multishot_of_player,list.wiz + 1,i,cnt3) - 90)
				end
				if list.loki and list.loki > 0 and auxi.check_rand(player.Luck,100,10,15) == true then
					for i = 1,3 do
						attack_params[#attack_params + 1] = auxi.MakeVector(gdir_ang + 90 * i)
					end
				end
				if list.momeye and list.momeye > 0 and auxi.check_rand(player.Luck,100,10,5) == true then
					attack_params[#attack_params + 1] = auxi.MakeVector(gdir_ang + 180)
				end
				if list.eye and list.eye > 0 and auxi.check_rand(player.Luck,50,10,20) == true then
					attack_params[#attack_params + 1] = auxi.MakeVector(math.random(36000)/100)
				end
				if list.pencil and list.pencil > 0 then 
					if d.pencil_delay == nil then d.pencil_delay = 0 end
					d.pencil_delay = d.pencil_delay% 15 + 1
					if d.pencil_delay == 15 then 
						for i = 1,3 do
							table.insert(attack_params,#attack_params + 1,auxi.MakeVector(gdir_ang + (i * 3 + 20) * (math.random(2) * 2 - 3)))
						end
					end
				end
				if list.greed_head and list.greed_head > 0 then			--理财眼
					if d.greed_head_delay == nil then d.greed_head_delay = 0 end
					d.greed_head_delay = d.greed_head_delay + 1
					if d.greed_head_delay == 20 then
						d.greed_head_delay = 0
						local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir) * 7 * (math.random(2) * 2 - 3),(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags | BitSet128(1<<53,0),thor = true,color = Color(1,0.69,0,1,1,0.69,0),Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,})
						player:AddCoins(-1)
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_CASH_REGISTER,1,1,false,0,2)
					end
				end
				if attack_params then
					for i = 1, #attack_params do			--发动攻击
						gdir = attack_params[i] * math.max(0.6,math.min(3,0.7 * player.ShotSpeed + 0.3 + math.log(player.TearRange/260)))
						if player:HasCollectible(418) and math.random(1000) > 800 then		--水果蛋糕：有20%概率每一次都是随机攻击。覆盖三美刀和编号丢失。
							weap = math.random(14)
							if weap == 8 or weap == 10 then weap = 1 end
						end
						if list.tech9 > 0 then 
							if math.random(1000) > 850 then weap = 3 end
							if math.random(1000) > 850 then weap = 9 end
						end
						if (weap == 1) and list.hae > 0 then weap = 15 end			--血泪的特殊配合

						if weap == 1 or weap == 2 or weap == 8 or weap == 4 or weap == 14 then		--通常，鲁科，硫磺火，妈刀，剖腹产：平A攻击
							if weap == 1 or weap == 4 or weap == 8 or weap == 14 then			--普通眼泪：5段斩击
								if d.fire_state > 4 then
									d.fire_state = 0
								end
							elseif weap == 2 then		--有硫磺火：额外发射激光
								if d.fire_state > 2 then
									d.fire_state = 0
								end
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
							elseif d.fire_state == 1 then
								d.firedelay = player.MaxFireDelay
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player/3,"AttackUp","AttackUp2",{source = nil,cooldown = 8,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech})
							elseif d.fire_state == 2 then
								d.firedelay = player.MaxFireDelay * 2
								local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
								local length = (player.Velocity + gdir * 10):Length()
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 60 + auxi.MakeVector(dirang) * (-20),auxi.MakeVector(dirang - 30) * length,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang - 90) * 60 + auxi.MakeVector(dirang) * (-20),auxi.MakeVector(dirang + 30) * length,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
							elseif d.fire_state == 3 then
								d.firedelay = player.MaxFireDelay * 3	
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player/2,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech})
							elseif d.fire_state == 4 then
								d.firedelay = player.MaxFireDelay
								local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
								local length = (player.Velocity + gdir * 10):Length()
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech})
							end
							if weap == 14 then
								d.firedelay = d.firedelay * 1.8
							end
							if weap == 2 then
								d.firedelay = d.firedelay * 1.3
							end
							if weap == 4 then
								d.firedelay = (d.firedelay * 1.4 + 20 * math.sqrt(player.MaxFireDelay/10))/2
							end
							if weap == 2 or weap == 4 then
								delay_buffer.addeffe(function(params)
									local dir = params.dir
									local player = params.player
									local list = params.list
									if player == nil or dir == nil or player:Exists() == false then
										return
									end
									if list.knife and list.knife > 0 then
										local rand_cnt = list.knife * 2 + 1
										local refang = dir:GetAngleDegrees() + 90
										for i = 1, rand_cnt do 
											if list.brimstone and list.brimstone > 0 then
												local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * (i-rand_cnt/2) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,math.sqrt(damage_of_player * 0.65 * 3.5),"IdleUp","IdleUp2",{source = nil,cooldown = 30,player = player,tearflags = player.TearFlags,color = player.TearColor,knife = true,Accerate = 2,list = list,tech = list.tech,Explosive = list.ipec + list.dr,dmgself = (list.ipec > 0 and list.dr > 0)})		--显式传入的kinfe、birmstone含义为生成时附带，而隐式传入的则只作为标记作用。
											else
												local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * (i-rand_cnt/2) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,math.sqrt(damage_of_player * 0.25 * 3.5),"IdleUp","IdleUp2",{source = nil,cooldown = 30,player = player,tearflags = player.TearFlags,color = player.TearColor,knife = true,Accerate = 2,list = list,tech = list.tech,Explosive = list.ipec + list.dr,dmgself = (list.ipec > 0 and list.dr > 0)})		--显式传入的kinfe、birmstone含义为生成时附带，而隐式传入的则只作为标记作用。
											end
										end
									elseif list.brimstone and list.brimstone > 0 then
										local rand_cnt = math.floor(math.random(list.brimstone)/2) + 1
										local refang = dir:GetAngleDegrees() + 90
										for i = 1, rand_cnt do 
											local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * (i-rand_cnt/2) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 30,player = player,tearflags = player.TearFlags,color = player.TearColor,brimstone = true,Accerate = 2,list = list,tech = list.tech,Explosive = list.ipec + list.dr,dmgself = (list.ipec > 0 and list.dr > 0)})
											if damage_of_player > player.Damage / 2 then
												local q2 = player:FireBrimstone( - (player.Velocity + dir * 10):Normalized())
												q2.PositionOffset = Vector(0,0)
												if list.brimstone > 1 then
													q2:SetTimeout(25)
												else
													q2:SetTimeout(13)
												end
												q2.Parent = q1
												q2.Position = q1.Position
											end
										end
									end
								end,{dir = gdir,player = player,list = auxi.copy(list)},d.firedelay / 4)
								local multitar = 0
								if (list.lung and list.lung > 0) or (list.eye and list.eye > 0) then
									for i = 1,list.lung do
										multitar = multitar + math.random(3)
									end
									for i = 1,list.eye do
										multitar = multitar + math.random(1)
									end
								end
								for i = 1,multitar do
									delay_buffer.addeffe(function(params)
									local dir = params.dir
									local player = params.player
									local list = params.list
									if player == nil or dir == nil or player:Exists() == false then
										return
									end
									if list.knife and list.knife > 0 then
										local rand_cnt = list.knife * 2 + 1
										local refang = dir:GetAngleDegrees() + 90
										for i = 1, rand_cnt do 
											if list.brimstone and list.brimstone > 0 then
												local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * (i-rand_cnt/2) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,knife = true,Accerate = 2})		--显式传入的kinfe、birmstone含义为生成时附带，而隐式传入的则只作为标记作用。
											else
												local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * (i-rand_cnt/2) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,knife = true,Accerate = 2})		--显式传入的kinfe、birmstone含义为生成时附带，而隐式传入的则只作为标记作用。
											end
										end
									elseif list.brimstone and list.brimstone > 0 then
										local refang = dir:GetAngleDegrees() + 90
										local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(refang) * 15,(player.Velocity + dir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,brimstone = true,Accerate = 2})
										local q2 = player:FireBrimstone( - (player.Velocity + dir * 10):Normalized())
										q2.PositionOffset = Vector(0,0)
										q2:SetMaxDistance(100)
										q2:SetTimeout(30)
										q2.Parent = q1
										q2.Position = q1.Position
									end
								end,{dir = auxi.MakeVector(math.random(18000)/100 - 90 + gdir:GetAngleDegrees()),player = player,list = auxi.copy(list)},d.firedelay / 8)
								end
							end
							d.fire_delay_puni = player.MaxFireDelay * 0			--无后摇
						elseif weap == 3 then		--科技1：科技剑光+新剑法
							if list.lung and list.lung > 0 then			--科技1+肺：特殊攻击。
								if d.fire_state > 2 then
									d.fire_state = 0
								end
								if d.fire_state == 0 then
									d.firedelay = player.MaxFireDelay * 1.5
									d.fire_delay_puni = player.MaxFireDelay * 1
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q4 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q5 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 2,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
								elseif d.fire_state == 1 then
									d.firedelay = player.MaxFireDelay * 2
									d.fire_delay_puni = player.MaxFireDelay * 0.5
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(dirang) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 60,auxi.MakeVector(dirang - 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity - auxi.MakeVector(dirang + 90) * 60,auxi.MakeVector(dirang + 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 120,auxi.MakeVector(dirang - 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity - auxi.MakeVector(dirang + 90) * 120,auxi.MakeVector(dirang + 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
								elseif d.fire_state == 2 then
									d.firedelay = player.MaxFireDelay * 2.6
									d.fire_delay_puni = player.MaxFireDelay * 0
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity - auxi.MakeVector(dirang) * length,auxi.MakeVector(dirang) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list,tech = true,lung_and_tech = 4,lung_and_tech_cnt = 3})
								end
							else
								if weap == 3 then
									if d.fire_state > 4 then
										d.fire_state = 0
									end
								end
								if d.fire_state == 0 then
									d.firedelay = player.MaxFireDelay * 0.75
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,4),size2 = 13})	--科技
								elseif d.fire_state == 1 then
									d.firedelay = player.MaxFireDelay * 1.25
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20),player.Velocity + gdir * 10,damage_of_player * 0.75,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20),player.Velocity + gdir * 10,damage_of_player * 0.75,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
								elseif d.fire_state == 2 then
									d.firedelay = player.MaxFireDelay * 1.75
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-40),player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (0),player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,4),size2 = 13})
									local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (40),player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
								elseif d.fire_state == 3 then
									d.firedelay = player.MaxFireDelay * 2.25
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-60),player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20),player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (60),player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q4 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20),player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
								elseif d.fire_state == 4 then
									d.firedelay = player.MaxFireDelay * 2.75
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
									local q4 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
									local q5 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 2,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = true})
								end
								d.fire_delay_puni = player.MaxFireDelay * 0			--无后摇
							end
						elseif weap == 5 then		--博士：没灵感了，权且就这样了
							if d.fire_state > 3 then
								d.fire_state = 0
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 0.5
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech,Explosive = 1,dmgself = (list.ipec > 0 and list.dr > 0)})
							elseif d.fire_state == 2 then
								d.firedelay = player.MaxFireDelay * 0.8
								local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
								local length = (player.Velocity + gdir * 10):Length()
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 60 + auxi.MakeVector(dirang) * (-20),auxi.MakeVector(dirang - 30) * length,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.MakeVector(dirang - 90) * 60 + auxi.MakeVector(dirang) * (-20),auxi.MakeVector(dirang + 30) * length,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								local q3 = player:FireBomb(player.Position + player.Velocity,player.Velocity + gdir * 10 * player.ShotSpeed)
							elseif d.fire_state == 1 then
								d.firedelay = player.MaxFireDelay * 1
								local refang = gdir:GetAngleDegrees() + 90
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 30,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 2,list = list,tech = list.tech,Explosive = 1,dmgself = (list.ipec > 0 and list.dr > 0)})
								if list.brimstone and list.brimstone > 0 then
									local rand_cnt = math.floor(math.random(list.brimstone)/2) + 1
									if damage_of_player > player.Damage / 2 then
										local q2 = player:FireBrimstone(  auxi.Get_rotate(player.Velocity + gdir * 10):Normalized())
										local q3 = player:FireBrimstone(  - auxi.Get_rotate(player.Velocity + gdir * 10):Normalized())
										q2.PositionOffset = Vector(0,0)
										q3.PositionOffset = Vector(0,0)
										if list.brimstone > 1 then
											q2:SetTimeout(25)
											q3:SetTimeout(25)
										else
											q2:SetTimeout(13)
											q3:SetTimeout(13)
										end
										q2.Parent = q1
										q3.Parent = q1
										q2.Position = q1.Position
										q3.Position = q1.Position
									end
								end
							elseif d.fire_state == 3 then
								d.firedelay = player.MaxFireDelay * 1.5
								for i = 1,4 do 
									local dir = (player.Velocity + gdir * 10):GetAngleDegrees() - 30 + 60/3 * (i-1)
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(dir) * 20 * player.ShotSpeed,damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 30,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 2,list = list,tech = list.tech,Explosive = 1,dmgself = (list.ipec > 0 and list.dr > 0)})
									if list.tech and list.tech > 0 then
										local q3 = player:FireTechLaser(player.Position,1,-auxi.MakeVector(dir),false,false)
										q3.PositionOffset = Vector(0,0)
										q3:SetTimeout(30)
										q3.Parent = q1
										q3:SetMaxDistance((player.Position - q1.Position):Length())
										--q3:SetMaxDistance(0.01)
										--q3.Position = q1.Position
										q3:GetData().followParent = q1
									end
								end
							end
							d.fire_delay_puni = 0
						elseif weap == 6 then		--史诗：飞雷神转化为史诗标记。
							if d.fire_state > 0 then
								d.fire_state = 0
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 4
								d.fire_delay_puni = player.MaxFireDelay * 1
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 0.85,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,epic = true,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,multishot = multishot_of_player - 1})
							end
						elseif weap == 9 then		--科X：与科技X光环配合的帅气攻击。	还差得远呢。
							if d.fire_state > 2 then
								d.fire_state = 0
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 2
								d.fire_delay_puni = player.MaxFireDelay * 4
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								for i = 1, 10 do
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity + gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * -30 + auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * -30,player.Velocity + gdir * (10) + gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 + auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								end
								local q2 = player:FireTechXLaser(player.Position + player.Velocity + (player.Velocity + gdir * 10) * 4,player.Velocity + gdir * (10),30)
								q2.Velocity = Vector(0,0)
								q2.PositionOffset = Vector(0,0)
								q2:SetTimeout(10)
							elseif d.fire_state == 1 then
								d.firedelay = player.MaxFireDelay * 2.5
								d.fire_delay_puni = player.MaxFireDelay * 7
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								for i = 1, 10 do
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity + gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * -30 + auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * -30,(player.Velocity + gdir * (10) + gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 + auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10)/1000,damage_of_player/2,"AttackUp","AttackUp2",{source = nil,cooldown = 8,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech})
								end
								local q2 = player:FireTechXLaser(player.Position + player.Velocity + (player.Velocity + gdir * 10) * 4,player.Velocity + gdir * (10),30)
								q2.Velocity = Vector(0,0)
								q2.PositionOffset = Vector(0,0)
								q2:SetTimeout(10)
							elseif d.fire_state == 2 then
								d.firedelay = player.MaxFireDelay * 6.5
								d.fire_delay_puni = player.MaxFireDelay * 0
								local q2 = player:FireTechXLaser(player.Position + player.Velocity + (player.Velocity + gdir * 10) * 4,player.Velocity + gdir * (10),30)
								--local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								for i = 1, 10 do
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * -30 + auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * -30,(player.Velocity + gdir * (10) - gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10),damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,Accerate = 2,brimstone = player:HasCollectible(118),tech = list.tech})
									if list.brimstone and list.brimstone > 0 then
										local q3 = player:FireBrimstone( - (player.Velocity + gdir * 10):Normalized())
										q3.PositionOffset = Vector(0,0)
										if list.brimstone > 1 then
											q3:SetTimeout(40)
										else
											q3:SetTimeout(25)
										end
										q3.Parent = q1
										q3.Position = q1.Position
									end
									if list.tech and list.tech > 0 then
										local q3 = player:FireTechLaser(player.Position,1,(player.Velocity + gdir * (10) - gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10),false,false)
										q3.PositionOffset = Vector(0,0)
										q3:SetTimeout(30)
										q3.Parent = q1
										q3:SetMaxDistance((player.Position - q1.Position):Length())
										--q3:SetMaxDistance(0.01)
										--q3.Position = q1.Position
										q3:GetData().followParent = q1
									end
									q1.Parent:GetData().follower = q2
									q1.Parent:GetData().continue_after_follower = true
									q1.Parent:GetData().continue_and_resetvel = (player.Velocity + gdir * (10) - gdir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(gdir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10)
								end
								--q2.Velocity = Vector(0,0)
								q2.PositionOffset = Vector(0,0)
								q2:SetTimeout(math.floor(player.ShotSpeed) * 10)
							end
							if list.lung and list.lung > 0 or list.eye and list.eye > 0 then
								local multitar = 0
								if list.lung and list.lung > 0 then
									d.firedelay = d.firedelay * 0.5
								end
								if (list.lung and list.lung > 0) or (list.eye and list.eye > 0) then
									for i = 1,list.lung do
										if math.random(1000) > 300 then
											multitar = multitar + math.random(3)
										end
									end
									for i = 1,list.eye do
										if math.random(1000) > 950 then
											multitar = multitar + 1
										end
									end
								end
								for i = 1, multitar do
									local rand_ang = math.random(18000)/100 - 90 + gdir:GetAngleDegrees()
									local rand_dir = auxi.MakeVector(rand_ang)
									local q2 = player:FireTechXLaser(player.Position + player.Velocity + (player.Velocity + rand_dir * 10) * 4,player.Velocity + rand_dir * (10),30)
									for i = 1, 10 do
										local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + rand_dir:Normalized() * math.sin(math.rad(i/10 * 360)) * -30 + auxi.Get_rotate(rand_dir):Normalized() * math.cos(math.rad(i/10 * 360)) * -30,(player.Velocity + rand_dir * (10) - rand_dir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(rand_dir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10),damage_of_player/2,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,Accerate = 2,brimstone = player:HasCollectible(118),tech = list.tech})
										if list.brimstone and list.brimstone > 0 then
											local q3 = player:FireBrimstone( - (player.Velocity + rand_dir * 10):Normalized())
											q3.PositionOffset = Vector(0,0)
											if list.brimstone > 1 then
												q3:SetTimeout(40)
											else
												q3:SetTimeout(25)
											end
											q3.Parent = q1
											q3.Position = q1.Position
										end
										if list.tech and list.tech > 0 then
											local q3 = player:FireTechLaser(player.Position,1,(player.Velocity + rand_dir * (10) - rand_dir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(rand_dir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10),false,false)
											q3.PositionOffset = Vector(0,0)
											q3:SetTimeout(30)
											q3.Parent = q1
											q3:SetMaxDistance((player.Position - q1.Position):Length())
											--q3:SetMaxDistance(0.01)
											--q3.Position = q1.Position
											q3:GetData().followParent = q1
										end
										q1.Parent:GetData().follower = q2
										q1.Parent:GetData().continue_after_follower = true
										q1.Parent:GetData().continue_and_resetvel = (player.Velocity + rand_dir * (10) - rand_dir:Normalized() * math.sin(math.rad(i/10 * 360)) * 10 - auxi.Get_rotate(rand_dir):Normalized() * math.cos(math.rad(i/10 * 360)) * 10)
									end
									--q2.Velocity = Vector(0,0)
									q2.PositionOffset = Vector(0,0)
									q2:SetTimeout(math.floor(player.ShotSpeed) * 10)
								end
							end
						elseif weap == 7 then		--肺：暴力近身剑舞。稍微提升了判定大小。目前设定为6段。多个肺叠加与其他不同。
							if d.fire_state > 5 then
								d.fire_state = 0
							end
							damage_of_player = damage_of_player
							local multitar = 1 + math.max(0,player:GetCollectibleNum(229)-1)
							local multi_pos = gdir * 20
							for mul_i = 1,multitar do
								local multi_posi = (mul_i-1) * multi_pos
								if d.fire_state == 0 then
									d.firedelay = player.MaxFireDelay * 0.5
									d.fire_delay_puni = player.MaxFireDelay * 0.25
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 60,auxi.MakeVector(dirang - 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity - auxi.MakeVector(dirang + 90) * 60,auxi.MakeVector(dirang + 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * 120,auxi.MakeVector(dirang - 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity - auxi.MakeVector(dirang + 90) * 120,auxi.MakeVector(dirang + 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
								elseif d.fire_state == 1 then
									d.firedelay = player.MaxFireDelay * 0.5
									d.fire_delay_puni = player.MaxFireDelay * 1
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang - 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang + 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang - 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang + 60) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
								elseif d.fire_state == 2 then
									d.firedelay = player.MaxFireDelay * 0.6
									d.fire_delay_puni = player.MaxFireDelay * 1.4
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player,"AttackUp","AttackUp2",{source = nil,cooldown = 8,player = player,tearflags = player.TearFlags,color = player.TearColor,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									for i = 1, 7 do
										delay_buffer.addeffe(function(params)
											local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang - 120 + i * 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
										end,{},(i))
									end
								elseif d.fire_state == 3 then
									d.firedelay = player.MaxFireDelay * 0.4
									d.fire_delay_puni = player.MaxFireDelay * 1.8
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * (60) + auxi.MakeVector(dirang) * (0) ,auxi.MakeVector(dirang - 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									local q2 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang - 90) * (60) + auxi.MakeVector(dirang) * (0),auxi.MakeVector(dirang + 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
									for i = 1,9 do
										delay_buffer.addeffe(function(params)
											local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang + 90) * (55 + 5 * i) + auxi.MakeVector(dirang) * (25 - 5 *i) ,auxi.MakeVector(dirang - 30 - 5 * i) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
											local q2 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang - 90) * (55 + 5 * i) + auxi.MakeVector(dirang) * (25 - 5 *i),auxi.MakeVector(dirang + 30 + 5 * i) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
										end,{},9 - i)
									end
								elseif d.fire_state == 4 then
									d.firedelay = player.MaxFireDelay * 0.6
									d.fire_delay_puni = player.MaxFireDelay * 2.4
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player/2,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech})
									for i = 1, 16 do
										delay_buffer.addeffe(function(params)
											local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,auxi.MakeVector(dirang - 120 + i * 30) * length,damage_of_player,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = 7,size1 = Vector(1,3),size2 = 13,list = list})
										end,{},(i/2))
									end
								elseif d.fire_state == 5 then		--最后一击，类似肺的攻击。
									d.firedelay = player.MaxFireDelay * 4
									d.fire_delay_puni = player.MaxFireDelay * 0
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list})
									local q2 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,size = 7,size1 = Vector(1,2),size2 = 13})
									local q3 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (40) + gdir:Normalized() * -30,player.Velocity + gdir * 10,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 5,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,size = 7,size1 = Vector(1,2),size2 = 13})
									local q4 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 20,damage_of_player * 0.4,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list})
									local rand_cnt = math.random(list.lung * 6 + 1) + 2
									local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech})
									for i = 1, rand_cnt do
										local q1 = auxi.fire_dowhatknife(nil,multi_posi + player.Position + player.Velocity,(player.Velocity + gdir * 10 + auxi.MakeVector(math.random(360)) * 5):Normalized() * player.ShotSpeed * 8,damage_of_player * 2,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 1.5,size = 6,size1 = Vector(1,3),size2 = 13,list = list,shouldrotate = true,Way_Accerate = (player.Velocity + gdir * 10)})
									end
								end
								if list.dr and list.dr > 0 and (d.fire_state == 1 or d.fire_state == 3) then		--博士与肺的配合。
									local dirang = (player.Velocity + gdir * 10):GetAngleDegrees()
									local length = (player.Velocity + gdir * 10):Length()
									local q3 = player:FireBomb(multi_posi + player.Position + player.Velocity + auxi.MakeVector(dirang) * 20,auxi.MakeVector(dirang) * 0.0001)
									if list.brimstone and list.brimstone > 0 then
										local q2 = player:FireBrimstone(auxi.Get_rotate(player.Velocity + gdir * 10):Normalized())
										local q4 = player:FireBrimstone(-auxi.Get_rotate(player.Velocity + gdir * 10):Normalized())
										q2.PositionOffset = Vector(0,0)
										q4.PositionOffset = Vector(0,0)
										if list.brimstone > 1 then
											q2:SetTimeout(25)
											q4:SetTimeout(25)
										else
											q2:SetTimeout(13)
											q4:SetTimeout(13)
										end
										q2.Parent = q3
										q4.Parent = q3
										q2.Position = q3.Position
										q4.Position = q3.Position
									end
								end
							end
						elseif weap == 13 then		--英灵剑：斩击。
							if list.knife and list.knife > 0 then
								if d.fire_state > 2 then
									d.fire_state = 0
								end
								if list.dr and list.dr > 0 then
								else
									if d.fire_state == 1 then 
										d.fire_state = 2
									end
								end
							elseif list.dr and list.dr > 0 then
								if d.fire_state > 1 then
									d.fire_state = 0
								end
							else
								if d.fire_state > 0 then
									d.fire_state = 0
								end
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 2
								if list.knife and list.knife > 0 then
									d.firedelay = player.MaxFireDelay * 3
									d.fire_delay_puni = player.MaxFireDelay * 1
								end
								local q0 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player/4,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech,knife2 = list.knife})
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 0.75,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,knife = list.knife,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech})
								if list.brimstone and list.brimstone > 0 and damage_of_player > player.Damage / 2 then
									d.firedelay = d.firedelay * 1.5
									local q2 = player:FireBrimstone( - (player.Velocity + gdir * 10):Normalized())
									q2.PositionOffset = Vector(0,0)
									if list.brimstone > 1 then
										q2:SetTimeout(25)
									else
										q2:SetTimeout(13)
									end
									q2.Parent = q1
									q2.Position = q1.Position
								end
								local multitar = 0
								if (list.lung and list.lung > 0) or (list.eye and list.eye > 0) then
									for i = 1,list.lung do
										if math.random(1000) > 500 then
											multitar = multitar + math.random(2)
										end
									end
									for i = 1,list.eye do
										if math.random(1000) > 700 then
											multitar = multitar + 1
										end
									end
								end
								for i = 1,multitar do
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(math.random(36000)/100) * 20 * player.ShotSpeed,damage_of_player * 0.75,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,knife = list.knife,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech})
								end
							elseif d.fire_state == 1 then
								d.firedelay = player.MaxFireDelay * 2
								for i = 1,4 do 
									local dir = (player.Velocity + gdir * 10):GetAngleDegrees() - 30 + 60/3 * (i-1)
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(dir) * 20 * player.ShotSpeed,damage_of_player/4,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 2,list = list,tech = list.tech,Explosive = list.dr,dmgself = (list.ipec > 0 and list.dr > 0),knife2 = list.knife,knife2_delay = 9,})
								end
							elseif d.fire_state == 2 then
								d.firedelay = player.MaxFireDelay * 4
								for k = 1,-1,-2 do 
									local dir = (player.Velocity + gdir * 10):GetAngleDegrees() + 30 * k
									local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(dir) * 20 * player.ShotSpeed,damage_of_player/4,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 2,list = list,tech = list.tech,Explosive = list.dr,dmgself = (list.ipec > 0 and list.dr > 0),knife2 = list.knife,knife2_delay = 9,})
								end
							end
							d.fire_delay_puni = player.MaxFireDelay * 0		--无后摇
						elseif weap == 10 then		--骨棒：瞬杀之术
							if d.fire_state > 2 then
								d.fire_state = 0
							end
							if d.fire_state == 1 then
								d.firedelay = player.MaxFireDelay * 0.5
								d.fire_delay_puni = player.MaxFireDelay * 5
								local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/2,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
							elseif d.fire_state == 2 then
								d.firedelay = player.MaxFireDelay * 5.5
								d.fire_delay_puni = player.MaxFireDelay * 0
								local q0 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized()/1000,damage_of_player/2,"SpinUp","SpinUp2",{source = nil,cooldown = 14,player = player,tearflags = player.TearFlags,color = player.TearColor,list = list,tech = list.tech,knife2 = list.knife})
							elseif d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 0.5
								d.fire_delay_puni = player.MaxFireDelay * 4.5
								local posi = room:GetRandomPosition(10)
								local n_entity = Isaac.GetRoomEntities()
								local n_enemy = auxi.getenemies(n_entity)
								if #n_enemy > 0 then
									if gdir:Length() < 0.05 then
										posi = n_enemy[math.random(#n_enemy)].Position
									else
										posi = player.Position + gdir * 100
										for i = 1,#n_enemy do
											local lg = (n_enemy[i].Position - player.Position):Length()
											local the = (n_enemy[i].Position - player.Position):GetAngleDegrees()
											local cal = math.sin(math.rad(the)) * lg
											if cal > 0 and (player:GetData().birthright_counter2 == nil or player:GetData().birthright_counter2 > cal) then
												player:GetData().birthright_counter2 = cal
												posi = n_enemy[i].Position
											end
											player:GetData().birthright_counter2 = nil
										end
									end
								else
									if gdir:Length() > 0.05 then
										posi = player.Position + gdir * 100
									end
								end
								auxi.kill_thenm_all(player,posi,player.Damage * 0.5,list)
								auxi.kill_thenm_all2(player,posi,player.Damage * 1.5,list,7,150)
							end
						elseif weap == 11 then
							if d.fire_state > 0 then
								d.fire_state = 0
							end
						elseif weap == 15 then			--血泪的特殊攻击模式
							if list.dr and list.dr > 0 then
								if d.fire_state > 0 and d.fire_state < 3 then
									d.fire_state = 3
								end
								if d.fire_state > 4 then
									d.fire_state = 0
								end
							elseif list.brimstone and list.brimstone > 0 then
								if d.fire_state > 1 then
									d.fire_state = 0
								end
							else
								if d.fire_state > 3 then
									d.fire_state = 0
								end
							end
							if d.fire_state == 0 then
								d.firedelay = player.MaxFireDelay * 0.3
								d.fire_delay_puni = player.MaxFireDelay * 0.7
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Explosive = list.dr,dmgself = (list.ipec > 0 and list.dr > 0)})
							elseif d.fire_state == 1 then
								if list.tech and list.tech > 0 then
									d.firedelay = player.MaxFireDelay * 0.6
									d.fire_delay_puni = player.MaxFireDelay * 1
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 5):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 5):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								else
									d.firedelay = player.MaxFireDelay * 0.7
									d.fire_delay_puni = player.MaxFireDelay * 1.2
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
								end
							elseif d.fire_state == 2 then
								if list.tech and list.tech > 0 then
									d.firedelay = player.MaxFireDelay * 1
									d.fire_delay_puni = player.MaxFireDelay * 1.8
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 2,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 15):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 15):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
								else
									d.firedelay = player.MaxFireDelay * 1.2
									d.fire_delay_puni = player.MaxFireDelay * 2
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 10):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
								end
							elseif d.fire_state == 3 then
								if (list.tech and list.tech > 0) or (list.dr and list.dr > 0)then
									if list.dr > 0 then
										d.firedelay = player.MaxFireDelay * 1.2
										d.fire_delay_puni = player.MaxFireDelay * 2
									else
										d.firedelay = player.MaxFireDelay * 2
										d.fire_delay_puni = player.MaxFireDelay * 0
									end
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 2,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = gdir})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 45):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 45)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 30)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 30)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 45):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 45)})
								else
									d.firedelay = player.MaxFireDelay * 2.3
									d.fire_delay_puni = player.MaxFireDelay * 0
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 10,damage_of_player/3,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = list.tech})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 45):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 45)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 30)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 30)})
									auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 45):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 45)})
								end
							elseif d.fire_state == 4 then
								d.firedelay = player.MaxFireDelay * 3
								d.fire_delay_puni = player.MaxFireDelay * 0
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 90):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 60),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 60):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 60),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() + 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() - 30),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees()):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees()),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 30):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 30),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 60):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 60),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
								auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector((player.Velocity + gdir * 10):GetAngleDegrees() - 90):Normalized() * 20 * player.ShotSpeed,damage_of_player,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = true,epic = list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech,follow_hae = true,shouldrotate = true,Way_Accerate = auxi.MakeVector(gdir:GetAngleDegrees() + 60),Explosive = list.dr ,dmgself = (list.ipec > 0 and list.dr > 0)})
							end
							if list.brimstone and list.brimstone > 0 then
								d.firedelay = d.firedelay * 1.5
								d.fire_delay_puni = d.fire_delay_puni * 1.5
							end
						elseif weap == 12 then
							if d.fire_state > 0 then
								d.fire_state = 0
							end
						end
					end
				end
				
				for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   	--眼泪盆
					if (player:GetActiveItem(slot) == 323) then
						local mx = 6
						if player:HasCollectible(63) then mx = 12 end
						if player:GetActiveCharge(slot) + player:GetBatteryCharge(slot) < mx then
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_ITEMRECHARGE,1,1,false,0,2)
							player:SetActiveCharge(player:GetActiveCharge(slot) + player:GetBatteryCharge(slot) + 1, slot)
						end
					end
				end
				
				d.fire_state = d.fire_state + 1
				gdir = ggdir
			end
			
			if player:HasCollectible(316) then 		--诅咒之眼：5次快速攻击，那些延迟累加并在之后计算。
				if d.cursed_delay == nil or d.cursed_counter == nil then
					d.cursed_delay = 0 
					d.cursed_counter = 0
				end
				if d.firedelay > 0 and d.cursed_counter < 5 then --and d.cursed_delay < 240 then
					d.cursed_delay = d.cursed_delay + d.firedelay - 1
					if d.fire_delay_puni then
						d.cursed_delay = d.cursed_delay + d.fire_delay_puni
						d.fire_delay_puni = 0
					end
					d.firedelay = 3
					d.cursed_counter = d.cursed_counter + 1
				end
				if d.cursed_counter == 5 then --or d.cursed_delay > 240 then
					d.firedelay = d.cursed_delay * 0.7
					d.cursed_delay = 0
					d.cursed_counter = 0
				end
			end
		end
		
		if gdir:Length() > 0.05 and player:HasCollectible(152) then		--科技2
			if d.tech_2_firedelay == nil then
				d.tech_2_firestate = 0
				d.tech_2_firedelay = 0
			end
			if d.tech_2_firestate > 4 then
				d.tech_2_firestate = 0
			end
			if d.tech_2_firedelay < 0 then
				local dmg_float = 0.05
				if d.tech_2_firestate == 0 then
					local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,4),size2 = 13})	--科技
				elseif d.tech_2_firestate == 1 then
					local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-10),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
					local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (10),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
				elseif d.tech_2_firestate == 2 then
					local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
					local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (0),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 1,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,4),size2 = 13})
					local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
				elseif d.tech_2_firestate == 3 then
					local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
					local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (10),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
					local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
					local q4 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-10),player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
				elseif d.tech_2_firestate == 4 then
					local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-20) + gdir:Normalized() * -30,player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
					local q2 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (10) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 100,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
					local q3 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (20) + gdir:Normalized() * -30,player.Velocity + gdir * 50,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true,size = 7,size1 = Vector(1,2),size2 = 13})
					local q4 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity + auxi.Get_rotate(gdir):Normalized() * (-10) + gdir:Normalized() * 10,player.Velocity * 2 + gdir * 100,damage_of_player * dmg_float,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 3,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list,tech = true})
				end
				d.tech_2_firedelay = 5
				d.tech_2_firestate = d.tech_2_firestate + 1
			end
			d.tech_2_firedelay = d.tech_2_firedelay - 1
		end
		
		if gdir:Length() > 0.05 and player:HasCollectible(244) then		--科技.5
			if math.random(1000) > 950 and d.firedelay/2 > math.random(math.floor(player.MaxFireDelay) + 1) then
				local q1 = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,(player.Velocity + gdir * 10):Normalized() * 20 * player.ShotSpeed,damage_of_player * 0.5,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 2.5,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = list.tech})
				local q2 = player:FireTechLaser(player.Position,1,-(player.Velocity + gdir * 10),false,true)
				q2.PositionOffset = Vector(0,0)
				q2:GetData().followParent = q1
				q2:SetTimeout(13)
				local random_cnt = math.random(1000)
				local buff_list = {BitSet128(1<<2,0),BitSet128(1<<16,0),BitSet128(1<<30,0),BitSet128(1<<19,0),BitSet128(1<<33,0),BitSet128(0,1<<5)}
				for i = 1,6 do 
					if math.random(1000) > 800 then
						q2:AddTearFlags(buff_list[i])
					end
				end
			end
		end
		
		if d.firedelay > -10 then
			d.firedelay = d.firedelay - 1
		end
		if player:HasCollectible(316) and d.firedelay < -3 and d.cursed_delay and d.cursed_delay > 0 then		--诅咒之眼
			d.cursed_delay = d.cursed_delay - 1
		end	
		if player:HasCollectible(316) and d.cursed_counter and d.cursed_counter == 0 and d.firedelay < 0 then
			if (d.cursed_counterdelay == nil or d.cursed_counterdelay == false)  then
				player:GetData().is_setting_color = true
				player:SetColor(Color(1,1,1,1,1,1,1),10,99,true,false)
				delay_buffer.addeffe(function(para)
						player:GetData().is_setting_color = false
						end,{player = player},10)
				d.cursed_counterdelay = true
			end
		else
			d.cursed_counterdelay = false
		end
	end

	if d.repel_counter and d.repel_counter > 1 then
		d.repel_counter = math.min(d.repel_counter - 1,d.repel_counter * 0.85)
	else
		d.repel_counter = 1
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = nil,
Function = function(_,ent)
	if ent:IsBoss() == false then
		if ent:GetData().should_be_iced then
			ent:AddEntityFlags(EntityFlag.FLAG_ICE)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = nil,
Function = function(_,ent)
	if ent:GetData().should_be_iced then
		if ent:GetData().should_be_iced > 0 then
			ent:GetData().should_be_iced = ent:GetData().should_be_iced - 1
		else
			ent:GetData().should_be_iced = nil
		end
	end
end,
})

function item.dealt_extra_effect_to_col(ent,col,tp)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = Game():GetPlayer(0)
	if d.player then
		player = d.player
	end
	if d.deadeye and d.deadeye > 0 then
		player:AddDeadEyeCharge()
		d.deadeye = 0
	end
	if d.wavereye and d.wavereye > 0 then
		Wavering_Eyes.add_waver_eye_charge(player)
		d.wavereye = 0
	end
	if d.params and d.params.list then
		if d.params.list.dual and d.params.list.dual > 0 and d.Dual_cnt ~= nil and auxi.isenemies(col) then		--阴阳
			local d2 = col:GetData()
			if ent.Parent then
				if d2.Dual_effect == nil then
					d2.Dual_effect = Sprite()
					d2.Dual_effect:Load("gfx/Yin_Yang_orb.anm2",true)
					d2.Dual_effect:Play("Rotate_"..tostring(d.Dual_cnt),true)
					d2.Dual_player = player
					d2.Dual_cnt = d.Dual_cnt
					d2.Dual_total_render_frame = 0
				else
					if d2.Dual_cnt ~= d.Dual_cnt and d2.Dual_cnt ~= 2 then		--爆发伤害
						d2.Dual_cnt = 2
						d2.Dual_effect:Play("Rotate_"..tostring(d2.Dual_cnt),true)
						d2.Dual_effect.Rotation = math.ceil(d2.Dual_effect.Rotation) % 360
					end
				end
			end
		end
	end
	if d.tearflags and auxi.isenemies(col) then
		if d.tearflags & BitSet128(1<<3,0) == BitSet128(1<<3,0) then		--蜘蛛之咬
			if auxi.check_rand(player.Luck,15,2,6) == true then
				col:AddSlowing(EntityRef(player),30 * 7,0.9,Color(0.85,0.85,0.85,1))
			end
		end
		if d.tearflags & BitSet128(1<<4,0) == BitSet128(1<<4,0) then		--毒
			if auxi.check_rand(player.Luck,20,2,7) == true then
				col:AddPoison(EntityRef(player),30 * 10,ent.CollisionDamage * 0.1)
			end
		end
		if d.tearflags & BitSet128(1<<5,0) == BitSet128(1<<5,0) then		--石化
			if auxi.check_rand(player.Luck,25,3,12) == true then
				col:AddFreeze(EntityRef(player),30 * 5)
			end
		end
		if d.tearflags & BitSet128(1<<13,0) == BitSet128(1<<13,0) then		--魅惑
			if auxi.check_rand(player.Luck,30,3,4) == true then
				col:AddCharmed(EntityRef(player),30 * 5)
			end
		end
		if d.tearflags & BitSet128(1<<14,0) == BitSet128(1<<14,0) then		--眩晕
			if auxi.check_rand(player.Luck,20,3,13) == true then
				col:AddConfusion(EntityRef(player),30 * 5,false)
			end
		end
		if d.tearflags & BitSet128(1<<20,0) == BitSet128(1<<20,0) then		--恐惧
			if auxi.check_rand(player.Luck,20,3,7) == true then
				col:AddFear(EntityRef(player),30 * 5)
			end
		end
		if d.tearflags & BitSet128(1<<22,0) == BitSet128(1<<22,0) then		--火之意志
			if auxi.check_rand(player.Luck,30,10,15) == true then
				col:AddBurn(EntityRef(player),30 * 5,ent.CollisionDamage * 0.1)
			end
		end
		if d.tearflags & BitSet128(1<<32,0) == BitSet128(1<<32,0) then		--沥青
			if auxi.check_rand(player.Luck,7,2,8) == true then
				col:AddSlowing(EntityRef(player),30 * 9,0.9,Color(0.15,0.15,0.15,1))
			end
		end
		if d.tearflags & BitSet128(1<<33,0) == BitSet128(1<<33,0) then		--神秘液体
			if auxi.check_rand(5,100,30,10) == true then
				Isaac.Spawn(1000,53,0,ent.Position,Vector(0,0),player)
			end
		end
		if d.tearflags & BitSet128(1<<39,0) == BitSet128(1<<39,0) then		--圣光 
			if auxi.check_rand(player.Luck,35,1,15) == true then
				local q2 = Isaac.Spawn(1000,EffectVariant.CRACK_THE_SKY,0,col.Position,Vector(0,0),player):ToEffect()
				q2.CollisionDamage = ent.CollisionDamage * 1.5
			end
		end
		if d.tearflags & BitSet128(1<<43,0) == BitSet128(1<<43,0) then		--缩小
			if auxi.check_rand(player.Luck,6,1,13) == true then
				col:AddShrink(EntityRef(player),30 * 10)
			end
		end
		if d.tearflags & BitSet128(1<<44,0) == BitSet128(1<<44,0) then		--贪婪头
			if auxi.check_rand(player.Luck,3,1,13) == true then
				local room = Game():GetRoom()
				Isaac.Spawn(5,20,0,room:FindFreePickupSpawnPosition(col.Position,10,true),Vector(0,0),nil)
			end
		end
		if d.tearflags & BitSet128(1<<47,0) == BitSet128(1<<47,0) then		--青光眼
			if auxi.check_rand(player.Luck,10,1,10) == true then
				if not col:IsBoss() then
					col:AddEntityFlags(1<<9)
				end
			end
		end
		if d.tearflags & BitSet128(1<<49,0) == BitSet128(1<<49,0) then 		--中猫套
			local rand = math.random(1000)/1000
			if rand *(math.exp(3) + 2.35) < math.exp(math.min(3,player.Luck/10)) + 2.35 then		--随着幸运上升，在30达到100%。基础值为 15%
				if math.random(1000) > 500 then
					player:ThrowBlueSpider(ent.Position,player.Position)
				else
					player:AddBlueFlies(math.random(2),ent.Position,player)
				end
				Isaac.Spawn(1000,44,0,ent.Position,Vector(0,0),player)
			elseif math.random(1000) > 950 then
				Isaac.Spawn(1000,44,0,ent.Position,Vector(0,0),player)
			end
		end
		if d.tearflags & BitSet128(1<<53,0) == BitSet128(1<<53,0) then		--点金
			col:AddMidasFreeze(EntityRef(player),30 * 2)
		end
		if d.tearflags & BitSet128(1<<56,0) == BitSet128(1<<56,0) then 		--霍恩角
			if auxi.check_rand(player.Luck,10,1,13) == true then
				if not col:IsBoss() and not col:GetData().has_horn then
					local q1 = auxi.fire_nil(col.Position + Vector(0,-1),Vector(0,0),{cooldown = 60000})
					col:GetData().has_horn = true
					local d2 = q1:GetData()
					d2.follower = col
					col:AddEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE)
					Attribute_holder.try_hold_and_rewind_attribute(col,"Velocity",Vector(0,0),45,{toget = function(ent) return ent.Velocity end,tochange = function(ent,value) if value ~= true then ent.Velocity = value end end,tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
					Attribute_holder.try_hold_and_rewind_attribute(col,"EntityCollisionClass",EntityCollisionClass.ENTCOLL_NONE,45)
					d2.Is_Qing_Horn = true
				end
			end
		end
		if d.tearflags & BitSet128(0,1<<(64-64)) == BitSet128(0,1<<(64-64)) then		--拳头
			if auxi.check_rand(player.Luck,20,1,15) == true then
				col:AddConfusion(EntityRef(player),30 * 3,false)
				Attribute_holder.try_hold_and_rewind_attribute(col,"Velocity",ent.Velocity:Normalized() * 10,15,{toget = function(ent) return ent.Velocity end,tochange = function(ent,value) if value ~= true then ent.Velocity = value end end,tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
				Attribute_holder.try_hold_and_rewind_attribute(col,"ENTITY_FLAG_FLAG_KNOCKED_BACK",true,20,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_KNOCKED_BACK) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_KNOCKED_BACK) else ent:AddEntityFlags(EntityFlag.FLAG_KNOCKED_BACK) end end,})
				Attribute_holder.try_hold_and_rewind_attribute(col,"ENTITY_FLAG_FLAG_FLAG_APPLY_IMPACT_DAMAGE",true,20,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_APPLY_IMPACT_DAMAGE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_APPLY_IMPACT_DAMAGE) else ent:AddEntityFlags(EntityFlag.FLAG_APPLY_IMPACT_DAMAGE) end end,})
				Attribute_holder.try_hold_and_rewind_attribute(col,"ENTITY_FLAG_FLAG_FLAG_SLIPPERY_PHYSICS",true,20,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_SLIPPERY_PHYSICS) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_SLIPPERY_PHYSICS) else ent:AddEntityFlags(EntityFlag.FLAG_SLIPPERY_PHYSICS) end end,})
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_PUNCH,math.random(1000)/1000 * 0.3 + 0.85,math.random(1000)/1000 * 0.1 + 0.95,false,0,2)
			end
		end
		if d.tearflags & BitSet128(0,1<<(65-64)) == BitSet128(0,1<<(65-64)) then		--冰
			if auxi.check_rand(player.Luck,3,1,8) == true then
				col:AddSlowing(EntityRef(player),30 * 8,0.95,Color(0.8,0.8,1,1,0.15,0.15,0.3))
			end
			col:GetData().should_be_iced = 1
		end
		if d.tearflags & BitSet128(0,1<<(66-64)) == BitSet128(0,1<<(66-64)) then		--磁化
			if auxi.check_rand(player.Luck,20,1,10) == true then
				Attribute_holder.try_hold_and_rewind_attribute(col,"ENTITY_FLAG_FLAG_MAGNETIZED",true,30 * 15,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_MAGNETIZED) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_MAGNETIZED) else ent:AddEntityFlags(EntityFlag.FLAG_MAGNETIZED) end end,})
				Attribute_holder.try_hold_and_rewind_attribute(col,"Color",Color(0.5,0.5,0.5,1),30 * 15,{toget = function(ent) return ent:GetColor() end,tochange = function(ent,value) ent:SetColor(value,10,99,false,false) end,tocompare = function(v1,v2) return math.abs(v1.R - v2.R) < 0.01 and math.abs(v1.G - v2.G) < 0.01 and math.abs(v1.B - v2.B) < 0.01 and math.abs(v1.A - v2.A) < 0.01 end,})		--重载不等号
			end
		end
		if d.tearflags & BitSet128(0,1<<(67-64)) == BitSet128(0,1<<(67-64)) then		--烂番茄
			if auxi.check_rand(player.Luck,30,1,4) == true then
				Attribute_holder.try_hold_and_rewind_attribute(col,"ENTITY_FLAG_FLAG_BAITED",true,30 * 30,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_BAITED) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_BAITED) else ent:AddEntityFlags(EntityFlag.FLAG_BAITED) end end,})
				Attribute_holder.try_hold_and_rewind_attribute(col,"Color",Color(1,0.4,0.4,1,0.3,0,0),30 * 15,{toget = function(ent) return ent:GetColor() end,tochange = function(ent,value) ent:SetColor(value,10,99,false,false) end,tocompare = function(v1,v2) return math.abs(v1.R - v2.R) < 0.01 and math.abs(v1.G - v2.G) < 0.01 and math.abs(v1.B - v2.B) < 0.01 and math.abs(v1.A - v2.A) < 0.01 end,})		--重载不等号
			end
		end
		if d.tearflags & BitSet128(0,1<<(76-64)) == BitSet128(0,1<<(76-64)) then		--黑洞眼
			if auxi.check_rand(player.Luck,3,1,15) == true then
				local q = Isaac.Spawn(1000,EffectVariant.RIFT,0,col.Position,Vector(0,0),player):ToEffect()
				q:SetTimeout(120)
			end
		end
		
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_KNIFE_UPDATE, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	local s = ent:GetSprite()
	if ent.Variant == enums.Entities.StabberKnife then
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		local n_movable = auxi.getmovable(n_entity)
		local n_pickups = auxi.getpickups(n_entity,true)
		local n_bombs = auxi.getothers(n_entity,4,nil,nil)
		local n_projs = auxi.getothers(n_entity,9,nil,nil)
		local range = ent:GetSprite().Scale:Length()
		local player = Game():GetPlayer(0)
		if d.player then
			player = d.player
		elseif d.params and d.params.player then
			player = d.params.player
		end
		local damage = ent.CollisionDamage
		local damageflag = 0
		if d.damage then
			damage = d.damage
		end
		if d.damageflag then
			damageflag = d.damageflag
		end
		d.inner_frame = (d.inner_frame or 0) + 1
		if s:IsPlaying("SpinUp") and s:IsFinished("SpinUp") == false or (s:IsPlaying("SpinUp2") and s:IsFinished("SpinUp2") == false) then
			if s:GetFrame() == 1 and math.random(1000) > 700 then
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_SWORD_SPIN,math.random(1000)/2000 + 1,math.random(1000)/5000 + 0.8,false,0,2)
			end
			if d.nowroom == nil or d.nowroom == level:GetCurrentRoomIndex() then		--还是有问题。暂时不会解决了。
				if d.inner_frame == 6 then
					for i = 1,#n_movable do
						if (ent.Position - n_movable[i].Position):Length() < 75 * range then
							qing_s_knife_holder.collide_knife_on_it(ent,n_movable[i],true)
							if damage > 0 then
								n_movable[i]:TakeDamage(1,damageflag,EntityRef(ent),0)
							end
						end
					end
					local grids = auxi.get_near_grid_info(ent.Position,75 * range)
					for u,v in pairs(grids) do
						if d.params and d.params.no_grid == nil then
							v.grid:Hurt(1)
						end
						if d.params and d.params.list and d.params.list.sulfur and d.params.list.sulfur > 0 then
							if auxi.check_rand(player.Luck,50,20,6) then
								auxi.try_destroy_grid(v.grid,1)
							end
						end
						if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
							if auxi.check_rand(player.Luck,80,40,4) then
								local succ = auxi.try_destroy_grid(grid,2)
								if succ then
									delay_buffer.addeffe(function(params)
										sound_tracker.PlayStackedSound(SoundEffect.SOUND_STONE_IMPACT,math.random(1000)/1000 * 0.2 + 0.9,math.random(1000)/1000 * 0.1 + 0.95,false,0,2)
									end,{},1)
								end
							end
						end
					end
				end
				for i = 1,#n_enemy do
					if (ent.Position - n_enemy[i].Position):Length() < 75 * range then
						qing_s_knife_holder.collide_knife_on_it(ent,n_enemy[i],true)
						if n_enemy[i]:GetData().Qing_blade_countdown == nil then
							n_enemy[i]:GetData().Qing_blade_countdown = -1
						end
						if n_enemy[i]:GetData().Qing_blade_countdown < 0 then
							if d.params and d.params.list and d.params.list.damo and d.params.list.damo > 0 and (ent.Position - n_enemy[i].Position):Length() < 75 * range then
								if ent.Parent and n_enemy[i]:GetData().Damo_effect == nil then
									local damo = d.params.list.damo
									local q1 = auxi.fire_nil(n_enemy[i].Position,n_enemy[i].Velocity,{cooldown = 60000})
									local d2 = q1:GetData()
									d2.follower = n_enemy[i]
									d2.Is_Qing_Damo = true
									n_enemy[i]:GetData().Damo_effect = true
								end
							end
							n_enemy[i]:TakeDamage(damage,damageflag,EntityRef(ent),6)
							if d.params and d.params.no_repel ~= nil then
							else
								n_enemy[i]:AddVelocity((ent.Position - n_enemy[i].Position):Normalized() * (-6) * auxi.get_repel_params(n_enemy[i]))
							end
							n_enemy[i]:GetData().Qing_blade_countdown = 2
							if ent:GetData().Explosive_cnt and ent:GetData().Explosive_cnt > 0 then		--引发爆炸
								local dmg = ent.CollisionDamage
								local tearflags = ent:GetData().bomb_knife_flag
								if tearflags == nil and ent:GetData().params and ent:GetData().params.bomb_knife_flag then
									tearflags = ent:GetData().params.bomb_knife_flag
								end
								if tearflags == nil then
									tearflags = BitSet128(0,0)
								end
								local dmgself = true
								if d.params.dmgself == true then dmgself = false end
								Game():BombExplosionEffects(n_enemy[i].Position,dmg * 5,tearflags,player.TearColor,player,1,false,dmgself)	
								ent:GetData().Explosive_cnt = ent:GetData().Explosive_cnt - 1
							end
							if d.fire_sound_effect and d.fire_sound_effect == true then
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_FIREDEATH_HISS,1.0,auxi.random_1() * 0.3 + 0.8,false,0,2)
							end
							
							local col = n_enemy[i]
							item.dealt_extra_effect_to_col(ent,col,"Spin")
						else
							n_enemy[i]:GetData().Qing_blade_countdown = n_enemy[i]:GetData().Qing_blade_countdown - 1
						end
					end
				end
				for i = 1,#n_pickups do
					if (ent.Position - n_pickups[i].Position):Length() < 75 * range and n_pickups[i]:ToPickup():IsShopItem() == false then
						qing_s_knife_holder.collide_knife_on_it(ent,n_pickups[i],true)
						if n_pickups[i]:GetData().Qing_blade_countdown == nil then
							n_pickups[i]:GetData().Qing_blade_countdown = -1
						end
						if n_pickups[i]:GetData().Qing_blade_countdown < 0 then
							n_pickups[i]:GetData().Qing_blade_countdown = 3
							if d.params and d.params.no_repel ~= nil then
							else
								n_pickups[i]:AddVelocity((ent.Position - n_pickups[i].Position):Normalized() * (-3) * auxi.get_repel_params(n_pickups[i]))
							end
							if d.params and d.params.no_open ~= nil then
							else
								if (n_pickups[i].Variant > 49 and n_pickups[i].Variant < 70) or n_pickups[i].Variant == 360 or n_pickups[i].Variant == 390 then
									local s = n_pickups[i]:GetSprite()
									if n_pickups[i].Variant == 60 or n_pickups[i].Variant == 55 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									elseif n_pickups[i].Variant == 57 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("UseKey") or s:IsFinished("UseGoldenKey")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											if math.random(1000) > 50 then
												s:Play("Idle",true)
												if player:HasGoldenKey() == true then
													s:Play("UseGoldenKey",true)
												else
													s:Play("UseKey",true)
												end
											else
												n_pickups[i]:ToPickup():TryOpenChest()
											end
										end
									elseif n_pickups[i].Variant == 53 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("Close")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									elseif n_pickups[i].Variant == 51 then
										if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
											if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("Close")) then
												n_pickups[i]:ToPickup():TryOpenChest()
											end
										end
									elseif n_pickups[i].Variant == 69 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) then
											n_pickups[i]:ToPickup():TryOpenChest()
											n_pickups[i]:Remove()
										end
									else
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									end
								end
							end
						else
							n_pickups[i]:GetData().Qing_blade_countdown = n_pickups[i]:GetData().Qing_blade_countdown - 1
						end
					end
				end
				for i = 1,#n_bombs do
					if (ent.Position - n_bombs[i].Position):Length() < 75 * range then
						qing_s_knife_holder.collide_knife_on_it(ent,n_bombs[i],true)
						if d.params and d.params.no_repel ~= nil then
						else
							n_bombs[i]:AddVelocity((ent.Position - n_bombs[i].Position):Normalized() * (-1.5))
						end
					end
				end
				if d.tearflags and d.tearflags & BitSet128(1<<34,0) == BitSet128(1<<34,0) then		--泪盾
					for i = 1,#n_projs do
						if (ent.Position - n_projs[i].Position):Length() < 75 * range then
							n_projs[i]:AddVelocity((ent.Position - n_projs[i].Position):Normalized() * (-2))
						end
					end
				end
				if ent.FrameCount == (d.record_knife2_on_delay or 1) and d.params and d.params.list and d.params.knife2 and d.params.knife2 > 0 then
					if d.record_dir_for_knife_and_sword and d.delta_dir_for_knife_and_sword and d.delta_dir_for_knife_and_sword < 180 then
						d.delta_dir_for_knife_and_sword = d.delta_dir_for_knife_and_sword + 20 + math.random(20)
						for k = 1,-1,-2 do
							auxi.fire_dowhatknife(nil,ent.Position,auxi.MakeVector(d.record_dir_for_knife_and_sword + d.delta_dir_for_knife_and_sword * k):Normalized() * 20 * player.ShotSpeed,ent.CollisionDamage * 1.5,"IdleUp","IdleUp2",{source = nil,cooldown = 50,player = player,tearflags = player.TearFlags,color = player.TearColor,epic = d.params.list.epic,Accerate = 2,size = 5,size1 = Vector(1,3),size2 = 13,list = d.params.list,tech = d.params.list.tech,shouldrotate = true,Way_Accerate = auxi.MakeVector(d.record_dir_for_knife_and_sword),Explosive = d.params.list.dr ,dmgself = (d.params.list.ipec > 0 and d.params.list.dr > 0)})								
						end
						d.record_knife2_on_delay = (d.record_knife2_on_delay or 1) + (d.record_knife2_delay or 3)
					end
				end
			end
		end
		
		if (s:IsPlaying("AttackUp") and s:IsFinished("AttackUp") == false) or (s:IsPlaying("AttackUp2") and s:IsFinished("AttackUp2") == false) then
			if s:GetFrame() == 1 and math.random(1000) > 700 then
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_SWORD_SPIN,math.random(1000)/2000 + 0.5,math.random(1000)/5000 + 0.4,false,0,2)
			end
			if d.nowroom == nil or d.nowroom == level:GetCurrentRoomIndex() then
				if d.inner_frame == 6 then
					for i = 1,#n_movable do
						if (ent.Position - n_movable[i].Position):Length() < 55 * range and auxi.MakeVector((ent.Position - n_movable[i].Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
							qing_s_knife_holder.collide_knife_on_it(ent,n_movable[i],true)
							if damage > 0 then
								n_movable[i]:TakeDamage(1,damageflag,EntityRef(ent),0)
							end
						end
					end
					local grids = auxi.get_near_grid_info(ent.Position,55 * range)
					for u,v in pairs(grids) do
						if auxi.MakeVector((ent.Position - room:GetGridPosition(v.idx)):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
							if d.params and d.params.no_grid == nil then
								v.grid:Hurt(1)
							end
						end
						if d.params and d.params.list and d.params.list.sulfur and d.params.list.sulfur > 0 then
							if auxi.check_rand(player.Luck,50,20,6) then
								auxi.try_destroy_grid(v.grid,1)
							end
						end
						if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
							if auxi.check_rand(player.Luck,80,40,4) then
								local succ = auxi.try_destroy_grid(grid,2)
								if succ then
									delay_buffer.addeffe(function(params)
										sound_tracker.PlayStackedSound(SoundEffect.SOUND_STONE_IMPACT,math.random(1000)/1000 * 0.5 + 0.75,math.random(1000)/1000 + 0.5,false,0,2)
									end,{},1)
								end
							end
						end
					end
				end
				--l local q = Isaac.Spawn(292,0,0,Vector(200,200),Vector(0,0),nil) q:TakeDamage(1,0,EntityRef(Game():GetPlayer(0)),0)
				for i = 1,#n_enemy do
					if (ent.Position - n_enemy[i].Position):Length() < 55 * range and auxi.MakeVector((ent.Position - n_enemy[i].Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
						qing_s_knife_holder.collide_knife_on_it(ent,n_enemy[i],true)
						if n_enemy[i]:GetData().Qing_blade_countdown == nil then
							n_enemy[i]:GetData().Qing_blade_countdown = -1
						end
						if n_enemy[i]:GetData().Qing_blade_countdown < 0 then
							if d.params and d.params.list and d.params.list.damo and d.params.list.damo > 0 and (ent.Position - n_enemy[i].Position):Length() < 55 * range then
								if ent.Parent and n_enemy[i]:GetData().Damo_effect == nil then
									local damo = d.params.list.damo
									local q1 = auxi.fire_nil(n_enemy[i].Position,n_enemy[i].Velocity,{cooldown = 60000})
									local d2 = q1:GetData()
									d2.follower = n_enemy[i]
									d2.Is_Qing_Damo = true
									n_enemy[i]:GetData().Damo_effect = true
								end
							end
							n_enemy[i]:TakeDamage(damage,damageflag,EntityRef(ent),3)
							if d.params and d.params.no_repel ~= nil then
							else
								n_enemy[i]:AddVelocity((ent.Position - n_enemy[i].Position):Normalized() * (-3) * auxi.get_repel_params(n_enemy[i]))
							end
							n_enemy[i]:GetData().Qing_blade_countdown = 2
							if ent:GetData().Explosive_cnt and ent:GetData().Explosive_cnt > 0 then		--引发爆炸
								local dmg = ent.CollisionDamage
								local tearflags = ent:GetData().bomb_knife_flag
								if tearflags == nil and ent:GetData().params and ent:GetData().params.bomb_knife_flag then
									tearflags = ent:GetData().params.bomb_knife_flag
								end
								if tearflags == nil then
									tearflags = BitSet128(0,0)
								end
								local dmgself = true
								if d.params.dmgself == true then dmgself = false end
								Game():BombExplosionEffects(n_enemy[i].Position,dmg * 5,tearflags,player.TearColor,player,1,false,dmgself)	
								ent:GetData().Explosive_cnt = ent:GetData().Explosive_cnt - 1
							end
							if d.fire_sound_effect and d.fire_sound_effect == true then
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_FIREDEATH_HISS,1.0,auxi.random_1() * 0.3 + 0.8,false,0,2)
							end
							local col = n_enemy[i]
							item.dealt_extra_effect_to_col(ent,col,"Attack")
						else
							n_enemy[i]:GetData().Qing_blade_countdown = n_enemy[i]:GetData().Qing_blade_countdown - 1
						end
					end
				end
				for i = 1,#n_pickups do
					if (ent.Position - n_pickups[i].Position):Length() < 55 * range and auxi.MakeVector((ent.Position - n_pickups[i].Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 and n_pickups[i]:ToPickup():IsShopItem() == false then
						qing_s_knife_holder.collide_knife_on_it(ent,n_pickups[i],true)
						if n_pickups[i]:GetData().Qing_blade_countdown == nil then
							n_pickups[i]:GetData().Qing_blade_countdown = -1
						end
						if n_pickups[i]:GetData().Qing_blade_countdown < 0 then
							n_pickups[i]:GetData().Qing_blade_countdown = 3
							if d.params and d.params.no_repel ~= nil then
							else
								n_pickups[i]:AddVelocity((ent.Position - n_pickups[i].Position):Normalized() * (-3) * auxi.get_repel_params(n_pickups[i]))
							end
							if d.params and d.params.no_open ~= nil then
							else
								if (n_pickups[i].Variant > 49 and n_pickups[i].Variant < 70) or n_pickups[i].Variant == 360 or n_pickups[i].Variant == 390 then
									local s = n_pickups[i]:GetSprite()
									if n_pickups[i].Variant == 60 or n_pickups[i].Variant == 55 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									elseif n_pickups[i].Variant == 57 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("UseKey") or s:IsFinished("UseGoldenKey")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											if math.random(1000) > 50 then
												s:Play("Idle",true)
												if player:HasGoldenKey() == true then
													s:Play("UseGoldenKey",true)
												else
													s:Play("UseKey",true)
												end
											else
												n_pickups[i]:ToPickup():TryOpenChest()
											end
										end
									elseif n_pickups[i].Variant == 53 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("Close")) and (player:HasTrinket(19) or player:TryUseKey() == true) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									elseif n_pickups[i].Variant == 51 then
										if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
											if (s:IsPlaying("Idle") or s:IsFinished("Idle") or s:IsFinished("Close")) then
												n_pickups[i]:ToPickup():TryOpenChest()
											end
										end
									elseif n_pickups[i].Variant == 69 then
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) then
											n_pickups[i]:ToPickup():TryOpenChest()
											n_pickups[i]:Remove()
										end
									else
										if (s:IsPlaying("Idle") or s:IsFinished("Idle")) then
											n_pickups[i]:ToPickup():TryOpenChest()
										end
									end
								end
							end
						else
							n_pickups[i]:GetData().Qing_blade_countdown = n_pickups[i]:GetData().Qing_blade_countdown - 1
						end
					end
				end
				for i = 1,#n_bombs do
					if (ent.Position - n_bombs[i].Position):Length() < 55 * range and auxi.MakeVector((ent.Position - n_bombs[i].Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
						qing_s_knife_holder.collide_knife_on_it(ent,n_bombs[i],true)
						if d.params and d.params.no_repel ~= nil then
						else
							n_bombs[i]:AddVelocity((ent.Position - n_bombs[i].Position):Normalized() * (-1.5))
						end
					end
				end
				if d.tearflags and d.tearflags & BitSet128(1<<34,0) == BitSet128(1<<34,0) then
					for i = 1,#n_projs do
						if (ent.Position - n_projs[i].Position):Length() < 55 * range and auxi.MakeVector((ent.Position - n_projs[i].Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
							qing_s_knife_holder.collide_knife_on_it(ent,n_projs[i],true)
							n_projs[i]:AddVelocity((ent.Position - n_projs[i].Position):Normalized() * (-1))
						end
					end
				end
			end
		end
		
		if s:IsPlaying("IdleUp") or s:IsFinished("IdleUp") or s:IsPlaying("IdleUp2") or s:IsFinished("IdleUp2") then
			if d.params and d.params.knife and (d.params.knife == true or d.params.knife > 0) then
				if d.params.list and d.params.list.brimstone and d.params.list.brimstone > 0 then
					if d.brim_and_knife_firedelay == nil then
						d.brim_and_knife_firedelay = -1
					end
					if d.brim_and_knife_firedelay < 0 then
						local vel = ent.Parent.Velocity
						if vel:Length() < 0.005 then
							vel = auxi.MakeVector(ent.RotationOffset) * 0.005
						end
						local q1 = auxi.fire_knife(ent.Position, - vel * 0.5,ent.CollisionDamage / 3,nil,{cooldown = math.random(10),player = player,Color = Color(-1,-1,-1,0.3,0,0,0)})
						q1:SetColor(Color(-1,-1,-1,0.3,0,0,0),15,99,false,false)
						local s2 = q1:GetSprite()
						s2.Scale = Vector(2,2)
						q1.RotationOffset = 180 + q1.RotationOffset
						d.brim_and_knife_firedelay = math.random(6)
					end
					d.brim_and_knife_firedelay = d.brim_and_knife_firedelay - 1
				elseif d.params.knife3 and (d.params.knife3 == true or d.params.knife3 > 0) then
					if d.Only_knife_firedelay == nil then
						d.Only_knife_firedelay = -1
					end
					local d2 = ent.Parent:GetData()
					if d.Only_knife_firedelay < 0 and d2.Params and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
						local vel = ent.Parent.Velocity
						if vel:Length() < 0.005 then
							vel = auxi.MakeVector(ent.RotationOffset) * 0.005
						end
						local q1 = auxi.fire_knife(ent.Position,(d2.Params.Homing_target.Position - ent.Position):Normalized(),ent.CollisionDamage * 0.05,nil,{cooldown = 8,player = player,Color = Color(1,1,1,0.5,0,0,0)})
						q1:Shoot(1,player.TearRange/4)
						d.Only_knife_firedelay = math.random(20)
					end
					d.Only_knife_firedelay = d.Only_knife_firedelay - 1
				end
			end
			
			if d.params and d.params.Dr_fet and (d.params.Dr_fet == true or d.params.Dr_fet > 0) then
				local d2 = ent.Parent:GetData()
				if d2.Params and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
					if d.Dr_fetus_firedelay == nil then
						d.Dr_fetus_firedelay = -1
					end
					if d.Dr_fetus_firedelay < 0 then
						if math.random(1000) > 800 then
							local d2 = ent.Parent:GetData()
							local vel = (d2.Params.Homing_target.Position - ent.Parent.Position):Normalized() * ent.Parent.Velocity:Length()
							if vel:Length() < 0.005 then
								vel = auxi.MakeVector(ent.RotationOffset) * 0.005
							end
							local q1 = player:FireBomb(ent.Position,vel * (math.random(50)/10 + 2))
						end
						d.Dr_fetus_firedelay = math.random(65) + 10 + player.MaxFireDelay
					end
					d.Dr_fetus_firedelay = d.Dr_fetus_firedelay - 1
				end
			end
			
			if d.params and d.params.epic and (d.params.epic == true or d.params.epic > 0) then -- and auxi.isenemies(col) == true then
				if ent.Parent then
					if d.touch ~= nil then
						ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
						ent.CollisionDamage = 0
					else
						local grident = room:GetGridEntityFromPos(ent.Position)
						if grident ~= nil and auxi.issolid(grident) then
							ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 3
							ent.Parent:GetData().Params.Accerate = -1
							ent.Parent:GetData().Params.Homing = false		--强制停止跟踪
							ent.Parent:GetData().Accerate_flag = true
							local tearflags = d.params.tearflags
							if tearflags == nil then
								tearflags = player.TearFlag
							end
							tearflags = tearflags | player:GetBombFlags()		--强度大增！
							local q1 = auxi.launch_Missile(ent.Position,Vector(0,0),ent.CollisionDamage/2,nil,{color = d.params.color,Cooldown = 25,Spawner = ent,Player = player,tearflags = tearflags,knife = player:GetCollectibleNum(114),brimstone = player:GetCollectibleNum(118), Tech = player:GetCollectibleNum(68),TechX = player:GetCollectibleNum(395),MultipleRockets = d.params.multishot, NumRockets = d.params.multishot})
							q1.Visible = false
							q1:GetSprite().Scale = ent:GetSprite().Scale
							d.touch = true
							ent.Parent:GetData().Params.FollowInput = nil
							if s:IsPlaying("IdleUp") or s:IsFinished("IdleUp") then
								s:Play("ChargedUp",false)
							elseif s:IsPlaying("IdleUp2") or s:IsFinished("IdleUp2") then
								s:Play("ChargedUp2",false)
							end
						end
					end
				end
			end
		
			if d.params and ((d.params.tearflags and d.params.tearflags & BitSet128(1<<2,0) == BitSet128(1<<2,0)) or (d.params.shouldrotate and d.params.shouldrotate == true)) then
				local d2 = ent.Parent:GetData()
				if d2.Params then --and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
					ent.RotationOffset = ent.Parent.Velocity:GetAngleDegrees()
					d2.Params.removeanimate = true
				end
			end
		
			if d.start_sec ~= nil and d.start_sec == false and ent.Parent and ent.Parent.Velocity:Length() < 0.005 then
				local d2 = ent.Parent:GetData()
				if d2.Params and (d2.Params.Homing_target and d2.Params.Homing_target:Exists() == false) then
					d2.Params.Homing_target = nil
					ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 3
					ent.Parent:GetData().Params.Accerate = 0
				end
			end
		
			if d.params and d.params.sword and (d.params.sword == true or d.params.sword > 0) then
				local d2 = ent.Parent:GetData()
				if d2.Params and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
					if d.Dr_fetus_firedelay == nil then
						d.Dr_fetus_firedelay = -1
					end
					if d.Dr_fetus_firedelay < 0 then
						if math.random(1000) > 400 then
							
							local d2 = ent.Parent:GetData()
							local vel = (d2.Params.Homing_target.Position - ent.Parent.Position):Normalized() * ent.Parent.Velocity:Length()
							if vel:Length() < 0.005 then
								vel = auxi.MakeVector(ent.RotationOffset) * 0.005
							end
							local q1 = auxi.fire_Sword(ent.Position,vel,ent.CollisionDamage/3,nil,{cooldown = 14,Accerate = 0.5,player = player,tearflags = player.TearFlags,Color = player.TearColor,Qing = (player:GetName() == "W.Qing")})
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_SWORD_SPIN,math.random(1000)/2000 + 1,math.random(1000)/5000 + 0.8,false,0,2)
						end
						d.Dr_fetus_firedelay = math.random(65) + 10 + player.MaxFireDelay
					end
					d.Dr_fetus_firedelay = d.Dr_fetus_firedelay - 1
				end
			end
		
			if d.params and d.params.Hae and (d.params.Hae == true or d.params.Hae > 0) then
				local d2 = ent.Parent:GetData()
				if d2.removecd and d2.removecd == 1 then
					local maxcnt = math.random(d.params.list.hae * 1 + 1) - 1
					for i = 1, maxcnt do 
						local q1 = player:FireTear(ent.Position, auxi.MakeVector(math.random(36000)/100) * 3 * player.ShotSpeed * (math.random(1000)/400+0.3),true,true,true)
						q1.FallingSpeed = 10
						q1.FallingAcceleration = 2.6
						q1.PositionOffset = Vector(0,0)
						q1.Scale = q1.Scale * (math.random(1500)/1000 + 0.8)
					end
				end
			end
			
			local grid = room:GetGridEntityFromPos(ent.Position)
			if grid then
				if d.params and d.params.list and d.params.list.sulfur and d.params.list.sulfur > 0 then
					if auxi.check_rand(player.Luck,50,20,6) then
						auxi.try_destroy_grid(grid,1)
					end
				end
				if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
					if auxi.check_rand(player.Luck,80,40,4) then
						local succ = auxi.try_destroy_grid(grid,2)
						if succ then
							delay_buffer.addeffe(function(params)
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_STONE_IMPACT,math.random(1000)/1000 * 0.5 + 0.75,math.random(1000)/1000 + 0.5,false,0,2)
							end,{},1)
						end
					end
				end
			end
		
			local n_multi_baby = auxi.getothers(n_entity,3,101)
			if d.params and d.params.list and d.params.list.not_allow_multi_dimen == nil then
				for u,v in pairs(n_multi_baby) do
					if (v.Position - ent.Position):Length() < 20 then
						d.params = d.params or {}
						d.params.color = d.params.color or Color(1,1,1,1)
						d.params.list = d.params.list or {}
						d.params.list.not_allow_multi_dimen = 1
						auxi.fire_dowhatknife(nil,ent.Position,ent.Velocity:Normalized() * 25,ent.CollisionDamage/2,"IdleUp","IdleUp2",{player = player,cooldown = 60,tearflags = d.tearflags,Accerate = 2,color = auxi.AddColor(d.params.color,Color(0,0,0,1,0.5,0.5,0.5),0.25,0.75),tech = d.params.tech,list = d.params.list,})
						break
					end
				end
			end
			
			local n_prism = auxi.getothers(n_entity,3,123)
			if d.params and d.params.list and d.params.list.not_allow_multi_prism == nil then
				for u,v in pairs(n_prism) do
					if (v.Position - ent.Position):Length() < 20 then
						d.params = d.params or {}
						d.params.color = d.params.color or Color(1,1,1,1)
						d.params.list = d.params.list or {}
						d.params.list.not_allow_multi_prism = 1
						local color_idx = {
							Color(0,0,0,1,1,0,0),
							Color(0,0,0,1,0,1,0),
							Color(0,0,0,1,0,0,1),
							Color(0,0,0,1,0,1,1),
						}
						for i = 1,4 do
							auxi.fire_dowhatknife(nil,ent.Position,auxi.MakeVector(ent.Velocity:GetAngleDegrees() - 18 + 12 * (i - 1)) * 25,ent.CollisionDamage/2,"IdleUp","IdleUp2",{player = player,cooldown = 60,tearflags = d.tearflags,Accerate = 2,color = auxi.AddColor(d.params.color,color_idx[i],0.25,0.75),tech = d.params.tech,list = d.params.list,})
						end
						break
					end
				end
			end
		end
		
		if s:IsPlaying("StabDown") or s:IsFinished("StabDown") or s:IsPlaying("StabDown2") or s:IsFinished("StabDown2") then
			if d.params and ((d.params.tearflags and d.params.tearflags & BitSet128(1<<2,0) == BitSet128(1<<2,0)) or (d.params.shouldrotate and d.params.shouldrotate == true)) then
				local d2 = ent.Parent:GetData()
				if d2.Params and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
					ent.RotationOffset = ent.Parent.Velocity:GetAngleDegrees()
					d2.Params.removeanimate = true
				end
			end
			if d.params and d.params.lung_and_tech and d.params.lung_and_tech > 0 and d.params.lung_and_tech_cnt and d.params.lung_and_tech_cnt> 0 then
				if s:GetFrame() == 2 then
					local dirang = (ent.Velocity):GetAngleDegrees()
					local rang = math.random(60) + 30
					local leap = rang/(d.params.lung_and_tech_cnt - 1)
					local length = (ent.Velocity):Length()
					for i = 1,d.params.lung_and_tech_cnt do 
						local q1 = auxi.fire_dowhatknife(nil,ent.Position + ent.Velocity,auxi.MakeVector(dirang - rang/2 + (i-1) * leap) * math.max(0.001,(length + math.random(10000)/1000 - 5)),ent.CollisionDamage,"StabDown","StabDown2",{source = d.params.source,player = d.params.player,tearflags = d.params.tearflags,color = d.params.color,repel = d.params.repel/2,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,size = d.params.size,size1 = d.params.size1,size2 = d.params.size2,list = d.params.list,tech = d.params.tech,lung_and_tech = d.params.lung_and_tech - math.random(d.params.lung_and_tech + 1),lung_and_tech_cnt = math.max(1,d.params.lung_and_tech_cnt + math.random(3) - 2)})
					end
				end
			end
			
			local n_multi_baby = auxi.getothers(n_entity,3,101)
			if d.params and d.params.list and d.params.list.not_allow_multi_dimen == nil then
				for u,v in pairs(n_multi_baby) do
					if (v.Position - ent.Position):Length() < 20 then
						d.params = d.params or {}
						d.params.color = d.params.color or Color(1,1,1,1)
						d.params.list = d.params.list or {}
						d.params.list.not_allow_multi_dimen = 1
						auxi.fire_dowhatknife(nil,ent.Position,ent.Velocity:Normalized() * 15,ent.CollisionDamage/2,"IdleUp","IdleUp2",{player = player,cooldown = 60,tearflags = d.tearflags,Accerate = 2,color = auxi.AddColor(d.params.color,Color(0,0,0,1,0.5,0.5,0.5),0.25,0.75),tech = d.params.tech,list = d.params.list,})
						break
					end
				end
			end
			
			local n_prism = auxi.getothers(n_entity,3,123)
			if d.params and d.params.list and d.params.list.not_allow_multi_prism == nil then
				for u,v in pairs(n_prism) do
					if (v.Position - ent.Position):Length() < 20 then
						d.params = d.params or {}
						d.params.color = d.params.color or Color(1,1,1,1)
						d.params.list = d.params.list or {}
						d.params.list.not_allow_multi_prism = 1
						local color_idx = {
							Color(0,0,0,1,1,0,0),
							Color(0,0,0,1,0,1,0),
							Color(0,0,0,1,0,0,1),
							Color(0,0,0,1,0,1,1),
						}
						for i = 1,4 do
							auxi.fire_dowhatknife(nil,ent.Position,auxi.MakeVector(ent.Velocity:GetAngleDegrees() - 18 + 12 * (i - 1)) * 15,ent.CollisionDamage/2,"IdleUp","IdleUp2",{player = player,cooldown = 60,tearflags = d.tearflags,Accerate = 2,color = auxi.AddColor(d.params.color,color_idx[i],0.25,0.75),tech = d.params.tech,list = d.params.list,})
						end
						break
					end
				end
			end
			
			local grid = room:GetGridEntityFromPos(ent.Position)
			if grid then
				if d.params and d.params.list and d.params.list.sulfur and d.params.list.sulfur > 0 then
					if auxi.check_rand(player.Luck,50,20,6) then
						auxi.try_destroy_grid(grid,1)
					end
				end
				if d.params and d.params.list and d.params.list.rock and d.params.list.rock > 0 then
					if auxi.check_rand(player.Luck,80,40,4) then
						local succ = auxi.try_destroy_grid(grid,2)
						if succ then
							delay_buffer.addeffe(function(params)
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_STONE_IMPACT,math.random(1000)/1000 * 0.5 + 0.75,math.random(1000)/1000 + 0.5,false,0,2)
							end,{},1)
						end
					end
				end
			end
		end

		if d.params and d.params.list and d.params.list.pro and d.params.list.pro > 0 then		--突眼
			if d.damage_float == nil then
				d.damage_float = 3
				d.damage_count = ent.CollisionDamage
			end
			d.damage_float = d.damage_float - 0.15 / player.ShotSpeed		--15帧后减少至0。
			if d.damage_float < 0 then
				d.damage_float = 0
			end
			ent.CollisionDamage = d.damage_float * d.damage_count
		end
		
		if d.params and d.params.list and d.params.list.coal and d.params.list.coal > 0 then	--煤块
			if d.damage_float == nil then
				d.damage_float = 0.4
				d.damage_count = ent.CollisionDamage
			end
			d.damage_float = d.damage_float + 0.05 / player.ShotSpeed
			ent.CollisionDamage = d.damage_float * d.damage_count
		end
		
		if d.deadeye and d.deadeye > 0 and ent.Parent then		--死眼
			local d2 = ent.Parent:GetData()
			if d2.removecd and d2.removecd == 1 then
				if math.random(1000) > 750 then		--随便取个参数
					player:ClearDeadEyeCharge()
				end
				d.deadeye = 0
			end
		end
		if d.wavereye and d.wavereye > 0 and ent.Parent then
			local d2 = ent.Parent:GetData()
			if d2.removecd and d2.removecd == 1 then
				if math.random(1000) > 250 then
					Wavering_Eyes.clear_waver_eye_charge(player)
				end
				d.wavereye = 0
			end
		end
		
		if d.params and d.params.list and (not d.params.no_sec) and d.params.list.sec and d.params.list.sec > 0 and ent.Parent then			--剖腹产：转化为飞刀攻击！只会成功一次！
			if (s:IsFinished("AttackUp") or s:IsFinished("SpinUp") or s:IsFinished("StabUp")) or (s:IsPlaying("StabDown") and ent.FrameCount > 8) then
				d.start_sec = true
				s:Play("IdleUp")
			elseif (s:IsFinished("AttackUp2") or s:IsFinished("SpinUp2") or s:IsFinished("StabUp2")) or (s:IsPlaying("StabDown2") and ent.FrameCount > 8) then
				d.start_sec = true
				s:Play("IdleUp")
			end
			if d.start_sec and d.start_sec == true then
				ent.Parent:GetData().Is_Qing_Fetus = true
				d.start_sec = false
				if ent.Parent:GetData().Params == nil then
					ent.Parent:GetData().Params = {}
				end
				ent.Parent:GetData().Params.Homing = true
				ent.Parent:GetData().Params.HomingSpeed = 8
				ent.Parent:GetData().Params.HomingDistance = 170 + math.sqrt(math.max(0,(player.TearRange - 260))) * 0.3		--跟踪距离为100。
				ent.Parent:GetData().Params.Accerate = 0.55
				ent.Parent.Velocity = ent.Velocity:Normalized() * 3
				ent.Parent:GetData().removecd = ent.Parent:GetData().removecd + math.sqrt(math.max(0,(player.TearRange - 200)))
				d.params.shouldrotate = true
				d.params.repel = Vector(0,0)
				if d.params.thor_effe == nil or d.params.thor_effe ~= true then		--对飞雷神攻击的附加特效是无效的
					d.params.epic = d.params.list.epic
					d.params.sword = d.params.list.sword
					d.params.knife = d.params.list.knife
					d.params.knife3 = d.params.list.knife		--独属于剖腹产和妈刀配合的特效
					d.params.brimstone = d.params.list.brimstone
					d.params.TechX = d.params.list.techX
					d.params.Tech = d.params.list.tech
					d.params.Hae = d.params.list.hae
					d.params.Dr_fet = d.params.list.dr + d.params.list.epic
				end
				if d.params.knife and d.params.brimstone and d.params.knife == 0 and d.params.brimstone > 0 then
					local q2 = player:FireBrimstone(-ent.Parent.Velocity)
					q2.PositionOffset = Vector(0,0)
					q2:SetTimeout(ent.Parent:GetData().removecd - 1)
					q2:SetMaxDistance(player.TearRange/4)
					q2.Parent = ent
					q2.Position = ent.Position
					q2:GetData().followRotation = ent.Parent
				elseif d.params.Tech and d.params.Tech > 0 then
					local q2 = player:FireTechLaser(ent.Position,1,(player.Position - ent.Position):Normalized(),false,true)
					q2.Parent = ent
					q2.PositionOffset = Vector(0,0)
					q2:GetData().followParent = ent
					--q2.CollisionDamage = ent.CollisionDamage/10
					q2:GetData().followRotation = ent.Parent
					--q2:GetData().followRotation_aidang = 180
					q2:GetData().reset_startp = true
					q2:GetData().reset_startp_source = player
					q2:SetMaxDistance((player.Position - ent.Position):Length())
					q2:SetTimeout(ent.Parent:GetData().removecd - 1)
				end
				if d.params.TechX and d.params.TechX > 0 and d.params.Tech and d.params.Tech == 0then
					local q2 = player:FireTechXLaser(ent.Position,ent.Velocity,player.TearRange/10)
					q2.PositionOffset = Vector(0,0)
					q2:GetData().followParent = ent
					q2:SetTimeout(ent.Parent:GetData().removecd - 1)
				end
			end
		end
		
		if d.params and d.params.thor then
			if d.has_thor and d.has_thor == true then
				if d.has_fall == nil and room:GetType() ~= RoomType.ROOM_DUNGEON then
					if ent.Parent and ent.Parent:GetData().follower and ent.Parent:GetData().follower:IsDead() == true then
						ent.Parent:GetData().follower = nil
						if ent.Parent:GetData().removecd and ent.Parent:GetData().removecd > 0 then ent.Parent:GetData().removecd = ent.Parent:GetData().removecd + 30 * 2 end
						if s:IsPlaying("ChargedUp") then
							s:Play("ChargedFall",true)
						end
						if s:IsPlaying("NoChargedUp") then
							s:Play("NoChargedFall",true)
						end
						d.has_fall = true
					end
				end
			end
		end
		
		if d.params and d.params.follow_hae then
			if d.hae_brim_hold_it ~= nil then
				for u,v in pairs(d.hae_brim_hold_it) do
					if v.ent:Exists() and not v.ent:IsDead() and ent.Velocity:Length() > 0.05 then
						v.ent.Angle = ent.Velocity:GetAngleDegrees() + v.adder
					end
				end
			end
		end
		
		if s:IsPlaying("ChargedFall") or s:IsPlaying("NoChargedFall") or s:IsFinished("ChargedFall") or s:IsFinished("NoChargedFall") then
			if d.save_rotation == nil then d.save_rotation = s.Rotation end
			d.save_rotation = d.save_rotation * 0.7
			s.Rotation = d.save_rotation
			if ent.Parent then
				ent.Parent.Velocity = ent.Parent.Velocity * 0.1
			end
			if s:IsEventTriggered("TryCrack") then
				if d.params and d.params.list and d.params.list.lemon and d.params.list.lemon > 0 then		--柠檬：掉落的瓶子会流出酸水
					if auxi.check_rand(player.Luck,35,15,6) == true then
						local q = Isaac.Spawn(1000,EffectVariant.PLAYER_CREEP_LEMON_MISHAP,0,ent.Position,Vector(0,0),player):ToEffect()
						if ent.Parent then
							q:SetTimeout(ent.Parent:GetData().removecd)
						end
						auxi.replace_dagger_graph(ent,"Empty_Stabknife")
						s:ReplaceSpritesheet(3,"gfx/effects/ground_yellow.png")
						s:LoadGraphics()
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_GLASS_BREAK,1,1,false,0,2)
					end
				end
				if d.tearflags and d.tearflags & BitSet128(1<<57,0) == BitSet128(1<<57,0) and not d.linked_zero then
					local d2 = player:GetData()
					if d2.last_zero_knife and d2.last_zero_knife:Exists() then
						d2.last_zero_knife:GetData().last_zero_target = ent
					end
					d2.last_zero_knife = ent
					d.linked_zero = true
				end
				if d.params and d.params.list and d.params.list.godhead and d.params.list.godhead > 0 then
					if d.god_head_gospel_ring == nil then
						d.god_head_gospel_ring = true
						local q = Isaac.Spawn(7,5,3,ent.Position,Vector(0,0),player):ToLaser()
						q.PositionOffset = ent.PositionOffset
						q.Parent = ent
						q.Radius = 70
						local d2 = q:GetData()
						q.CollisionDamage = ent.CollisionDamage/3 * d.params.list.godhead
						d2.is_gospel_laser = true
						d2.radius_vel = -14
						d2.radius_acc = 2.8
						local s = q:GetSprite()
						s:Load("gfx/to_be_laser_concerter.anm2",true)
						s:ReplaceSpritesheet(0,"gfx/effects/lasers/lofty_brim3.png")
						s:LoadGraphics()
						s:Play("LargeRedLaser",true)
						s.Color = Color(1,1,0,0.2)
						s.Scale = Vector(1,1)
					end
				end
			end
		end
		
		if s:IsPlaying("ChargedDown") or s:IsPlaying("NoChargedDown") then
			if d.should_renew_charge then 
				d.should_renew_charge = nil 
				s:Play("ChargedDown",true)
			end
			if d.should_clear_charge then 
				d.should_clear_charge = nil 
				s:Play("NoChargedDown",true)
			end
			s.Rotation = 0
			if ent.Parent then
				ent.Parent.Velocity = ent.Parent.Velocity * 0.1
			end
			if d.tearflags and d.tearflags & BitSet128(1<<57,0) == BitSet128(1<<57,0) then
				if ent.Parent and ent.Parent:GetData().removecd and (d.zero_stack or 0) > 0 then ent.Parent:GetData().removecd = math.max(5,ent.Parent:GetData().removecd) end
				if d.zero_stack > 0 and ent.FrameCount % 8 == 1 then
					if d.last_zero_target then
						if d.last_zero_target:Exists() then
							d.zero_stack = d.zero_stack - 1
							local q = Isaac.Spawn(7,10,4,ent.Position,Vector(0,0),player):ToLaser()
							q.AngleDegrees = (d.last_zero_target.Position - ent.Position):GetAngleDegrees()
							q.TearFlags = BitSet128(0,0)
							q.PositionOffset = Vector(0,0)
							q:SetTimeout(2)
							q.Parent = ent
							q.CollisionDamage = damage * 0.7
							q:SetOneHit(true)
							q:SetMaxDistance((d.last_zero_target.Position - ent.Position):Length())
						else
							d.zero_stack = 0
						end
					end
				end
			end
		end
		
		if s:IsPlaying("StabDown") or s:IsPlaying("IdleUp") or s:IsPlaying("ChargedDown") or s:IsPlaying("NoChargedDown") or s:IsPlaying("ChargedUp") or s:IsPlaying("NoChargedUp") or s:IsPlaying("ChargedFall") or s:IsPlaying("NoChargedFall") then
			if d.tearflags then
				if d.tearflags & BitSet128(1<<55,0) == BitSet128(1<<55,0) then
					if d.Qing_Laser_counter == nil then d.Qing_Laser_counter = 0 end
					if d.Qing_Laser_random_counter == nil then d.Qing_Laser_random_counter = math.random(7) + 7 end
					d.Qing_Laser_counter = d.Qing_Laser_counter + 1
					if d.Qing_Laser_counter >= d.Qing_Laser_random_counter then
						d.Qing_Laser_random_counter = math.random(7) + 7
						d.Qing_Laser_counter = 0
						local range = 50
						if d.params and d.params.list and d.params.list.onlaser then range = range + d.params.list.onlaser * 30 end
						local n_entity = Isaac.FindInRadius(ent.Position,range,1<<3)
						local n_enemy = auxi.getenemies(n_entity)
						local ignore_it = nil
						if ent.Parent and ent.Parent:GetData().follower then ignore_it = ent.Parent:GetData().follower end
						for u,v in pairs(n_enemy) do
							if ignore_it and auxi.check_for_the_same(v,ignore_it) then
							else
								local q = Isaac.Spawn(7,10,4,ent.Position,Vector(0,0),player):ToLaser()
								q.AngleDegrees = (v.Position - ent.Position):GetAngleDegrees()
								q.TearFlags = BitSet128(0,0)
								q.PositionOffset = Vector(0,0)
								q:SetTimeout(2)
								q.Parent = ent
								q.CollisionDamage = damage * 0.2
								q:SetOneHit(true)
								q:SetMaxDistance((v.Position - ent.Position):Length())
							end
						end
					end
				end
			end
		end
		
		if s:IsPlaying("ChargedUp") or s:IsPlaying("NoChargedUp") then
			if d.should_renew_charge then 
				d.should_renew_charge = nil 
				s:Play("ChargedUp",true)
			end
			if d.should_clear_charge then 
				d.should_clear_charge = nil 
				s:Play("NoChargedUp",true)
			end
		end
		
		if s:IsFinished("ChargedFall") then
			s:Play("ChargedDown",true)
		end
		
		if s:IsFinished("NoChargedFall") then
			s:Play("NoChargedDown",true)
		end
		
		if s:IsFinished("AttackUp") and d.params and d.params.continueafter and d.params.continueafter == true then
			s:Play("AttackUp",true)
		end
		if s:IsFinished("AttackUp2") and d.params and d.params.continueafter and d.params.continueafter == true then
			s:Play("AttackUp2",true)
		end
		if s:IsFinished("SpinUp") and d.params and d.params.continueafter and d.params.continueafter == true then
			s:Play("SpinUp",true)
		end
		if s:IsFinished("SpinUp2") and d.params and d.params.continueafter and d.params.continueafter == true then
			s:Play("SpinUp2",true)
		end
	
		if s:IsPlaying("IdleUp") or s:IsFinished("IdleUp") or s:IsPlaying("IdleUp2") or s:IsFinished("IdleUp2") then		--特效们
			if d.tearflags and d.tearflags & BitSet128(1<<16,0) == BitSet128(1<<16,0) and ent.Parent then		--原版星球
				local leg = ent.Parent.Velocity:Length()
				ent.Parent.Velocity = (auxi.Get_rotate(ent.Parent.Velocity):Normalized() * 0.2 + ent.Parent.Velocity:Normalized()):Normalized() * leg
				ent.RotationOffset = ent.Parent.Velocity:GetAngleDegrees()
			end
			if d.tearflags and d.tearflags & BitSet128(0,1<<(69-64)) == BitSet128(0,1<<(69-64)) and ent.Parent then		--星球2
				if (ent.Parent.Position - player.Position):Length() > 100 then
					local leg = ent.Parent.Velocity:Length()
					ent.Parent.Velocity = auxi.Get_rotate(ent.Parent.Position - player.Position):Normalized() * leg
				end
			end
			if d.tearflags and d.tearflags & BitSet128(1<<30,0) == BitSet128(1<<30,0) and ent.Parent then		--方蛇
				if d.Addition_Pulse_flag == nil then
					d.Addition_Pulse_flag = math.random(2) * 2 - 1
					d.Addition_Pulse_cnt = 5
					d.OriginalVelocity = ent.Parent.Velocity
				end
				if d.Addition_Pulse_flag == 0 or d.Addition_Pulse_flag == 1 and d.Addition_Pulse_cnt < 0 then
					ent.Parent.Velocity = auxi.Get_rotate(ent.Parent.Velocity)
					d.Addition_Pulse_flag = d.Addition_Pulse_flag + 1
					d.Addition_Pulse_cnt = 5
				elseif d.Addition_Pulse_flag == 2 or d.Addition_Pulse_flag == 3 and d.Addition_Pulse_cnt < 0 then
					ent.Parent.Velocity = - auxi.Get_rotate(ent.Parent.Velocity)
					d.Addition_Pulse_flag = d.Addition_Pulse_flag + 1
					d.Addition_Pulse_cnt = 5
				end
				if d.Addition_Pulse_flag > 3 then
					d.Addition_Pulse_flag = 0
				end
				d.Addition_Pulse_cnt = d.Addition_Pulse_cnt - 1
			end
			if d.tearflags and d.tearflags & BitSet128(1<<26,0) == BitSet128(1<<26,0) and ent.Parent then		--环蛇
				if d.AdditionVelocity == nil then
					d.AdditionVelocity = 0
					d.OriginalVelocity = ent.Parent.Velocity
				end
				local leg = ent.Parent.Velocity:Length()
				ent.Parent.Velocity = (d.OriginalVelocity:Normalized() + auxi.MakeVector(d.AdditionVelocity) * 2):Normalized() * leg
				d.AdditionVelocity = d.AdditionVelocity + 20
			end
			if d.tearflags and d.tearflags & BitSet128(1<<46,0) == BitSet128(1<<46,0) and ent.Parent then		--黑蛇
				if d.AdditionVelocity == nil then
					d.AdditionVelocity = 0
					d.OriginalVelocity = ent.Parent.Velocity
				end
				local leg = ent.Parent.Velocity:Length()
				ent.Parent.Velocity = (d.OriginalVelocity:Normalized() + auxi.MakeVector(d.AdditionVelocity) * 2):Normalized() * leg
				d.AdditionVelocity = d.AdditionVelocity + 10
			end
			if d.tearflags and d.tearflags & BitSet128(1<<10,0) == BitSet128(1<<10,0) and ent.Parent then		--弯虫（共用了也没关系对吧？）
				if d.AdditionVelocity == nil then
					d.AdditionVelocity = 0
					d.OriginalVelocity = ent.Parent.Velocity
				end
				local leg = ent.Parent.Velocity:Length()
				ent.Parent.Velocity = (d.OriginalVelocity:Normalized() + auxi.MakeVector(d.AdditionVelocity) * 0.6):Normalized() * leg
				d.AdditionVelocity = d.AdditionVelocity + 20
			end
			if d.tearflags and d.tearflags & BitSet128(1<<17,0) == BitSet128(1<<17,0) and ent.Parent then		--反重力
				if ent.Parent:GetData().Params == nil then
					ent.Parent:GetData().Params = {}
				end
				if ent.Parent:GetData().Params.Accerate == nil then
					ent.Parent:GetData().Params.Accerate = 0
				end
				if d.Antig_velo == nil and ent.FrameCount > 1 then
					d.Antig_velo = ent.Parent.Velocity
					d.Antig_acce = ent.Parent:GetData().Params.Accerate
					d.Antig_flag = false
				end
				if auxi.ggdir(player,false):Length() > 0.05 and d.Antig_flag ~= nil and d.Antig_flag == false and ent.FrameCount > 1 then
					ent.Parent.Velocity = ent.Parent.Velocity/100000
					ent.Parent:GetData().Params.Accerate = 0	
				elseif d.Antig_flag ~= nil and d.Antig_flag == false then
					ent.Parent.Velocity = d.Antig_velo
					ent.Parent:GetData().Params.Accerate = d.Antig_acce
					d.Antig_flag = true
				end
			end
			if d.tearflags and d.tearflags & BitSet128(1<<8,0) == BitSet128(1<<8,0) and ent.Parent then		--镜子
				if d.Mirror_counter == nil then
					d.Mirror_counter = 3
					d.Mirror_Velocity = ent.Parent.Velocity
				end
				if ent.Parent:GetData().Params == nil then
					ent.Parent:GetData().Params = {}
				end
				if ent.Parent:GetData().Params.Accerate == nil then
					ent.Parent:GetData().Params.Accerate = 0
				end
				if d.Mirror_counter == 0 then
					ent.Parent:GetData().Params.Accerate =  - ent.Parent:GetData().Params.Accerate * 3
				end
				if ent.Parent.Velocity:Length() < 0.01 then
					ent.Parent:AddVelocity(-d.Mirror_Velocity:Normalized() * 2)
					ent.Parent:GetData().Params.Accerate =  - ent.Parent:GetData().Params.Accerate / 3
					ent.Parent:GetData().Accerate_flag = true
				end
				d.Mirror_counter = d.Mirror_counter - 1
			end
			if d.tearflags and d.tearflags & BitSet128(1<<38,0) == BitSet128(1<<38,0) and ent.Parent and ent:GetData().Continum_flag == nil then		--连续集：似乎还有小bug。
				local btrp = room:GetBottomRightPos()
				if ent.Parent.Position.X < 0 or ent.Parent.Position.X > btrp.X - 0 then
					if ent.Parent.Position.Y < 50 or ent.Parent.Position.Y > btrp.Y - 50 then
						ent.Parent.Position = Vector(btrp.X - ent.Parent.Position.X,btrp.Y - ent.Parent.Position.Y)
					else
						ent.Parent.Position = Vector(btrp.X - ent.Parent.Position.X,ent.Parent.Position.Y)
					end
					ent:GetData().Continum_flag = true
				elseif ent.Parent.Position.Y < 0 or ent.Parent.Position.Y > btrp.Y - 0 then
					if ent.Parent.Position.X < 50 or ent.Parent.Position.X > btrp.X - 50 then
						ent.Parent.Position = Vector(btrp.X - ent.Parent.Position.X,btrp.Y - ent.Parent.Position.Y)
					else
						ent.Parent.Position = Vector(ent.Parent.Position.X,btrp.Y - ent.Parent.Position.Y)
					end
					ent:GetData().Continum_flag = true
				end
			end
			if d.tearflags and d.tearflags & BitSet128(0,(1<<(71-64))) == BitSet128(0,(1<<(71-64))) and ent.Parent and ent.FrameCount > 7 then		--脑虫
				local d2 = ent.Parent:GetData()
				if d2.Params and d2.Params.Homing == nil then
					d.brain_worm_effect = true
					d2.Params.Homing = true
					d2.Params.HomingDistance = 200
				end
				if d.brain_worm_effect and d.brain_worm_effect == true and d2.Params and d2.Params.Homing_target and d2.Params.Homing_target:Exists() == true then
					d2.Params.Homing = false
					d.brain_worm_effect = false
					local dir = d2.Params.Homing_target.Position - ent.Position
					ent.Parent.Velocity = dir:Normalized() * ent.Parent.Velocity:Length()/2
					ent.RotationOffset = ent.Parent.Velocity:GetAngleDegrees()
					d2.Params.Accerate = 1
				end
			end
			if d.tearflags and d.tearflags & BitSet128(0,1<<(68-64)) == BitSet128(0,(1<<68-64)) and ent.Parent then		--魔眼
				local d2 = ent.Parent:GetData()
				if d2.Params == nil then
					d2.Params = {}
				end
				d2.Params.FollowInput = true
				d.params.shouldrotate = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = Game():GetPlayer(0)
	if d.player then
		player = d.player
	end
	if ent.Variant == enums.Entities.StabberKnife then
		if d.params then
			if d.params.repel then
				local should_reflect_repel = false
				if col.Type == 4 then
					if (col.Velocity + d.params.repel):Length() < 20 then
						col:AddVelocity(d.params.repel)
					else
						col.Velocity = (col.Velocity + d.params.repel):Normalized() * 20
					end
					should_reflect_repel = true
				else
					if auxi.isenemies(col) then
						if (col.Velocity):Length() < 20 then
							col:AddVelocity(d.params.repel * auxi.get_repel_params(col))
						else
							col.Velocity = (col.Velocity + d.params.repel * auxi.get_repel_params(col)):Normalized() * 20
						end
						should_reflect_repel = true
					end
				end
				if should_reflect_repel then
					local d2 = player:GetData()
					if d2.repel_counter == nil or d2.repel_counter < 1 then d2.repel_counter = 1 end		--希望这个写法会让击退变弱。
					local repel_cnt = math.exp(-(d2.repel_counter - 1) * 0.4)
					if repel_cnt > 0.01 then
						if player.Velocity:Length() > 5 then
							player.Velocity = (player.Velocity - d.params.repel/10 * repel_cnt):Normalized() * 10
						else
							player:AddVelocity( -d.params.repel/10 * repel_cnt)
						end
					end
					d2.repel_counter = d2.repel_counter + 1
				end
			end
			if d.params.brimstone and (d.params.brimstone == true or d.params.brimstone > 0) and auxi.isenemies(col) == true then
				if ent.Parent then
					ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 5
				end
			end
			if d.params.knife and (d.params.knife == true or d.params.knife > 0) and auxi.isenemies(col) == true then
				if ent.Parent then
					if d.params.brimstone and d.params.brimstone == true then
						ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 8
					else
						ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 3
					end
				end
			end
			if d.params.epic and (d.params.epic == true or d.params.epic > 0) and auxi.isenemies(col) == true then
				if ent.Parent then
					if d.touch ~= nil then
						ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
						ent.CollisionDamage = 0
					else
						ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 3
						ent.Parent:GetData().Params.Accerate = -1
						ent.Parent:GetData().Params.Homing = false
						local tearflags = d.params.tearflags
						if tearflags == nil then
							tearflags = player.TearFlag
						end
						tearflags = tearflags | player:GetBombFlags()
						local q1 = auxi.launch_Missile(ent.Position,ent.Velocity,ent.CollisionDamage/2,nil,{color = d.params.color,Cooldown = 25,Spawner = ent,Player = player,tearflags = tearflags,knife = player:GetCollectibleNum(114),brimstone = player:GetCollectibleNum(118), Tech = player:GetCollectibleNum(68),TechX = player:GetCollectibleNum(395),MultipleRockets = d.params.multishot, NumRockets = d.params.multishot})
						q1.Visible = false
						q1:GetSprite().Scale = ent:GetSprite().Scale
						q1:GetData().follower = ent
						d.touch = true
						ent.Parent:GetData().Params.removeanimate = true
						ent.Parent:GetData().follower = col
						ent.Parent:GetData().Params.FollowInput = nil
						if s:IsPlaying("IdleUp") or s:IsFinished("IdleUp") then
							s:Play("ChargedUp",true)
						elseif s:IsPlaying("IdleUp2") or s:IsFinished("IdleUp2") then
							s:Play("ChargedUp2",true)
						end
					end
				end
			end
			if d.params.thor and d.params.thor == true and auxi.isenemies(col) == true then
				if d.has_thor == nil then 
				d.has_thor = true 
					local d2 = player:GetData()
					if d2.thor_target and d2.thor_target:Exists() then 
						local e3 = d2.thor_target.Child
						if e3 then
							e3:GetData().should_renew_charge = nil
							e3:GetData().should_clear_charge = true
							local s3 = e3:GetSprite()
							local name = s3:GetAnimation()
							if name == "ChargedUp" or name == "ChargedDown" then
								s3:Play("No"..name,true)
							end
						end
						if d.params.list and d.params.list.link_knife then d.link_thor = d2.thor_target end
					end
					d2.thor_target = ent.Parent
					
					if d.tearflags and d.tearflags & BitSet128(1<<57,0) == BitSet128(1<<57,0) and not d.linked_zero then
						local d2 = player:GetData()
						if d2.last_zero_knife and d2.last_zero_knife:Exists() then
							d2.last_zero_knife:GetData().last_zero_target = ent
						end
						d2.last_zero_knife = ent
						d.linked_zero = true
					end
				end
				if ent.Parent then
					if d.touch ~= nil then
						ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
						ent.CollisionDamage = 0
					else
						ent.Parent.Velocity = ent.Parent.Velocity:Normalized() * 3
						ent.Parent:GetData().Params.Accerate = -1
						d.touch = true
						ent.Parent:GetData().Params.removeanimate = true
						ent.Parent:GetData().follower = col
						ent.Parent:GetData().Params.FollowInput = nil
						--ent.Parent:GetData().check_distance_and_get_close = true
						--ent.Parent:GetData().check_distance_distance = 25
						--ent.Parent:GetData().check_distance_delta_distance = ent.Velocity:Length()
						if s:IsPlaying("IdleUp") or s:IsFinished("IdleUp") then
							s:Play("ChargedUp",true)
						elseif s:IsPlaying("IdleUp2") or s:IsFinished("IdleUp2") then
							s:Play("ChargedUp2",true)
						end
					end
				end
			end
			if d.params.list and d.params.list.damo and d.params.list.damo > 0 and auxi.isenemies(col) == true then		--达摩
				if ent.Parent and col:GetData().Damo_effect == nil then
					local damo = d.params.list.damo
					local q1 = auxi.fire_nil(col.Position,col.Velocity,{cooldown = 60000})
					local d2 = q1:GetData()
					d2.follower = col
					d2.Is_Qing_Damo = true
					col:GetData().Damo_effect = true
				end
			end
			if d.params.follow_hae then
				if d.hae_counter == nil then d.hae_counter = 0 end
				if d.hae_counter > 0 then
					d.hae_counter = d.hae_counter - 1
					if d.params.list then
						if d.params.list.brimstone and d.params.list.brimstone > 0 then
							if d.has_thor and d.has_thor == true then
								local cnt = d.params.list.brimstone
								local rnd = math.random(3) + math.ceil((1 + cnt)/2)
								for i = 1,rnd do
									local q = player:FireBrimstone(auxi.MakeVector(math.random(3600)/10))
									q.PositionOffset = Vector(0,0)
									q:SetTimeout(7)
									q.Parent = ent
									q.Position = ent.Position
								end
							else
								local cnt = d.params.list.brimstone
								local tot = cnt + 1
								d.hae_brim_hold_it = {}
								for k = 1,-1,-2 do
									for i = 1,tot do
										local adder = (90 + (i - 0.5) * 60 / tot) * k
										local q = player:FireBrimstone(auxi.MakeVector(ent.Velocity:GetAngleDegrees() + adder))
										q.PositionOffset = Vector(0,0)
										q:SetTimeout(15)
										q.Parent = ent
										q.Position = ent.Position
										table.insert(d.hae_brim_hold_it,{ent = q,adder = adder,})
									end
								end
							end
						end
						if d.params.list.techX and d.params.list.techX > 0 then
							if d.has_thor and d.has_thor == true then
								local cnt = d.params.list.techX
								local rnd = math.random(2) + math.ceil((3 + cnt)/4)
								for i = 1,rnd do
									local q = player:FireTechXLaser(ent.Position + ent.Velocity,auxi.MakeVector(math.random(3600)/10) * 10 * player.ShotSpeed,20 + math.random(30))
									q.PositionOffset = Vector(0,0)
									if d.params.list.brimstone and d.params.list.brimstone > 0 then
									else
										q:SetTimeout(10)
									end
									q.Parent = ent
								end
							else
								local cnt = d.params.list.techX
								local tot = cnt + 1
								d.hae_brim_hold_it = {}
								for k = 1,-1,-2 do
									for i = 1,tot do
										local adder = (90 + (i - 0.5) * 60 / tot) * k
										local q = player:FireTechXLaser(ent.Position + ent.Velocity,auxi.MakeVector(ent.Velocity:GetAngleDegrees() + k * (180 - (i - 0.5) * 60/tot)) * 10 * player.ShotSpeed,20 + math.random(30))
										q.PositionOffset = Vector(0,0)
										if d.params.list.brimstone and d.params.list.brimstone > 0 then
										else
											q:SetTimeout(20)
										end
										q.Parent = ent
									end
								end
							end
						end
					end
				end
			end
			if d.params and d.params.list and d.params.list.godhead and d.params.list.godhead > 0 then
				if s:IsPlaying("IdleUp") or s:IsPlaying("ChargedUp") or s:IsPlaying("NoChargedUp") then
					if d.god_head_gospel_ring == nil then
						d.god_head_gospel_ring = true
						local q = Isaac.Spawn(7,5,3,ent.Position,Vector(0,0),player):ToLaser()
						q.PositionOffset = ent.PositionOffset
						q.Parent = ent
						q.Radius = 70
						local d2 = q:GetData()
						q.CollisionDamage = ent.CollisionDamage/3 * d.params.list.godhead
						d2.is_gospel_laser = true
						d2.radius_vel = -14
						d2.radius_acc = 2.8
						local s = q:GetSprite()
						s:Load("gfx/to_be_laser_concerter.anm2",true)
						s:ReplaceSpritesheet(0,"gfx/effects/lasers/lofty_brim3.png")
						s:LoadGraphics()
						s:Play("LargeRedLaser",true)
						s.Color = Color(1,1,0,0.2)
						s.Scale = Vector(1,1)
					end
				end
			end
		end
		if d.tearflags and auxi.isenemies(col) then		--彼列之眼：第一次攻击后，追加一发飞刀。
			if d.tearflags & BitSet128(1<<52,0) == BitSet128(1<<52,0) and d.params and d.params.list and d.params.list.not_allow_multi_belial == nil then
				d.params = d.params or {}
				d.params.color = d.params.color or Color(1,1,1,1)
				d.params.list = d.params.list or {}
				d.params.list.not_allow_multi_belial = 1
				local q = auxi.fire_dowhatknife(nil,ent.Position,ent.Velocity:Normalized() * 15,ent.CollisionDamage/2,"IdleUp","IdleUp2",{player = player,cooldown = 60,tearflags = (d.tearflags & (~BitSet128(1<<52,0)))|BitSet128(1<<2,0),Accerate = 1,color = auxi.AddColor(d.params.color,Color(1,0,0,1,1,0,0),0.5,1),tech = d.params.tech,list = d.params.list,})
			end
		end
		if d.tearflags and d.tearflags & BitSet128(1<<6,0) == BitSet128(1<<6,0) then		--分裂
			local list = auxi.get_qing_list(player)
			if d.divi_list then
				for u,v in pairs(d.divi_list) do
					list.ignore_divi = 1
					local q1 = auxi.fire_dowhatknife(nil,ent.Position,auxi.MakeVector(v.dir + ent.Velocity:GetAngleDegrees()) * 20 * player.ShotSpeed,(v.dmg or 0.5) * ent.CollisionDamage,"IdleUp","IdleUp2",{source = nil,cooldown = 10,player = player,tearflags = player.TearFlags,color = player.TearColor,Accerate = 3,size = 2,size1 = Vector(1,3),size2 = 13,size_scale = Vector(0.5,0.5),list = list,tech = list.tech,})
				end
				d.divi_list = nil
			end
		end
		item.dealt_extra_effect_to_col(ent,col,"Stab")
		if d.fire_sound_effect and d.fire_sound_effect == true then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_FIREDEATH_HISS,1.0,auxi.random_1() * 0.1 + 0.95,false,0,2)
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,
Function = function(_,ent, amt, flag, source, cooldown)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.Damo_effect == true and amt > ent.HitPoints then
		ent:TakeDamage(ent.HitPoints - 1,0,EntityRef(player),0)
		d.should_be_kill_by_damo = true
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if d.Dual_effect and d.Dual_cnt then
			if d.Dual_cnt >=0 and d.Dual_cnt <= 2 then
				d.Dual_effect:Render(Isaac.WorldToScreen(ent.Position + Vector(0,-5)) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
			end
			if Game():IsPaused() == false then
				if d.Dual_cnt == 2 then
					d.Dual_effect.Rotation = d.Dual_effect.Rotation * 0.6
				else
					d.Dual_effect.Rotation = d.Dual_effect.Rotation + 360/60
				end
				d.Dual_effect:Update()
				if d.Dual_effect:IsEventTriggered("Attack") then
					local col = Color(1,1,1,1)
					d.Dual_col = math.random(2)
					if d.Dual_col == 2 then col = Color(1,1,1,1,1,1,1) else col = Color(-1,-1,-1,1,-1,-1,-1) end
					local player = d.Dual_player
					if player == nil then player = Game():GetPlayer(0) end
					Game():BombExplosionEffects(ent.Position,player.Damage * 0.4,0,col,player,0.6,false,false)
				end
				if d.Dual_effect:IsEventTriggered("Attack2") then
					local col = Color(1,1,1,1)
					if d.Dual_col == 1 then col = Color(1,1,1,1,1,1,1) else col = Color(-1,-1,-1,1,-1,-1,-1) end
					local player = d.Dual_player
					if player == nil then player = Game():GetPlayer(0) end
					local rnd = math.random(6) + 9
					for i = 1,rnd do
						Game():BombExplosionEffects(ent.Position + auxi.MakeVector(360/rnd * i) * 30,player.Damage * 0.1,0,col,player,0.2,false,false)
					end
				end
				if d.Dual_effect:IsEventTriggered("Attack3") then
					local player = d.Dual_player
					if player == nil then player = Game():GetPlayer(0) end
					local rnd = math.random(5) * 2 + 15
					for i = 1,rnd do
						local col = Color(1,1,1,1,1,1,1)
						if i % 2 == 1 then col = Color(1,1,1,1,1,1,1) else col = Color(-1,-1,-1,1,-1,-1,-1) end
						Game():BombExplosionEffects(ent.Position + auxi.MakeVector(360/rnd * i) * 60,player.Damage * 0.05,0,col,player,0.1,false,false)
					end
				end
				if d.Dual_effect:IsEventTriggered("Remove") then
					d.Dual_effect = nil
					d.Dual_cnt = nil
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = EntityType.ENTITY_PLAYER,
Function = function(_,ent, amt, flag, source, cooldown)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	local s = ent:GetSprite()
	
	if ent.Type == 1 and ent:ToPlayer():GetName() == "W.Qing" then
		local player = ent:ToPlayer()
		if player:HasCollectible(316) and player:HasCollectible(260) == false and d.cursed_delay and d.cursed_delay > 0 then	--受伤传送
			player:AnimateTeleport(true)
			player:UseActiveItem(CollectibleType.COLLECTIBLE_TELEPORT,false,true,false,false)
			d.cursed_delay = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = ent:GetData()
	if d.followParent and d.followParent:Exists() and not d.followParent:IsDead() then
		local pos = d.followParent.Position
		if d.followParent_offset_position then
			pos = pos + d.followParent_offset_position
		end
		ent.Position = pos
	end
	if d.followRotation and d.followRotation:Exists() then
		local ang = 180
		if d.followRotation_aidang then
			ang = d.followRotation_aidang + ang
		end
		ent.Angle = ang + d.followRotation.Velocity:GetAngleDegrees()
	end
	if d.reset_startp and d.reset_startp == true then
		if d.reset_startp_source and d.reset_startp_source:Exists() == true then
			d.reset_startp_position = d.reset_startp_source.Position
		end
		if d.reset_startp_position == nil then
			d.reset_startp_position = room:GetCenterPos()
		end
		ent.EndPoint = d.reset_startp_position
		ent:SetMaxDistance((ent.Position - d.reset_startp_position):Length())
	end
end,
})

--[[
	还要做的内容：
	双穿？
	牙和苹果
	妈妈的假发？
	毛霉菌、粘弹、鼻涕
	妈刀+科技X、英灵剑+科技X。
	弹弹弹、跳石	
	三圣颂
	黑针
	收束光线
	邪王真眼
	拳头
	镐子和魂瓶
	眼球、噬泪症
	悬浮
	
	血泪的配合：
	无特殊：
	妈刀：覆盖，飞刀变大
	史诗：覆盖，飞刀变大
	硫磺火：覆盖硫磺火，在被飞刀命中的敌人身上飞溅硫磺火。
	悬浮：覆盖
	肺：
	科技X：覆盖科技X，在被飞刀命中的敌人身上飞溅科技X。
	博士：覆盖博士，改变飞刀的攻击方式，碰撞后爆炸。
	科技：覆盖科技，在被飞刀命中的敌人身上飞溅镭射。
	英灵剑：覆盖，飞刀变大。
	剖：配合已完成
	
	可以增加的特效：
	达摩剑：被飞刀标记的敌人头上将生成一把达摩剑。生命低于10%时将掉落并斩杀。
	阴阳：伤害*85%。被阴、阳剑命中的敌人将会被标记。受到另一剑的伤害时，该伤害会爆发出来。
	柠檬：
	
	狗身、寄生虫、骨裂、死眼、.5、血块、小圣心、科技2、多重射击、洛基角、后眼、理财眼、钱币已完成。

	考虑小青的攻击方式与眼泪特效的配合。
	0、1：自带双穿，没效果。
	2.弯勺：已完成。
	3.减速：已失去效果。已重新完成。
	4.中毒：已失去效果。已重新完成。
	5.石化：已失去效果。已重新完成。
	6.骨裂：没做。
	7.煤块：已完成。
	8.镜像：已完成。
	9.大眼：已完成。
	10.弯虫：已完成。
	11.中猫套：已完成。
	12.吐根：已完成。
	13.魅惑：已完成。
	14.眩晕：已完成。
	15.掉落红心？
	16.小星球：已完成。
	17.反重力：已完成。
	18.狗身：没做。
	19.橡胶：没做。
	20.恐惧：已失去效果。已重新完成。
	21.突眼：已完成。
	22.燃烧：已失去效果。已重新完成。
	23.黑磁铁：
	24.击退提升：没做。
	25.变大变小虫：无效。
	26.旋涡：已完成。
	27.扁平：无效。
	28.伤心炸弹
	29.便便炸弹
	30.方波：已完成。
	31.神性：没做。
	32.吉仕：已完成。
	33.神秘液体：已完成。
	34.泪盾：已完成。
	35.炸弹
	36.炸弹
	37.炸弹
	38.连续集：已完成。
	39.圣光：已失去效果。已重新完成。
	40.掉钱
	41.掉黑心
	42.牵引光束：无效。
	43.缩小：已失去效果。已重新完成。
	44.贪婪头：已完成。
	45.十字雷
	46.黑蛇：已完成
	47.青光眼(永久眩晕)：已完成。
	48.鼻涕：无效。
	49.中猫套2：已完成
	50.硫酸：没做。
	51.骨裂：没做。
	52.彼列：已完成。
	53.点金：已完成。
	54.黑针：没做。
	55.天梯：已完成。
	56.黑角：已完成。
	57.科技0：已完成。
	58.眼球：没做。
	59.噬泪：没做。
	60.三圣颂：没做。
	61.跳石：没做
	62.血泪：没做
	63.鲍勃的膀胱？

	64.拳头：没做
	65.冰：已失去效果。已重新完成。
	66.磁石：已失去效果。已重新完成。
	67.烂番茄：已失去效果。已重新完成。
	68.神秘之眼：已完成。
	69.真·环绕：没做
	70.石头眼泪：没做
	71.脑虫：已完成。
	72.血炸弹
	73.大肠杆菌
	74.倒位倒吊人
	75.硫磺火炸弹
	76.黑洞眼：已完成。
	77.毛霉菌：没做
	78.鬼炸弹
	79.掉落塔罗牌
	80.掉落符文
	81.传送
	
	114.婴儿
	115.roll石头？
	116.妈妈践踏？
	117.
	118.D10
	119.超大炸弹
	120.更多内脏物
	121.镭射自动变色
	122.远程控制（炸弹爆炸）
	123.血田
	124.黑暗艺术？
	125.金炸弹
	126.快速炸弹
	127.鲁科
-]]

return item