local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local Fusion_Destiny = require("Qing_Extra_scripts.challanges.Fusion_Destiny")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local qing_s_knife_holder = require("Qing_Extra_scripts.callbacks.qing_s_knife_holder")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")	
local consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Players.Tecro,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,collid, itemRng, player, useFlags, activeSlot, customVarData)
	if collid == 283 or collid == 284 or collid == 703 then
		if player:GetName() == "Tecro" then
			player:AddNullCostume(enums.Costumes.Tecrohair)
			player:AddNullCostume(enums.Costumes.Tecroface)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	if player:GetName() == "Tecro" then
		player:AddNullCostume(enums.Costumes.Tecrohair)
		player:AddNullCostume(enums.Costumes.Tecroface)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:GetName() == "Tecro" then
		local d = player:GetData()
		if player:IsCoopGhost() then 
			d.coopghost = true
		elseif d.coopghost then
			d.coopghost = nil
			player:AddNullCostume(enums.Costumes.Tecrohair)
			player:AddNullCostume(enums.Costumes.Tecroface)
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:GetName() == "Tecro" then
		if cacheFlag == CacheFlag.CACHE_SPEED then
			player.MoveSpeed = player.MoveSpeed + 0.2
		end
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = (player.Damage + 1.5)*(8/10)
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			player.Luck = player.Luck + 0.8
		end
		if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
			player.ShotSpeed = player.ShotSpeed
		end
	end
end,
})

--l local player = Game():GetPlayer(0) local q = Isaac.Spawn(7,1,4,Vector(200,100),Vector(0,5),player):ToLaser() local s = q:GetSprite() s:Load("gfx/spear_laser.anm2",true) s:Play("LargeRedLaser",true) q.Angle = 270 q.TearFlags = BitSet128(1<<2,0) q:SetMaxDistance(100)

return item