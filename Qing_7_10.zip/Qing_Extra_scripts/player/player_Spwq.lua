local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local Fusion_Destiny = require("Qing_Extra_scripts.challanges.Fusion_Destiny")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")	
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Players.Spwq,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:GetName() == "SP.W.Qing" then
		if cacheFlag == CacheFlag.CACHE_SPEED then
			player.MoveSpeed = player.MoveSpeed - 0.15
		end
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage - 0.5
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			player.Luck = player.Luck * 0.66
		end
		if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
			player.ShotSpeed = player.ShotSpeed + 0.15
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange - 20
		end
	end
end,
})

--目前尚未完全支持的部分：巧克力奶、诅咒之眼、大眼、煤块突眼（大部分关于史诗）、血凝块、鲁科、英灵剑、骨剑（做了一半）、BFFS！（还在考虑要不要做）、剖腹产、长子权：提供飞行，攻击、防御、辅助模块各增加1个。
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.ID_EFFECT_MeusNIL,
Function = function(_,ent)		--介质
	local d = ent:GetData()
	if ent.Variant == enums.Entities.ID_EFFECT_MeusNIL then
		if d.Params == nil then
			d.Params = {}
		end
		if d.removecd == nil then
			d.removecd = 60
		end
		if d.removecd > 0 then
			d.removecd = d.removecd - 1
		end
		local player = d.Params.player
		if player == nil then
			player = Game():GetPlayer(0)
		end
		if (player.Position - ent.Position):Length() > 1000 then 
			d.removecd = 0
		end
		if d.removecd <= 0 then
			if d.Params.removeanimate then
				if ent.Child then
					local q1 = Isaac.Spawn(1000,15,0,ent.Child.Position,Vector(0,0),nil):ToEffect()
					q1:GetSprite().Scale = ent.Child:GetSprite().Scale:Length() * Vector(1,1)
				end
			end
			ent:Remove()
		end
		if d.follower then		--当有跟随者时，自动粘附敌人。否则追加加速度。
			if d.follower:Exists() then
				if d.nw_follow_pos == nil then
					d.nw_follow_pos = ent.Position - d.follower.Position
				end
				if d.ignore_follower_distance then
					d.nw_follow_pos = Vector(0,0)
				end
				--if d.check_distance_and_get_close and d.check_distance_distance and d.check_distance_delta_distance then 
				--	if d.check_distance_distance < d.nw_follow_pos then
				--		d.nw_follow_pos = d.nw_follow_pos:Normalized() * (d.nw_follow_pos:Length() - d.check_distance_delta_distance)
				--	end
				--end
				ent.Position = d.follower.Position + d.nw_follow_pos
				ent.Velocity = d.follower.Velocity
			else
				if ent.Velocity:Length() > 0.05 then		--强制停止。
					if (d.continue_after_follower and d.continue_after_follower == true) then
						if d.continue_and_resetvel ~= nil then
							ent.Velocity = d.continue_and_resetvel
						end
						d.follower = nil
					else
						d.Params.Accerate = -1
						if d.Accerate_flag == nil or d.Accerate_flag == false then
							d.Accerate_flag = true
						end
						d.follower = nil
					end
				end
			end
		else
			if d.Params.FollowInput and d.Params.FollowInput == true then
				local gdir = auxi.ggdir(player,true,ModConfigSettings.allow_mouse_control)
				if gdir:Length() < 0.05 and ent.Velocity:Length() > 0.0005 then
					ent.Velocity = ent.Velocity * 0.85
				else
					ent.Velocity = (gdir + ent.Velocity:Normalized()):Normalized() * math.min(20,(ent.Velocity:Length() * 1.5))
				end
			elseif d.Params.Accerate then
				if d.Params.Way_Accerate then
					ent.Velocity = ent.Velocity * (d.Params.Way_Accerate_mul or 1) + d.Params.Way_Accerate:Normalized() * d.Params.Accerate
				else
					if d.Accerate_flag == nil then
						d.Accerate_flag = true
					end
					if d.Accerate_avoid_lock == nil then
						d.Accerate_avoid_lock = false
					end
					if d.Accerate_flag == true or d.Accerate_avoid_lock == true then
						local leg_vel = ent.Velocity:Length() + d.Params.Accerate
						if leg_vel < 0.001 and d.Accerate_avoid_lock ~= true then
							ent.Velocity = ent.Velocity / 100000
							d.Accerate_flag = false
						else
							ent:AddVelocity(ent.Velocity:Normalized() * d.Params.Accerate)
						end
					end
				end
			end
			if d.Params.Homing then
				local shouldHome = true
				if d.Homing_cnt and d.Homing_cnt > 0 then
					d.Homing_cnt = d.Homing_cnt - 1
					shouldHome = false
				end
				
				local nowpos = ent.Position
				if ent.Child then
					nowpos = ent.Child.Position
				end
				
				if d.Params.Homing_target == nil or d.Params.Homing_target:Exists() == false or d.Params.Homing_target:IsDead() == true then-- or d.Params.Homing_target:Exists() == false or (d.Params.HomingDistance and d.Params.Homing_target.Position:DistanceSquared(ent.Position) < d.Params.HomingDistance) then
					local n_entity = Isaac.GetRoomEntities()
					local n_enemy = auxi.getenemies(n_entity)
					for i = 1,#n_enemy do
						if (d.Params.Homing_target == nil or (n_enemy[i].Position - nowpos):Length() < (d.Params.Homing_target.Position - nowpos):Length()) and (d.Params.HomingDistance == nil or (n_enemy[i].Position - nowpos):Length() < d.Params.HomingDistance) then
							d.Params.Homing_target = n_enemy[i]
						end
					end
				end
				
				if d.Params.Homing_target ~= nil then
					shouldHome = true
				else
					shouldHome = false
				end

				if shouldHome and d.Params.Homing_target and d.Params.Homing_target:Exists() == true then
					if d.Params.HomingAcce == nil then
						d.Params.HomingAcce = d.Params.Accerate
						d.Params.Accerate = 0
					end
					d.Params.HomingSpeed = (d.Params.HomingSpeed or 15) + d.Params.HomingAcce * 0.4
					local direction = (d.Params.Homing_target.Position - nowpos)
					if direction:Length() < 70 then
						if direction:Length() < 30 then 
							ent.Velocity = ent.Velocity * 1.1 + d.Params.Homing_target.Velocity * 0.2
							d.nill_homing_dont_repeat = math.max(16,(d.nill_homing_dont_repeat or -1) - 1)
						else
							d.nill_homing_dont_repeat = math.min(16,(d.nill_homing_dont_repeat or -1) + 1)
							ent.Velocity = ent.Velocity * (3 + d.nill_homing_dont_repeat) / 20 + (direction:Normalized() * math.max(ent.Velocity:Length()* 1.05,d.Params.HomingSpeed * 1.3)) * (17 - d.nill_homing_dont_repeat) / 20
						end
					else
						d.nill_homing_dont_repeat = -1
						if ent.Velocity:Length() > d.Params.HomingSpeed * 0.6 then
							ent.Velocity = ent.Velocity * 0.9 + (direction:Normalized() * math.max(ent.Velocity:Length() * 1.05,d.Params.HomingSpeed)) * 0.1
						else
							ent.Velocity = ent.Velocity * 0.75 + (direction:Normalized() * math.max(ent.Velocity:Length() * 1.2,d.Params.HomingSpeed)) * 0.25
						end
					end
					--print(d.nill_homing_dont_repeat)
				end
			end
		end
		
		if ent:GetData().Is_Qing_Fetus and ent:GetData().Is_Qing_Fetus == true then		--只要有fetus标记就是婴儿。
			ent:GetData().Is_Qing_Fetus = false
			local s = ent:GetSprite()
			s:Load("gfx/1000.2338_NILL_Fetus.anm2")
			s:Play("IdleX")
		end
		if ent:GetData().Is_Qing_Fetus == false then
			local ang = ent.Velocity:GetAngleDegrees()
			if ent.Velocity:Length() < 0.05 or d.follower and d.follower:Exists() then
				if ent.Child then
					ang = (ent.Child.Position - ent.Position):GetAngleDegrees()
				end
			end
			local s = ent:GetSprite()
			if (ang > 60 and ang < 120) or (ang < -60 and ang > -120) then
				if ang < 0 then
					if s:IsPlaying("IdleX") == true or s:IsPlaying("IdleY2") == true then
						s:Play("IdleY1",true)
					end	
				else
					if s:IsPlaying("IdleX") == true or s:IsPlaying("IdleY1") == true then
						s:Play("IdleY2",true)
					end	
				end
			else
				if s:IsPlaying("IdleY") == true then
					s:Play("IdleX",true)
				end
				if ang > 90 or ang < -90 then
					s.FlipX = false
				else
					s.FlipX = true
				end
			end
		end
		
		if d.Is_Qing_Damo and d.Is_Qing_Damo == true then		--只要有达摩标记就是达摩
			local s = ent:GetSprite()
			s:Load("gfx/003.2020_damocles.anm2")
			s:Play("Idle")
			d.Is_Qing_Damo = false
		end
		if d.Is_Qing_Damo == false then
			local s = ent:GetSprite()
			if s:IsPlaying("Idle") == true or s:IsFinished("Idle") == true or s:IsPlaying("Idle2") == true or s:IsFinished("Idle2") == true or s:IsPlaying("Idle") == true or s:IsFinished("Idle2") == true then
				local rand = math.random(1000)
				if rand > 600 then
					s:Play("Idle3",true)
				elseif rand > 800 then
					s:Play("Idle2",true)
				else
					s:Play("Idle",true)
				end
			end	
			if d.follower == nil or d.follower:Exists() == false or d.follower:IsDead() or d.follower.HitPoints < d.follower.MaxHitPoints * 0.1 or d.follower.HitPoints < 3 or d.follower:GetData().should_be_kill_by_damo or d.should_kill_damo then
				if s:IsPlaying("Fall") == false and s:IsFinished("Fall") == false then
					s:Play("Fall",true)
				elseif s:IsFinished("Fall") == true then
					d.removecd = 1
				end
				if s:IsEventTriggered("Hit") or s:WasEventTriggered("Hit") or s:IsFinished("Fall") == true then
					if d.follower and d.follower:Exists() == true then
						d.follower:Kill()
					end
					d.should_kill_damo = true
				end
			end
		end
		
		if d.Is_Qing_Horn and d.Is_Qing_Horn == true then
			local s = ent:GetSprite()
			s:Load("gfx/big_horn_hand.anm2")
			s:Play("SmallHoleOpen",true)
			d.Is_Qing_Horn = false
		end
		if d.Is_Qing_Horn == false then
			local s = ent:GetSprite()
			if s:IsFinished("SmallHoleOpen") then
				if d.follower and d.follower:Exists() then
					s:Play("HandGrab",true)
				else
					d.removecd = 1
				end
			end
			if s:IsFinished("HandGrab") then
				s:Play("SmallHoleClose",true)
			end
			if s:IsFinished("SmallHoleClose") then
				d.removecd = 1
			end
			if s:IsEventTriggered("Slam") then
				if d.follower and d.follower:Exists() then
					d.follower:GetData().has_horn = nil
					d.follower:ClearEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE)
					d.follower:Kill()
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_DEATH_BURST_SMALL,1,1,false,0,2)
					Game():ShakeScreen(7)
				end
			end
		end
		
		if d.Is_Destiny_Guide and d.Is_Destiny_Guide == true then
			local s2 = ent:GetSprite()
			if Fusion_Destiny.roomsteak and Fusion_Destiny.roomsteak <= 0 then
				d.removecd = 0
			end
			if d.follower == nil or d.follower:Exists() == false then
				local n_entity = Isaac.GetRoomEntities()
				local n_enemy = auxi.getenemies(n_entity)
				local n_small_enemy = auxi.getsmallenemies(n_enemy)					
				if #n_small_enemy ~= 0 then
					local targ = auxi.getrandenemies(n_small_enemy)
					ent.Position = targ.Position + Vector(0,3)
					s2.Offset = Vector(0,-40 - ent.Size * ent.SizeMulti.Y - ent.PositionOffset.Y)
					--ent.Velocity = targ.Velocity
					s2:Play("Appear",true)
					d.follower = targ
					targ:GetData().Can_Be_Carfted_As_Cain = true
				else
					if s2:IsPlaying("Disappear") == false and s2:IsFinished("Disappear") == false then
						s2:Play("Disappear")
					end
				end
			end
			if s2:IsFinished("Appear") then
				s2:Play("Idle")
			end
		end

		if d.is_Aphasia_word and d.Aphasia_word then
			if d.RenderHeight and d.RenderHeight < 0.0001 then
				if (player.Position - ent.Position):Length() < 30 and d.should_not_collect == nil then
					local d2 = player:GetData()
					if d2.Aphasia_buffer == nil then d2.Aphasia_buffer = {} end
					table.insert(d2.Aphasia_buffer,d.Aphasia_word)
					player:AnimateHappy()
					d.is_Aphasia_word = nil
					d.removecd = 1
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_RENDER, params = enums.Entities.ID_EFFECT_MeusNIL,
Function = function(_,ent,offset)
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		local d = ent:GetData()
		if d.is_Aphasia_word and d.Aphasia_word then
			if d.word_size == nil then d.word_size = 1 end
			if d.floor == nil then d.floor = 0 end
			local player = d.Params.player
			if player == nil then
				player = Game():GetPlayer(0)
			end
			local sx = d.word_size
			local sy = d.word_size
			gui.draw_ch(Isaac.WorldToScreen(ent.Position + Vector(0,-2) * d.RenderHeight) + Vector(-sx * 5,-sy * 5),d.Aphasia_word,sx,sy,auxi.Color_2_KColor(player.TearColor),true)
			d.RenderHeight = math.max(0,d.RenderHeight + d.RenderHeight_Velocity)
			if d.RenderHeight > 0.0001 then
				d.word_size = d.word_size * 1.01
			elseif d.floor < 10 then
				d.floor = d.floor + 1
				d.word_size = d.word_size + 0.05
			else
				d.word_size = d.word_size * 0.97
			end
			if d.small_quickly then d.word_size = d.word_size * 0.75 end
			if d.word_size <= 0.3 then 
				d.should_not_collect = true
				d.small_quickly = true
				d.removecd = 7
			end
			d.RenderHeight_Velocity = d.RenderHeight_Velocity - 0.3
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.ID_EFFECT_MeusFetus,
Function = function(_,ent)	--史诗
	local d = ent:GetData()
    if ent.Variant == enums.Entities.ID_EFFECT_MeusFetus and d.BossMissile then
        local s = ent:GetSprite()
        local boss = d.Boss
        local target
        if boss then
            target = d.Boss:GetPlayerTarget()
        end
		
		if d.follower and d.follower:Exists() then
			if d.nw_follow_pos == nil then
				d.nw_follow_pos = ent.Position - d.follower.Position
			end
			ent.Position = d.follower.Position + d.nw_follow_pos
			ent.Velocity = d.follower.Velocity
		end
		
		if d.MissileParams == nil then		--缺少参数，无法运行。
			return
		end
		
        if d.MissileParams.Homing and target then
            local shouldHome = true
            if d.MissileParams.HomingWait and d.MissileParams.HomingWait > 0 then
                d.MissileParams.HomingWait = d.MissileParams.HomingWait - 1
                shouldHome = false
            end

            if d.MissileParams.HomingDistance then
                if not (target.Position:DistanceSquared(ent.Position) < d.MissileParams.HomingDistance) then
                    shouldHome = false
                end
            end

            if shouldHome then
                local direction = (target.Position - ent.Position):Normalized()
                ent:AddVelocity(direction * (d.MissileParams.HomingSpeed or 0.6))
            end
        end

        if d.MissileParams.Cooldown and d.MissileParams.Cooldown > 0 then
            d.MissileParams.Cooldown = d.MissileParams.Cooldown - 1
        elseif not d.Rocket then
            local rocket = Isaac.Spawn(EntityType.ENTITY_EFFECT, enums.Entities.ID_EFFECT_MeusRocket, 0, ent.Position, Vector(0,0), d.Boss)
            rocket.SpriteOffset = rocket.SpriteOffset + Vector(0, -300)
            d.Rocket = rocket
			rocket:GetSprite().Scale = ent:GetSprite().Scale
        end

        if d.Rocket then
            d.Rocket.Position = ent.Position
            d.Rocket.SpriteOffset = d.Rocket.SpriteOffset + Vector(0, 30)
            if d.Rocket.SpriteOffset.Y >= 0 then
                --Isaac.Explode(d.Rocket.Position, d.Boss, d.Damage * 20)
				local tearflags = d.MissileParams.tearflags
				if tearflags == nil then
					tearflags = BitSet128(0,0)
				end
				local color = d.MissileParams.color
				if color == nil then
					color = Color(1,1,1,1)
				end
				if d.MissileParams.Player == nil then
					d.MissileParams.Player = Game():GetPlayer(0)
				end
				Game():BombExplosionEffects(d.Rocket.Position,d.Damage * 20,tearflags,color,d.MissileParams.Player,ent:GetSprite().Scale:Length()/math.sqrt(2),false,true)		--耶耶耶！！！	
				if d.MissileParams.knife and d.MissileParams.knife ~= 0 then
					local para = {
						cooldown = 30,
						Accerate = 0.7,
					}
					if d.MissileParams.Player then
						para.player = d.MissileParams.Player
					end
					local rand_cnt1 = math.random(4) + 4
					local rand_cnt2 = math.random(36000)/100
					for i = 0, rand_cnt1 do
						auxi.fire_knife(ent.Position,auxi.MakeVector(360/rand_cnt1 * i + rand_cnt2) * 10,d.Damage*0.65,nil,para)
					end
				end
				if d.MissileParams.brimstone and d.MissileParams.brimstone ~= 0 then
					if d.MissileParams.Player == nil then
						d.MissileParams.Player = Game():GetPlayer(0)
					end
					local q2 = Isaac.Spawn(1000,enums.Entities.ID_EFFECT_MeusNIL,0,d.Rocket.Position,Vector(0,0),nil):ToEffect()
					q2:GetData().removecd = 60
					local rand_cnt1 = math.random(4) + 4
					local rand_cnt2 = math.random(36000)/100
					for i = 0, rand_cnt1 do
						local q1 = d.MissileParams.Player:FireBrimstone(auxi.MakeVector(360/rand_cnt1 * i + rand_cnt2))
						q1.Parent = q2
						q1.Position = q2.Position
					end
				end
				if d.MissileParams.Tech and d.MissileParams.Tech ~= 0 then
					if d.MissileParams.Player == nil then
						d.MissileParams.Player = Game():GetPlayer(0)
					end
					local q2 = Isaac.Spawn(1000,enums.Entities.ID_EFFECT_MeusNIL,0,d.Rocket.Position,Vector(0,0),nil):ToEffect()
					q2:GetData().removecd = 60
					local rand_cnt1 = math.random(4) + 4
					local rand_cnt2 = math.random(36000)/100
					for i = 0, rand_cnt1 do
						local q1 = d.MissileParams.Player:FireTechLaser(ent.Position,1,auxi.MakeVector(360/rand_cnt1 * i + rand_cnt2),false,true)
						q1.Parent = q2
					end
				end
				if d.MissileParams.TechX and d.MissileParams.TechX ~= 0 then
					if d.MissileParams.Player == nil then
						d.MissileParams.Player = Game():GetPlayer(0)
					end
					local player = d.MissileParams.Player
					local rand_cnt1 = math.random(4) + 4
					local rand_cnt2 = math.random(36000)/100
					for i = 0, rand_cnt1 do
						local q1 = player:FireTechXLaser(ent.Position,auxi.MakeVector(360/rand_cnt1 * i + rand_cnt2) * 7 * player.ShotSpeed , player.Damage/3 + 30)
					end
				end
                d.Rocket:Remove()
                d.Rocket = nil
                d.RocketsFired = d.RocketsFired + 1

                if d.MissileParams.MultipleRockets and d.MissileParams.NumRockets and d.RocketsFired < d.MissileParams.NumRockets then
                    d.MissileParams.Cooldown = d.MissileParams.Cooldown + (d.MissileParams.TimeBetweenRockets or 1)
                else
                    ent:Remove()
                end
            end
        end
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = nil,
Function = function(_,ent)		--准星
	if ent.Variant == 30 or ent.Variant == 153 or ent.Variant == enums.Entities.QingsMarks then
		local sprite = ent:GetSprite()
		local room = Game():GetRoom()
		local level = Game():GetLevel()
		local d = ent:GetData()
		local player = d.Player
		if player ~= nil then
			local d2 = player:GetData()
			if player:GetName() == "SP.W.Qing" then	
				if d2.focus_time == nil or Game():GetFrameCount() - d2.focus_time > 5 then		--每一个在5帧内成为控制目标的准星均可以成为辅助准星。
					d2.focus_target = ent
					d2.focus_time = Game():GetFrameCount()
					if d2.focus_type == nil then
						d2.focus_type = 0
					end
				end
				if ent.Variant == enums.Entities.QingsMarks then
					ent.Velocity = auxi.ggdir(player,true,ModConfigSettings.mouseSupport1,ModConfigSettings.mouseSupport2,ent.Position) * player.ShotSpeed * 15
					local ctrlidx = player.ControllerIndex
					if auxi.check_bottom_down(ModConfigSettings.Off_air_key,ctrlidx) then
						d2.focus_target = nil
						d2.focus_time = nil
						ent:Remove()
						return
					end
					if d2.focus_type == 1 then
						if d.focus_1_counter == nil then d.focus_1_counter = 0 end
						d.focus_1_counter = d.focus_1_counter + 1
						if d.focus_1_counter > 30 then
							d.focus_1_counter = 0
							d2.focus_type = 0
						end
					end
					if d2.focus_counter == nil then d2.focus_counter = 0 end
					if auxi.check_bottom_down(ModConfigSettings.On_air_key,ctrlidx) or auxi.check_bottom_down(12,ctrlidx) or (ModConfigSettings.allow_mouse_control and Input.IsMouseBtnPressed(1)) then				--按下alt时，切换攻击模式。
						if d2.focus_flag == nil or d2.focus_flag == true then 
							d2.focus_type = d2.focus_type + 1
							if d2.focus_type > 2 then			--3种模式。0：自主寻敌；1：目标优先；2：强制攻击。
								d2.focus_type = 0
							end
							if d2.focus_type == 1 then		--切换为目标优先状态时，立刻重新选择敌人。
								d.focus_1_counter = 0
								local n_entity = Isaac.GetRoomEntities()
								local n_familiars = auxi.getothers(n_entity,3,enums.Familiars.QingsAirs)
								for u,v in pairs(n_familiars) do
									v:ToFamiliar().State = 0
								end
							end
							d2.focus_flag = false
						end
						d2.focus_counter = d2.focus_counter + 1
					else
						if d2.focus_counter > 60 then
							d2.focus_target = nil
							d2.focus_time = nil
							d2.focus_counter = 0
							ent:Remove()
							return
						end
						d2.focus_counter = 0
						d2.focus_flag = true
					end
					if d2.focus_type == 0 then
						ent:SetColor(Color(1,1,1,1,0,0,0),99,50,false,false)		--红色
					elseif d2.focus_type == 1 then
						if d.focus_1_counter == nil then d.focus_1_counter = 0 end
						ent:SetColor(Color(1,1,-1 + 2 * (d.focus_1_counter/30),1,1 * (1 - d.focus_1_counter/30),1 * (1 - d.focus_1_counter/30),1 * (1 - d.focus_1_counter/30)),99,50,false,false)		--白色
					else
						ent:SetColor(Color(-1,-1,1,1,-1,-1,-1),99,50,false,false)	--黑色
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = player:GetData()
	if player:GetName() == "SP.W.Qing" then
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			if d["mov_or_dir_buff"] == nil then d["mov_or_dir_buff"] = 0 end
			if (d["mov_or_dir_buff"] > 5) then
				if d["Spwq_s_charge_bar"] == nil then 
					d["Spwq_s_charge_bar"] = Sprite()
					d["Spwq_s_charge_bar"]:Load("gfx/chargebar_Qing.anm2",true)
					d["Spwq_s_charge_bar"]:Play("Charging",true)
				end
				if d.Air_buff == nil then d.Air_buff = 0 end
				local cnt = d.Air_buff + 1
				if player:HasCollectible(619) then cnt = cnt * 0.7 - 0.2 end
				cnt = cnt * auxi.get_level_stat_of_spwq()
				if d["mov_or_dir_buff"] > 300 * cnt then
					if d["Spwq_s_charge_bar"]:IsPlaying("Charging") or d["Spwq_s_charge_bar"]:IsFinished("Charging") then
						d["Spwq_s_charge_bar"]:Play("StartCharged",true)
					elseif d["Spwq_s_charge_bar"]:IsFinished("StartCharged") then
						d["Spwq_s_charge_bar"]:Play("Charged",true)
						d["should_mov_and_dir"] = true
					end
					d["Spwq_s_charge_bar"]:Update()
				else
					d["Spwq_s_charge_bar"]:SetFrame("Charging",math.ceil(d["mov_or_dir_buff"]/(3 * cnt)))
				end
				local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"SPWQ_C_B",true)
				if type(pos) == "number" then pos = Vector(-20,-30) end
				d["Spwq_s_charge_bar"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
			else
				if d["Spwq_s_charge_bar"] == nil then
					d["Spwq_s_charge_bar"] = Sprite()
					d["Spwq_s_charge_bar"]:Load("gfx/chargebar_Qing.anm2",true)
					d["Spwq_s_charge_bar"]:SetFrame("Disappear",8)
				end
				if d["Spwq_s_charge_bar"]:IsPlaying("Disappear") == false and d["Spwq_s_charge_bar"]:IsFinished("Disappear") == false then
					d["Spwq_s_charge_bar"]:Play("Disappear",true)
				end
				if d["Spwq_s_charge_bar"]:IsPlaying("Disappear") == true then
					local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"SPWQ_C_B",true)
					if type(pos) == "number" then pos = Vector(-20,-30) end
					d["Spwq_s_charge_bar"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					d["Spwq_s_charge_bar"]:Update()
				else
					Charging_Bar_holder.remove_charge_bar(player,"SPWQ_C_B")
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)		--里万青总算法
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local d = player:GetData()
	if player:GetName() == "SP.W.Qing" then
		local is_mov_or_dir = false
		if d.focus_target then
			is_mov_or_dir = auxi.ggmov_dir_is_zero(player,true,ModConfigSettings.mouseSupport1,ModConfigSettings.mouseSupport2,d.focus_target.Position)
		else
			is_mov_or_dir = auxi.ggmov_dir_is_zero(player,true,ModConfigSettings.mouseSupport1,ModConfigSettings.mouseSupport2,player.Position)
		end
		if d.mov_or_dir_buff == nil then
			d.mov_or_dir_buff = 0
		end
		if d.add_after_pickup and d.add_after_pickup == true and player:AreControlsEnabled() == true and player:IsExtraAnimationFinished() == true and player.Visible == true then
			d.Air_buff = d.Air_buff + 1
			player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
			d.should_evaluate_on_update_once = true
			d.add_after_pickup = false
		end
		if room:IsClear() == false then
			if is_mov_or_dir then
				d.mov_or_dir_buff = d.mov_or_dir_buff + 1
			else
				d.mov_or_dir_buff = 0
			end
		else
			d.mov_or_dir_buff = 0
		end
		if d.Air_buff == nil then d.Air_buff = 0 end
		if d.should_mov_and_dir then
			d.should_mov_and_dir = nil
			d.mov_or_dir_buff = 0
			local spr = Sprite()
			spr:Load("gfx/003.2335_AirFlig.anm2",true)
			spr:Play("Rotate",true)
			player:AnimatePickup(spr)
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_POWERUP1,1,1,false,0,2)
			d.add_after_pickup = true
		end
		
		local gdir = auxi.ggdir(player,true,ModConfigSettings.mouseSupport1,ModConfigSettings.mouseSupport2,player.Position)
		
		if (d.focus_target == nil or auxi.check(d.focus_target) == false or d.focus_nowroom ~= level:GetCurrentRoomIndex()) and gdir:Length() > 0.05 then
			local q1 = Isaac.Spawn(1000,enums.Entities.QingsMarks,0,player.Position,gdir,player)
			q1:GetData().Player = player
			q1.GridCollisionClass = 3
			d.focus_target = q1
			d.focus_time = Game():GetFrameCount()
			d.focus_nowroom = level:GetCurrentRoomIndex()
		end
		if d.focus_target ~= nil and auxi.check(d.focus_target) and d.nowroom == level:GetCurrentRoomIndex() and d.focus_target.Position ~= nil then
			d.focus_time = Game():GetFrameCount()
		end
		if d.focus_type == nil then
			d.focus_type = 1
		end
		
		if player:IsCoopGhost() then 
			d.coopghost = true
		elseif d.coopghost then
			d.coopghost = nil
			player:AddNullCostume(enums.Costumes.Qingrobes)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = enums.Familiars.QingsAirs,
Function = function(_,ent)
	local player = ent.Player
	if player:GetName() == "SP.W.Qing" then
		local d = ent:GetData()
		local s = ent:GetSprite()
		if player:HasCollectible(619) then
			if math.random(1000) > 500 then
				s:ReplaceSpritesheet(0, "gfx/familiar/Air_Flig_2.png")
				s:LoadGraphics()
			end
		end
		if player:HasCollectible(395) then
			s:ReplaceSpritesheet(0, "gfx/familiar/Air_Flig_techx.png")
			s:LoadGraphics()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = enums.Familiars.QingsAirs,
Function = function(_,ent)			--浮游炮
	local sprite = ent:GetSprite()
	local room = Game():GetRoom()
	local player = ent.Player
	local level = Game():GetLevel()
	local d = ent:GetData()
	if player ~= nil then
		if true then		--第一步：寻找目标；第二步：移动；第三步：攻击。
			local d2 = player:GetData()
			if ent.State == nil then
				ent.State = 0
			end
			
			if ent:GetData().MakeState then
				ent.State = ent:GetData().MakeState
			end
			local maintarg = player.Position		
			if ent.State == 0 then				--	0意味着寻找目标
				if d2.focus_target ~= nil then -- and auxi.check(d2.focus_target) then
					if d2.focus_target.Position ~= nil then
						maintarg = d2.focus_target.Position
					end
				end
				if d.targpos == nil then --or auxi.check(d.targpos) == false then
					d.targpos = player.Position
				end
				if d2.focus_type == nil then d2.focus_type = 0 end

				local range = 500	--射程根据攻击模式确定。
				if d2.focus_type == 0 then				--0：自主寻敌；1：目标优先；2：强制攻击。
					range = 200
				elseif d2.focus_type == 1 then
					range = 50	
				elseif d2.focus_type == 2 then
					range = 10
				else
					range = 200
				end
				if d2.focus_type == 0 or d2.focus_type == 1 or d2.focus_type == 2 then				--0：自主寻敌；1：目标优先；2：强制攻击。
					d.targpos = maintarg 
				else
					d.targpos = d.targpos * 0.9 + maintarg * 0.1
				end
				if player:GetName() == "SP.W.Qing" and (d2.focus_target == nil or d2.focus_target:Exists() == false) then
					range = 30
				else
					range = 100
				end
				local focu = nil
				if d2.focus_type == 1 or d2.focus_type == 2 then
					focu = auxi.getdisenemies(auxi.getenemies(Isaac.FindInRadius(d.targpos,range * player.ShotSpeed,1<<3)),d.targpos,1000)
				elseif d2.focus_type == 0 or d2.focus_type == nil then
					focu = auxi.getrandenemies(auxi.getenemies(Isaac.FindInRadius(d.targpos,range * player.ShotSpeed,1<<3)))
				end
				if focu ~= nil then --and auxi.check(focu) then
					if d2.focus_type ~= 3 then			--3：不攻击。
						ent.State = 1
						d.randpos = auxi.MakeVector(math.random(18000)/100)*100
						d.focu = focu		--确定目标。但不能确定是否还存活。
					end
				else			--没有检查到敌人的情况下，环绕角色。
					if d2.focus_type == 2 then
						ent.State = 2
					end
					if d.ang == nil then
						d.ang = math.random(36000)/100
					end
					d.ang = d.ang + math.random(1000)/1000
					d.randpos = auxi.MakeVector(d.ang) * 150
					ent:FollowPosition(player.Position + d.randpos)
				end
			end
			
			if ent.State == 1 then				--	1意味着进行移动
				if d2.focus_type == 0 or d2.focus_type == 1 then
					if d.focu == nil then
						ent.State = 0
					else
						local tarpos = d.focu.Position + d.randpos
						ent:FollowPosition(tarpos)
						ent.Velocity = ent.Velocity * math.min(player.ShotSpeed,2)
						if (ent.Position - tarpos):Length() < 90 + 10 then		--试试这个判定条件
							d.Vel = math.random(1000)/500 + 4
							ent.State = 2
						end
					end
				elseif d2.focus_type == 2 then
					if d2.focus_target == nil then
						ent.State = 0
					else
						local tarpos = d2.focus_target.Position + d.randpos
						ent:FollowPosition(tarpos)
						ent.Velocity = ent.Velocity * math.min(player.ShotSpeed,2)
						if (ent.Position - tarpos):Length() < 90 + 10 then
							d.Vel = math.random(1000)/500 + 4
							ent.State = 2
						end
					end
				end
			end

			if ent.State == 2 then				--	2意味着发动攻击
				if d2.focus_type == 0 or d2.focus_type == 1 or d2.focus_type == nil then
					if d.orbang == nil then
						d.orbang = 0
					end
					if d.focu ~= nil and d.focu:Exists() == true then -- and auxi.check(d.focu) then
						d.orbang = (ent.Position - d.focu.Position):GetAngleDegrees() + 90
						if d.Vel == nil then
							 d.Vel = math.random(1000)/500 + 4
						end
						local folopos = ent.Position
						folopos = folopos + auxi.MakeVector(d.orbang) * player.ShotSpeed * d.Vel * (10)
						--ent.Velocity = d.focu.Velocity + auxi.MakeVector(d.orbang) * player.ShotSpeed * d.Vel
						local leg = (ent.Position - d.focu.Position):Length()
						if leg < 80 and leg > 10 then
							folopos = folopos +	(ent.Position - d.focu.Position)/leg * 10 * (100 - leg)/10
							--ent.Velocity = ent.Velocity + (ent.Position - d.focu.Position)/leg * 10 * (100 - leg)/50
						elseif leg > 120 then	 
							folopos = folopos - (ent.Position - d.focu.Position)/leg * 10 * (math.min(200,leg) - 100)/10
							--ent.Velocity = ent.Velocity - (ent.Position - d.focu.Position)/leg * 10 * (math.min(200,leg) - 100)/50
						end
						ent:FollowPosition(folopos)
						d.targ_Position = d.focu.Position
					else
						ent.State = 0
					end
				elseif d2.focus_type == 2 then
					if d2.focus_target == nil then --or auxi.check(d2.focus_target) == false then
						ent.State = 0
					else
						if d.orbang == nil then
							d.orbang = 0
						end
						if d2.focus_target ~= nil then --and auxi.check(d2.focus_target) then
							d.orbang = (ent.Position - d2.focus_target.Position):GetAngleDegrees() + 90
							if d.Vel == nil then
								 d.Vel = math.random(1000)/500 + 4
							end
							ent.Velocity = ent.Velocity * 0 + 0 * d2.focus_target.Velocity + (auxi.MakeVector(d.orbang) * player.ShotSpeed * d.Vel)
							local leg = (ent.Position - d2.focus_target.Position):Length()
							if leg < 80 and leg > 15 then
								ent.Velocity = ent.Velocity * 0.95 + (ent.Position - d2.focus_target.Position)/leg * 10 * (100 - leg)/50
							elseif leg > 120 then	 
								ent.Velocity = ent.Velocity * 0.95 - (ent.Position - d2.focus_target.Position)/leg * 10 * (math.min(200,leg) - 100)/50
							end
							d.targ_Position = d2.focus_target.Position
						else
							ent.State = 0
						end
					end
				end
				
				local should_bind_brimstone = true
				
				if d.firedelay ~= nil and d.firedelay < 0 then
					should_bind_brimstone = false
					d.firedelay = player.MaxFireDelay
					if d.targ_Position == nil then -- or auxi.check(d2.focus_target) == false then
						d.targ_Position = -(2*ent.Position - player.Position)
					end
					local leg = (ent.Position - d.targ_Position):Length()
					local weap = 1								--	不太清楚是否会成功。也许需要修改。
					for i = 1,16 do 
						if player:HasWeaponType(i) == true then
							weap = i
						end
					end
					if player:HasCollectible(418) then
						weap = math.random(13)
					end
					local pepper_cnt = 1
					if weap == 1 or weap == 8 or weap == 14 then		--眼泪和悬浮
						if player:HasCollectible(69) then		--巧克力奶：翻倍攻击、子弹大小，或是减半攻击，快速发射。
							if player:HasCollectible(316) then		--诅咒之眼：增加小子弹（延续AB+的版本）
								local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
								if weap == 14 then
									auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
								end
								q1.Parent = ent
								q1.Scale = q1.Scale * 2
								q1.CollisionDamage = q1.CollisionDamage * 3
								for i = 1,4 do 
									delay_buffer.addeffe(function(params)
										local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
										if weap == 14 then
											auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
										end
										q1.Parent = ent
										q1.Scale = q1.Scale * 0.4
										q1.CollisionDamage = q1.CollisionDamage * 0.2
									end,{},i*2)
								end
								d.firedelay = player.MaxFireDelay * 2.7
								pepper_cnt = pepper_cnt + 4		--多4发
							else
								local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
								if weap == 14 then
									auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
								end
								q1.Parent = ent
								q1.Scale = q1.Scale * 2
								q1.CollisionDamage = q1.CollisionDamage * 3
								d.firedelay = player.MaxFireDelay * 2.5
							end
						elseif player:HasCollectible(316) then		--诅咒之眼：五次攻击，延迟3.5倍
							for i = 1,5 do 
								delay_buffer.addeffe(function(params)
									local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
									if weap == 14 then
										auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
									end
									q1.Parent = ent
								end,{},(i-1)*2)
							end
							d.firedelay = player.MaxFireDelay * 3.5
							pepper_cnt = pepper_cnt + 4		--多4发
						else
							local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
							if weap == 14 then
								auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
							end
							q1.Parent = ent
						end
						if weap == 14 then
							d.firedelay = player.MaxFireDelay * 3
						end
					elseif weap == 2 then		--硫磺火
						if player:HasCollectible(330) or player:HasCollectible(561) then
							should_bind_brimstone = true
							if d.brimstone_bind == nil or d.brimstone_bind:Exists() == false or d.brimstone_bind:IsDead() then
								d.brimstone_bind = player:FireBrimstone(-(ent.Position - d.targ_Position))
								d.brimstone_bind.Parent = ent
								d.brimstone_bind.Timeout = 0
								d.brimstone_bind.PositionOffset = Vector(ent.PositionOffset.X,ent.PositionOffset.Y)
							end
							if player:HasCollectible(678) then
								local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
								auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
								d.firedelay = player.MaxFireDelay * 0.8
							end
						else
							local q1 = player:FireBrimstone(-(ent.Position - d.targ_Position))
							q1.Parent = ent
							q1.Position = ent.Position
							q1.PositionOffset = Vector(0,-10)
							if player:HasCollectible(678) then
								for i = 1,3 do
									delay_buffer.addeffe(function(params)
										local q1 = player:FireTear(ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true,true)
										auxi.fire_fetus(q1,player,ent.Position, -(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,true,true)
									end,{},(i)*3)
								end
								d.firedelay = d.firedelay * 1.4
							end
							local multitar = 0
							if player:HasCollectible(229) or player:HasCollectible(558) then
								for i = 1,player:GetCollectibleNum(229) do
									multitar = multitar + math.random(5) + 1
								end
								for i = 1,player:GetCollectibleNum(558) do
									multitar = multitar + math.random(1) 
								end
							end
							for i = 1,multitar do
								local q1 = player:FireBrimstone(auxi.MakeVector(math.random(36000)/100))
								q1.Parent = ent
								q1.Position = ent.Position
								q1.PositionOffset = Vector(0,-10)
							end
							d.firedelay = d.firedelay + 7		--自带不可消除的7延迟
							pepper_cnt = pepper_cnt + 4		--多4发
						end
					elseif weap == 3 then		--科技
						if player:HasCollectible(229) then
							local cnt = player:GetCollectibleNum(229)
							local params = {player = player,Direction = -(ent.Position - d.targ_Position):Normalized(),Position = ent.Position,delang = 30,Length = 40,length = 30,multi_cnt = 3,multi_shot = 3,cool_down = 3}
							params.loop_func = function(trans)auxi.fire_lung_Laser(trans) end
							delay_buffer.addeffe(auxi.fire_lung_Laser,params,3)
							d.firedelay = player.MaxFireDelay * 3
						else
							if player:HasCollectible(316) then		--诅咒之眼：五次攻击，延迟3.5倍
								for i = 1,5 do 
									delay_buffer.addeffe(function(params)
										local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,-(ent.Position - d.targ_Position),false,true)
										q1.PositionOffset = Vector(0,-10)
										q1.Parent = ent
										local multitar = 0
										if player:HasCollectible(558) then
											for i = 1,player:GetCollectibleNum(558) do
												multitar = multitar + math.random(1) 
											end
										end
										for i = 1,multitar do
											local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,auxi.MakeVector(math.random(36000)/100),false,true)
											q1.PositionOffset = Vector(0,-10)
											q1.Parent = ent
										end
									end,{},(i-1)*2)
								end
								d.firedelay = player.MaxFireDelay * 3.5
								pepper_cnt = pepper_cnt + 4
							else
								local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,-(ent.Position - d.targ_Position),false,true)
								q1.PositionOffset = Vector(0,-10)
								q1.Parent = ent
								local multitar = 0
								if player:HasCollectible(558) then
									for i = 1,player:GetCollectibleNum(558) do
										multitar = multitar + math.random(1) 
									end
								end
								for i = 1,multitar do
									local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,auxi.MakeVector(math.random(36000)/100),false,true)
									q1.PositionOffset = Vector(0,-10)
									q1.Parent = ent
								end
							end
						end
					elseif weap == 5 then		--博士
						local q1 = player:FireBomb(ent.Position,-(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed)
						q1.Parent = ent
						local multitar = 0
						if player:HasCollectible(558) then
							for i = 1,player:GetCollectibleNum(558) do
								multitar = multitar + math.random(2)
							end
						end
						for i = 1,multitar do
							local q1 = player:FireBomb(ent.Position,(auxi.MakeVector(math.random(36000)/100)) * 7 * player.ShotSpeed)
							q1.Parent = ent
						end
					elseif weap == 6 then		--史诗
						local params = {
							Cooldown = player.MaxFireDelay * 3 + 5,
							Spawner = ent,
							Player = player,
							tearflags = player.TearFlags | player:GetBombFlags()
						}
						if player:HasCollectible(114) then
							params.knife = player:GetCollectibleNum(114)
						end
						if player:HasCollectible(118) then
							params.brimstone = player:GetCollectibleNum(118)
						end
						if player:HasCollectible(68) and player:HasCollectible(118) == false then		--硫磺火+科技不需要额外配合
							params.Tech = player:GetCollectibleNum(68)
						end
						if player:HasCollectible(395) then
							params.TechX = player:GetCollectibleNum(395)
						end
						auxi.launch_Missile(ent.Position, -(ent.Position - d.targ_Position)/(params.Cooldown+0.1),player.Damage, nil, params)
						local multitar = 0
						if player:HasCollectible(229) or player:HasCollectible(558) then
							for i = 1,player:GetCollectibleNum(229) do
								multitar = multitar + math.random(5) + 1
							end
							for i = 1,player:GetCollectibleNum(558) do
								multitar = multitar + math.random(1) 
							end
						end
						for i = 1,multitar do
							auxi.launch_Missile(ent.Position, -(ent.Position - d.targ_Position)/(params.Cooldown+0.1) + auxi.MakeVector(math.random(36000)/100)* (math.random(10)/3 + 0.5),player.Damage, nil, params)
						end
						d.firedelay = player.MaxFireDelay * 5
					elseif weap == 9 then		--科技X
						d.firedelay = player.MaxFireDelay * 4
						if player:HasCollectible(229) then		--科X+肺
							local rnd = math.random(5) + 3
							for i = 1,rnd do
								local dir = (d.targ_Position - ent.Position):GetAngleDegrees() + math.random(80) - 40
								local radus = math.random(30) + 10
								local q1 = player:FireTechXLaser(ent.Position + ent.Velocity * 3, auxi.MakeVector(dir) * 7 * player.ShotSpeed,radus,player,math.random(1000)/1000 * 0.6 + 0.7)
								q1.PositionOffset = Vector(0,0)
								q1.Parent = ent
							end
						else
							local q1 = player:FireTechXLaser(ent.Position + ent.Velocity * 3,-(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,30)
							q1.PositionOffset = Vector(0,0)
							q1.Parent = ent
						end
					elseif weap == 7 then		--肺
						d.firedelay = player.MaxFireDelay * 1.5
						if player:HasCollectible(52) then		--博士被肺覆盖
							local maxcnt = math.random(5) + 3 
							for i = 1, maxcnt do 
								local ang = (ent.Position - d.targ_Position):GetAngleDegrees() + 180 + math.random(20) - 10
								local q1 = player:FireBomb(ent.Position,auxi.MakeVector(ang) * 7 * player.ShotSpeed * (math.random(100)+950)/1000)
							end
						else
							local maxcnt = math.random(10) + 15
							if player:HasCollectible(531) then maxcnt = math.random(5) + 3 end
							for i = 1, maxcnt do 
								local q1 = player:FireTear(ent.Position, auxi.MakeVector(180 + (ent.Position - d.targ_Position):GetAngleDegrees() + math.random(900)/15 - 30) * 7 * player.ShotSpeed * (math.random(1000)/1000 * 1.3 + 0.7),true,true,true)
								q1.FallingSpeed = -20
								q1.FallingAcceleration = 1.6
								q1.Scale = q1.Scale * (math.random(500)/1000 + 0.8)
							end
						end
						pepper_cnt = pepper_cnt + 1
					elseif weap == 4 then		--妈刀
						local params = {
							cooldown = 60,
							Accerate = 0.5,
							player = player,
							tearflags = player.TearFlags,
							Color = player.TearColor,
							Explosive = player:GetCollectibleNum(149) + player:GetCollectibleNum(52)
						}
						local q2 = auxi.fire_knife(ent.Position + Vector(0,-10),-(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,player.Damage,nil,auxi.copy(params))
						if q2:IsFlying() == false then
							q2:Shoot(1,player.TearRange/4)
						end
						if player:HasCollectible(229) then
							params.Accerate = 1.5
							local cnt = player:GetCollectibleNum(229)
							local rnd = math.random(cnt * 3) + 2
							for i = 1,rnd do
								auxi.fire_knife(ent.Position + Vector(0,-10),auxi.MakeVector(math.random(360000)/1000) * 13 * player.ShotSpeed,player.Damage/2,nil,auxi.copy(params))
							end
						end
						d.firedelay = player.MaxFireDelay * 1.8 + 1
						if player:HasCollectible(118) then
							params.tearflags = nil
							params.Accerate = 1.5
							d.firedelay = player.MaxFireDelay * 4 + 3
							local cnt = math.random(3) + 1 + 2 * (player:GetCollectibleNum(118) - 1)
							for i = 1,cnt do
								local cnt2 = math.random(2) + (player:GetCollectibleNum(118) - 1)
								for j = 1,cnt2 do
									delay_buffer.addeffe(function(params)
										if params.ent == nil or params.player == nil or params.dir == nil then
											return
										end
										local ent = params.ent
										local dir = params.dir
										local player = params.player
										local pm = params.pm
										local rand = math.random(31) - 16
										local q2 = auxi.fire_knife(ent.Position + Vector(0,-10),dir:Length() * auxi.MakeVector(dir:GetAngleDegrees() + rand),player.Damage,nil,pm)
										if rand < 0 then 
											q2:GetSprite().FlipX = true 
											q2.RotationOffset = 180 - q2.RotationOffset
										end
										delay_buffer.addeffe(function(params)
											local mnil = q2.Parent
											if mnil then
												mnil.Velocity = mnil.Velocity:Length() * auxi.MakeVector(dir:GetAngleDegrees())
											end
										end,{},5)
										for i = 1,4 do
											delay_buffer.addeffe(function(params)
												if q2:GetSprite().FlipX then
													q2.RotationOffset = 180 - dir:GetAngleDegrees()
												else
													q2.RotationOffset = dir:GetAngleDegrees()
												end
											end,{},5 + i)
										end
									end,auxi.copy({ent = ent,player = player,dir = -(ent.Position - d.targ_Position)/leg * 12 * player.ShotSpeed,pm = params,}),i * 3)
								end
							end
						end
						if player:HasCollectible(68) then
							if player:HasCollectible(229) then
								local cnt = player:GetCollectibleNum(229)
								local params = {player = player,Direction = -(ent.Position - d.targ_Position):Normalized(),Position = ent.Position,delang = 30,Length = 40,length = 30,multi_cnt = 3,multi_shot = 3,cool_down = 3}
								params.loop_func = function(trans)auxi.fire_lung_Laser(trans) end
								delay_buffer.addeffe(auxi.fire_lung_Laser,params,3)
								d.firedelay = math.max(d.firedelay + 5,player.MaxFireDelay * 3 + 10)
							else
								for i = 1,5 do
									delay_buffer.addeffe(function(params)
										local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,(q2.Position - (ent.Position + Vector(0,-30))),false,true)
										q1:SetMaxDistance((q2.Position - (ent.Position + Vector(0,-30))):Length())
										q1.PositionOffset = Vector(0,-10)
										q1.Parent = ent
									end,{},i * 2 + 5)
								end
								d.firedelay = d.firedelay + 2
								local multitar = 0
								if player:HasCollectible(558) then
									for i = 1,player:GetCollectibleNum(558) do
										multitar = multitar + math.random(1) 
									end
								end
								for i = 1,multitar do
									local q1 = player:FireTechLaser(ent.Position,1,auxi.MakeVector(math.random(36000)/100),false,true)
									q1.Parent = ent
								end
							end
						end
					elseif weap == 13 or weap == 10 then		--英灵剑
						if d.sword_counter == nil then d.sword_counter = 0 end
						d.sword_counter = (d.sword_counter + 1)% 5
						if d.sword_counter == 0 then
							local params = {
								cooldown = 14,
								Accerate = -1,
								player = player,
								tearflags = player.TearFlags,
								Color = player.TearColor,
								Tech = player:HasCollectible(68) or player:HasCollectible(395),
							}
							if player:HasCollectible(114) then
								params.cool_down = 20
								params.del_RotationOffset = 35
							end
							local q2 = auxi.fire_Sword(ent.Position,-(ent.Position - d.targ_Position)/leg * 7 * player.ShotSpeed,player.Damage * 0.2,nil,auxi.copy(params))
							delay_buffer.addeffe(function(params)
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_SWORD_SPIN,1,1,false,0,2)
							end,{},4)
							if player:HasCollectible(395) then
								local q3 = player:FireTechXLaser(ent.Position -(ent.Position - d.targ_Position)/leg * 60,Vector(0,0),70,player,0.3)
								q3.Velocity = Vector(0,0)
								q3.PositionOffset = Vector(0,0)
								q3:GetData().followParent = q2
								delay_buffer.addeffe(function(params)
									local ent = params.ent
									if ent and ent:Exists() and not ent:IsDead() then
										ent:Remove()
									end
								end,{ent = q3,},12)
							end
							if player:HasCollectible(114) then
								local qn = q2:ToKnife()
								qn:Shoot(1,player.TearRange/4)
								for i = 1,6 do
									delay_buffer.addeffe(function(params)
										local ent = params.ent
										local q2 = params.q2
										if ent and ent:Exists() and not ent:IsDead() and q2 and q2:Exists() and not q2:IsDead() then
											local mnil = q2.Parent
											if mnil and mnil:Exists() and not mnil:IsDead() then
												mnil.Position = mnil.Position * 0.7 + ent.Position * 0.3
											end
										end
									end,{ent = ent,q2 = q2,},i * 2 + 6)
								end
							end
							d.firedelay = player.MaxFireDelay * 3 + 10
						else
							local params = {
								cooldown = 8,
								Accerate = -2,
								player = player,
								tearflags = player.TearFlags,
								Color = player.TearColor,
								Tech = player:HasCollectible(68) or player:HasCollectible(395),
								Attack = true,
								RotationOffset = 180 + (ent.Position - d.targ_Position):GetAngleDegrees(),
							}
							local q2 = auxi.fire_Sword(ent.Position + -(ent.Position - d.targ_Position)/leg * 30 * player.ShotSpeed,Vector(0,0),player.Damage * 0.04,nil,auxi.copy(params))	
							delay_buffer.addeffe(function(params)
								sound_tracker.PlayStackedSound(SoundEffect.SOUND_SHELLGAME,1,1,false,0,2)
							end,{},4)
							local s2 = q2:GetSprite()
							s2.Offset = (ent.Position - d.targ_Position):Normalized() * 30
							d.firedelay = player.MaxFireDelay * 0.4 + 0.3
						end
					end
					
					if player:HasCollectible(616) then		--检查辣椒火焰
						if math.random(1000)/1000 * (math.exp(11/5) + 2) < math.exp(math.max(-3/5,math.min(11/5,player.Luck/5))) + 2.01 then
							for i = 1,pepper_cnt do
								delay_buffer.addeffe(function(params)
									local q1 = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.RED_CANDLE_FLAME,0,ent.Position,-(ent.Position - d.targ_Position):Normalized() * 9 * player.ShotSpeed,player):ToEffect()
									q1.CollisionDamage = player.Damage * 4
									q1:SetTimeout(600)
								end,{}, (i-1) * 3)
							end
						end
					end
					if player:HasCollectible(495) then
						if math.random(1000)/1000 * (math.exp(11/5) + 2) < math.exp(math.max(-3/5,math.min(11/5,player.Luck/5))) + 2.01 then
							for i = 1,pepper_cnt do
								delay_buffer.addeffe(function(params)
									local q1 = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.BLUE_FLAME,0,ent.Position,-(ent.Position - d.targ_Position):Normalized() * 9 * player.ShotSpeed,player):ToEffect()
									q1.CollisionDamage = player.Damage * (math.random(3000)/1000 + 3)
									q1:SetTimeout(120)
								end,{}, (i-1) * 3)
							end
						end
					end
					
					if player:GetName() == "SP.W.Qing" then				-- 存在小概率重新选择目标。这个概率根据攻击次数累加。
						if d.re_attack_counter == nil then d.re_attack_counter = 0 end
						d.re_attack_counter = d.re_attack_counter + 1
						if auxi.check_rand(d.re_attack_counter/5 - 2,10,1,8) == true then
							d.re_attack_counter = 0
							ent.State = 0
						end
					end
				end
				
				--附加攻击
				if should_bind_brimstone then
					if d.brimstone_bind ~= nil then
						d.brimstone_bind.TearFlags = player.TearFlags
						if d.brimstone_bind.TearFlags & BitSet128(0,1<<(121-64)) ~= BitSet128(0,1<<(121-64)) then
							d.brimstone_bind:SetColor(player.LaserColor,3,60,false,false)
						end
						d.brimstone_bind.Angle = (ent.Position - d.targ_Position):GetAngleDegrees() + 180
						d.brimstone_bind.CollisionDamage = player.Damage * 0.5
						d.brimstone_bind_counter = 0
					end
				else
					if d.brimstone_bind then		
						d.brimstone_bind:Remove()
						d.brimstone_bind = nil
					end
				end
				
				if player:HasCollectible(152) then		--科技2
					if d.tech_2 == nil then
						if player:HasCollectible(494) then
							d.tech_2 = Isaac.Spawn(7,10,0,ent.Position,Vector(0,0),player):ToLaser()
						else
							d.tech_2 = Isaac.Spawn(7,2,0,ent.Position,Vector(0,0),player):ToLaser()
						end
						d.tech_2.Parent = ent
						d.tech_2.Timeout = 0
						d.tech_2.TearFlags = player.TearFlags
						d.tech_2.PositionOffset = Vector(ent.PositionOffset.X,ent.PositionOffset.Y)
						d.tech_2.Angle = (ent.Position - d.targ_Position):GetAngleDegrees() + 180
						d.tech_2.CollisionDamage = player.Damage * 0.2
					else
						d.tech_2.TearFlags = player.TearFlags
						if d.tech_2.TearFlags & BitSet128(0,1<<(121-64)) ~= BitSet128(0,1<<(121-64)) then
							d.tech_2:SetColor(player.LaserColor,3,60,false,false)
						end
						d.tech_2.Angle = (ent.Position - d.targ_Position):GetAngleDegrees() + 180
					end
				end
				
				if player:HasCollectible(244) then		--科技.5：随机间隔发射激光攻击。
					if math.random(1000) > 900 and d.firedelay/2 > math.random(math.max(0,math.floor(player.MaxFireDelay)) + 1) then
						local q1 = player:FireTechLaser(ent.Position + ent.Velocity * 3,1,-(ent.Position - d.targ_Position),false,true)
						q1.PositionOffset = Vector(0,-10)
						local random_cnt = math.random(1000)
						local buff_list = {BitSet128(1<<2,0),BitSet128(1<<16,0),BitSet128(1<<30,0),BitSet128(1<<19,0),BitSet128(1<<33,0),BitSet128(0,1<<5)}
						for i = 1,6 do 
							if math.random(1000) > 800 then
								q1:AddTearFlags(buff_list[i])
							end
						end
					end
				end
				
			end
			
			if ent.State ~= 2 and d.tech_2 then		
				d.tech_2:Remove()
				d.tech_2 = nil
			end
			if ent.State ~= 2 and d.brimstone_bind then	
				if d.brimstone_bind_counter == nil then d.brimstone_bind_counter = 0 end
				d.brimstone_bind_counter = d.brimstone_bind_counter + 1
				if d.brimstone_bind_counter > 10 then
					d.brimstone_bind:Remove()
					d.brimstone_bind = nil
				end
			end
			if d.firedelay == nil then
				d.firedelay = 0
			end
						
			d.firedelay = d.firedelay - 1
			
			if d.focu == nil or d.focu:IsActiveEnemy() == false then
				d.focu = nil
				ent.State = 0
			end
			if true then			--sprite的控制
				local ang = nil
				if d.focu ~= nil then
					if d.focu.Position ~= nil then
						ang = (ent.Position - d.focu.Position):GetAngleDegrees() + 90
					end
				end
				if ang == nil then
					if player ~= nil then
						ang = (ent.Position - player.Position):GetAngleDegrees() + 90
					end
				end
				if d2.focus_type == 2 and d2.focus_target ~= nil then
					ang = (ent.Position - d2.focus_target.Position):GetAngleDegrees() + 90
				end
				if ang == nil then
					ang = 0
				end
				
				if true then			
					if ang < 0 then			
						ang = ang + 360
					end
					if ang < 0 then
						ang = ang + 360
					end
					if ang > 360 then
						ang = ang - 360
					end
					if ang > 360 then
						ang = ang - 360
					end
					if ang > 180 then
						ang = 360 - ang
						sprite.FlipX = true
					else
						sprite.FlipX = false
					end
					if ang < 22.5 then
						sprite:Play("FloatUp", true)
						sprite.Rotation = ang
					elseif ang < 67.5 then
						sprite:Play("FloatDT", true)
						sprite.Rotation = ang - 45
					elseif ang < 112.5 then
						sprite:Play("FloatTo", true)
						sprite.Rotation = ang - 90
					elseif ang < 157.5 then
						sprite:Play("FloatUT", true)
						sprite.Rotation = ang - 135
					else
						sprite:Play("FloatDown", true)
						sprite.Rotation = ang - 180
					end
				end
				ent.PositionOffset = Vector(ent.PositionOffset.X,math.max(-30,math.min(-20,ent.PositionOffset.Y + math.random(1000)/10000)))
			end
		
			if d.nowroom ~= level:GetCurrentRoomIndex() then		--进入新房间后重置的部分
				d.nowroom = level:GetCurrentRoomIndex()
				d.ang = nil
			end
		else
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:GetName() == "SP.W.Qing" then
			local d = player:GetData()
			d.Air_buff = 0
			d.add_after_pickup = false
			player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
			d.should_evaluate_on_update_once = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)		--防止小退的情况。
	if player:GetName() == "SP.W.Qing" then
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	if player:GetName() == "SP.W.Qing" then
		player:AddNullCostume(enums.Costumes.SPWQinghair)
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	if player:GetName() == "SP.W.Qing" then
		if Game():GetFrameCount() < 2 then
			if save.UnlockData.Others.Ending1.Unlock ~= true then
				Game():Fadeout(1,1)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,collid, itemRng, player, useFlags, activeSlot, customVarData)
	if collid == 283 or collid == 284 or collid == 703 then
		if player:GetName() == "SP.W.Qing" then
			player:AddNullCostume(enums.Costumes.SPWQinghair)
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if player:GetName() == "SP.W.Qing" then
		player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
		player:GetData().should_evaluate_on_update_once = true
	end
end,
})

return item