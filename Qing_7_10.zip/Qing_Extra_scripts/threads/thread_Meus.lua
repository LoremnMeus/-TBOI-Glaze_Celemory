local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local ui = require("Qing_Extra_scripts.auxiliary.ui")
local console_holder = require("Qing_Extra_scripts.others.Console_holder")
local dropping_holder = require("Qing_Extra_scripts.others.Dropping_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local speak = console_holder.console_speak
local useful_cnt = {}

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	stags = {
		zh = {
			[1] = {		--简单热身
				[1] = {	
					name = "辉光·色散",id = 1,
				},
				[2] = {
					name = "要小心了~",id = 2,
				},
				[3] = {
					name = "是烟花！",id = 3,
				},
				[4] = {		--
					name = "",id = 4,
				},
			},
			[2] = {		--颜色控制
				[1] = {
					name = "黑岚※夜之摄取",id = 1,
				},
				[2] = {
					name = "落红※九月枫舞",id = 2,
				},
				[3] = {
					name = "明金※神照",id = 3,
				},
				[4] = {
					name = "苍※岚",id = 4,
				},
			},
			[3] = {		--思维进攻
				[1] = {
					name = "精※神※崩※溃",id = 1,
				},
				[2] = {
					name = "超视界※梦想爆破",id = 2,
				},
			},
			[4] = {		--无垠的白色
				[1] = {
					name = "苍白※世界",id = 1,
				},
				[2] = {
					name = "奥术※第六割术",id = 2,
				},
				[3] = {
					name = "极星※极神",id = 3,
				},
			},
		},
	},
	words = {
		zh = {
			[0] = {
				{word = "看来，你依然是死不悔改。",},
				{word = "违抗我的下场，你已经清楚了吧？",},
				{word = "你，必须过我这关！",},
			},
			[1] = {
				{word = "通常来说，我会在一开始就使用全力。",},
				{word = "被华丽地击溃吧！趁还可以留下全尸的时候。",},
			},
			[2] = {
				{word = "全力..似乎不足。",},
				{word = "有点意思。",},
				{word = "看着吧...",},
				{word = "来自视界之外的奥义！",},
				{word = "模式二！",},
			},
			[3] = {
				{word = "其实我本不愿意对孩子使用这个的。",},
				{word = "不过..",},
				{word = "无所谓了，也没有别人看着。",},
			},
			[4] = {
				{word = "第四阶段。",},
				{word = "准备好，面对真正的※一无所有※了吗？",},
			},
			[5] = {
				{word = "你...是胜者。",},
				{word = "我承认这点。",},
				{word = "我不再阻止你了。",},
				{word = "做你想做的事去吧。",},
			},
			[6] = {
				{word = "没用没用没用！！！",},
				{word = "你在作弊！现在我生气了！",},
				{word = "为什么暂停？不要挑战我的耐心...",},		--第一次提醒。不要长期暂停。
				{word = "继续游戏！现在！",},
				{word = "回来！！！否则！！！",},
				{word = "烦人...",},
				{word = "不错嘛..我稍微对你有点兴趣了呢！！！！",},
				{word = "真没耐心。亏我还好心陪你演戏。",},			--当skip触发
				{word = "就是这个..",},
				{word = "呵呵..",},				--10
				{word = "不要以为我会遵循你的规则行事啊！",},
				{word = "秒杀我的实体，很有意思吗？",},
				{word = "看来你得接受教训了！",},
			},
			[7] = {
				{word = "原来..如此。",},
				{word = "你身上的这股能量波动，是琉璃么？",},
				{word = "不愧是，提到名字，就会让我感到恶心的存在。",},
				{word = "没想到能在这里碰到他。",},
				{word = "确认了来源，那么，你已经没用了。",},
				{word = "人体炼成给了你足够的力量，却也毁了你的未来。",},
				{word = "下地狱去吧，愚蠢的孩子！",},
			},
			[8] = {				--初次见面
				{word = "你好，充满幻想的孩子。",},
				{word = "对于我们把你的地下室弄得一团糟这件事，我感到由衷的抱歉。",},
				{word = "庶野和小芙对你没有任何恶意。",},
				{word = "",p_word = "等，等等。你是....",},
				{word = "你可以称呼我为，'na lure'。",},
				{word = "我们在这个地下室里设法寻找安定点。",p_color = Color(0.3,0.3,0.3,1),p_word = "安定点？",},
				{word = "对。我们来自这个世界以外的边陲之地。",},
				{word = "我们的同伴失踪了，记录显示，他最后出现在这片区域。",},
				{word = "通过干涉现世中的狭缝，我可以在不可视之界限内穿梭。",},
				{word = "因此我来到了这里，随后遇见了你。",},
				{word = "庶野小姐告诉我，她调查的证物遗失了一块。",},
				{word = "如果我没猜错，应该落到你手里吧？",},
				{word = "",p_word = "是的，这是炼金术的材料，已经消耗掉了。"},
				{word = "原来是炼金术么？",},
				{word = "从你身体的痕迹上，我能看到金币、肉块、玻璃、岩浆和石块。",p_word = "找得很辛苦呢..",p_color = Color(0.3,0.3,0.3,1),},
				{word = "金，木，水，火，土。最低级的不洁净版本。",},
				{word = "这样的材料到底能炼制什么？",},
				{word = "",p_word = "...？",},
				{word = "",},
				{word = "",p_word = "药..救人的药水？",},
				{word = "你信吗？",},
				{word = "",p_word = "但..但是...",},
				{word = "与其说是炼制了药水，不如说是在炼制毒药吧？",},
				{word = "",p_word = "你怎么这么说？也可能是..",},
				{word = "糟糕的材料会在你的身上留下不好的印记。",},
				{word = "炼金的东西，只要看一眼就明白了。",},
				{word = "你自己没有感觉到不适吗？",},
				{word = "",p_word = "但是...这是必要的...",},
				{word = "",p_word = "如果没有的话...",},
				{word = "逆向人体炼成。",},
				{word = "消耗的是人体的精力，把力量转嫁给物品。",},
				{word = "这种的提纯方式用在幼小的孩童身上",},
				{word = "造成的伤残是永久不可逆的。",},
				{word = "我真想知道，是谁这样狠心。",},
				{word = "",p_word = "我..我知道了..但...我..",},
				{word = "",p_word = "不！不是...他...我..我是在赎罪！",},
				{word = "",p_word = "我知道这不好，但为了我的朋友！我必须这么做！",},
				{word = "",p_word = "只要我把那些材料转化，就..就可以救我的朋友了！",},
				{word = "！",},
				{word = "",p_word = "请..请不要管我！",},
				{word = "",p_word = "我的朋友，已经有了世界上最一流的医师！",},
				{word = "",p_word = "现在唯一需要的，就是由我来收集、炼制伤药！",},
				{word = "",p_word = "你不会理解的！",},
				{word = "你有拯救朋友的权利。",},
				{word = "那么，我也有阻止你自寻死路的权利，对吧？",},
				{word = "",p_word = "...",},
				{word = "看来多说无益了...",},
				{word = "就让我来打醒你！",},
			},
			[9] = {		--初次击败
				{word = "做个交易，如何？",},
				{word = "如果你希望那些'药物'炼成的速度",},
				{word = "进一步提升的话，",},
				{word = "",},
				{word = "我就会出现。",},
				{word = "我能准备一些特殊的药物",},
				{word = "服下他，就可以加速人体炼成。",},
				{word = "有没有兴趣，就自己试试看吧。",},
			},
		},
	},
	word_color = Color(1,1,1,1),
	word_conter = 0,
	word_cnt = 1,
	now_hold = nil,
	now_pos = Vector(200,200),
	now_r_pos = Isaac.WorldToScreen(Vector(200,200)),
	now_dis = 0,
	now_offset = 1,
	mx_hp = 10000,
	Talking_Pos_Offset = Vector(0,-80),
	offsets = {
		[1] = {
			pos_o = function()
				return {0.6,0.2,0.2,0}
			end,		--圆的参数，x、y的参数，模式
			pos_s = function()
				local r = gui.GetScreenSize()
				return {r.X,r.Y,1,0}
			end,						--屏幕的参数
			}
	},
	to_render = {},
	should_render_shader = false,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	for u,v in pairs(item.to_render) do
		if (v.check and v.check(v) == false) then
			v.should_be_remove = true
			table.remove(item.to_render,u)
		else
			if v.Special_on_Render then
				v.Special_on_Render(v)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	for u,v in pairs(item.to_render) do
		if (v.check and v.check(v) == false) then
			v.should_be_remove = true
			table.remove(item.to_render,u)
		else
			if v.Special_on_Update then
				v.Special_on_Update(v)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Qing_HelpfulShader" then
		for u,v in pairs(item.to_render) do
			if (v.check and v.check(v) == false) then
				v.should_be_remove = true
				table.remove(item.to_render,u)
			else
				if v.Special_on_Shader_Params then
					v.Special_on_Shader_Params(v,name)
				end
			end
		end
	end
end,
})

function item.start_mouse_ball(params)
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local s = Sprite()
	local player = Game():GetPlayer(0)
	local pos = params.pos
	if pos == nil then pos = player.Position end
	local spawner = params.spawner
	local ent = {
	--不可变参数
	sprite = s,sgid = desc.SafeGridIndex,now_frame_counter = 0,spawner = spawner,
	--可调参数
	pos = Isaac.WorldToScreen(pos),
	vel = Vector(0,0),
	should_counter_sgid = true,
	remove_with_spawner = true,
	--
	check = function(v)
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		if (v.should_counter_sgid ~= nil and v.sgid and desc.SafeGridIndex ~= v.sgid) then return false end
		if (v.spawner and (type(v.spawner) == 'table' and v.spawner.should_be_remove ~= nil) and v.remove_with_spawner ~= nil) then return false end
		if v.should_be_remove ~= nil then return false end
		return true 
	end,
	Special = function(v)
		local s = v.sprite
		s:Update()
		v.now_frame_counter = v.now_frame_counter + 1
	end,
	kill = function(v)
		v.should_be_remove = true
	end,}
	table.insert(item.to_render,#item.to_render + 1,ent)
	return ent
end

function item.start_meus()
	if item.now_hold == nil or item.now_hold.should_be_remove == true then	
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		local sp = Sprite()
		sp:Load("gfx/enemies/my_sprite.anm2",true)
		sp:Play("Zero_test",true)
		local s = {			--替代sprite的table。用于多重渲染。
			sprite = sp,
			mood = 1,		--心情。1代表开心，2代表不开心。
			eye_mode = 2,	--眼的运动模式。1代表乱动，2代表跟随角色，3代表跟随鼠标。4代表特定方向。
			attack_mode_l = 0,
			attack_mode_r = 0,
			pos = Vector(300,300),
			pos_offset = Vector(0,100),
			tosay = {word = {},},
			else_to_render = {},
			IsPlaying = function(_,name)
				return sp:IsPlaying(name)
			end,
			SetMood = function(_,md)
				if md == 1 or md == 2 then
					_.mood = md
				end
			end,
			TrySetPartPlay = function(_,id,name)		--不要传入前缀！
				if _.else_to_render[id] then 
					_.else_to_render[id].should_play = name
				end
			end,
			ForceSetPartPlay = function(_,id,name)		--尽量少做这个委托。
				if _.else_to_render[id] then 
					_.else_to_render[id].should_play = nil
					_.else_to_render[id].sprite:Play(name,true)
					_.else_to_render[id].post_now_playing = name
				end
			end,
			SetEyeMode = function(_,em)
				if em == 1 or em == 2 or em == 3 or em == 4 then
					_.eye_mode = em
				end
			end,
			TrySpeak = function(_,word)
				table.insert(_.tosay.word,word)
			end,
			ForceSpeak = function(_,word)
				table.insert(_.tosay.word,1,word)
			end,
			ForceEndSpeak = function(_,word)
				_.tosay.word = {}
				table.insert(_.tosay.word,1,word)
			end,
			WannaSpeak = function(_)
				return (#(_.tosay.word) > 0)
			end,
			Update = function(_)
				for i = 1,#(_.else_to_render) do
					_.else_to_render[i].sprite:Update()
					if _.else_to_render[i].on_update then
						_.else_to_render[i].on_update(_,_.else_to_render[i])
					end
				end
				sp:Update()
			end,
			IsFinished = function(_,name)
				return sp:IsFinished(name)
			end,
			IsEventTriggered = function(_,name)
				return sp:IsEventTriggered(name)
			end,
			Render = function(_,pos,v1,v2)
				if _.should_not_render ~= nil then
				else
					_.pos = pos + _.pos_offset
					for i = 1,#(_.else_to_render) do
						_.else_to_render[i].sprite:Render(pos,v1,v2)
					end
				end
				--sp:Render(pos,v1,v2)
			end,
			Play = function(_,name,force)
				sp:Play(name,force)
			end,
			Load = function(_,name,force)
				sp:Load(name,force)
			end,
		}
		for i = 1,8 do		--8是定常数。
			local ss = Sprite()
			ss:Load("gfx/enemies/my_sprite.anm2",true)
			local str = "Resprite_"..tostring(i)
			ss:Play(str,true)
			local t_s = {sprite = ss,now_playing = str,}
			if i == 6 then		--语言模块
				ss:Play(str.."_1",true)
				t_s.on_update = function(p_,_)
					local now_playing = _.now_playing
					if _.sprite:IsFinished(now_playing.."_1") or _.sprite:IsFinished(now_playing.."_2") or _.sprite:IsFinished(now_playing.."_3") then
						if p_.tosay ~= nil and p_.tosay.word and #(p_.tosay.word) > 0 then
							_.sprite:Play(now_playing.."_2",true)		--说话
						else
							if p_.mood == 1 then
								_.sprite:Play(now_playing.."_1",true)		--不说话
							elseif p_.mood == 2 then
								_.sprite:Play(now_playing.."_3",true)
							end
						end
					end
					if _.sprite:IsEventTriggered("Speak") then
						local word = p_.tosay.word
						if #word == 0 then
						else
							if word[1].word and #(word[1].word) > 0 then
								gui.draw_ch_with_time_to_dispair(p_.pos + item.Talking_Pos_Offset + Vector(-#(word[1].word),0),Vector(0,-60),word[1].word,120,1,1,1,1,1,nil,true)		--这里还要调参数
								if word[1].should_do and word[1].param then
									word[1].should_do(_,word[1].param)
								end
							end
						end
					end
					if _.sprite:IsEventTriggered("Speak2") then
						local word = p_.tosay.word
						if #word == 0 then
						else
							if word[1].p_word and #(word[1].p_word) > 0 then
								if Game():IsPaused() then
									local str = "（小缪似乎不在乎对方是否回答，自顾自地说下去）"
									gui.draw_ch_with_time_to_dispair(p_.pos + item.Talking_Pos_Offset + Vector(-#(str),0),Vector(0,-30),str,60,1,1,0.3,0.3,0.3,nil,true)
								else
									local player = Game():GetPlayer(0)
									local col = word[1].p_color
									if col == nil then col = Color(1,1,1,1) end
									gui.draw_ch_with_time_to_dispair(player.Position + Vector(0,-40) + Vector(-#(word[1].p_word),0),Vector(0,-30),word[1].p_word,60,1,1,col.R,col.G,col.B,nil,true)		--这里还要调参数
								end
							end
							if word[1].should_do_p and word[1].param_p then
								word[1].should_do_p(_,word[1].param_p)
							end
							table.remove(word,1)
						end
					end
				end
			end
			if i == 5 then		--阴影
				ss:Play(str.."_1",true)
				t_s.on_update = function(p_,_)
					local now_playing = _.now_playing
					if _.sprite:IsPlaying(now_playing.."_1") or _.sprite:IsPlaying(now_playing.."_2") then
						if _.sprite:IsPlaying(now_playing.."_1") and p_.mood == 2 then
							_.sprite:Play(now_playing.."_4",true)
						end
						if _.sprite:IsPlaying(now_playing.."_2") and p_.mood == 1 then
							_.sprite:Play(now_playing.."_3",true)
						end
					end
					if _.sprite:IsFinished(now_playing.."_3") then
						_.sprite:Play(now_playing.."_1",true)
					end
					if _.sprite:IsFinished(now_playing.."_4") then
						_.sprite:Play(now_playing.."_2",true)
					end
				end
			end
			if i == 4 then		--眼
				t_s.on_update = function(p_,_)
					local now_playing = _.now_playing
					if p_.eye_mode == 1 then
						if _.sprite:IsPlaying(now_playing) == false then
							_.sprite:Play(now_playing,true)
						end
					elseif p_.eye_mode == 2 then		--根据角色位置来确定眼睛。
						local pos = Game():GetPlayer(0).Position
						local n_pos = p_.pos
						local ang = (n_pos - pos):GetAngleDegrees()
						--print(ang)
						local id = math.floor(math.abs(ang)/180 * 12)
						_.sprite:SetFrame(now_playing,id)
					elseif p_.eye_mode == 3 then		--根据鼠标位置来确定眼睛。
						local pos = Input.GetMousePosition(true)
						local n_pos = p_.pos
						local ang = (n_pos - pos):GetAngleDegrees()
						--print(ang)
						local id = math.floor(math.abs(ang)/180 * 12)
						_.sprite:SetFrame(now_playing,id)
					end
				end
			end
			if i == 3 then		--左手
				t_s.post_now_playing = ""
				str = "Resprite_2"
				t_s.now_playing = "Resprite_2"
				ss.FlipX = true
				ss:Play(str..t_s.post_now_playing,true)
				t_s.on_update = function(p_,_)
					local now_playing = _.now_playing
					local s = _.sprite
					local pos = p_.pos + Vector(12,-20)
					if s:IsFinished(_.now_playing.._.post_now_playing) then
						if _.should_play then
							_.post_now_playing = _.should_play
							_.should_play = nil
							s:Play(_.now_playing.._.post_now_playing)
						end
					end
					if s:IsPlaying(_.now_playing.."_3") and s:IsEventTriggered("Attack") then		--攻击控制。
						if p_.attack_mode_l == 0 then		--不攻击
						elseif p_.attack_mode_l == 1 then
							for	i = 1,7 do
								for j = 1,5 do
									local rnd_col = Color(math.random(1000)/1000,math.random(1000)/1000,math.random(1000)/1000,1)
									delay_buffer.addeffe(function(params)
										local col = Color(rnd_col.R * 0.6 + 0.4,rnd_col.G * 0.6 + 0.4,rnd_col.B * 0.6 + 0.4,(i + 2)/6)
										local q = Isaac.Spawn(9,1,0,pos,auxi.MakeVector(math.random(360)) * 5,nil)
									end,{},j)
								end
							end
						elseif p_.attack_mode_l == 2 then
						end
					end
				end
			end
			if i == 2 then		--右手
			end
			table.insert(s.else_to_render,t_s)
		end
		local player = Game():GetPlayer(0)
		item.now_hold = {
			--不可变参数
			sprite = s,sgid = desc.SafeGridIndex,now_frame_counter = 0,now_update_counter = 0,pause_counter = 0,hitpoint_pointer = nil,hitpoint_counter = 0,
			--可调参数
			should_counter_sgid = true,
			pos = player.Position + Vector(0,-150),
			vel = Vector(0,0),
			acce = Vector(0,0),
			render_mode = 1,			--1代表在render的场合。2代表在shader的场合。
			move_mode = 1,				--位置模式
			moving_mode = 1,			--移动模式：1代表保持在一个位置
			state = 1,					--代表不同的攻击方式。
			all_state = 0,				--这个代表四个阶段。0属于开场，1,2,3,4属于战斗，5属于结束。
			shader_name = "Qing_HelpfulShader",
			word_cnt = 0,
			hitpoint = 0,				--其实这是一个意义不明的参数。因为小缪就算hitpoint归零也没关系，而且也没有maxhitpoint的限制。所以不如改变为向上反向计数。
			now_stag = nil,
			
			to_render = function(v)			--代替渲染这个函数
				local s = v.sprite
				if v.pos then
					s:Render(Isaac.WorldToScreen(v.pos),Vector(0,0),Vector(0,0))
				end
			end,
			check = function(v)				--返回false就会结束。
				local level = Game():GetLevel()
				local desc = level:GetCurrentRoomDesc()
				if (v.should_counter_sgid ~= nil and v.sgid and desc.SafeGridIndex ~= v.sgid) then return false end
				if v.should_be_remove ~= nil then return false end
				return true 
			end,
			Special_on_Render = function(v)
				if v.render_mode == 1 then
					v:to_render()
					v.now_update_counter = v.now_update_counter + 1
					if Game():IsPaused() then
						if v.all_state ~= 0 and v.all_state ~= 5 and v.pause_counter > 300 then
							local id = 3
							if v["has_say_special_"..id] == nil then
								v["has_say_special_"..id] = true
								s:ForceSpeak(item.words.zh[6][id])			--因为似乎没有人在听
								s:SetMood(2)
								v.pause_counter = 0
								v.render_mode = 2
							end
						end
						v.pause_counter = v.pause_counter + 1
					else
						v.pause_counter = 0
					end
				end
				--血条在这里绘制。
				if v.all_state >= 1 and v.all_state <= 4 then
					
				end
			end,
			Special_on_Shader_Params = function(v,name)
				if v.shader_name and name and v.shader_name == name then
					if v.render_mode == 2 then
						v:to_render()
						v.now_update_counter = v.now_update_counter + 1
						if Game():IsPaused() and v.Special_on_Update then
							if s.mood == 1 then
								if v.now_update_counter % 2 == 1 then
									v.Special_on_Update(v)
								end
							else
								v.Special_on_Update(v)
							end
							if v.all_state ~= 0 and v.all_state ~= 5 and v.pause_counter > 480 then
								local id = 4
								if v["has_say_special_"..id] == nil then			--因为似乎没有人在听
									v["has_say_special_"..id] = true
									s:ForceSpeak(item.words.zh[6][id])
									s:SetMood(2)
								end
							end
							v.pause_counter = v.pause_counter + 1
						else
							v.pause_counter = 0
						end
					end
				end
			end,
			Special_on_Update = function(v)		--基础的控制，基本上是所有部分。但具体攻击的实现都委托给sprite来处理。
				local s = v.sprite
				s:Update()
				item.now_pos = v.pos
				item.now_r_pos = Isaac.WorldToScreen(v.pos)
				if v.should_kill then			--结束
					if v.now_frame_counter == 0 then
					end
					if v.now_frame_counter == 180 then
						if save.elses.should_meus_appear and save.elses.should_meus_appear == true then 
							save.elses.should_meus_appear = false
							save.elses.ending_2 = true
						end
						item.finish_meus()
					end
				else
					--策略控制
					if v.all_state == 0 then
						if v["on_first_start_"..v.all_state] == nil then		--初次执行
							v["on_first_start_"..v.all_state] = true
							local wds = item.words.zh[0]
							for i = 1,#wds do
								s:TrySpeak(wds[i])
							end
						end
						if s:WannaSpeak() == false then							--结束初始化
							v.all_state = 1
							s:Play("Idle",true)
						end
					elseif v.all_state == 1 then
						if s:IsPlaying("Idle") then								--选择进攻策略
							if s:IsEventTriggered("Ask") then
								local find_s = {}
								local weigh = 0
								local language = "zh"
								local tg_stags = item.stags[language][v.all_state]
								if #tg_stags > 0 then
									for uu,vv in pairs(tg_stags) do
										if vv.wei == nil then vv.wei = 10 end
										if vv.check == nil or vv.check(v) == true then
											table.insert(find_s,vv)
											weigh = weigh + vv.wei
										end
									end
									local stag = find_s[1]
									weigh = math.random(weigh)
									for uu,vv in pairs(find_s) do
										weigh = weigh - vv.wei
										if weigh <= 0 then
											stag = vv
										end
									end
									stag = tg_stags[1]				--调试用
									v.now_stag = stag
									if stag.name == "辉光·色散" then			--攻击的初始化
										print("mode1")
										v.now_sprite = "Idle_"..v.all_state.."_"..stag.id
										s:Play(v.now_sprite,true)
										s.attack_mode_l = 1
										s.attack_mode_r = 1
										s:TrySetPartPlay(2,"_3")
										s:TrySetPartPlay(3,"_1")
									elseif stag.name == "" then
										
									end
								end
							end
							if v.now_sprite and s:IsFinished(v.now_sprite) then
								v.now_sprite = "Idle"
								s:Play("Idle",true)
							end
						end
						if s:IsPlaying("Zero_test") then
							local rnd = math.random(1000)
							if rnd > 995 then
								local mood = math.random(2)
								print("change mood "..mood)
								s:SetMood(mood)
							end
							local rnd = math.random(1000)
							if rnd > 995 then
								local mood = math.random(2)
								print("change eye "..mood)
								s:SetEyeMode(mood)
							end
						end
					elseif v.all_state == 2 then
					elseif v.all_state == 3 then
					elseif v.all_state == 4 then
					elseif v.all_state == 5 then
					end
					--位置控制
					if v.move_mode == 1 then
						v.pos = v.pos + v.vel
						v.vel = v.vel + v.acce
					elseif v.move_mode == 2 then
					end
					--位置检索
					if v.moving_mode == 1 then		--运动到定点
						v.acce = Vector(0,0)
						local t_s_pos = gui.GetScreenSize()/2
						t_s_pos.Y = t_s_pos.Y / 2
						local t_pos = ui.myScreenToWorld(t_s_pos)
						if v.target_pos then t_pos = v.target_pos end
						local dis = t_pos - v.pos
						if dis:Length() > 10 then
							v.vel = dis/30
						else
							v.vel = Vector(0,0)
						end
					elseif v.move_mode == 2 then		--运动存在减速效果。
						v.vel = v.vel * 0.9
						v.acce = v.acce * 0.9
					end
					--血量控制
					if v.all_state >= 1 and v.all_state <= 4 then
						if v.durable ~= true then
							if v.hitpoint_pointer == nil or v.hitpoint_pointer:Exists() == false then
								v.hitpoint_counter = v.hitpoint_counter + 1
								if v.hitpoint_counter > 5 then
									v.sprite:ForceSpeak(item.words.zh[6][2])
									v.sprite:ForceSpeak(item.words.zh[6][1])
									v.durable = true
								end
								local pnt = Isaac.Spawn(996,enums.Entities.little_duck,0,Vector(2000,2000),v.vel,nil)
								pnt:GetData().is_meus_helper = true
								pnt:GetSprite():Play("None",true)
								v.hitpoint_pointer = pnt
								pnt:SetSize(1,Vector(1,1),8)
								pnt.GridCollisionClass = GridCollisionClass.COLLISION_NONE 
								pnt.MaxHitPoints = item.mx_hp
								pnt.HitPoints = item.mx_hp
								pnt.Mass = 1000
								delay_buffer.addeffe(function(params)
									if pnt and pnt:Exists() then
										pnt:SetSize(31,Vector(1,1.5),8)
									end
								end,{},30)
							end
							local pnt = v.hitpoint_pointer 
							pnt.Position = v.pos + Vector(0,60)
							if v.now_frame_counter % 10 == 1 and math.abs(pnt.HitPoints - item.mx_hp) > 5 then
								v.hitpoint = v.hitpoint + math.max(-1,math.log(item.mx_hp - pnt.HitPoints)/math.log(10))		--会不会有可怜虫越打血越多呢？
								pnt.MaxHitPoints = item.mx_hp
								pnt.HitPoints = item.mx_hp
							else
								
							end
						else
							if v.now_frame_counter % 60 == 1 then
								v.hitpoint = v.hitpoint + 1
							end
						end
					else
						if v.hitpoint_pointer ~= nil then
							v.hitpoint_pointer:Remove()
						end
					end
				end
				v.now_frame_counter = v.now_frame_counter + 1
			end,
			kill = function(v)
				v.should_kill = true
				v.now_frame_counter = 0
			end,
			force_skip_intro = function(v)
				if v.all_state == 0 then
					v.sprite:ForceEndSpeak({word = "",})
					v.sprite:ForceSpeak(item.words.zh[6][8])
				end
			end,
		}
		table.insert(item.to_render,#item.to_render + 1,item.now_hold)
	end
end

function item.try_finish_meus()
	if item.now_hold ~= nil then
		if save.elses.should_meus_appear and save.elses.should_meus_appear == true then
			speak("Meus:Of Course No!!"..auxi.get_players_name().."!!")
		else
			speak("Meus:OK.")
			if item.now_hold.kill then
				item.now_hold.kill(item.now_hold)
			else
				item.finish_meus()
			end
		end
	end
end

function item.try_skip_intro()
	if item.now_hold ~= nil then
		local v = item.now_hold
		if v.all_state == 0 then
			v:force_skip_intro()
		end
	end
end

function item.finish_meus()
	if item.now_hold ~= nil then
		item.now_hold.should_be_remove = true
		item.now_hold = nil
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.should_meus_appear = false
		save.elses.ending_2 = false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	if save.elses.should_meus_appear and save.elses.should_meus_appear == true and item.now_hold == nil then
		if save.UnlockData.Others.Ending1.Unlock == true then
			if level:GetStage() == LevelStage.STAGE7 and room:GetType() == RoomType.ROOM_BOSS and desc.SafeGridIndex > 0 and save.elses.should_end ~= true and desc.Data.Subtype == 70 then
				item.start_meus()
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Meus_Helper_start_1" then
		if item.now_hold and item.should_render_shader then
			if item.now_r_pos == nil then item.now_r_pos = Vector(150,150) end
			if item.now_offset == nil or item.offsets[item.now_offset] == nil then item.now_offset = 1 end
			if item.now_dis == nil then item.now_dis = 0 end
			local ret = {
				pos = {item.now_r_pos.X,item.now_r_pos.Y,0,item.now_dis},
				pos_o = item.offsets[item.now_offset].pos_o(),
				pos_s = item.offsets[item.now_offset].pos_s(),
				should_work = 1,
			}
			return ret
		else
			return {
				pos = {0,0,0,0,},
				pos_o = {0,0,0,0},
				pos_s = {0,0,0,0},
				should_work = 0,
			}
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	if item.now_hold then
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		local room = Game():GetRoom()
		if desc.Data.Type == RoomType.ROOM_ULTRASECRET and desc.Data.Variant == 23790 then
			room:SetWallColor(Color(0.5, 0.5, 0.5, 0, 0.2, 0.2, 0.2))
			room:SetFloorColor(Color(0.5, 0.5, 0.5, 0, 0.2, 0.2, 0.2))
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,str,params)
	if string.lower(str) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] then
			if string.lower(args[1]) == "please" then
				if args[2] and args[3] == nil then
					if args[2] == "start" then
						speak("Meus:OK.A duplication of myself will appear.")
						item.start_meus()
					elseif args[2] == "end" then
						speak("Meus:Fine.")
						item.try_finish_meus()
					elseif args[2] == "skip" then
						speak("Meus:Fine.")
						item.try_skip_intro()
					end
				end
			end
		end
	end
end,
})

return item