local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder")

local item = {
	ToCall = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if save.elses.mirr ~= true and save.elses.mirror and save.elses.mirror == true and room:IsMirrorWorld() ~= save.elses.is_mirror then
			if level:GetStage() == LevelStage.STAGE1_2 and (level:GetStageType() == StageType.STAGETYPE_REPENTANCE or level:GetStageType() == StageType.STAGETYPE_REPENTANCE_B) then
				local room = Game():GetRoom()
				for k,v in pairs({60, 74}) do
					if room:GetGridEntity(v) and room:GetGridEntity(v):GetType() == GridEntityType.GRID_DOOR and room:GetGridEntity(v):ToDoor().TargetRoomIndex == -100 and desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 10000 and desc.Data.Variant <= 10500 then
						--if room:GetGridEntity(v).Desc.Variant ~= 8 then
							local pedestalIdx = 61
							if v == 74 then pedestalIdx = 73 end
							local spawnItem = enums.Items.A_Shard_Of_Glaze
							local q1 = Isaac.Spawn(5,100, spawnItem, room:GetGridPosition(pedestalIdx), Vector.Zero, nil):ToPickup()
							q1:ClearEntityFlags(EntityFlag.FLAG_ITEM_SHOULD_DUPLICATE)
							local d1 = q1:GetData()
							if d1._Data == nil then d1._Data = {} end
							d1._Data.is_glaze_alt_p = true
							consistance_holder.try_hold_entity(q1,"Thread_Glaze",{ignore_subtype = true})
							room:MamaMegaExplosion(room:GetGridPosition(v))
							local s1 = q1:GetSprite()
							s1:ReplaceSpritesheet(5,"gfx/items/to_item_altar.png")
							s1:LoadGraphics()
							s1:SetOverlayFrame("Alternates", 0)
							Game():Darken(1,60)
							Game():ShakeScreen(30)
							save.elses.mirr = true
						--end
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 100,
Function = function(_,ent)
	if save.elses.mirr then
		if ent.Type == 5 and ent.Variant == 100 then
			if consistance_holder.try_check_entity(ent,"Thread_Glaze") then
				local d = ent:GetData()
				if d._Data.is_glaze_alt_p then
					local s = ent:GetSprite()
					s:ReplaceSpritesheet(5,"gfx/items/to_item_altar.png")
					s:LoadGraphics()
					s:SetOverlayFrame("Alternates", 0)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if level:GetStage() == LevelStage.STAGE1_2 and (level:GetStageType() == StageType.STAGETYPE_REPENTANCE or level:GetStageType() == StageType.STAGETYPE_REPENTANCE_B) then
			local room = Game():GetRoom()
			for k,v in pairs({60, 74}) do
				if room:GetGridEntity(v) and room:GetGridEntity(v):GetType() == GridEntityType.GRID_DOOR and room:GetGridEntity(v):ToDoor().TargetRoomIndex == -100 and desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 10000 and desc.Data.Variant <= 10500 then
					local door = room:GetGridEntity(v):ToDoor()
					if door.Desc.Variant ~= 8 then
						local n_entity = Isaac.GetRoomEntities()
						local n_bomb = auxi.getothers(n_entity,4)
						local mrdl = 10000
						for i = 1,#n_bomb do
							local s = n_bomb[i]:GetSprite()
							if s:IsPlaying("Pulse") and n_bomb[i]:GetData()._Data and n_bomb[i]:GetData()._Data.glaze_bomb == true and (n_bomb[i].Position - door.Position):Length() < 100 then
								mrdl = math.min(mrdl,58 - n_bomb[i]:GetSprite():GetFrame())
							end
						end
						local tg = 1
						if room:IsMirrorWorld() then tg = 2 end
						if mrdl == 10000 then
							save.elses.mirror_delay[tg] = -1
						else
							save.elses.mirror_delay[tg] = mrdl
						end
						--print(save.elses.mirror_delay[1])
						--print(save.elses.mirror_delay[2])
						if save.elses.mirror_delay[3 - tg] == nil then save.elses.mirror_delay[3 - tg] = -1 end
						if save.elses.mirror_delay[3 - tg] >= 0 then
							save.elses.mirror_delay[3 - tg] = save.elses.mirror_delay[3 - tg] - 1
						end
						if save.elses.mirror_delay[3 - tg] == 0 then
							save.elses.mirror = true
							if tg == 1 then
								save.elses.is_mirror = true
							else
								save.elses.is_mirror = false
							end
						end
					end
					
					--print(tostring(save.elses.mirror_delay[1]).." "..tostring(save.elses.mirror_delay[2]))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = EntityType.ENTITY_FIREPLACE,
Function = function(_,ent)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	if ent.Type == EntityType.ENTITY_FIREPLACE and ent.Variant == 4 then
		if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
			if save.elses.mirr ~= true and room:IsMirrorWorld() == true then
				local s = ent:GetSprite()
				s:Load("gfx/glaze_fireplace.anm2")
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	save.elses.mirr = false
	save.elses.mirror = false
	save.elses.is_mirror = false
	save.elses.mirror_delay = {-1,-1,}
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.mirr = false
		save.elses.mirror = false
		save.elses.is_mirror = false
		save.elses.mirror_delay = {-1,-1,}
	end
end,
})

return item