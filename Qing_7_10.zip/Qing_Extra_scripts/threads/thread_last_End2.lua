local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local console_holder = require("Qing_Extra_scripts.others.Console_holder")
local meus = require("Qing_Extra_scripts.threads.thread_Meus")

local speak = console_holder.console_speak
local useful_cnt = {}

local item = {
	ToCall = {},
	target = {
		enums.Items.A_Shard_Of_Coin,
		enums.Items.A_Shard_Of_Glaze,
		enums.Items.A_Shard_Of_Lava,
		enums.Items.A_Shard_Of_Meat,
		enums.Items.A_Shard_Of_Rock,
		enums.Items.A_Shard_Of_Blood,
		},
	words = {
		{
			Special = function()
				local player = Game():GetPlayer(0)
				local name = auxi.get_players_name()
				if name == nil then name = player:GetName() end
				return "???:Hey,"..name.."."
			end,
			word = "",
		},
		{
			word = "???:Can you hear me?",
		},
		{
			Special_delay = function()
				if useful_cnt[2] ~= true then
					return false
				end
				return true
			end,
			Should_do_on_ask = function(cmd,params)
				--print(cmd.." "..params)
				if string.lower(cmd) == "yes" then
					useful_cnt[2] = true
				elseif string.lower(cmd) == "no" then
					speak("???:Hey,You must be kidding..Tell me again!")
				end
			end,
			should_do_when_fail = function()
				if useful_cnt[1] == nil then
					speak("(Say 'Yes' or 'No' to continue the game)")
					useful_cnt[1] = true
				end
			end,
		},
		{
			word = "???:OK,I'm sure that the connection has been established.",
			time_conter = 90,
		},
		{
			word = "???:Wait a minute! Me-us?\n		Do you really know WHAT's going on??",
			time_conter = 65,
		},
		{
			Special = function()
				local ret = "Meus:Framony, don't be worry."
				local r1 = "is a"
				local r2 = ""
				local r3 = "he"
				if auxi.get_players_counter() > 1 then 
					r1 = "are"
					r2 = "s"
					r3 = "they"
				end
				ret = ret .. auxi.get_players_name() .. " "..r1.." good boy"..r2..".\n		I believe "..r3.." won't spread the words around."
				return ret
			end,
			time_conter = 65,
		},
		{
			word = "Framony:Well...",
			time_conter = 15,
		},
		{
			Special = function()
				local ret = "Meus:Anyway,"..auxi.get_players_name()..",I have an important thing to tell you!"
				return ret
			end,
		},
		{
			word = "Meus:Please Listen to me Carefully!!",
			time_conter = 45,
		},
		{
			word = "Meus:Now,we have confirmed that you are trapped.",
			time_conter = 35,
		},
		{
			word = "Meus:Deeply trapped..",
			time_conter = 25,
		},
		{
			word = "Meus:In your mind...",
			time_conter = 15,
		},
		{
			word = "Meus:your mind......",
			time_conter = 7,
		},
		{
			word = "Meus:mind..............",
			time_conter = 3,
		},
		{
			word = "Meus:mi...............................",
			time_conter = 45,
		},
		{
			word = "Framony:Directly to the point,OK? We don't have much time,my lord.",
			time_conter = 45,
		},
		{
			word = "Meus:Err...",
			time_conter = 45,
		},
		{
			Special = function()
				local ret = "Meus:OK,I will briefly explain it,"..auxi.get_players_name()..".We are travelling in the interface of the basement to save you."
				return ret
			end,
			time_conter = 45,
		},
		{
			Special = function()
				if auxi.have_player(enums.Players.wq) or auxi.have_player(enums.Players.Spwq) then			--以后要计算皮肤。
					return "Meus:As you have known,Framony and Hreeze had encountered with you in some other places.And I'm so glad that you still wear my best friend's clothes."
				else
					return "Meus:As you have known,Framony and Hreeze had encountered with you in some other places.And I wondered if you have also found my another friend's clothes."
				end
			end,
			time_conter = 45,
		},
		{
			word = "Meus:We are here to search for Prince the Glaze,who turned everything upside down in our homeland.",
			time_conter = 45,
		},
		{
			word = "Meus:And you are also affected.Prince the Glaze managed to hide in your dream so that we can't find him.",
			time_conter = 45,
		},
		{
			word = "Meus:Therefore...",
			time_conter = 30,
		},
		{
			word = "Hreeze:We are getting close now.The connection has become unstable.Shut down the console,Meus!!",
			time_conter = 15,
		},
		{
			Special = function()
				for i = 1,10 do
					delay_buffer.addeffe(function(params)
						local rnd = math.random(3) - 2
						local rnd2 = math.random(1000)/1000 * 0.2 + 1.35
						local rnd3 = math.random(1000)/1000 * 0.2 + 0.95
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_DOGMA_TV_BREAK,rnd2,rnd3,false,rnd,2)
					end,{},3 + math.ceil(i/3))
				end
				return "Meus:Fine.Anyway,what I wanna say is that you hav......"
			end,
			time_conter = 15,
		},
		{
			should_finish = true,
			Special_delay = function()
				if useful_cnt[3] ~= true then
					return false
				end
				return true
			end,
		},
	},
	word_conter = 0,
	word_cnt = 1,
	word = {
		
	},
}

local function start_end()
	--save.elses.should_end = true
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if save.elses.should_end and save.elses.should_end == true then
			if item.word_conter <= 0 then
				if item.words[item.word_cnt] then
					if item.should_finish and item.should_finish then
						save.elses.should_end = false
						save.elses.should_meus_appear = true
						--meus.start_meus()
					end
					if (item.words[item.word_cnt].Special_delay == nil or item.words[item.word_cnt].Special_delay() == true) then
						speak(item.words[item.word_cnt])
						item.word_conter = 30
						if item.words[item.word_cnt].time_conter then
							item.word_conter = item.words[item.word_cnt].time_conter
						end
						item.word_cnt = item.word_cnt + 1
					elseif item.words[item.word_cnt].should_do_when_fail then
						item.words[item.word_cnt].should_do_when_fail()
						item.word_conter = 30
					end
				end
			else
				item.word_conter = item.word_conter - 1
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,cmd,params)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if save.elses.should_end and save.elses.should_end == true then
			if item.words[item.word_cnt] and item.words[item.word_cnt].Should_do_on_ask then
				item.words[item.word_cnt].Should_do_on_ask(cmd,params)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 340,
Function = function(_,ent)
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if save.elses.should_end and save.elses.should_end == true then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 370,
Function = function(_,ent)
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if save.elses.should_end and save.elses.should_end == true then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,Rng,spwnpos)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if level:GetStage() == LevelStage.STAGE7 and room:GetType() == RoomType.ROOM_BOSS and desc.SafeGridIndex > 0 and save.elses.should_end ~= true then --and desc.Data.Subtype == 70 then
			local cnt = 0
			for u,v in pairs(item.target) do
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					if player:HasCollectible(v) then
						cnt = cnt + 1
						break
					end
				end
			end
			if cnt >= 5 then
				start_end()
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		if save.UnlockData.Others.Ending1.Unlock == true then
			save.elses.should_end = false
		end
	end
end,
})

--l print(Game():GetLevel():GetCurrentRoomDesc().Data.Variant)
--l local room = Game():GetRoom();local size = room:GetGridSize();for i = 0,size - 1 do local gent = room:GetGridEntity(i);if (gent) then if gent:GetType() == GridEntityType.GRID_PRESSURE_PLATE and gent:GetVariant() == 9 then gent:Destroy(true); end end end
return item