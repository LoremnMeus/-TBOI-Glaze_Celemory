local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local wind = require("Qing_Extra_scripts.Enemies.enemy_wildwind")
local Hreeze = require("Qing_Extra_scripts.Enemies.enemy_hreeze")

local item = {
	ToCall = {},
	myToCall = {},
}

local rng = RNG()

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then		--击败大霍恩之后才开始。
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE and (save.elses.should_Hreeze_spawn == true) then
			
		end
	end
end,
})

--l print(Game():GetLevel():GetCurrentRoomDesc().SafeGridIndex)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,Rng,spwnpos)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if level:GetStage() == LevelStage.STAGE3_1 and stageType >= StageType.STAGETYPE_REPENTANCE and room:GetType() == RoomType.ROOM_BOSS and desc.SafeGridIndex > 0 and (save.elses.should_Hreeze_spawn == nil or save.elses.should_Hreeze_spawn == false) and (save.elses.Hreeze_end ~= true) then
			local str = "风暴开始席卷大地"
			if Options.Language == "en" then str = "The Wind is blowing heavily" end
			gui.general_speak(Vector(0,0),str,0,#str * 3 + 20,1,1,2,2,0)
			save.elses.should_Hreeze_spawn = true
			local q = wind.start_()
			local sgid = desc.SafeGridIndex
			if save.elses["Hreeze_room_conter_"..sgid] ~= 0 then
				wind.change_control(1,{dir = save.elses["Hreeze_room_dir_"..sgid],power = save.elses["Hreeze_room_conter_"..sgid],})
			else
				wind.change_control(2,{pos = room:GetCenterPos(),})
			end
			if save.elses.wind_in_secret then
				local player = Game():GetPlayer(0)
				player:UsePill(PillEffect.PILLEFFECT_SEE_FOREVER, PillColor.PILL_NULL, UseFlag.USE_NOANIM | UseFlag.USE_NOANNOUNCER | UseFlag.USE_MIMIC)
				save.elses.wind_in_secret = false
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_NEW_LEVEL, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		save.elses.should_Hreeze_spawn = false
		save.elses.Hreeze_end = nil
		for i = 0,150 do
			save.elses["Hreeze_room_conter_"..i] = nil
			save.elses["Hreeze_room_dir_"..i] = nil
			save.elses["Hreeze_room"] = nil
		end
		rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
		if level:GetStage() == LevelStage.STAGE3_1 and stageType >= StageType.STAGETYPE_REPENTANCE then		--在下层的瞬间确定熏风小姐的降落地点，同时用bfs计算出所有房间的位置。
			local rooms = level:GetRooms()
			local tg = {}
			local secret = {}
			for i = 0, rooms.Size do
				local targ = rooms:Get(i)
				if targ ~= nil and targ.SafeGridIndex >= 0 then
					local id = targ.SafeGridIndex
					local desc = level:GetRoomByIdx(id)
					if desc.Data.Shape == 1 and desc.Data.Type ~= 5 and desc.Data.Type ~= 29 and desc.Data.Type ~= 11 then		--不会是挑战房、boss房或是红隐。
						table.insert(tg,#tg+1,targ)
					end
					if desc.Data.Type == 7 then		--隐藏房单独处理。
						table.insert(secret,#secret+1,targ)
					end
				end
			end
			local targ_id = math.random(#tg)
			local targ = tg[targ_id]
			local id = targ.SafeGridIndex
			local desc = level:GetRoomByIdx(id)
			if desc.Data.Type == 7 or desc.Data.Type == 8 then 
				save.elses.wind_in_secret = true 		--随机生成在隐藏或超隐的时候，提供一个i can see。
			else
				save.elses.wind_in_secret = false
			end
			local tg2 = {}		--尝试运用bfs算法。
			table.insert(tg2,{id = targ.SafeGridIndex,power = 0,})		--注意！总是传入safegridindex！！
			save.elses["Hreeze_room_conter_"..targ.SafeGridIndex] = 0
			save.elses["Hreeze_room_dir_"..targ.SafeGridIndex] = -1		--方向沿用以撒的好了
			save.elses["Hreeze_room"] = targ.SafeGridIndex
			--print(targ.SafeGridIndex)
			while(#tg2 > 0) do
				local ntg = {}
				for u,v in pairs(tg2) do
					local pos_rou = auxi.move_in_rou(v.id,13,13)
					local pos_tg = {v.id,}
					for u1,v1 in pairs(pos_rou) do
						if level:GetRoomByIdx(v1).SafeGridIndex == v.id then		--是同一房间
							table.insert(pos_tg,#pos_tg+1,v1)
						end
					end
					for u1,v1 in pairs(pos_tg) do
						local pos_pos = auxi.move_in_sq(v1,13,13)
						for u2,v2 in pairs(pos_pos) do
							local tar = level:GetRoomByIdx(v2.id)
							local sgid = tar.SafeGridIndex
							if sgid > 0 and tar.Data.Type ~= 7 and (save.elses["Hreeze_room_conter_"..sgid] == nil or save.elses["Hreeze_room_conter_"..sgid] > v.power + 1) then		--希望我的bfs没写错
								save.elses["Hreeze_room_conter_"..sgid] = v.power + 1
								save.elses["Hreeze_room_dir_"..sgid] = v2.dir
								table.insert(ntg,#ntg+1,{id = sgid,power = v.power + 1,})
								--print(sgid.." "..v.power + 1)
							end
						end
					end
				end
				tg2 = ntg
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	--print(2)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if level:GetStage() == LevelStage.STAGE3_1 and stageType >= StageType.STAGETYPE_REPENTANCE and desc.SafeGridIndex > 0 and save.elses.should_Hreeze_spawn == true then
			local sgid = desc.SafeGridIndex
			if save.elses["Hreeze_room_conter_"..sgid] ~= nil then
				local q = wind.start_()
				--print(save.elses["Hreeze_room_conter_"..sgid])
				if save.elses["Hreeze_room_conter_"..sgid] ~= 0 then
					wind.change_control(1,{dir = save.elses["Hreeze_room_dir_"..sgid],power = save.elses["Hreeze_room_conter_"..sgid],})
				else
					local size = room:GetGridSize()
					for i = 0,size - 1 do
						local gent = room:GetGridEntity(i)
						if (gent) then
							local s = gent:GetSprite()
							if gent:GetType() == GridEntityType.GRID_PRESSURE_PLATE and gent:GetVariant() == 9 then
								Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01, 0, room:GetGridPosition(i), Vector(0, 0), nil)		--记得移除压力板
								room:RemoveGridEntity(i, 0, true)
							end
						end
					end
					local hreeze = Hreeze.start_()
					wind.change_control(3,{ent = hreeze,delta_pos = Vector(0,-20)})
				end
			end
		end
	end
end,
})

--l print(Game():GetLevel():GetCurrentRoomDesc().Data.Variant)
--l local room = Game():GetRoom();local size = room:GetGridSize();for i = 0,size - 1 do local gent = room:GetGridEntity(i);if (gent) then if gent:GetType() == GridEntityType.GRID_PRESSURE_PLATE and gent:GetVariant() == 9 then gent:Destroy(true); end end end
return item