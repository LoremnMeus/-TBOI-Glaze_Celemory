local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local console_holder = require("Qing_Extra_scripts.others.Console_holder")
local Screen_Filter = require("Qing_Extra_scripts.others.Screen_Filter")

local item = {
	pre_ToCall = {},
	ToCall = {},
	myToCall = {},
	post_ToCall = {},
	target_item = enums.Items.Reversal_Film,
}

local function clear_stats()
	save.elses.Shadoll_start = nil
	save.elses.special_Shadoll_start = nil
	save.elses.shift_to_death = nil
	save.elses.Shadoll_door_value = nil
	save.elses.shadoll_item = nil
	--print(save.elses.shadoll_level)
	save.elses.shadoll_level = math.max(0,(save.elses.shadoll_level or 1) - 1)
	--print(save.elses.shadoll_level)
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_LOSE_COLLECTIBLE, params = CollectibleType.COLLECTIBLE_NEGATIVE,
Function = function(_,player,col,num,curNum)
	if auxi.get_acceptible_level() == 6 then
		if num == 1 then
			local room = Game():GetRoom()
			for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
				local door = room:GetDoor(slot)
				if door then
					local s = door:GetSprite()
					--print(s:GetFilename().." " .. door.TargetRoomIndex.." " ..(player.Position - door.Position):Length())
					if ((player.Position - door.Position):Length() <= 50) then
						if door.TargetRoomIndex == -10 and s:GetFilename() == "gfx/grid/Door_Mausoleum_Alt.anm2" and s:IsPlaying("Open") then
							save.elses.Shadoll_start = true
						end
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.target_item) then
		if auxi.get_acceptible_level() == 6 then
			local level = Game():GetLevel()
			local room = Game():GetRoom()
			if(level:GetCurrentRoomIndex() == 84) then
				for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
					local door = room:GetDoor(slot)
					if door then
						local s = door:GetSprite()
						local doorTarget = door.TargetRoomIndex
						if ((player.Position - door.Position):Length() <= 35) then
							--print(s:GetFilename().." "..s:GetAnimation())
							if doorTarget == -10 and s:GetFilename() == "gfx/grid/Door_Mausoleum_Alt.anm2" and (s:IsPlaying("Closed") or s:IsFinished("Closed") or s:IsPlaying("KeyClosed") or s:IsFinished("KeyClosed")) then
								room:RemoveDoor(slot)
								grid_manager.functs.try_spawn_grid_door(room,slot,nil,{check_and_leave = function(doorinfo)
									local door = doorinfo.door
									local s = door:GetSprite()
									if s:IsPlaying("Opened") or s:IsFinished("Opened") then
										local player = Game():GetPlayer(0)
										save.elses.shift_to_death = true
										item.shift_to_death = true
										Screen_Filter.add_filter(25)
										player:UseActiveItem(CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE,UseFlag.USE_NOANIM)
										for i = 1,15 do player:Update() end 
									end
								end,should_update = true,loadname = "gfx/grid/Door_Mausoleum_Alt_shaddoll.anm2",playname = "Open",should_not_allow = true,on_update = function(doorinfo)
									local door = doorinfo.door
									local s = door:GetSprite()
									if s:IsFinished("Open") then
										door.CollisionClass = GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER
										s:Play("Opened",true)
									end
								end,mov = 15,})
								player:RemoveCollectible(item.target_item)
								save.elses.special_Shadoll_start = true
								sound_tracker.PlayStackedSound(52,1,0.7,false,0,2)
								delay_buffer.addeffe(function(params)
									sound_tracker.PlayStackedSound(enums.SoundEffect.Betray,1,1,false,0,5)
								end,{},1)
							end
						end
					end
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		clear_stats()
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_NEW_LEVEL, params = nil,
Function = function(_)
	clear_stats()
end,
})

--l print(Game():GetLevel():GetCurrentRoomIndex())
--l local player = Game():GetPlayer(0) player:UseActiveItem(CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE) for i = 1,15 do player:Update() end 
--l for i = 1,30 do Game():Update() end
--l Game():StartRoomTransition(84,1,RoomTransitionAnim.WALK,nil,0)
--l local desc = Game():GetLevel():GetCurrentRoomDesc() print(desc.Data.Variant)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	
	--print(save.elses.shadoll_level or 0)
	if save.elses.shadoll_level and save.elses.shadoll_level > 0 then
		if auxi.get_acceptible_level() == 6 then
			if(level:GetCurrentRoomIndex() == 84) then
				for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
					local door = room:GetDoor(slot)
					if door then
						local s = door:GetSprite()
						if s:GetFilename() == "gfx/grid/Door_Mausoleum_Alt.anm2" then
							room:RemoveDoor(slot)
						end
					end
				end
			end
		end
	else
		if item.shadoll_center then
			item.shadoll_center = nil
			if auxi.get_acceptible_level() == 6 and level:GetCurrentRoomIndex() == 84 then
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					player.Position = room:FindFreePickupSpawnPosition(room:GetCenterPos(),10,true)
				end
			end
		end
		if save.elses.special_Shadoll_start then
			if auxi.get_acceptible_level() == 6 then
				if(level:GetCurrentRoomIndex() == 84) then
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
						local door = room:GetDoor(slot)
						if door then
							local s = door:GetSprite()
							if s:GetFilename() == "gfx/grid/Door_Mausoleum_Alt.anm2" then
								room:RemoveDoor(slot)
								grid_manager.functs.try_spawn_grid_door(room,slot,nil,{check_and_leave = function(doorinfo)
									local player = Game():GetPlayer(0)
									save.elses.shift_to_death = true
									item.shift_to_death = true
									Screen_Filter.add_filter(25)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE,UseFlag.USE_NOANIM)
									for i = 1,15 do player:Update() end 
								end,should_update = true,loadname = "gfx/grid/Door_Mausoleum_Alt_shaddoll.anm2",playname = "Opened",mov = 15,})
							end
						end
						if item.pos_hold_it then
							item.pos_hold_it = nil
							for playerNum = 1, Game():GetNumPlayers() do
								local player = Game():GetPlayer(playerNum - 1)
								player.Position = room:GetGridPosition(22)
							end
						end
					end
				end
			end
			if save.elses.shift_to_death and desc.Data.Variant == 100 and Game():GetLevel():GetCurrentRoomIndex() == 80 then
				grid_manager.functs.try_spawn_grid_door(room,nil,100,{check_and_leave = function(doorinfo)
					Game():StartRoomTransition(84,0,RoomTransitionAnim.FADE_MIRROR,nil,0)
					item.pos_hold_it = true
					--l Game():StartRoomTransition(80,0,RoomTransitionAnim.FADE_MIRROR,nil,-1)
				end,should_update = true,loadname = "gfx/grid/Door_Mausoleum_Alt_shaddoll.anm2",playname = "Opened",dir = 3,})
				if item.shift_to_death then 
					--if item.shift_to_death == 1 then
						item.shift_to_death = nil 
						--for playerNum = 1, Game():GetNumPlayers() do
						--	local player = Game():GetPlayer(playerNum - 1)
						--	delay_buffer.addeffe(function(params)
						--		player.Position = room:GetGridPosition(85)
						--	end,{},1)
						--end
					--else
						--item.shift_to_death = 1
						--local rng = Game():GetPlayer(0):GetCollectibleRNG(item.target_item)
						--Game():StartRoomTransition(level:GetRandomRoomIndex(false,rng:GetSeed()),0,RoomTransitionAnim.FADE_MIRROR,nil,-1)
						--rng:Next()
	--					Game():StartRoomTransition(80,0,RoomTransitionAnim.FADE_MIRROR,nil,-1)
					--end
					--l Game():StartStageTransition(true,1)
					--l Game():GetLevel():SetStage(LevelStage.STAGE3_2, StageType.STAGETYPE_ORIGINAL)
					--l Game():ShowHallucination(0,38) SFXManager():Stop(SoundEffect.SOUND_DEATH_CARD) local room = Game():GetRoom() room:SetFloorColor(Color(1,-1,1,1)) room:SetWallColor(Color(1,-1,1,1))
				end
			end
		end
		if save.elses.Shadoll_start then
			--print(1)
			--print(level:GetCurrentRoomIndex().." " .. desc.Data.Type)
			if auxi.get_acceptible_level() == 6 and level:GetCurrentRoomIndex() == -10 and desc.Data.Type == 27 then
				local desc = level:GetRoomByIdx(level:GetCurrentRoomDesc().SafeGridIndex)
				if desc then
					desc.Flags = desc.Flags | RoomDescriptor.FLAG_PITCH_BLACK
				end
				if save.elses.Shadoll_door_value == nil then
					grid_manager.functs.try_spawn_grid_door(room,1,nil,{check_and_leave = function(doorinfo)
						local door = doorinfo.door
						local s = door:GetSprite()
						for i = 1,3 do
							if s:IsPlaying("Opened"..tostring(i)) or s:IsFinished("Opened"..tostring(i)) then
								if i == 1 then
									Game():GetLevel():SetStage(LevelStage.STAGE5, StageType.STAGETYPE_WOTL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(35)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
									--for i = 1,20 do player:Update() end 
									--Game():StartRoomTransition(84,1,RoomTransitionAnim.PIXELATION,nil,-1)
								elseif i == 2 then
									save.elses.shadoll_level = 2
									Game():GetLevel():SetStage(LevelStage.STAGE3_2, StageType.STAGETYPE_ORIGINAL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(60)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
								else
									Game():GetLevel():SetStage(LevelStage.STAGE5, StageType.STAGETYPE_ORIGINAL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(35)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
									--for i = 1,20 do player:Update() end 
									--Game():StartRoomTransition(84,1,RoomTransitionAnim.PIXELATION,nil,-1)
								end
							end
						end
					end,should_update = true,loadname = "gfx/grid/Door_Mausoleum_Alt_shaddoll2.anm2",playname = "KeyClosed",should_not_allow = true,on_update = function(doorinfo)
						local door = doorinfo.door
						local s = door:GetSprite()
						if s:IsPlaying("KeyClosed") or s:IsFinished("KeyClosed") then
							for playerNum = 1, Game():GetNumPlayers() do
								local player = Game():GetPlayer(playerNum - 1)
								if (player.Position - door.Position):Length() <= 35 then
									if player:GetCollectibleNum(item.target_item,true) > 0 then
										player:RemoveCollectible(item.target_item)
										s:Play("Open2",true)
										save.elses.Shadoll_door_value = 2
										sound_tracker.PlayStackedSound(52,1,1,false,0,2)
										break
									elseif player:GetCollectibleNum(CollectibleType.COLLECTIBLE_POLAROID,true) > 0 then
										player:RemoveCollectible(CollectibleType.COLLECTIBLE_POLAROID)
										s:Play("Open1",true)
										save.elses.Shadoll_door_value = 1
										sound_tracker.PlayStackedSound(52,1,0.5,false,0,2)
										break
									elseif player:GetCollectibleNum(CollectibleType.COLLECTIBLE_NEGATIVE,true) > 0 then
										player:RemoveCollectible(CollectibleType.COLLECTIBLE_NEGATIVE)
										s:Play("Open3",true)
										save.elses.Shadoll_door_value = 3
										sound_tracker.PlayStackedSound(52,1,1.5,false,0,2)
										break
									end
								end
							end
						end
						for i = 1,3 do
							if s:IsFinished("Open"..tostring(i)) then
								door.CollisionClass = GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER
								s:Play("Opened"..tostring(i),true)
							end
						end
					end,mov = 15,})
				else
					grid_manager.functs.try_spawn_grid_door(room,1,nil,{check_and_leave = function(doorinfo)
						local door = doorinfo.door
						local s = door:GetSprite()
						for i = 1,3 do
							if s:IsPlaying("Opened"..tostring(i)) or s:IsFinished("Opened"..tostring(i)) then
								if i == 1 then
									Game():GetLevel():SetStage(LevelStage.STAGE5, StageType.STAGETYPE_WOTL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(35)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
									--for i = 1,20 do player:Update() end 
									--Game():StartRoomTransition(84,1,RoomTransitionAnim.PIXELATION,nil,-1)
								elseif i == 2 then
									save.elses.shadoll_level = 2
									Game():GetLevel():SetStage(LevelStage.STAGE3_2, StageType.STAGETYPE_ORIGINAL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(35)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
								else
									Game():GetLevel():SetStage(LevelStage.STAGE5, StageType.STAGETYPE_ORIGINAL)
									local player = Game():GetPlayer(0)
									Screen_Filter.add_filter(35)
									player:UseActiveItem(CollectibleType.COLLECTIBLE_FORGET_ME_NOW,UseFlag.USE_NOANIM)
									--for i = 1,20 do player:Update() end 
									--Game():StartRoomTransition(84,1,RoomTransitionAnim.PIXELATION,nil,-1)
								end
							end
						end
					end,should_update = true,loadname = "gfx/grid/Door_Mausoleum_Alt_shaddoll2.anm2",playname = "Opened"..tostring(save.elses.Shadoll_door_value),on_update = function(doorinfo)
						local door = doorinfo.door
						local s = door:GetSprite()
						for i = 1,3 do
							if s:IsFinished("Open"..tostring(i)) then
								door.CollisionClass = GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER
								s:Play("Opened"..tostring(i),true)
							end
						end
					end,mov = 15,})
				end
			end
		
			if auxi.get_acceptible_level() == 6 and desc.Data.Type == 5 and room:IsCurrentRoomLastBoss() and room:IsClear() then
				if save.elses.shadoll_item == nil then
					local q1 = Isaac.Spawn(5,100, item.target_item, room:FindFreePickupSpawnPosition(room:GetCenterPos(),10,true), Vector.Zero, nil):ToPickup()
					q1:ClearEntityFlags(EntityFlag.FLAG_ITEM_SHOULD_DUPLICATE)
					local d1 = q1:GetData()
					save.elses.shadoll_item = true
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_GAIN_COLLECTIBLE, params = item.target_item,
Function = function(_,player,collid,count,touched)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	if Game():IsGreedMode() == false and auxi.get_acceptible_level() == 6 and desc.Data.Type == 5 and room:IsCurrentRoomLastBoss() and room:IsClear() then
		player:PlayExtraAnimation("DeathTeleport")
		Game():StartRoomTransition(84, Direction.NO_DIRECTION, RoomTransitionAnim.PIXELATION, player)
		item.shadoll_center = true
	end
end,
})


return item