local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")

local item = {
	ToCall = {},
}

local rng = RNG()
--l print(Game():GetLevel():GetCurrentRoomDesc().SafeGridIndex)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,Rng,spwnpos)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE and room:GetType() == RoomType.ROOM_BOSS and desc.SafeGridIndex > 0 and (save.elses.should_piece_door_spawn == nil or save.elses.should_piece_door_spawn == false) then
			--print("boss_finish")
			local str = "棋盘已开启"
			if Options.Language == "en" then str = "Check Board Has Appeared in the Level." end
			gui.general_speak(Vector(0,0),str,0,#str * 3 + 20,1,1,2,0,0)
			save.elses.should_piece_door_spawn = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		save.elses.should_piece_door_spawn = false
		rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE then
			local rooms = level:GetRooms()
			for i = 0, rooms.Size do
				local targ = rooms:Get(i)
				if targ ~= nil and targ.SafeGridIndex >= 0 then
					for i = 0,7 do
						save.elses["thread_stone"..tostring(targ.SafeGridIndex).."_"..tostring(i)] = false
					end
				end
			end
			save.elses.thread_stone_piece_door_counter = 0
			save.elses.thread_stone_piece_room = -1
			save.elses.thread_stone_piece_door = 0
		end
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE and room:GetType() ~= RoomType.ROOM_BOSS and desc.SafeGridIndex > 0 and (save.elses.should_piece_door_spawn == nil or save.elses.should_piece_door_spawn == false or save.elses.thread_stone_piece_door_counter == 0) then
			for i = 0,7 do
				if room:IsDoorSlotAllowed(i) and room:GetDoor(i) == nil then
					if save.elses["thread_stone"..tostring(desc.SafeGridIndex).."_"..tostring(i)] ~= true then
						if save.elses.thread_stone_piece_door_counter == nil then save.elses.thread_stone_piece_door_counter = 0 end
						save.elses.thread_stone_piece_door_counter = save.elses.thread_stone_piece_door_counter + 1
						if rng:RandomInt(save.elses.thread_stone_piece_door_counter) == 0 then
							save.elses.thread_stone_piece_room = desc.SafeGridIndex
							save.elses.thread_stone_piece_door = i
						end
						save.elses["thread_stone"..tostring(desc.SafeGridIndex).."_"..tostring(i)] = true
					end
				end
			end
			--print(tostring(save.elses.thread_stone_piece_door_counter).." "..tostring(save.elses.thread_stone_piece_room).." "..tostring(save.elses.thread_stone_piece_door))
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE and room:GetType() ~= RoomType.ROOM_BOSS and room:GetType() ~= RoomType.ROOM_CHALLENGE and desc.SafeGridIndex > 0 and (save.elses.should_piece_door_spawn == nil or save.elses.should_piece_door_spawn == false or save.elses.thread_stone_piece_door_counter == 0) then
			for i = 0,7 do
				if room:IsDoorSlotAllowed(i) and room:GetDoor(i) == nil then
					if save.elses["thread_stone"..tostring(desc.SafeGridIndex).."_"..tostring(i)] ~= true then
						if save.elses.thread_stone_piece_door_counter == nil then save.elses.thread_stone_piece_door_counter = 0 end
						save.elses.thread_stone_piece_door_counter = save.elses.thread_stone_piece_door_counter + 1
						if rng:RandomInt(save.elses.thread_stone_piece_door_counter) == 0 then
							save.elses.thread_stone_piece_room = desc.SafeGridIndex
							save.elses.thread_stone_piece_door = i
						end
						save.elses["thread_stone"..tostring(desc.SafeGridIndex).."_"..tostring(i)] = true
					end
				end
			end
			--print(tostring(save.elses.thread_stone_piece_door_counter).." "..tostring(save.elses.thread_stone_piece_room).." "..tostring(save.elses.thread_stone_piece_door))
		end
		if desc.Data.Type == RoomType.ROOM_DEFAULT and desc.Data.Variant >= 23752 and desc.Data.Variant <= 23762 then
			save.elses.should_piece_door_spawn = false
		end
		if level:GetStage() == LevelStage.STAGE2_1 and stageType >= StageType.STAGETYPE_REPENTANCE and (save.elses.should_piece_door_spawn == true) then
			if save.elses.thread_stone_piece_room >= 0 and desc.SafeGridIndex == save.elses.thread_stone_piece_room then
				local slot = save.elses.thread_stone_piece_door
				local rnd = rng:RandomInt(11)
				local g = grid_manager.functs.try_spawn_grid_door(room,slot,nil,{check_and_leave = "s.default."..tostring(rnd + 23752),should_update = true,loadname = "gfx/grid/door_checkboarddoor.anm2",playname = "Appear_and_Open",
				vr = rnd + 23752,special_reminder = function()
					local room = Game():GetRoom()
					local pos = room:GetGridPosition(172)
					for playerNum = 1, Game():GetNumPlayers() do
						local player = Game():GetPlayer(playerNum - 1)
						player.Position = pos
						player.Velocity = Vector(0,0)
					end
					return 10
				end,should_not_allow = true,on_update = function(doorinfo)
					local door = doorinfo.door
					local s = door:GetSprite()
					if s:IsFinished("Appear_and_Open") then
						s:Play("Opened",true)
						door.CollisionClass = GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER
					end
					if not s:IsPlaying("Opened") and not s:IsPlaying("Appear_and_Open") then
						s:Play("Appear_and_Open",true)
					end
				end})
				sound_tracker.PlayStackedSound(52,1,0.7,false,0,2)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local level = Game():GetLevel()
	local desc = level:GetCurrentRoomDesc()
	local stage = Game():GetLevel():GetStage()
	local stageType = level:GetStageType()
	if save.UnlockData.Others.Ending1.Unlock == true then
		if stageType >= StageType.STAGETYPE_REPENTANCE and Game():GetLevel():GetCurrentRoomDesc().SafeGridIndex == -11 and desc.Data.Variant == 1000 and room:IsFirstVisit() then
			local n_ent = Isaac.GetRoomEntities()
			local keys = auxi.getothers(n_ent,5,30,1)
			if #keys > 0 then
				local targ = keys[1]:ToPickup()
				targ:Morph(5,100,enums.Items.A_Shard_Of_Rock,false,false,true)
			end
		end
	end
end,
})

--l print(Game():GetLevel():GetCurrentRoomDesc().Data.Variant)

return item