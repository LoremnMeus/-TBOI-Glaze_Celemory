local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local dropping_holder = require("Qing_Extra_scripts.others.Dropping_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local option_index_holder = require("Qing_Extra_scripts.others.Option_Index_holder")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local ui = require("Qing_Extra_scripts.auxiliary.ui")
local Achievement_Display_holder = require("Qing_Extra_scripts.others.Achievement_Display_holder")

local Lure_effect = Sprite()
Lure_effect:Load("gfx/Tarot_Lure_effect.anm2",true)
Lure_effect:Play("Idle",true)

local Art_effect = Sprite()
Art_effect:Load("gfx/Tarot_Art_effect.anm2",true)
Art_effect:Play("Idle",true)

local itemList = auxi.GetItemList()

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Items.Book_of_Thoth,		--这样显式地列出来感觉好帅
	cards = {
		[enums.Cards.Adjustment] = {},
		[enums.Cards.Lure] = {},
		[enums.Cards.Art] = {},
		[enums.Cards.Aeon] = {},
		[enums.Cards.Universe] = {},
		[enums.Cards.Adjustment_r] = {},
		[enums.Cards.Lure_r] = {},
		[enums.Cards.Art_r] = {},
		[enums.Cards.Aeon_r] = {},
		[enums.Cards.Universe_r] = {},
	},
	card1 = enums.Cards.Adjustment,
	card2 = enums.Cards.Lure,
	card3 = enums.Cards.Art,
	card4 = enums.Cards.Aeon,
	card5 = enums.Cards.Universe,
	card6 = enums.Cards.Adjustment_r,
	card7 = enums.Cards.Lure_r,
	card8 = enums.Cards.Art_r,
	card9 = enums.Cards.Aeon_r,
	card10 = enums.Cards.Universe_r,
	Star_items = {
		588,589,590,591,592,593,594,595,596,597,598,enums.Items.Pendulum_Star,
		233,651,
		299,300,301,302,303,304,305,306,307,308,309,318,
	},
	render_counter = 0,
	color_map = {
		Color(1,0,0,1,1,0,0),
		Color(1,0.5,0,1,1,0.5,0),
		Color(1,1,0,1,1,1,0),
		Color(0.5,1,0,1,0.5,1,0),
		Color(0,1,0,1,0,1,0),
		Color(0,1,0.5,1,0,1,0.5),
		Color(0,1,1,1,0,1,1),
		Color(0,0.5,1,1,0,0.5,1),
		Color(0,0,1,1,0,0,1),
		Color(0.5,0,1,1,0.5,0,1),		--10
		Color(1,0,1,1,1,0,1),
		Color(1,0,0.5,1,1,0,0.5),
	},
}

local function get_thoth_color(count)
	if count >= 46 then 
		return Color(1,1,1,1,1,1,1)
	elseif count >= 23 then
		return item.color_map[Game():GetFrameCount()% 12 + 1]
	elseif count > 13 then
		return Color(1,0.2,1,1,0.6,0.1,0.6)
	elseif count > 9 then
		return Color(0.2,1,0.2,1,0.1,0.6,0.1)
	elseif count > 5 then
		return Color(1,0.2,0.2,1,0.1,0.1,0.1)
	elseif count > 2 then
		return Color(0.2,0.2,1,1,0.1,0.1,1)
	elseif count > 0 then
		return Color(0.5,0.5,0.5,1,0.3,0.3,0.3)
	end
	return Color(1,1,1,1)
end

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local d = player:GetData()
	local i = d.__Index
	if i ~= nil then
		if save.elses["Thoth_cd1_effect"..tostring(i)] == nil or save.elses["Thoth_cd1_effect"..tostring(i)] < 0 then save.elses["Thoth_cd1_effect"..tostring(i)] = 0 end
		if save.elses["Thoth_cd6_effect"..tostring(i)] == nil or save.elses["Thoth_cd6_effect"..tostring(i)] < 0 then save.elses["Thoth_cd6_effect"..tostring(i)] = 0 end
		if save.elses["Thoth_cd9_effect"..tostring(i)] == nil then save.elses["Thoth_cd9_effect"..tostring(i)] = 0 end
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage + auxi.get_damage_multiplier(player) * (((math.sqrt(save.elses["Thoth_cd1_effect"..tostring(i)] + 10) - math.sqrt(10)) * 0.2 + (math.sqrt(save.elses["Thoth_cd6_effect"..tostring(i)] + 5) - math.sqrt(5)) * 0.3) * 0.7 + math.sqrt(save.elses["Thoth_cd9_effect"..tostring(i)] * 1.2))
			if d.Thoth_cd7_effect then
				if d.Thoth_cd7_effect == 1 then
					player.Damage = player.Damage * 0.7
				elseif d.Thoth_cd7_effect == 2 then
					player.Damage = player.Damage * 0.4
				end
			end
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay , auxi.get_mxdelay_multiplier(player) * (((math.sqrt(save.elses["Thoth_cd1_effect"..tostring(i)] + 10) - math.sqrt(10)) * 0.2 + (math.sqrt(save.elses["Thoth_cd6_effect"..tostring(i)] + 5) - math.sqrt(5)) * 0.3) * 0.7 + math.sqrt(save.elses["Thoth_cd9_effect"..tostring(i)]) * 0.7))
			if d.Thoth_cd7_effect then
				if d.Thoth_cd7_effect == 1 then
					player.MaxFireDelay = math.abs(player.MaxFireDelay) * 1.5
				elseif d.Thoth_cd7_effect == 2 then
					player.MaxFireDelay = math.abs(player.MaxFireDelay) * 2
				end
			end
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange + ((math.sqrt(save.elses["Thoth_cd1_effect"..tostring(i)] + 10) - math.sqrt(10)) * 0.2 + (math.sqrt(save.elses["Thoth_cd6_effect"..tostring(i)] + 5) - math.sqrt(5)) * 0.3 + math.sqrt(save.elses["Thoth_cd9_effect"..tostring(i)]) * 4) * 10
			if d.Thoth_cd7_effect then
				if d.Thoth_cd7_effect == 1 then
					player.TearRange = math.abs(player.TearRange - 4 * 40) * 0.5 + 4 * 40
				elseif d.Thoth_cd7_effect == 2 then
					player.TearRange = math.abs(player.TearRange - 4 * 40) * 0.3 + 4 * 40
				end
			end
		end
		if cacheFlag == CacheFlag.CACHE_SPEED then
			player.MoveSpeed = player.MoveSpeed + ((math.sqrt(save.elses["Thoth_cd1_effect"..tostring(i)] + 10) - math.sqrt(10)) * 0.2 + (math.sqrt(save.elses["Thoth_cd6_effect"..tostring(i)] + 5) - math.sqrt(5)) * 0.3 + math.sqrt(save.elses["Thoth_cd9_effect"..tostring(i)]) * 1.2) * 0.13
			if d.Thoth_cd7_effect then
				if d.Thoth_cd7_effect == 1 then
					player.MoveSpeed = math.abs(player.MoveSpeed - 0.5) * 0.7 + 0.5
				elseif d.Thoth_cd7_effect == 2 then
					player.MoveSpeed = math.abs(player.MoveSpeed - 0.5) * 0.5 + 0.5
				end
			end
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			player.Luck = player.Luck + ((math.sqrt(save.elses["Thoth_cd1_effect"..tostring(i)] + 10) - math.sqrt(10)) * 0.2 + (math.sqrt(save.elses["Thoth_cd6_effect"..tostring(i)] + 5) - math.sqrt(5)) * 0.3) * 0.4
			if d.Thoth_cd7_effect then
				if d.Thoth_cd7_effect == 1 then
					player.Luck = math.abs(player.Luck - 2) * 1.5 + 2
				elseif d.Thoth_cd7_effect == 2 then
					player.Luck = math.abs(player.Luck - 4) * 2 + 4
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	local ret = true
	local d = player:GetData()
	local room = Game():GetRoom()
	local rng = player:GetCollectibleRNG (coltyp)
	rng = auxi.rng_for_sake(rng)
	if coltyp == item.entity then
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local idx = d.__Index
			if save.elses["Thoth_effect_"..tostring(idx)] == nil then save.elses["Thoth_effect_"..tostring(idx)] = {} end
			local tg = 0
			local tg2 = 0
			for u,v in pairs(save.elses["Thoth_effect_"..tostring(idx)]) do
				if type(v) == "table" then
					tg = tg + v.counter
					tg2 = tg2 + 1
				end
			end
			if tg2 == 0 then		--生成二选一的随机卡
				local cd1 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
				rng:Next()
				local cd2 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
				rng:Next()
				local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				local q2 = Isaac.Spawn(5,300,cd2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				local ndx = option_index_holder.find_a_new_index()
				q1.OptionsPickupIndex = ndx
				q2.OptionsPickupIndex = ndx
			elseif tg2 >= 46 then		--使用46种塔罗牌的场合，
				local q1 = Isaac.Spawn(5,100,CollectibleType.COLLECTIBLE_DEATH_CERTIFICATE,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				player:RemoveCollectible(item.entity)
				Game():Darken(1,60)
				Game():ShakeScreen(60)
			elseif tg2 >= 23 then		--使用多于一半的塔罗牌，生成一个注定一抽，失去此书。
				local q1 = Isaac.Spawn(5,100,enums.Items.Fate_s_Draw,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				player:RemoveCollectible(item.entity)
				Game():Darken(1,60)
				Game():ShakeScreen(60)
			elseif tg2 > 13 then		--使用13张以上的塔罗牌，生成那个数量减半下取整张记录过的卡。
				local tg = {}
				for u,v in pairs(save.elses["Thoth_effect_"..tostring(idx)]) do
					if type(v) == "table" then
						table.insert(tg,#tg + 1,u)
					end
				end
				tg = auxi.RandomTable(tg,rng)
				for i = 1,math.floor(tg2/2) do
					local cd1 = tg[i]
					local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				end
			elseif tg2 > 9 then		--使用9张以上的塔罗牌，生成三张随机卡，再生成它们的倒卡与之二选一。
				for i = 1,3 do
					local cd1 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
					rng:Next()
					local cd2 = auxi.get_reversed_card(cd1)
					local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					local ndx = option_index_holder.find_a_new_index()
					q1.OptionsPickupIndex = ndx
					if cd2 ~= 0 then
						local q2 = Isaac.Spawn(5,300,cd2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						q2.OptionsPickupIndex = ndx
					end
				end
			elseif tg2 > 5 then		--使用5张以上的塔罗牌，生成六选三的随机卡
				for i = 1,3 do
					local cd1 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
					rng:Next()
					local cd2 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
					rng:Next()
					local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					local q2 = Isaac.Spawn(5,300,cd2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					local ndx = option_index_holder.find_a_new_index()
					q1.OptionsPickupIndex = ndx
					q2.OptionsPickupIndex = ndx
				end
			elseif tg2 > 2 then			--使用2张以上的塔罗牌，生成一张随机卡，然后再生成那张卡的倒卡。
				local cd1 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
				rng:Next()
				local cd2 = auxi.get_reversed_card(cd1)
				local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				if cd2 ~= 0 then
					local q2 = Isaac.Spawn(5,300,cd2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				end
			else		--使用1或2张塔罗牌，从使用过的塔罗牌中抽取随机一张生成。
				local tg = {}
				for u,v in pairs(save.elses["Thoth_effect_"..tostring(idx)]) do
					if type(v) == "table" then
						table.insert(tg,#tg + 1,u)
					end
				end
				local cd1 = tg[rng:RandomInt(#tg) + 1]
				local q1 = Isaac.Spawn(5,300,cd1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
			end
			save.elses["Thoth_effect_"..tostring(idx)] = {}
			return ret
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Thoth_cd9_effect"..tostring(idx)] == nil then save.elses["Thoth_cd9_effect"..tostring(idx)] = 0 end
		if save.elses["Thoth_cd9_effect"..tostring(idx)] > 0 then
			save.elses["Thoth_cd9_effect"..tostring(idx)] = math.max(0,save.elses["Thoth_cd9_effect"..tostring(idx)] - math.abs(count) * 1.5)
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local player = Game():GetPlayer(0)
	if save.elses["Thoth_cd10_effect_s"] ~= nil and save.elses["Thoth_cd10_effect_s"] ~= false and save.elses["Thoth_cd10_effect"] ~= nil and save.elses["Thoth_cd10_effect"] ~= 0 then
		local q = Isaac.Spawn(5,300,item.card10,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
		q.PositionOffset = Vector(0,-600)
		q:GetData().should_fall = true
		save.elses.Thoth_cd10_effect_s = false
	end
end,
})
--l local room = Game():GetRoom() local player = Game():GetPlayer(0) local q = Isaac.Spawn(5,300,111,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup() q.PositionOffset = Vector(0,-100)

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_BASIC, params = nil,
Function = function(_,player,changetype,count)
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Thoth_cd9_effect"..tostring(idx)] == nil then save.elses["Thoth_cd9_effect"..tostring(idx)] = 0 end
		if save.elses["Thoth_cd9_effect"..tostring(idx)] > 0 then
			save.elses["Thoth_cd9_effect"..tostring(idx)] = math.max(0,save.elses["Thoth_cd9_effect"..tostring(idx)] - math.abs(count))
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_PICKUP_TRINKET, params = nil,
Function = function(_,player,trinket,isgolden,touched)
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Thoth_cd9_effect"..tostring(idx)] == nil then save.elses["Thoth_cd9_effect"..tostring(idx)] = 0 end
		save.elses["Thoth_cd9_effect"..tostring(idx)] = math.max(0,save.elses["Thoth_cd9_effect"..tostring(idx)] - 1)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:GetData().should_evaluate_on_update_once = true
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_GET_CARD, params = nil,
Function = function(_,rng,card,playing,rune,onlyrune)
	local should_morph = false
	if math.random(100) > 50 then should_morph = true end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) then
			should_morph = true
			break
		end
	end
	if should_morph then
		if card == Card.CARD_JUSTICE then return item.card1 end
		if card == Card.CARD_STRENGTH then return item.card2 end
		if card == Card.CARD_TEMPERANCE then return item.card3 end
		if card == Card.CARD_JUDGEMENT then return item.card4 end
		if card == Card.CARD_WORLD then return item.card5 end
		if card == Card.CARD_REVERSE_JUSTICE then return item.card6 end
		if card == Card.CARD_REVERSE_STRENGTH then return item.card7 end
		if card == Card.CARD_REVERSE_TEMPERANCE then return item.card8 end
		if card == Card.CARD_REVERSE_JUDGEMENT then return item.card9 end
		if card == Card.CARD_REVERSE_WORLD then return item.card10 end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = nil,
Function = function(_,ent)
	if ent.Type == 5 and ent.Variant ~= 300 and ent.Variant ~= 370 and ent.Variant ~= 340 and ent.Variant ~= 350 and ent.Variant ~= 70 and ent:GetSprite():IsPlaying("Appear") then
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) then
				local rng = player:GetCollectibleRNG(item.entity)
				rng = auxi.rng_for_sake(rng)
				if rng:RandomInt(100) < 20 then 
					local cd1 = Game():GetItemPool():GetCard(player.InitSeed + rng:GetSeed(), false, false, false)
					rng:Next()
					ent:Morph(5,300,cd1,true,true,true)
					break
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = nil,
Function = function(_,ent)
	if ent.Type == 5 and ent.Variant == 300 and ((ent.SubType > 0 and ent.SubType < 23) or (ent.SubType > 55 and ent.SubType < 78)) then
		local should_morph = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) then
				should_morph = true
				break
			end
		end
		if should_morph then
			if (ent.SubType > 0 and ent.SubType < 23) then
				local s = ent:GetSprite()
				local pln = s:GetAnimation()
				s:Load("gfx/tarot_of_thoth.anm2",true)
				s:Play(pln,true)
				local card = ent.SubType
				if card == Card.CARD_JUSTICE then ent.SubType = item.card1 end
				if card == Card.CARD_STRENGTH then ent.SubType = item.card2 end
				if card == Card.CARD_TEMPERANCE then ent.SubType = item.card3 end
				if card == Card.CARD_JUDGEMENT then ent.SubType = item.card4 end
				if card == Card.CARD_WORLD then ent.SubType = item.card5 end
			elseif (ent.SubType > 55 and ent.SubType < 78) then
				local s = ent:GetSprite()
				local pln = s:GetAnimation()
				s:Load("gfx/tarot_of_thoth_reverse.anm2",true)
				s:Play(pln,true)
				local card = ent.SubType
				if card == Card.CARD_REVERSE_JUSTICE then ent.SubType = item.card1 end
				if card == Card.CARD_REVERSE_STRENGTH then ent.SubType = item.card2 end
				if card == Card.CARD_REVERSE_TEMPERANCE then ent.SubType = item.card3 end
				if card == Card.CARD_REVERSE_JUDGEMENT then ent.SubType = item.card4 end
				if card == Card.CARD_REVERSE_WORLD then ent.SubType = item.card5 end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	if shouldsave then
	else
		save.elses.Thoth_cd10_effect_s = nil
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.Thoth_cd3_effect = 0
		for i = 1,10 do
			save.elses["Thoth_effect_"..tostring(i)] = {}
			save.elses["Thoth_cd1_effect"..tostring(i)] = 0
			save.elses["Thoth_cd6_effect"..tostring(i)] = 0
			save.elses["Thoth_cd9_effect"..tostring(i)] = 0
		end
		save.elses.Thoth_cd10_effect = 0
		save.elses.Thoth_cd8_effect = 0
		save.elses.Thoth_cd10_effect_s = nil
	end
	save.elses.Thoth_cd2_effect = 0
	save.elses.Thoth_cd8_counter = 0.7
	Lure_effect.Color = Color(1,1,1,0)
	Art_effect.Color = Color(1,1,1,0)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:EvaluateItems()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	save.elses.Thoth_cd2_effect = 0
	save.elses.Thoth_cd8_effect = 0
	save.elses.Thoth_cd8_counter = 0.7
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local d = player:GetData()
		d.Thoth_cd7_effect = 0
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:GetData().should_evaluate_on_update_once = true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = nil,
Function = function(_,ent)
	if ent.Type ~= 1000 then
		if save.elses.Thoth_cd8_effect and save.elses.Thoth_cd8_effect ~= 0 then
			local should_do = true
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if (player.Position - ent.Position):Length() < 50 then
					should_do = false
					break
				end
			end
			if should_do then
				local dmgself = true
				if save.elses.Thoth_cd8_effect == 2 then dmgself = false end
				local player = save.elses.Thoth_cd8_player
				if player == nil or player:Exists() == false or player:IsDead() then player = Game():GetPlayer(0) end
				if save.elses.Thoth_cd8_counter == nil then save.elses.Thoth_cd8_counter = 0.7 end
				Game():BombExplosionEffects(ent.Position,player.Damage * 2,player.TearFlags,player.TearColor,player,save.elses.Thoth_cd8_counter,false,dmgself)	
				save.elses.Thoth_cd8_counter = math.min(3,save.elses.Thoth_cd8_counter + 0.1)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	local scz = auxi.GetScreenSize()
	if save.elses.Thoth_cd2_effect ~= nil and save.elses.Thoth_cd2_effect > 0 then
		Lure_effect.Color = auxi.AddColor(Lure_effect.Color,Color(1.5,1.5,1.5,1,0.3,0.3,0.3),0.9,0.1)
	else
		Lure_effect.Color = auxi.AddColor(Lure_effect.Color,Color(1,1,1,0,0,0,0),0.9,0.1)
	end
	if Lure_effect.Color.A > 0.05 then
		Lure_effect:Render(auxi.GetScreenCenter()/2 - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
		Lure_effect:Update()
		Lure_effect.Rotation = Lure_effect.Rotation + 0.3
		Lure_effect.Scale = Vector(scz.X/205 * (1 + 0.3 * math.sin(1.2 * math.rad(item.render_counter - 82))),scz.Y/205 * (1 + 0.3 * math.cos(math.rad(item.render_counter + 38))))
	end
	if save.elses.Thoth_cd3_effect ~= nil and save.elses.Thoth_cd3_effect > 0 then
		Art_effect.Color = auxi.AddColor(Art_effect.Color,Color(1,1,1,1,0.3,0.3,0.3),0.9,0.1)
		save.elses.Thoth_cd3_effect = save.elses.Thoth_cd3_effect - 1
	else
		Art_effect.Color = auxi.AddColor(Art_effect.Color,Color(1,1,1,0,0,0,0),0.9,0.1)
	end
	if Art_effect.Color.A > 0.05 then
		Art_effect:Render(auxi.GetScreenCenter()/2 - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
		Art_effect:Update()
		Art_effect.Rotation = Art_effect.Rotation - 0.3
		Art_effect.Scale = Vector(scz.X/205 * (1 + 0.3 * math.sin(math.rad(item.render_counter + 81))),scz.Y/205 * (1 + 0.3 * math.cos(0.8 * math.rad(item.render_counter + 145))))
	end
	item.render_counter = item.render_counter + 0.1
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = 300,
Function = function(_,ent)
	local d = ent:GetData()
	if d.should_fall then 
		if d.add_vel == nil then d.add_vel = 0 end
		if d.add_acce == nil then d.add_acce = 7 end
		d.add_vel = d.add_vel + d.add_acce
		local ymx = ent.PositionOffset.Y + d.add_vel
		if ymx > 0 then 
			d.add_vel = - d.add_vel * 0.7 
			if d.add_vel < 10 then
				d.add_acce = 0
				d.add_vel = 0
			end
			ymx = 0
		end
		ent.PositionOffset = Vector(ent.PositionOffset.X,ymx)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.Thoth_cd2_effect then
		if d.Thoth_cd2_counter == nil then d.Thoth_cd2_counter = 0 end
		d.Thoth_cd2_counter = (d.Thoth_cd2_counter + 1) % 7
		if d.Thoth_cd2_effect == 2 then
			d.Thoth_cd2_counter = (d.Thoth_cd2_counter) % 5
		end
		if d.Thoth_cd2_counter == 1 then
			ent:Update()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	local rng = player:GetCardRNG(item.card7)
	rng = auxi.rng_for_sake(rng)
	local room = Game():GetRoom()
	if player then
		local d = player:GetData()
		if d.Thoth_cd7_effect then
			local rnd = 0
			if d.Thoth_cd7_effect == 1 then
				rnd = rng:RandomInt(1000)
			elseif d.Thoth_cd7_effect == 2 then
				rnd = rng:RandomInt(1400)
			end
			if rnd > 550 then
				if d.Thoth_cd7_effect == 2 and rnd > 1300 then
					Isaac.Spawn(5,0,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				else
					if auxi.is_player_only_soul_hearts(player) then
						local rnd = rng:RandomInt(1000)
						if rnd > 700 then
							Isaac.Spawn(5,10,3,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						else
							Isaac.Spawn(5,10,8,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						end
					elseif auxi.is_player_only_coin_hearts(player) then
						Isaac.Spawn(5,20,1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					elseif auxi.is_player_only_red_hearts(player) then
						if rnd > 950 then
							Isaac.Spawn(5,10,5,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						elseif rnd > 700 then
							Isaac.Spawn(5,10,1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						else
							Isaac.Spawn(5,10,2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						end
					else
						Isaac.Spawn(5,10,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,		--记录数字
Function = function(_,name)
	if name == "Qing_HelpfulShader" and Game():GetHUD():IsVisible() then
		local player = Game():GetPlayer(0)
		local act = player:GetActiveItem(0)
		if act and act == item.entity then
			local idx = player:GetData().__Index
			if idx then
				local pos = ui.UIActivePos(0,false)
				if (player:HasCollectible(584) and act ~= 584) or (player:HasCollectible(59) and act ~= 59)then
					pos = pos + Vector(0,-4)
				end
				pos = pos + Vector(-8,-16)
				local counter = save.elses["Thoth_effect_"..tostring(idx)].counter or 0
				gui.draw_ch(pos,tostring(counter),1,1,auxi.Color_2_KColor(get_thoth_color(counter)),true)
			end
		end
		if Game():GetNumPlayers() > 1 then
			local player = Game():GetPlayer(1)
			if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
				local act = player:GetActiveItem(0)
				if act and act == item.entity then
					local idx = player:GetData().__Index
					if idx then
						local pos = ui.UIActivePos(1,false)
						if (player:HasCollectible(584) and act ~= 584) or (player:HasCollectible(59) and act ~= 59)then
							pos = pos + Vector(0,-4)
						end
						pos = pos + Vector(-8,-16)
						local counter = save.elses["Thoth_effect_"..tostring(idx)].counter or 0
						gui.draw_ch(pos,tostring(counter),1,1,auxi.Color_2_KColor(get_thoth_color(counter)),true)
					end
				end
			end
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,
Function = function(_,ent,amt,flag,source,cooldown)
	local d = ent:GetData()
	if d.Thoth_cd2_effect then
		if flag & DamageFlag.DAMAGE_CLONES == 0 and amt ~= 0 then
			local dmg = 5
			if d.Thoth_cd2_effect == 2 then dmg = 10 end
			ent:TakeDamage(dmg,flag | DamageFlag.DAMAGE_CLONES,source,cooldown)
		end
	end
	if not ent:IsBoss() then
		if save.elses.Thoth_cd3_effect and save.elses.Thoth_cd3_effect > 0 then
			if d.Thoth_cd3_effect == nil then
				if ent.HitPoints/ent.MaxHitPoints < 0.1 then
					d.Thoth_cd3_effect = true
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local room = Game():GetRoom()
	if not ent:IsBoss() then
		if d.Thoth_cd3_effect ~= nil then
			Isaac.Spawn(5,0,0,room:FindFreePickupSpawnPosition(ent.Position,10,true),Vector(0,0),ent):ToPickup()
			d.Thoth_cd3_effect = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,rng,pos)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
		if idx then
			if save.elses["Thoth_cd9_effect"..tostring(idx)] and save.elses["Thoth_cd9_effect"..tostring(idx)] > 0 then
				save.elses["Thoth_cd9_effect"..tostring(idx)] = save.elses["Thoth_cd9_effect"..tostring(idx)] + 0.1
				player:AddCacheFlags(CacheFlag.CACHE_ALL)
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = nil,		--高速枚举
Function = function(_,cardtype,player,useFlags)
	local rng = player:GetCardRNG(cardtype)
	rng = auxi.rng_for_sake(rng)
	local n_entity = Isaac.GetRoomEntities()
	local n_enemy = auxi.getenemies(n_entity)
	local room = Game():GetRoom()
	local d = player:GetData()
	local idx = d.__Index
	if player:HasCollectible(item.entity) then
		if (cardtype > 0 and cardtype < 23) or (cardtype > 55 and cardtype < 78) or (item.cards[cardtype] ~= nil )then
			if idx then
				if save.elses["Thoth_effect_"..tostring(idx)] == nil then save.elses["Thoth_effect_"..tostring(idx)] = {} end
				if save.elses["Thoth_effect_"..tostring(idx)][cardtype] == nil then save.elses["Thoth_effect_"..tostring(idx)][cardtype] = {counter = 0,} end
				if save.elses["Thoth_effect_"..tostring(idx)].counter == nil then save.elses["Thoth_effect_"..tostring(idx)].counter = 0 end
				if save.elses["Thoth_effect_"..tostring(idx)][cardtype].counter == 0 then save.elses["Thoth_effect_"..tostring(idx)].counter = save.elses["Thoth_effect_"..tostring(idx)].counter + 1 end
				save.elses["Thoth_effect_"..tostring(idx)][cardtype].counter = save.elses["Thoth_effect_"..tostring(idx)][cardtype].counter + 1
			end
		end
	end
	
	for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   
		if (player:GetActiveItem(slot) == item.entity) then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_ITEMRECHARGE,1,1,false,0,2)
			player:SetActiveCharge(player:GetActiveCharge(slot) + player:GetBatteryCharge(slot) + 1, slot)
		end
	end
	
	if item.cards[cardtype] ~= nil then
		if save.UnlockData.Others["Thoth"].Unlock ~= true then
			save.UnlockData.Others["Thoth"].Unlock = true
			for i = 1,#(enums.AchievementGraphics.others.Thoth) do
				Achievement_Display_holder.PlayAchievement("gfx/ui/Some achievements/" .. enums.AchievementGraphics.others.Thoth[i] .. ".png")
			end
		end
	end
	
	if cardtype == item.card1 then
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local total = player:GetNumBombs() + player:GetNumKeys() + player:GetNumCoins()
			local ef2 = math.abs(math.floor(total/3) - player:GetNumBombs()) + math.abs(math.floor(total/3) - player:GetNumKeys()) * 0.6 + math.abs(total - math.floor(total/3) * 2 - player:GetNumCoins()) * 0.1
			player:AddBombs(math.floor(total/3) - player:GetNumBombs())
			player:AddKeys(math.floor(total/3) - player:GetNumKeys())
			player:AddCoins(total - math.floor(total/3) * 2 - player:GetNumCoins())
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				if idx ~= nil then
					if save.elses["Thoth_cd1_effect"..tostring(idx)] == nil then save.elses["Thoth_cd1_effect"..tostring(idx)] = 0 end
					save.elses["Thoth_cd1_effect"..tostring(idx)] = save.elses["Thoth_cd1_effect"..tostring(idx)] + ef2
					player:AddCacheFlags(CacheFlag.CACHE_ALL)
					player:GetData().should_evaluate_on_update_once = true
				end
			end
		end
	elseif cardtype == item.card2 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				for u,v in pairs(n_enemy) do
					v:GetData().Thoth_cd2_effect = 2
				end
			else
				for u,v in pairs(n_enemy) do
					v:GetData().Thoth_cd2_effect = 1
				end
			end
			save.elses.Thoth_cd2_effect = 1
		end
	elseif cardtype == item.card3 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
			if save.elses.Thoth_cd3_effect == nil then save.elses.Thoth_cd3_effect = 0 end
			save.elses.Thoth_cd3_effect = math.max(save.elses.Thoth_cd3_effect,45 * 60)
		else
			if save.elses.Thoth_cd3_effect == nil then save.elses.Thoth_cd3_effect = 0 end
			save.elses.Thoth_cd3_effect = math.max(save.elses.Thoth_cd3_effect,30 * 60)
		end
	elseif cardtype == item.card4 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local coins = player:GetNumCoins()
			if coins % 2 == 1 then	
				local q1 = Isaac.Spawn(6,17,0,room:FindFreePickupSpawnPosition(room:FindFreeTilePosition(player.Position,10),10,true),Vector(0,0),player)
				local e1 = Isaac.Spawn(1000,15,0,q1.Position,Vector(0,0),q1)
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_SUMMONSOUND,1.2,1,false,0,2)
			elseif coins % 2 == 0 then
				player:AddEternalHearts(1)
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_SUPERHOLY,1.2,1,false,0,2)
			end
		end
	elseif cardtype == item.card5 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local config = Isaac:GetItemConfig()
			local quis = {}
			local now_quis = -1
			for u,v in pairs(itemList) do
				if d["collectible_counter_"..tostring(v)] and d["collectible_counter_"..tostring(v)] > 0 then
					local qui = config:GetCollectible(v).Quality
					if now_quis < qui then
						now_quis = qui
						quis = {}
					end
					if now_quis == qui then
						table.insert(quis,#quis + 1,v)
					end
				end
			end
			if now_quis == -1 then
			else
				local rnd = rng:RandomInt(#quis) + 1
				local col = quis[rnd]
				player:AnimateCollectible(col,"LiftItem","PlayerPickup")
				local tg = {}
				for u,v in pairs(item.Star_items) do
					if player:HasCollectible(v) == false then
						table.insert(tg,#tg + 1,v)
					end
				end
				if #tg == 0 then table.insert(tg,#tg + 1,233) end
				local rnd1 = rng:RandomInt(#tg) + 1
				local targ1 = tg[rnd1]
				if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
					table.remove(tg,rnd1)
					local rnd2 = rng:RandomInt(#tg) + 1
					local targ2 = tg[rnd2]
					delay_buffer.addeffe(function(params)
						if player:IsHoldingItem() then
							player:AnimateCollectible(col,"HideItem","PlayerPickup")
							player:RemoveCollectible(col)
							local q1 = Isaac.Spawn(5,100,targ1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
							local q2 = Isaac.Spawn(5,100,targ2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
							local e1 = Isaac.Spawn(1000,16,2,player.Position,Vector(0,0),player)
							local e2 = Isaac.Spawn(1000,16,1,player.Position,Vector(0,0),player)
							local ndx = option_index_holder.find_a_new_index()
							q1.OptionsPickupIndex = ndx
							q2.OptionsPickupIndex = ndx
						end
					end,{},15)
				else
					delay_buffer.addeffe(function(params)
						if player:IsHoldingItem() then
							player:AnimateCollectible(col,"HideItem","PlayerPickup")
							player:RemoveCollectible(col)
							local q = Isaac.Spawn(5,100,targ1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
							local e1 = Isaac.Spawn(1000,16,2,player.Position,Vector(0,0),player)
							local e2 = Isaac.Spawn(1000,16,1,player.Position,Vector(0,0),player)
						end
					end,{},15)
				end
			end
		end
	elseif cardtype == item.card6 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local total = player:GetNumBombs() + player:GetNumKeys() * 0.7 + player:GetNumCoins() * 0.1
			player:AddBombs(- player:GetNumBombs())
			player:AddKeys(- player:GetNumKeys())
			player:AddCoins(- player:GetNumCoins())	
			if idx then
				if save.elses["Thoth_cd6_effect"..tostring(idx)] == nil then save.elses["Thoth_cd6_effect"..tostring(idx)] = 0 end
				save.elses["Thoth_cd6_effect"..tostring(idx)] = save.elses["Thoth_cd6_effect"..tostring(idx)] + total
				player:AddCacheFlags(CacheFlag.CACHE_ALL)
				player:GetData().should_evaluate_on_update_once = true
			end
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				local rnd = rng:RandomInt(100)
				if rnd > 50 then
					Isaac.Spawn(5,300,cardtype,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player)
				end
			end
		end
	elseif cardtype == item.card7 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			d.Thoth_cd7_effect = 1
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				d.Thoth_cd7_effect = 2
			end
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	elseif cardtype == item.card8 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			save.elses.Thoth_cd8_effect = 1
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				save.elses.Thoth_cd8_effect = 2
			end
			save.elses.Thoth_cd8_player = player
		end
	elseif cardtype == item.card9 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local mxid = 7
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				mxid = 15
			end
			if idx then
				if save.elses["Thoth_cd9_effect"..tostring(idx)] == nil then save.elses["Thoth_cd9_effect"..tostring(idx)] = 0 end
				save.elses["Thoth_cd9_effect"..tostring(idx)] = math.max(mxid,save.elses["Thoth_cd9_effect"..tostring(idx)] + 2)
			end
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	elseif cardtype == item.card10 then 
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			save.elses.Thoth_cd10_effect_s = true
			if d.tarot_cloth_used and d.tarot_cloth_used == cardtype then
				local config = Isaac:GetItemConfig()
				local quis = {}
				for u,v in pairs(itemList) do
					if d["collectible_counter_"..tostring(v)] and d["collectible_counter_"..tostring(v)] > 0 then
						table.insert(quis,#quis + 1,v)
					end
				end
				local rnd = rng:RandomInt(#quis) + 1
				local col = quis[rnd]
				player:AnimateCollectible(col,"LiftItem","PlayerPickup")
				delay_buffer.addeffe(function(params)
					if player:IsHoldingItem() then
						player:AnimateCollectible(col,"HideItem","PlayerPickup")
						player:RemoveCollectible(col)
						if save.elses.Thoth_cd10_effect and save.elses.Thoth_cd10_effect ~= 0 then
							local q = Isaac.Spawn(5,100,save.elses.Thoth_cd10_effect,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						end
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
						local e1 = Isaac.Spawn(1000,16,2,player.Position,Vector(0,0),player)
						local e2 = Isaac.Spawn(1000,16,1,player.Position,Vector(0,0),player)
						save.elses.Thoth_cd10_effect = col
					end
				end,{},15)
			else
				if save.elses.Thoth_cd10_effect == nil or save.elses.Thoth_cd10_effect == 0 then
					local config = Isaac:GetItemConfig()
					local quis = {}
					for u,v in pairs(itemList) do
						if d["collectible_counter_"..tostring(v)] and d["collectible_counter_"..tostring(v)] > 0 then
							table.insert(quis,#quis + 1,v)
						end
					end
					local rnd = rng:RandomInt(#quis) + 1
					local col = quis[rnd]
					player:AnimateCollectible(col,"LiftItem","PlayerPickup")
					delay_buffer.addeffe(function(params)
						if player:IsHoldingItem() then
							player:AnimateCollectible(col,"HideItem","PlayerPickup")
							player:RemoveCollectible(col)
							save.elses.Thoth_cd10_effect = col
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
							local e1 = Isaac.Spawn(1000,16,2,player.Position,Vector(0,0),player)
							local e2 = Isaac.Spawn(1000,16,1,player.Position,Vector(0,0),player)
						end
					end,{},15)
				else
					local q = Isaac.Spawn(5,100,save.elses.Thoth_cd10_effect,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					q.Touched = true
					q.Charge = 0
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = nil,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local rng = ent:GetDropRNG()
		local q = Isaac.Spawn(5,300,0,ent.Position,ent.Velocity,nil)
	end
end,
})


return item