local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local convert_list = {
	[1] = {150,7,3,1,},
	[2] = {0,100,25,5,},
	[3] = {0,0,70,30,},
	[4] = {0,0,0,50,},
}

local item = {
	pre_ToCall = {},
	ToCall = {},
	entity = enums.Items.Abecarnil,
	to_add_list = {
		[1] = {Func = function(player)		--变成碎心
			if player ~= nil then
				player:AddBrokenHearts(1)
			end
		end,get_wei = function(player,counter,cg_id)
			if player == nil then return 0 end
			if counter and counter > 0 then
				return (3 + counter)/4 * convert_list[cg_id][1]
			else
				return 0
			end
		end,effect_cnt = 1,},
		[2] = {Func = function(player)		--变成魂心
			if player ~= nil then
				auxi.add_soul_heart(player, 2)
				if player:GetSoulHearts() % 2 == 1 then
					auxi.add_soul_heart(player, 1)
				end
			end
		end,Check = function(player)
			if player == nil then return false end
			if auxi.is_player_only_bone_hearts(player) or auxi.is_player_only_red_hearts(player) then 
				return false 
			else 
				return true 
			end
		end,get_wei = function(player,counter,cg_id)
			if player == nil then return 0 end
			if counter and counter > 0 then
				return (counter * 1.5 - 0.5)* convert_list[cg_id][2]
			else
				return 0
			end
		end,effect_cnt = 2,},
		[3] = {Func = function(player)		--变成骨心
			if player ~= nil then
				player:AddBoneHearts(1)
			end
		end,get_wei = function(player,counter,cg_id)
			if player == nil then return 0 end
			if counter and counter > 0 then
				if cg_id == 1 then return 3 end
				return counter * convert_list[cg_id][3]
			else
				return 0
			end
		end,effect_cnt = 3,},
		[4] = {Func = function(player)		--变成血上限
			if player ~= nil then
				player:AddMaxHearts(2,true)
			end
		end,Check = function(player)
			if player == nil then return false end
			if auxi.is_player_only_bone_hearts(player) or auxi.is_player_only_soul_hearts(player) then 
				return false 
			else 
				return true 
			end
		end,get_wei = function(player,counter,cg_id)
			if player == nil then return 0 end
			if counter and counter > 0 then
				if cg_id == 1 then return 1 end
				if cg_id == 2 then return 5 end
				return counter * convert_list[cg_id][4]
			else
				return 0
			end
		end,effect_cnt = 4,},
	},
	to_remove_list = {
		[1] = {Func = function(player)		--不变
		end,},
		[2] = {Func = function(player)		--失去碎心
			if player ~= nil then
				player:AddBrokenHearts(-1)
			end
		end,},
		[3] = {Func = function(player)		--失去魂心
			if player ~= nil then
				auxi.add_soul_heart(player, -2)
				if player:GetSoulHearts() % 2 == 1 then
					auxi.add_soul_heart(player, -1)
				end
			end
		end,},
		[4] = {Func = function(player)		--失去骨心
			if player ~= nil then
				player:AddBoneHearts(-1)
			end
		end,},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 10,
Function = function(_,ent)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count then
		if ent.Type == 5 and ent.Variant == 10 and ent:IsShopItem() then
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			if rng:RandomInt(1000) > 500 then
				ent:Morph(5,30,1,true,true)
			else
				ent:Morph(5,40,1,true,true)
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = 10,
Function = function(_,ent,col,low)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count then
		if ent.Type == 5 and ent.Variant == 10 then
			return false
		end
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_A_delay_counter"..tostring(j)] = 0
		end
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = player:GetData().__Index
		if idx ~= nil then
			if save.elses["P_A_delay_counter"..tostring(idx)] == nil then save.elses["P_A_delay_counter"..tostring(idx)] = 0 end
			local heart = player:GetBoneHearts() + math.ceil(player:GetSoulHearts()/2) + math.ceil(player:GetMaxHearts()/2)
			if save.elses["P_A_delay_counter"..tostring(idx)] > math.max(30,15 * 60 - heart * 10 - Game():GetFrameCount()/18000) then
				local bone_heart = player:GetBoneHearts()
				local mx_heart = math.ceil(player:GetMaxHearts()/2)
				local soul_heart = math.ceil(player:GetSoulHearts()/2)
				local lim_heart = player:GetHeartLimit()/2
				local bk_heart = player:GetBrokenHearts()
				local rng = player:GetDropRNG()
				local e_v_id = 5
				local stag = {}
				if lim_heart > heart then		--由空血随机进化
					for i = 1,4 do
						local v = item.to_add_list[i]
						if v.Check == nil or v.Check(player) == true then
							local wei = v.get_wei(player,(lim_heart - heart),1)
							table.insert(stag,#stag + 1,{should_do = v,should_end = item.to_remove_list[1],wei = wei,})
						end
					end
				end
				if bk_heart > 0 then
					for i = 2,4 do
						local v = item.to_add_list[i]
						if v.Check == nil or v.Check(player) == true then
							local wei = v.get_wei(player,bk_heart,2)
							table.insert(stag,#stag + 1,{should_do = v,should_end = item.to_remove_list[2],wei = wei,})
						end
					end
				end
				if soul_heart > 0 and auxi.is_player_only_soul_hearts(player) ~= true then
					for i = 3,4 do
						local v = item.to_add_list[i]
						if v.Check == nil or v.Check(player) == true then
							local wei = v.get_wei(player,soul_heart,3)
							table.insert(stag,#stag + 1,{should_do = v,should_end = item.to_remove_list[3],wei = wei,})
						end
					end
				end
				if bone_heart > 0 and auxi.is_player_only_bone_hearts(player) ~= true then
					local v = item.to_add_list[4]
					if v.Check == nil or v.Check(player) == true then
						local wei = v.get_wei(player,bone_heart,4)
						table.insert(stag,#stag + 1,{should_do = v,should_end = item.to_remove_list[4],wei = wei,})
					end
				end
				if #stag == 0 then
					player:Kill()
				else
					local stg = stag[1]
					local tot_wei = 0
					for u,v in pairs(stag) do
						tot_wei = tot_wei + math.ceil(v.wei)
					end
					tot_wei = rng:RandomInt(tot_wei)
					for i = 1,#stag do
						tot_wei = tot_wei - math.ceil(stag[i].wei)
						if tot_wei <= 0 then
							stg = stag[i]
							break
						end
					end
					if stg.should_end and stg.should_end.Func then
						stg.should_end.Func(player)
					end
					if stg.should_do and stg.should_do.Func then
						stg.should_do.Func(player)
						if stg.should_do.effect_cnt then
							e_v_id = stg.should_do.effect_cnt
						end
					end
					local q = Isaac.Spawn(1000,EffectVariant.HEART,0,player.Position + Vector(0,-30) * player.SpriteScale.Y + player.Velocity,Vector(0,0),nil)
					local s = q:GetSprite()
					s:ReplaceSpritesheet(0,"gfx/effects/P_A_heart0"..tostring(e_v_id)..".png")
					local toplay = {id = SoundEffect.SOUND_SUPERHOLY,vol = 1,pit = 1}
					if e_v_id == 3 then
						toplay.id = SoundEffect.SOUND_BONE_HEART
					elseif e_v_id == 2 then
						toplay.id = SoundEffect.SOUND_HOLY
					elseif e_v_id == 1 then
						toplay.id = SoundEffect.SOUND_DEVILROOM_DEAL
					end
					sound_tracker.PlayStackedSound(toplay.id,toplay.vol,toplay.pit,false,0,2)
					s:LoadGraphics()
					q.DepthOffset = 1000
				end
				save.elses["P_A_delay_counter"..tostring(idx)] = 0
			end
			save.elses["P_A_delay_counter"..tostring(idx)] = save.elses["P_A_delay_counter"..tostring(idx)] + 1
		end
	end
end,
})

--l local q = Isaac.Spawn(10,0,0,Vector(200,200),Vector(0,0),nil);q:AddEntityFlags(EntityFlag.FLAG_RENDER_FLOOR);

return item