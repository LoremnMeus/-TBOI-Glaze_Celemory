local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local costume_holder = require("Qing_Extra_scripts.others.Costume_holder")

local item = {
	ToCall = {},
	entity = enums.Items.Pageant_Cross_dresser,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 or (save.elses.should_counter_Pageant_Cross_dresser and save.elses.should_counter_Pageant_Cross_dresser == true) then
		save.elses.should_counter_Pageant_Cross_dresser = nil
		if player:GetData().__Index == nil then 
			player:GetData().__Index = 1
			--print("ERROR:No player Index!Please Contact Meus!")
		end
		local num = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
		if save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] == nil or save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] ~= num then
			if save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] == nil then save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] = 0 end
			--print(tostring(num).."_"..tostring(save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"]))
			local itemConfig = Isaac.GetItemConfig()
			local size = itemConfig:GetCollectibles().Size
			for i = 1,size do
				save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresseri_"..tostring(i)] = false
			end
			local enum = 5+5*save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"]
			if save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] == 0 then enum = 0 end
			for i = 1,enum do
				if save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_"..tostring(i)] and save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_"..tostring(i)] ~= -1 then
					player:RemoveCostume(itemConfig:GetCollectible(save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_"..tostring(i)]))
				end
				save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_"..tostring(i)] = -1
			end
			local targ = {}
			for u,v in pairs(costume_holder.CanAdd) do
				if player:HasCollectible(v) == false then
					table.insert(targ,#targ+1,v)
				end
			end
			local mx = 5+5*num
			if num == 0 then mx = 0 end
			if #targ < mx then mx = #targ end
			local rng = RNG()
			rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()) + player:GetData().__Index - 1,0)
			for i = 1,mx do
				local rnd = rng:RandomInt(#targ - i + 1) + i
				if targ[rnd] then
					player:AddCostume(itemConfig:GetCollectible(targ[rnd]),false)
					save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_"..tostring(i)] = targ[rnd]
					save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresseri_"..tostring(targ[rnd])] = true
					targ[rnd] = targ[i]
				end
			end
			player:AddCacheFlags(CacheFlag.CACHE_LUCK)
			player:GetData().should_evaluate_on_update_once = true
			save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser"] = num
		end
		if player:GetCollectibleCount() ~= save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_collectible_counter"] then
			save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresser_collectible_counter"] = player:GetCollectibleCount()
			player:AddCacheFlags(CacheFlag.CACHE_LUCK)
			player:GetData().should_evaluate_on_update_once = true
			--print(1)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses[tostring(j).."_Pageant_Cross_dresser"] = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,collid, itemRng, player, useFlags, activeSlot, customVarData)
	if collid == 283 or collid == 284 or collid == 703 then
		for j = 1,10 do
			save.elses[tostring(j).."_Pageant_Cross_dresser"] = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if cacheFlag == CacheFlag.CACHE_LUCK then
			local conter = 0
			if player:GetData().__Index == nil then 
				player:GetData().__Index = 1
				print("ERROR:No player Index!Please Contact Meus!")
			end
			for u,v in pairs(costume_holder.CanAdd) do
				if player:HasCollectible(v) or save.elses[tostring(player:GetData().__Index).."_Pageant_Cross_dresseri_"..tostring(v)] == true then
					conter = conter + 1
				end
			end
			player.Luck = player.Luck + 0.05 * conter
		end
	end
end,
})

--l local itemconfig = Isaac.GetItemConfig();local item = itemconfig:GetCollectible(598);Game():GetPlayer(0):AddCostume(item);

return item