local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	entity = enums.Items.My_Emblem,
	familiar = enums.Familiars.Emblem,
	exe_fami = {
		[FamiliarVariant.GUILLOTINE] = true,			--断头台很有趣，眼泪并不和环绕物绑定。
		[FamiliarVariant.SAMSONS_CHAINS] = true,		--脚链不能被拉。
		[FamiliarVariant.LOST_FLY] = true,				--迷路苍蝇不能被拉。
		[FamiliarVariant.LIL_GURDY] = true,				--优化一下小加迪。
		[FamiliarVariant.SPRINKLER] = true,
		[FamiliarVariant.DAMOCLES] = true,
		[FamiliarVariant.FORGOTTEN_BODY] = true,
		[enums.Familiars.QingsAirs] = true,
		[enums.Familiars.Star_Pendulum] = true,			--灵摆读阵不可以
		[enums.Familiars.Air_Terror] = true,
		[enums.Familiars.Nazca] = true,
	},
	rd_fami = {
		[FamiliarVariant.LITTLE_CHUBBY] = true,
		[FamiliarVariant.ABEL] = true,
		[FamiliarVariant.HOLY_WATER] = true,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
	if cnt > 0 then cnt = cnt + 2 end
	if cacheFlag == CacheFlag.CACHE_FAMILIARS then
		player:CheckFamiliar(item.familiar, cnt, player:GetCollectibleRNG(item.entity), Isaac.GetItemConfig():GetCollectible(item.entity))
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	if ent.SpawnerEntity and ent.SpawnerEntity:ToPlayer() then
		player = ent.SpawnerEntity:ToPlayer()
	end
	if (not d.IsFollowing) then
        ent:AddToFollowers()
        d.IsFollowing = true
    end
	if s:IsFinished("Appear") then
		s:Play("Idle")
	end
	if s:IsPlaying("Idle") then
	end
	if ent.Velocity:Length() > 0.01 then
		s.Rotation = ent.Velocity:GetAngleDegrees()
	end
	ent:FollowParent()
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = item.familiar,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	if d.coll_cnt == nil then d.coll_cnt = 0 end
	if ent:IsFrame(15,0) == true then
		local player = Game():GetPlayer(0)
		if ent.Player then player = ent.Player end
		if col:IsVulnerableEnemy() and col:IsActiveEnemy() and not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
			col:TakeDamage(7,0,EntityRef(player),0)
			d.coll_cnt = d.coll_cnt + 1
		end
	end
	if col.Type == 9 and d.coll_cnt > 0 then
		col:Remove()
		d.coll_cnt = d.coll_cnt - 1
	end
	if ent:IsFrame(250,0) == true then
		d.coll_cnt = math.min(d.coll_cnt,5)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FAMILIAR_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	if d.Emblem_visible_id then
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			local s = ent:GetSprite()
			d.r_pos = (ent.Position * 0.35 + d.r_pos * 0.65)
			s:Render(Isaac.WorldToScreen(d.r_pos) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
		end
	end
end,
})

local cnt = 0

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = nil,
Function = function(_,ent)
	local player = ent.Player
	local var = ent.Variant
	if player and item.exe_fami[var] ~= true then
		local d = player:GetData()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if d.Emblem_lists == nil then d.Emblem_lists = {} end
			if d.Emblem_counter == nil then d.Emblem_counter = 0 end
			local d2 = ent:GetData()
			if d2.baby_index == nil then
				d2.baby_index = d.Emblem_counter
				d.Emblem_counter = d.Emblem_counter + 1
			end
			if d2.tear_link == nil or d2.tear_link:Exists() == false or d2.tear_link:IsDead() == true or d2.tear_link:GetData().out_of_room == true then
				if d2.re_link == true then
					if (ent.Position - player.Position):Length() > 50 then
						ent:FollowPosition((ent.Position + player.Position) * 0.5)
					else
						if d2.re_vis ~= nil then
							if item.rd_fami[var] ~= true then
								local succ = Attribute_holder.try_hold_attribute(ent,"Visible",false)
								cnt = cnt + 1
								if succ > 0 then
									d2.Emblem_visible_id = succ
									if d2.r_pos == nil then	d2.r_pos = ent.Position end
									--控制10帧的渲染，问题不大。
									delay_buffer.addeffe(function(params)
										local ent = params.ent
										if ent and ent:Exists() and ent:IsDead() == false then
											local succ = params.id
											if succ ~= nil then
												local succc = Attribute_holder.try_rewind_attribute(ent,"Visible",succ)
												cnt = cnt - 1
												--if succc == false then print("fail") end
												--print(cnt)
											end
											if ent:GetData().Emblem_visible_id and ent:GetData().Emblem_visible_id == succ then 
												ent:GetData().Emblem_visible_id = nil 
												ent:GetData().r_pos = nil
											end
										end
									end,{ent = ent,id = d2.Emblem_visible_id},3)
								end
							end
							d2.re_vis = nil
							d2.re_link = nil
						end
					end
				end
				if d2.tear_list_alocate == nil then
					d2.tear_list_alocate = true
					table.insert(d.Emblem_lists,#d.Emblem_lists + 1,ent)
					--ent:AddToFollowers()
					d2.re_add_to = nil
				end
			else
				if d2.re_add_to == nil then
					d2.re_add_to = true
					d2.re_vis = true
					--ent:RemoveFromFollowers()
					--ent:RemoveFromDelayed()
					--ent:RemoveFromOrbit()
				end
				local tear = d2.tear_link
				local pos = tear.Position + tear.Velocity * 5
				ent:FollowPosition(pos)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	if ent.SpawnerEntity ~= nil then
		local spet = ent.SpawnerEntity--auxi.to_find_spawner(ent.SpawnerEntity)
		if spet.Type == 1 then
			local player = spet:ToPlayer()
			local d = player:GetData()
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local d2 = ent:GetData()
				local pos = ent.Position
				if d2.out_of_room ~= true then
					if room:IsPositionInRoom(pos,-10) == true then
						if d.Emblem_lists == nil then d.Emblem_lists = {} end
						if d2.Familiar_link == nil then
							if #d.Emblem_lists > 0 then
								d2.Familiar_link = d.Emblem_lists[1]
								d.Emblem_lists[1]:GetData().tear_link = ent
								d.Emblem_lists[1]:GetData().tear_list_alocate = nil
								d.Emblem_lists[1]:GetData().re_link = true
								table.remove(d.Emblem_lists,1)
							end
						end
					else
						d2.out_of_room = true
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_KNIFE_UPDATE, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	if ent.Variant == enums.Entities.StabberKnife then
		if ent.SpawnerEntity ~= nil then
			local spet = ent.SpawnerEntity--auxi.to_find_spawner(ent.SpawnerEntity)
			if spet.Type == 1 then
				local player = spet:ToPlayer()
				local d = player:GetData()
				if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
					local d2 = ent:GetData()
					local pos = ent.Position
					if d2.out_of_room ~= true then
						if room:IsPositionInRoom(pos,-10) == true then
							if d.Emblem_lists == nil then d.Emblem_lists = {} end
							if d2.Familiar_link == nil then
								if #d.Emblem_lists > 0 then
									d2.Familiar_link = d.Emblem_lists[1]
									d.Emblem_lists[1]:GetData().tear_link = ent
									d.Emblem_lists[1]:GetData().tear_list_alocate = nil
									d.Emblem_lists[1]:GetData().re_link = true
									table.remove(d.Emblem_lists,1)
								end
							end
						else
							d2.out_of_room = true
						end
					end
				end
			end
		end
	end
end,
})

return item