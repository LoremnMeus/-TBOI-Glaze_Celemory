local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Gospel,
	start_radius = 50,
	radius_start_vel = -10,
	radius_start_acc = 2,
}

local function fire_gospel(player,dir,pos,vel)
	for k = 1,-1,-2 do
		local q = player:FireTear(pos or player.Position,vel or player.ShotSpeed * 7 * dir,false,true,false)
		--local q = Isaac.Spawn(2,0,0,player.Position,vel or player.ShotSpeed * 7 * dir,player):ToTear()
		local d = q:GetData()
		local s = q:GetSprite()
		q.TearFlags = (q.TearFlags | BitSet128(1,0) | BitSet128(1<<1,0))
		--q.TearFlags = (player.TearFlags | BitSet128(1,0) | BitSet128(1<<1,0)) & (~BitSet128(1<<60,0))
		q.CollisionDamage = q.CollisionDamage * 0.75
		--q.CollisionDamage = player.Damage * 0.75
		--q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
		s.Color = Color(1,1,0.7,1,0.5,0.5,0.35)
		s:Load("gfx/Gospel_Tear.anm2",true)
		s:Play("Idle",true)
		q.FallingSpeed = 0
		q.FallingAcceleration = 0
		d.Ignore_me_flag = true
		d.ignore_field = true
		d.is_gospel_tear = true
		d.gospel_record_dir = dir
		d.gospel_rotate_follower = player
		d.gospel_follow_angel = 0
		d.gospel_follow_dir = k
		d.gospel_move_state = 0
		d.gospel_counter = 0
		d.gospel_rotation = 0
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
	if d.is_gospel_tear then
		if d.gospel_move_state == 0 then
			ent.Height = math.max(-30,math.min(ent.Height * 1.1,ent.Height - 1))
			local tg_pos = d.gospel_rotate_follower.Position + 45 * auxi.MakeVector(d.gospel_record_dir:GetAngleDegrees() + d.gospel_follow_dir * d.gospel_follow_angel)
			local delta = tg_pos - ent.Position
			if delta:Length() < 20 then
				d.gospel_follow_angel = d.gospel_follow_angel + 8
				s.Color = auxi.AddColor(s.Color,Color(1,1,0.7,1,0.5,0.5,0.35),0.95,0.05)
				ent.Velocity = (ent.Velocity + delta * 0.2):Normalized() * (ent.Velocity:Length() * 0.9 + 1)
			else
				ent.Velocity = (ent.Velocity + delta * 0.5):Normalized() * (ent.Velocity:Length() * 0.9 + 1)
				s.Color = auxi.AddColor(s.Color,Color(-1,-1,-1,1,-1,-1,-1),0.95,0.05)
				d.gospel_follow_angel = d.gospel_follow_angel + 4
			end
			if math.abs(d.gospel_follow_angel) > 180 then
				d.gospel_move_state = 1
				ent.TearFlags = ent.TearFlags & (~BitSet128(1<<60,0))
				ent.FallingAcceleration = 0
				ent.FallingSpeed = 0
			end
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,0,0.9,0.1,360)
		elseif d.gospel_move_state == 1 then
			ent.FallingSpeed = ent.FallingSpeed * 0.8 - 15 * 0.2
			d.gospel_counter = d.gospel_counter + 1
			ent.FallingAcceleration = ent.FallingAcceleration * 0.96 + 1 * 0.04
			ent.Velocity = (ent.Velocity + d.gospel_record_dir * 5):Normalized() * (ent.Velocity:Length() * 0.9 + 0.9)
			if d.gospel_counter > 10 then
				d.gospel_counter = 0
				d.gospel_move_state = 2
				if s.Color.RO < 0 then
					local target = auxi.get_by_nearest_enemy(ent.Position)
					if target and auxi.check_rand(player.Luck,30,2,20) then
						d.gospel_move_state = 7
						s:Play("Idle4",true)
					end
				end
			end
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,0,0.9,0.1,360)
		elseif d.gospel_move_state == 2 then
			ent.FallingAcceleration = ent.FallingAcceleration * 0.9 + 1.5 * 0.1
			ent.Velocity = (ent.Velocity + d.gospel_record_dir * 3):Normalized() * (ent.Velocity:Length() * 0.9 + 0.9)
			if ent.Height > - 20 then
				if s.Color.RO > 0 then
					d.gospel_move_state = 3
					ent.Height = - 20
					ent.FallingAcceleration = 0
					ent.FallingSpeed = 0
					if player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)] and player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)]:Exists() and not player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)]:IsDead() then 
						player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)].TearFlags = player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)].TearFlags & (~BitSet128(1<<(23),0))
					end
					player:GetData()["last_gospel_" .. tostring(d.gospel_follow_dir)] = ent
					ent.TearFlags = ent.TearFlags | BitSet128(1<<(23),0)
				else
					d.gospel_move_state = 4
				end
			end
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,0,0.9,0.1,360)
		elseif d.gospel_move_state == 3 then
			ent.Height = - 20
			ent.FallingAcceleration = 0
			ent.FallingSpeed = 0
			ent.Velocity = ent.Velocity * 0.8
			s.Color = auxi.AddColor(s.Color,Color(1,1,1,1,1,1,1),0.95,0.05)
			s.Scale = s.Scale * 0.99
			if s.Color.BO > 0.95 then
				if auxi.check_rand(player.Luck,50,5,15) then
					s:Play("Idle3",true)
					d.gospel_move_state = 6
					local q = Isaac.Spawn(7,5,3,ent.Position,Vector(0,0),player):ToLaser()
					q.PositionOffset = ent.PositionOffset
					q.Parent = ent
					q.Radius = item.start_radius
					local d2 = q:GetData()
					q.CollisionDamage = ent.CollisionDamage * 2
					d2.is_gospel_laser = true
					d2.radius_vel = item.radius_start_vel
					d2.radius_acc = item.radius_start_acc
					local s = q:GetSprite()
					s:Load("gfx/to_be_laser_concerter.anm2",true)
					s:ReplaceSpritesheet(0,"gfx/effects/lasers/lofty_brim.png")
					s:LoadGraphics()
					s:Play("LargeRedLaser",true)
					s.Color = Color(1,1,1,0)
					s.Scale = Vector(2,2)
				else
					d.gospel_move_state = 5
				end
			end
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,d.gospel_rotation + 20 * d.gospel_follow_dir,0.5,0.5,360)
		elseif d.gospel_move_state == 4 then
			Game():BombExplosionEffects(ent.Position,ent.CollisionDamage * 2,player.TearFlags,Color(-1,-1,-1,1),player,0.5,true,false)
			ent:Remove()
		elseif d.gospel_move_state == 5 then
			ent.Velocity = ent.Velocity * 0.8
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,d.gospel_rotation + 30 * d.gospel_follow_dir,0.5,0.5,360)
		elseif d.gospel_move_state == 6 then
			ent.Velocity = ent.Velocity * 0.8
			d.gospel_rotation = auxi.checkrounded(d.gospel_rotation,d.gospel_rotation + 60 * d.gospel_follow_dir,0.5,0.5,360)
			ent.Height = - 20
			ent.FallingAcceleration = 0
			ent.FallingSpeed = 0
			if s:IsFinished("Idle3") then
				local q1 = Isaac.Spawn(1000,173,0,ent.Position,Vector(0,0),nil)
				ent:Remove()
			end
		elseif d.gospel_move_state == 7 then
			ent.Velocity = ent.Velocity * 0.9
			if d.gospel_record_height == nil then d.gospel_record_height = ent.Height end
			ent.Height = ent.Height * 0.9 + d.gospel_record_height * 0.1
			ent.FallingAcceleration = ent.FallingAcceleration * 0.9
			ent.FallingSpeed = ent.FallingSpeed * 0.9
			--s.Scale = s.Scale * 1.01
			if s:IsEventTriggered("Explode") then
				local target = auxi.get_by_nearest_enemy(ent.Position)
				if target then
					local q = Isaac.Spawn(1000,EffectVariant.CRACK_THE_SKY,0,target.Position,Vector(0,0),player):ToEffect()
					q.Parent = player
					q.CollisionDamage = ent.CollisionDamage
					local s2 = q:GetSprite()
					local d2 = q:GetData()
					local dir = (target.Position + target.PositionOffset) - (ent.Position + ent.PositionOffset)
					s2.Rotation = - (90 - dir:GetAngleDegrees())
					s2.Color = auxi.AddColor(s.Color,Color(0,0,0,1,-1,-1,-1),0.7,0.3)
					d2.is_gospel_holy_light = true
					s2.Scale = Vector(0,1)
				end
			end
			if s:IsFinished("Idle4") then
				ent:Remove()
			end
		end
		s.Rotation = d.gospel_rotation
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_gospel_holy_light then
		local s = ent:GetSprite()
		s.Scale = s.Scale * 0.95 + Vector(1,1) * 0.05
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_gospel_laser then
		local s = ent:GetSprite()
		ent.Radius = ent.Radius + d.radius_vel
		d.radius_vel = math.min(-1,d.radius_vel + d.radius_acc)
		if ent.Radius <= 5 then 
			s.Color = auxi.AddColor(s.Color,Color(1,1,1,0,1,1,0.7),0.8,0.2)
			if s.Color.A < 0.1 then
				ent:Remove()
			end
		else
			s.Color = auxi.AddColor(s.Color,Color(1,1,1,1,1,1,0.7),0.95,0.05)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local room = Game():GetRoom()
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		d.Gospel_delay = d.Gospel_delay or 0
		d.Gospel_delay_max = d.Gospel_delay_max or 1
		if d.Gospel_delay >= 0 then 
			d.Gospel_delay = d.Gospel_delay - 1
		else
			local ggdir = auxi.ggdir(player,true,true)
			if ggdir:Length() > 0.05 then
				fire_gospel(player,ggdir)
				d.Gospel_delay_max = player.MaxFireDelay * 3
				d.Gospel_delay = player.MaxFireDelay * 3
			end
		end
	end
end,
})

return item