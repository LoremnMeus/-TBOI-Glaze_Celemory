local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Glaze_Mushroom,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GET_COLLECTIBLE, params = nil,
Function = function(_,pool,decrease,seed)
	local has_ent = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0  then
			has_ent = true
		end
	end
	if has_ent == true and pool == ItemPoolType.POOL_BOSS and (save.elses.has_spawn_mushroom == nil or save.elses.has_spawn_mushroom == false) and Game():GetFrameCount() > 5 then
		local has_mushroom = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(12) then
				has_mushroom = true
			end
		end
		if has_mushroom == false then
			local rng = RNG()
			rng:SetSeed(seed,0)
			rng = auxi.rng_for_sake(rng)
			local rnd = rng:RandomInt(5)
			if rnd == 1 then
				if decrease == true then
					save.elses.has_spawn_mushroom = true
				end
				return 12
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.has_spawn_mushroom = false
	end
end,
})

return item