local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Tzolkin,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local idx = player:GetData().__Index
	if idx ~= nil then
		local mul = -1
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then mul = 1 end
		local n_wisp = auxi.get_wisps(player,item.entity)
		if #n_wisp > 0 then mul = 1 end
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			if save.elses["Tzolikn_Buff_dmg_"..tostring(idx)] then
				player.Damage = player.Damage + save.elses["Tzolikn_Buff_dmg_"..tostring(idx)] * auxi.get_damage_multiplier(player) * mul
			end
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			if save.elses["Tzolikn_Buff_tear_"..tostring(idx)] then
				player.MaxFireDelay = math.min(300,auxi.TearsUp(player.MaxFireDelay , save.elses["Tzolikn_Buff_tear_"..tostring(idx)] * auxi.get_mxdelay_multiplier(player) * mul))
			end
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			if save.elses["Tzolikn_Buff_range_"..tostring(idx)] then
				player.TearRange = player.TearRange + save.elses["Tzolikn_Buff_range_"..tostring(idx)] * mul
			end
		end
		if cacheFlag == CacheFlag.CACHE_SPEED then
			if save.elses["Tzolikn_Buff_speed_"..tostring(idx)] then
				player.MoveSpeed = player.MoveSpeed + save.elses["Tzolikn_Buff_speed_"..tostring(idx)] * mul
			end
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			if save.elses["Tzolikn_Buff_luck_"..tostring(idx)] then
				player.Luck = player.Luck + save.elses["Tzolikn_Buff_luck_"..tostring(idx)] * mul
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["Tzolikn_Buff_dmg_"..tostring(j)] = 0
			save.elses["Tzolikn_Buff_tear_"..tostring(j)] = 0
			save.elses["Tzolikn_Buff_range_"..tostring(j)] = 0
			save.elses["Tzolikn_Buff_speed_"..tostring(j)] = 0
			save.elses["Tzolikn_Buff_luck_"..tostring(j)] = 0
		end
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	local ret = true
	local idx = player:GetData().__Index
	if idx ~= nil then
		save.elses["Tzolikn_Buff_dmg_"..tostring(idx)] = save.elses["Tzolikn_Buff_dmg_"..tostring(idx)] + 0.2
		save.elses["Tzolikn_Buff_tear_"..tostring(idx)] = save.elses["Tzolikn_Buff_tear_"..tostring(idx)] + 0.1
		save.elses["Tzolikn_Buff_range_"..tostring(idx)] = save.elses["Tzolikn_Buff_range_"..tostring(idx)] + 0.5 * 40
		save.elses["Tzolikn_Buff_speed_"..tostring(idx)] = save.elses["Tzolikn_Buff_speed_"..tostring(idx)] + 0.05
		save.elses["Tzolikn_Buff_luck_"..tostring(idx)] = save.elses["Tzolikn_Buff_luck_"..tostring(idx)] + 0.2
		sound_tracker.PlayStackedSound(SoundEffect.SOUND_SATAN_BLAST,0.8,1.25,false,0,2)
		player:AddCacheFlags(CacheFlag.CACHE_ALL)
		player:GetData().should_evaluate_on_update_once = true
	end
	return ret
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,count)
	player:AddCacheFlags(CacheFlag.CACHE_ALL)
	player:GetData().should_evaluate_on_update_once = true
end,
})

return item