local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Darkness,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function()
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local q = player:GetMaxHearts()
			local pltp = player:GetPlayerType()
			if pltp == 14 or pltp == 18 or pltp == 33 then
				if q > 2 then
					player:AddMaxHearts(-q + 2,true)
					player:AddBlackHearts(q - 2)
				end
			else
				if q > 0 then
					player:AddMaxHearts(-q,true)
					player:AddBlackHearts(q)
				end
			end
			if item.black_hearts == nil or item.black_hearts ~= auxi.Count_Flags(player:GetBlackHearts()) then
				if item.black_hearts and item.black_hearts > auxi.Count_Flags(player:GetBlackHearts()) then
					local n_entity = Isaac.GetRoomEntities()
					local n_enemy = auxi.getenemies(n_entity)
					for i = 1,#n_enemy do
						n_enemy[i]:AddFear(EntityRef(player),600)
					end
				end
				item.black_hearts = auxi.Count_Flags(player:GetBlackHearts())
			end
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			item_manager.params.should_evaluate_on_update = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = nil,
Function = function(_,ent)
	if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() and not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
		local darkness_counter = 0
		local darkness_player = nil
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				darkness_counter = darkness_counter + auxi.Count_Flags(player:GetBlackHearts())
				darkness_player = player
			end
		end
		if darkness_counter > 0 and darkness_player ~= nil then
			if math.random(1000) < darkness_counter then
				ent:AddFear(EntityRef(darkness_player),30)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			local q1 = auxi.Count_Flags(player:GetBlackHearts())
			local q2 = 0
			local n_entity = Isaac.GetRoomEntities()
			local n_enemy = auxi.getenemies(n_entity)
			for i = 1,#n_enemy do
				if n_enemy[i]:HasEntityFlags(EntityFlag.FLAG_FEAR) then
					q2 = q2 + 1
				end
			end
			if #n_enemy ~= 0 then
				q2 = q2 * 0.1
			end
			player.Damage = player.Damage * (1 + q1 * 0.003) * (1 + q2) + q1 * 0.8 * (cnt + 3)/4 * auxi.get_damage_multiplier(player)
        end
		if cacheFlag == CacheFlag.CACHE_TEARFLAG then
            player.TearFlags = player.TearFlags | BitSet128(1<<(20),0) 
        end
		if cacheFlag == CacheFlag.CACHE_TEARCOLOR then
            player.TearColor = auxi.AddColor(player.TearColor,Color(1,1,1,1,-1,-1,-1),0,1)
            player.LaserColor = auxi.AddColor(player.LaserColor,Color(1,1,1,1,-1,-1,-1),0,1)
        end
	end
end,
})

return item