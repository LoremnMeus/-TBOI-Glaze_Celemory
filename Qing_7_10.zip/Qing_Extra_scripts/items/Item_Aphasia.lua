local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local displaying_data = require("Qing_Extra_scripts.translations.data")
local displaying_data2 = require("Qing_Extra_scripts.translations.data2")
local displaying_data3 = require("Qing_Extra_scripts.translations.data3")
local gui = require("Qing_Extra_scripts.auxiliary.gui")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Aphasia,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local player = auxi.check_spawner_player(ent)
	if player ~= nil and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		local d = player:GetData()
		if d.Aphasia_buffer ~= nil and #d.Aphasia_buffer > 0 then
			local rng = player:GetCollectibleRNG(item.entity)
			rng = auxi.rng_for_sake(rng)
			local rnd = rng:RandomInt(#d.Aphasia_buffer) + 1
			ent:GetData().Aphasia_render_word = d.Aphasia_buffer[rnd]
			table.remove(d.Aphasia_buffer,rnd)
			ent.CollisionDamage = ent.CollisionDamage * auxi.get_word_damage(ent:GetData().Aphasia_render_word)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_RENDER, params = nil,
Function = function(_,ent,offset)
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		local d = ent:GetData()
		if d.Aphasia_render_word then
			local s = ent:GetSprite()
			local offset = auxi.get_word_render_offset(d.Aphasia_render_word)
			local sx = s.Scale.X
			local sy = s.Scale.Y
			gui.draw_ch(Isaac.WorldToScreen(ent.Position + ent.PositionOffset) + Vector(sx * offset.X,sy * offset.Y),d.Aphasia_render_word,sx,sy,auxi.Color_2_KColor(ent:GetColor()),true)
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_DESCRIPT_ITEM, params = nil,
Function = function(_,player,tp,id,value)
	if player == nil or player:Exists() == false or player:IsDead() then player = Game():GetPlayer(0) end
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local name = value.Name
		local des = value.Description
		local target = name..des
		local ret = auxi.random_shuffle_string(target,player:GetCollectibleRNG(item.entity))
		if #des > 0 then
			local cut_n = math.min(#ret,math.max(0,auxi.get_string_real_length(name) + math.random(3) - 1))
			local result_name = auxi.collect_table_to_string(ret,1,cut_n)
			local result_des = auxi.collect_table_to_string(ret,cut_n + 1,#ret)
			return {Name = result_name,Description = result_des,}
		else
			local result = auxi.collect_table_to_string(ret)
			return {Name = result,Description = "",}
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_DESCRIPT_ITEM, params = nil,
Function = function(_,player,tp,value)
	if player == nil or player:Exists() == false or player:IsDead() then player = Game():GetPlayer(0) end
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local name = value.Name or ""
		local des = value.Description or ""
		if type(des) == "table" then des = auxi.collect_table_to_string(des) end
		local target = auxi.spilt_string(name..des)
		local rng = player:GetCollectibleRNG(item.entity)
		rng = auxi.rng_for_sake(rng)
		local rnd = rng:RandomInt(math.floor(#target)) + 1
		target = auxi.randomTable(target,rng)
		for i = 1,rnd do
			local word = target[i]
			local q = auxi.fire_nil(player.Position,auxi.MakeVector(math.random(3600)/10) * (math.random(5) + 5),{cooldown = 30 * 5,})
			q.GridCollisionClass = GridCollisionClass.COLLISION_OBJECT
			local d2 = q:GetData()
			d2.is_Aphasia_word = true
			if d2.Params == nil then d2.Params = {} end
			d2.Params.Accerate = - 0.25
			d2.RenderHeight = math.random(1000)/1000 * 5 + 15
			d2.RenderHeight_Velocity = math.random(1000)/1000 * 3 + 2
			d2.floor = 0
			d2.Aphasia_word = word
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_TELL_FORTUNE, params = nil,
Function = function(_,tp,value)
	local should_do = false
	local player = Game():GetPlayer(0)
	local result = nil
	for playerNum = 1, Game():GetNumPlayers() do
		local t_player = Game():GetPlayer(playerNum - 1)
		if t_player:HasCollectible(item.entity) or t_player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			player = t_player
			should_do = true
			break
		end
	end
	if should_do == true then
		local rng = player:GetCollectibleRNG(item.entity)
		rng = auxi.rng_for_sake(rng)
		local language = auxi.get_language_map(Options.Language)
		if language then
			if tp == "Fortune" then
				if rng:RandomInt(1000) > 300 then
					local rnd = rng:RandomInt(64) + 1
					if displaying_data[language] then
						local data = displaying_data[language]["#Entry_"..tostring(rnd)]
						if data then
							result = auxi.random_work_on_the_raw_string(data,rng)
						end
					end
				else
					local rnd = rng:RandomInt(69) + 1
					if displaying_data3[language] then
						local data = displaying_data3[language]["#Entry_"..tostring(rnd)]
						if data then
							result = auxi.random_work_on_the_raw_string(data,rng)
						end
					end
				end
			elseif tp == "Tips" then
				local rnd = rng:RandomInt(8) + 1
				if displaying_data2[language] then
					local data = displaying_data2[language]["#Entry_"..tostring(rnd)]
					if data then
						result = auxi.random_work_on_the_raw_string(data,rng)
					end
				end
			end
		end
		result = {Description = result,}
	end
	return result
end,
})

return item