local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Tears_of_Pearl,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local s = ent:GetSprite()
	local d = ent:GetData()
	if d.Tears_of_Pearl_conter == nil and d.Ignore_me_flag == nil then
		d.Tears_of_Pearl_conter = true
		local player = auxi.check_spawner_player(ent)
		if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
			if auxi.check_rand(player.Luck,15,5,15) then
				s:Load("gfx/Pearl_Tear.anm2",true)
				s:Play("Idle",true)
				d.is_pearl_tear = true
				ent.TearFlags = ent.TearFlags & (~BitSet128(1<<60,0))
			end
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	if d.is_pearl_tear then
		d.pearl_bounce_counter = (d.pearl_bounce_counter or 0) + 1
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	if d.is_pearl_tear then
		if d.Pearl_state_2 or ent.Height > -5 then
			d.Pearl_state_2 = true
			ent.TearFlags = ent.TearFlags & (~BitSet128(1<<1,0))
			ent.Height = -5
			ent.FallingSpeed = 0
			d.Pearl_acce_del = (d.Pearl_acce_del or 0.6) * 0.98 + 0.6 * 0.02
			ent.Velocity = ent.Velocity * d.Pearl_acce_del
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				local dir = player.Position - ent.Position
				if dir:Length() < 20 then
					ent.Velocity = ent.Velocity - dir * 0.2 + player.Velocity * 0.4
					d.Pearl_acce_del = 1
				end
			end
			local n_entity = Isaac.GetRoomEntities()
			local n_proj = auxi.getothers(n_entity,9)
			for u,v in pairs(n_proj) do
				if (v.Position - ent.Position):Length() < 20 then
					v = v:ToProjectile()
					local q = Isaac.Spawn(2,0,0,v.Position,-v.Velocity,nil):ToTear()
					local s2 = v:GetSprite()
					local s3 = q:GetSprite()
					s3:Load(s2:GetFilename(),true)
					s3:Play(s2:GetAnimation(),true)
					s3.Color = s2.Color
					s3.Scale = s2.Scale
					q.Height = v.Height
					q.FallingSpeed = v.FallingSpeed
					q.FallingAcceleration = v.FallingAccel
					local q2 = Isaac.Spawn(1000,133,0,ent.Position,Vector(0,0),nil)
					d.pearl_bounce_counter = (d.pearl_bounce_counter or 0) + 1
					v:Remove()
				end
			end
			if (d.pearl_bounce_counter or 0) < 5 then
				ent.TearFlags = ent.TearFlags | BitSet128(1<<19,0)
			else
				ent.TearFlags = ent.TearFlags & (~BitSet128(1<<19,0))
			end
		end
	end
end,
})

return item