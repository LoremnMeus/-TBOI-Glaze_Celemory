local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	entity = enums.Items.Cable_Jar,
	tear_flag_buff = {
		[0] = TearFlags.TEAR_BONE,			--分裂1
		[1] = TearFlags.TEAR_SLOW,			--减速2
		[2] = TearFlags.TEAR_HOMING,		--深紫色3
		[3] = TearFlags.TEAR_FEAR,			--深色4
		[4] = BitSet128(0,1<<(65-64)),		--冰5
		[5] = TearFlags.TEAR_POISON,		--毒6
		[6] = BitSet128(0,1<<(66-64)),		--磁力7
		[7] = TearFlags.TEAR_ACID,			--硫酸8
		[8] = TearFlags.TEAR_GODS_FLESH,	--缩小
		[9] = TearFlags.TEAR_CONFUSION,		--眩晕
	},
	tear_color_buff = {
		[0] = Color(1,1,1,0.7,0,0,0),
		[1] = Color(1,0,0,0.7,0.5,0,0),
		[2] = Color(1,0.1,0.5,0.7,0.5,0,0.2),
		[3] = Color(1,0,1,0.7,0.2,0,0.2),
		[4] = Color(0.4,0,1,0.7,0,0,0.3),
		[5] = Color(0,0.5,1,0.7,0,0.2,0.5),
		[6] = Color(0.5,0.5,0,0.7,0.2,0.2,0),
		[7] = Color(0.4,0.6,0,0.8,0.1,0.3,0),
		[8] = Color(1,1,0,0.7,0.5,0.4,0),
		[9] = Color(1,0.7,0,0.7,0.5,0.2,0),
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local charge_count = math.random(4) - 1
		for i = 0,3 do
			if player:GetActiveItem(i) > 0 then 
				local collid = player:GetActiveItem(i)
				local col = Isaac.GetItemConfig():GetCollectible(collid)
				if player:GetActiveCharge(i) > 0 and col.MaxCharges <= 12 then
					charge_count = charge_count + player:GetActiveCharge(i) + player:GetBatteryCharge(i)
				elseif player:GetActiveCharge(i) > 0 then
					charge_count = charge_count + 1
					if player:GetBatteryCharge(i) > 0 then
						charge_count = charge_count + 1
					end
				end
				player:SetActiveCharge(0,i)
			end
		end
		local rng = player:GetCollectibleRNG(item.entity)
		for i = 1,charge_count do
			local ang = math.random(3600)/10
			local rnd = rng:RandomInt(10)
			local q = Isaac.Spawn(7,2,4,player.Position,Vector(0,0),player):ToLaser()
			local s = q:GetSprite()
			s:Load("gfx/laser_coverer.anm2",true)
			s:Play("Laser"..(math.random(4) - 1),true)
			s.Color = item.tear_color_buff[rnd]
			q.Angle = ang
			q:SetTimeout(5)
			q.TearFlags = q.TearFlags | item.tear_flag_buff[rnd]
			q.PositionOffset = Vector(0,0)
			q.CollisionDamage = player.Damage * 0.7 + 3
			q:SetOneHit(true)
			local endpos = player.Position + auxi.MakeVector(ang) * (100 + math.random(50))
			delay_buffer.addeffe(function(params)
				for i = 1,4 do
					local ang = ang + 130 + 20 * i
					local rnd = rng:RandomInt(10)
					local q = Isaac.Spawn(7,2,4,endpos,Vector(0,0),player):ToLaser()
					local s = q:GetSprite()
					s:Load("gfx/laser_coverer.anm2",true)
					s:Play("Laser"..(math.random(4) - 1),true)
					s.Color = item.tear_color_buff[rnd]
					q.Angle = ang
					q:SetTimeout(7)
					q.TearFlags = q.TearFlags | item.tear_flag_buff[rnd]
					q.PositionOffset = Vector(0,0)
					q.CollisionDamage = player.Damage * 0.2 + 0.5
					q:SetOneHit(true)
				end
			end,{},1)
			local q = Isaac.Spawn(2,0,0,endpos,auxi.MakeVector(ang) * (1.5 + math.random(1000)/1000),player):ToTear()
			local s2 = q:GetSprite()
			s2.Color = item.tear_color_buff[rnd]
			local d2 = q:GetData()
			d2.is_cable_jar_tear = true
			d2.Ignore_me_flag = true
			d2.ignore_field = true
			q.TearFlags = q.TearFlags | BitSet128(1<<1,0) | BitSet128(1<<0,0) 
			d2.target = player
			q.CollisionDamage = 2.5
		end
	end
end,
})

local function reward(player)
	local ret = false
	for i = 0,3 do
		if player:NeedsCharge(i) then
			if player:GetActiveItem(i) > 0 then 
				local collid = player:GetActiveItem(i)
				local col = Isaac.GetItemConfig():GetCollectible(collid)
				if col.MaxCharges <= 12 then
					player:SetActiveCharge(player:GetActiveCharge(i) + player:GetBatteryCharge(i) + 1,i)
				else
					if player:GetBatteryCharge(i) > 0 then
						player:SetActiveCharge(col.MaxCharges * 2,i)
					else
						player:SetActiveCharge(col.MaxCharges,i)
					end
				end
				ret = true
				break
			end
		end
	end
	return ret
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_cable_jar_tear then
		local s = ent:GetSprite()
		local player = Game():GetPlayer(0)
		if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
		if d.tail and d.tail:Exists() and d.tail:IsDead() ~= true then
			d.tail.Position = ent.Position
			d.tail.PositionOffset = d.tail.PositionOffset + (d.tail:GetData().vel or Vector(0,-1))
		else
			local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.HAEMO_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
			q:GetData().vel = auxi.MakeVector(math.random(3600)/10) * 1.7 + Vector(0,-1) - ent.Velocity:Normalized() * math.min(ent.Velocity:Length()/2,2)
			d.tail = q
			q.MinRadius = 0.15
			q.MaxRadius = 0.15
			q:GetSprite().Scale = Vector(0.5,0.5)
			q.Parent = ent
			q.PositionOffset = Vector(0,-24)
			q.Color = s.Color
			ent.Child = q
		end
		s.Rotation = ent.Velocity:GetAngleDegrees()
		ent.FallingSpeed = 0
		ent.Height = - 24
		if d.target then
			if (d.target.Position - ent.Position):Length() < 20 then
				local player = d.target:ToPlayer()
				if player then 
					local ret = reward(player)
					if ret == true then 
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_SOUL_PICKUP,0.3,1,false,0,2)
					end
				end
				ent:Remove()
			elseif (d.target.Position - ent.Position):Length() < 50 then
				ent.Velocity = (d.target.Position - ent.Position):Normalized() * math.max(math.min(6,d.target.Velocity:Length() * 1.2),ent.Velocity:Length() * 0.98)
			else
				ent.Velocity = ent.Velocity * 0.95
			end
		end
	end
end,
})

return item