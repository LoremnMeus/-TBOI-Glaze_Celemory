local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local dropping_holder = require("Qing_Extra_scripts.others.Dropping_holder")
local option_index_holder = require("Qing_Extra_scripts.others.Option_Index_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local item_displaying_holder = require("Qing_Extra_scripts.callbacks.item_displaying_holder")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Book_of_Vision,
	should_duplicate = nil,
	duplicate_filter = {},
	should_check_for_the_same = {
		"bomb",
		"key",
		"coin",
		"gbomb",
		"gkey",
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	local ret = true
	if coltyp == item.entity then
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
			item.should_duplicate = (item.should_duplicate or 0) + 1
		else
			item.should_duplicate = (item.should_duplicate or 0) + 1
		end
		return ret
	end
end,
})

local function check_the_same(player,changetype)
	if item.should_check_for_the_same[changetype] == nil then return true end
	return auxi.check_for_the_same(player,Game():GetPlayer(0))
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_BASIC, params = nil,
Function = function(_,player,changetype,count)
	local n_wisp = auxi.get_wisps(player,item.entity)
	if ((item.should_duplicate and item.should_duplicate > 0) or (#n_wisp > 0 and count > 0)) and check_the_same(player,changetype) then
		local cnt = (item.should_duplicate or 0)
		if (#n_wisp > 0 and count > 0) then 
			cnt = cnt + (#n_wisp)
			for u,v in pairs(n_wisp) do v:Remove() end 
		end
		local idx = player:GetData().__Index
		if idx then
			if (item.duplicate_filter[changetype] or 0) < Game():GetFrameCount() then
				if changetype == "bomb" then
					player:AddBombs(count * cnt)
				elseif changetype == "key" then
					player:AddKeys(count * cnt)
				elseif changetype == "coin" then
					player:AddCoins(count * cnt)
				elseif changetype == "gbomb" then
					player:AddBombs(count * 3 * cnt)
					item.duplicate_filter["bomb"] = Game():GetFrameCount() + 5
				elseif changetype == "gkey" then
					player:AddKeys(count * 3 * cnt)
					item.duplicate_filter["key"] = Game():GetFrameCount() + 5
				elseif changetype == "rd_heart" then
					player:AddHearts(count * cnt)
				elseif changetype == "gd_heart" then
					player:AddGoldenHearts(count * cnt)
				elseif changetype == "sl_heart" then
					auxi.add_soul_heart(player,count * cnt)
				elseif changetype == "et_heart" then
					player:AddEternalHearts(count * cnt)
				elseif changetype == "rt_heart" then
					player:AddRottenHearts(count * cnt)
				end
				item.duplicate_filter[changetype] = Game():GetFrameCount() + 5
			else
				item.duplicate_filter[changetype] = nil
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	item.should_duplicate = nil
	item.duplicate_filter = {}
end,
})

return item