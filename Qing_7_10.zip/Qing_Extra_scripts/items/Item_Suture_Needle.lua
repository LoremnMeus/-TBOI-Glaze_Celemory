local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	pre_ToCall = {},
	ToCall = {},
	entity = enums.Items.Suture_Needle,
	now_ent = nil,
	enemy = enums.Enemies.chimella,
	should_update = 0,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,collect,rng,player,useFlags,activeSlot,varData)
	if collect == item.entity then
		local room = Game():GetRoom()
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		local targ = {}
		for u,v in pairs(n_enemy) do
			if auxi.is_movable_enemy(v,true) == true then
				table.insert(targ,#targ+1,v)
			end
		end
		for u,v in pairs(targ) do
			if v:GetData().is_suture_enemy then table.remove(targ,u) end
		end
		if #targ > 1 or (#targ == 1 and item.now_ent and item.now_ent:Exists() and item.now_ent:IsDead() == false) then
			local tgs = #targ
			local tgs_leg = math.max(2,math.min(20,5 * (tgs - 1)))
			local pos = player.Position + auxi.MakeVector(math.random(10000)/10000 * 360)* 50
			if item.now_ent == nil or item.now_ent:Exists() == false or item.now_ent:IsDead() == true then
				item.now_ent = Isaac.Spawn(996,item.enemy,0,pos,Vector(0,0),nil)
				item.now_ent.MaxHitPoints = 1
				item.now_ent.HitPoints = 1
			end
			local chi = item.now_ent
			local d2 = chi:GetData()
			if d2.attach_enemy == nil then d2.attach_enemy = {} end
			for u,v in pairs(targ) do
				local d_pos = Vector(math.random(10000)/10000 * tgs_leg - tgs_leg/2,math.random(10000)/10000 * tgs_leg - tgs_leg/2)
				if v:IsBoss() == true then
					d_pos = Vector(0,0)
				end
				local d = v:GetData()
				local s = v:GetSprite()
				v.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				d.suture_pre_grid_coll = v.GridCollisionClass
				v.GridCollisionClass = GridCollisionClass.COLLISION_WALL
				v.Position = room:FindFreePickupSpawnPosition(pos,10,false) + d_pos
				d.is_suture_enemy = true
				d.suture_posi = d_pos
				s.Color = Color(0.3,0.2,0.3,0.4,0.1,0.2,0.15)
				s.Rotation = 180 + math.random(10000)/10000 * 90
				s.Scale = Vector(math.random(1000)/1000 * 0.4 + 0.8,math.random(1000)/1000 * 0.4 + 0.2)
				d.suture_chimella = chi
				chi.MaxHitPoints = chi.MaxHitPoints + v.MaxHitPoints * 0.8
				chi.HitPoints = chi.HitPoints + v.HitPoints * 0.8
				table.insert(d2.attach_enemy,#(d2.attach_enemy) + 1,v)
			end
			for i = 1,10 do
				delay_buffer.addeffe(function(params)
					local rnd = math.random(3) - 2
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_TOOTH_AND_NAIL,math.random(2000)/10000 + 0.9,math.random(2000)/10000 + 0.9,false,rnd,2)
				end,{},i * 2)
			end
			if auxi.should_spawn_wisp(player,useFlags) then
				local n_wisp = auxi.get_wisps(player,item.entity)
				local ent = nil
				if #n_wisp > 0 then 
					ent = n_wisp[1] or player:AddWisp(item.entity,player.Position,false,false)
					for i = 2,#n_wisp do n_wisp[i]:Remove() end
				else
					ent = player:AddWisp(item.entity,player.Position,false,false)
				end
				local d = ent:GetData()
				d.Suture_Needle_mul = (d.Suture_Needle_mul or 0) + #targ
				ent.MaxHitPoints = ent.MaxHitPoints + (#targ)
				ent.HitPoints = ent.HitPoints + (#targ)
				local s = ent:GetSprite()
				d.Suture_Needle_scale = (d.Suture_Needle_scale or Vector(0,0)) * 1.3
				d.Suture_Needle_Color = Color(-1,-1,-1,1,1,1,1)
			end
		end
		return true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = FamiliarVariant.WISP,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local d = ent:GetData()
		local s = ent:GetSprite()
		local mul = d.Suture_Needle_mul or 0
		d.Suture_Needle_scale = (d.Suture_Needle_scale or Vector(1,1)) * 0.98 + Vector(mul * 0.05 + 1,mul * 0.05 + 1) * 0.02
		s.Scale = d.Suture_Needle_scale
		d.Suture_Needle_Color = auxi.AddColor(d.Suture_Needle_Color or Color(1,1,1,1),Color(1,1,1,1),0.98,0.02)
		s.Color = d.Suture_Needle_Color
		ent.CollisionDamage = mul * 2
		if ent.MaxHitPoints > ent.HitPoints then
			d.Suture_Needle_mul = math.max(0.5,d.Suture_Needle_mul - (ent.MaxHitPoints - ent.HitPoints))
			ent.MaxHitPoints = ent.HitPoints
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = FamiliarVariant.WISP,
Function = function(_,ent,col,low)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local d = ent:GetData()
		if d.is_suture_enemy or (col.Type == 996 and col.Variant == item.enemy) then 
			if item.now_ent then
				item.now_ent:TakeDamage(ent.CollisionDamage * 2,0,EntityRef(ent),0)
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_FIREDEATH_HISS,1.2,1,false,0,2)
			end
			col:TakeDamage(ent.CollisionDamage * 2,0,EntityRef(ent),0)
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_FIREDEATH_HISS,0.8,1,false,0,2)
			d.Suture_Needle_mul = math.max(0.5,(d.Suture_Needle_mul or 1) - 1)
			return false 
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = 996,
Function = function(_,ent,offset)
	if ent.Type == 996 and ent.Variant == item.enemy then
		if ent:GetData().imi_target then
			if Game():IsPaused() == false then
				if item.should_update == 0 then
					item.should_update = 1
					ent:GetSprite():Update()
				else
					item.should_update = 0
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = 996,
Function = function(_,ent)
	if ent.Type == 996 and ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if ent.FrameCount > 2 and (d.attach_enemy == nil or #d.attach_enemy == 0) then
			ent:Kill()
		else
			if ent.FrameCount % 60 == 10 or d.imi_target == nil or d.imi_target:Exists() == false or d.imi_target:IsDead() == true then
				local tg = d.attach_enemy[math.random(#d.attach_enemy)]
				local cnt = 1
				for u,v in pairs(d.attach_enemy) do
					if v:IsBoss() == true and v ~= nil and v:Exists() == true and v:IsDead() == false then
						v.MaxHitPoints = ent.MaxHitPoints
						v.HitPoints = ent.HitPoints
						if math.random(cnt) == 1 then
							tg = v
							cnt = cnt + 1
						end
					end
				end
				if tg ~= nil and tg:Exists() == true and tg:IsDead() == false then
					if d.imi_target and d.imi_target:Exists() then
						d.imi_target:GetData().is_suture_imi = nil
						d.imi_target.GridCollisionClass = GridCollisionClass.COLLISION_WALL
					end
					d.imi_target = tg
					if tg:GetData().suture_pre_grid_coll then d.imi_target.GridCollisionClass = tg:GetData().suture_pre_grid_coll end
					tg:GetData().is_suture_imi = true
				else
					ent:Remove()
				end
			end
		end
		for u,v in pairs(d.attach_enemy) do
			if v:IsBoss() == true and v ~= nil and v:Exists() == true and v:IsDead() == false then
				v.HitPoints = ent.HitPoints / ent.MaxHitPoints * v.MaxHitPoints
			end
		end
		if d.imi_target then
			if s:GetFilename() ~= d.imi_target:GetSprite():GetFilename() then
				s:Load(d.imi_target:GetSprite():GetFilename(),true)
			end
			if s:GetAnimation() ~= d.imi_target:GetSprite():GetAnimation() then
				s:Play(d.imi_target:GetSprite():GetAnimation(),true)
			end
			s.FlipX = d.imi_target:GetSprite().FlipX
			if s:GetOverlayAnimation() ~= d.imi_target:GetSprite():GetOverlayAnimation() then
				s:PlayOverlay(d.imi_target:GetSprite():GetOverlayAnimation(),true)
			end
		end
		s.Color = Color(0.5,0.5,0.6,1,0.9,0.9,0.8)
		if d.imi_target and d.imi_target:Exists() and d.imi_target:IsDead() == false then
			if d.imi_target:GetData().suture_posi then
				ent.Position = d.imi_target.Position - d.imi_target:GetData().suture_posi
			end
			ent.Velocity = d.imi_target.Velocity
			d.imi_target:Update()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_suture_enemy and d.is_suture_enemy == true then
		if d.suture_chimella and d.suture_chimella:Exists() and d.suture_chimella:IsDead() == false then
			if d.suture_posi then
				if d.is_suture_imi and d.is_suture_imi == true then
					
				else
					ent.Position = d.suture_chimella.Position + d.suture_posi
					if (ent.Velocity - d.suture_chimella.Velocity):Length() > 1e-2 then
						ent.Velocity = d.suture_chimella.Velocity
						if d.suture_rotate_dir == nil then d.suture_rotate_dir = 0 end
						--s.Rotation = s.Rotation + math.sin(math.rad(d.suture_rotate_dir * 5)) * 1
						d.suture_rotate_dir = d.suture_rotate_dir + (math.random(2) * 2 - 3)
					end
					if ent:IsBoss() == true then
						if d.suture_rotate_dir == nil then d.suture_rotate_dir = 0 end
						--s.Rotation = s.Rotation + math.sin(math.rad(d.suture_rotate_dir * 5)) * 1
						d.suture_rotate_dir = d.suture_rotate_dir + (math.random(2) * 2 - 3)
					end
				end
			end
		else
			ent:Kill()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = 996,
Function = function(_,ent)
	if ent.Type == 996 and ent.Variant == item.enemy then
		local s = ent:GetSprite()
		local d = ent:GetData()
		s:Play("Idle",true)
		ent:AddEntityFlags(EntityFlag.FLAG_NO_STATUS_EFFECTS)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 996,
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Type == 996 and ent.Variant == item.enemy then
		if source and source.Entity and source.Entity:GetData().is_suture_enemy then
			return false
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,		--先置
Function = function(_,ent,amt,flag,source,cooldown)
	local d = ent:GetData()
	if d.is_suture_enemy and d.is_suture_enemy == true then
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = 45,	--防止某些奇怪情况
Function = function(_,ent,col,low)
	if col.Variant == item.enemy and col.Type == 996 then
		return false
	end
end,
})

return item