local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Drama_of_sorrow_and_joy,
	tear1_height = 200,
	tear2_height = 80,
	limit = 13,
	costumes = {
		[1] = enums.Costumes.Despia_1,
		[2] = enums.Costumes.Despia_2,
		[3] = enums.Costumes.Despia_3,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["DOSAJ_effect_"..tostring(j)] = 0
			save.elses["DOSAJ_effect_smile_"..tostring(j)] = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if amt > 0 and auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
		if player then
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local idx = player:GetData().__Index
				if idx then
					save.elses["DOSAJ_effect_"..tostring(idx)] = 1 - (save.elses["DOSAJ_effect_"..tostring(idx)] or 0)
				end
				save.elses["DOSAJ_effect_smile_"..tostring(idx)] = (save.elses["DOSAJ_effect_smile_"..tostring(idx)] or 0) + 1
				if save.elses["DOSAJ_effect_smile_"..tostring(idx)] == item.limit then
					for i = 1,2 do
						player:TryRemoveNullCostume(item.costumes[i])
					end
					player:AddNullCostume(item.costumes[3])
					player:GetData().DOSAJ_sad = true
				end
				if save.elses["DOSAJ_effect_smile_"..tostring(idx)] < item.limit then
					for i = 1,2 do
						player:TryRemoveNullCostume(item.costumes[i])
					end
					player:AddNullCostume(item.costumes[save.elses["DOSAJ_effect_"..tostring(idx)] + 1])
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,count,lastnumber)
	if count < 0 and player:HasCollectible(item.entity) == false and player:GetEffects():GetCollectibleEffectNum(item.entity) == 0 then
		for i = 1,3 do
			player:TryRemoveNullCostume(item.costumes[i])
		end
	end
	if count > 0 and player:GetCollectibleNum(item.entity,true) == count then
		local idx = player:GetData().__Index
		if idx then
			if save.elses["DOSAJ_effect_"..tostring(idx)] == nil then save.elses["DOSAJ_effect_"..tostring(idx)] = 0 end
			if save.elses["DOSAJ_effect_smile_"..tostring(idx)] >= item.limit then
				player:AddNullCostume(item.costumes[3])
			else
				player:AddNullCostume(item.costumes[save.elses["DOSAJ_effect_"..tostring(idx)] + 1])
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if player:IsExtraAnimationFinished() then
			if player:GetData().DOSAJ_sad then
				player:AnimateSad()
				player:GetData().DOSAJ_sad = nil
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	for j = 1,10 do
		if (save.elses["DOSAJ_effect_smile_"..tostring(j)] or 0) < item.limit then save.elses["DOSAJ_effect_smile_"..tostring(j)] = 0 end
	end
end,
})

local function make_DOSAJ_tear(tp,ent)
	if ent == nil or ent:ToTear() == nil then return nil end
	ent = ent:ToTear()
	sound_tracker.PlayStackedSound(SoundEffect.SOUND_PLOP,1,0.7 + math.random(1000)/1000 * 0.6,false,0,2)
	if tp == 1 then
		local d = ent:GetData()
		local s = ent:GetSprite()
		ent.TearFlags = BitSet128(1,0) | BitSet128(1<<1,0)
		ent.Variant = 0
		s:Load("gfx/Despia_Tear.anm2",true)
		s:Play("Idle1",true)
		d.Ignore_me_flag = true
		d.is_despia_1 = true
		d.start_rotation = ent.Velocity:GetAngleDegrees() - 90
		ent.FallingSpeed = 0
		ent.FallingAcceleration = 0
		d.despia_state = 1
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
	else
		local d = ent:GetData()
		local s = ent:GetSprite()
		ent.TearFlags = ent.TearFlags & ~(BitSet128(1<<60,0)| BitSet128(0,1<<(68-64)) | BitSet128(1<<2,0))
		s:Load("gfx/Despia_Tear.anm2",true)
		s:Play("Idle2",true)
		d.Ignore_me_flag = true
		d.is_despia_2 = true
		d.start_rotation = ent.Velocity:GetAngleDegrees() - 90
		ent.FallingSpeed = 0
		ent.FallingAcceleration = 0
		d.despia_state = 1
	end
	return ent
end

local function try_fire_DOSAJ_tear(player,pos,vel)
	if player == nil then return nil end
	local idx = player:GetData().__Index
	if idx then
		local ignore_flag = false
		if (save.elses["DOSAJ_effect_smile_"..tostring(idx)] or 0) >= item.limit then ignore_flag = true end
		if (ignore_flag ~= true and (save.elses["DOSAJ_effect_"..tostring(idx)] or 0) == 0) or (ignore_flag == true and math.random(1000) > 500)then
			if auxi.check_rand(player.Luck,15,5,12) or ignore_flag then
				local ent = Isaac.Spawn(2,0,0,pos or player.Position,vel or Vector(0,0),player)
				return make_DOSAJ_tear(1,ent)
			end
		else
			if auxi.check_rand(player.Luck,20,15,9) or ignore_flag then
				local ent = Isaac.Spawn(2,0,0,pos or player.Position,vel or Vector(0,0),player)
				return make_DOSAJ_tear(2,ent)
			end
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local player = auxi.check_spawner_player(ent)
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) and d.Ignore_me_flag == nil then
		local idx = player:GetData().__Index
		if idx then
			local ignore_flag = false
			if (save.elses["DOSAJ_effect_smile_"..tostring(idx)] or 0) >= item.limit then ignore_flag = true end
			if (ignore_flag ~= true and (save.elses["DOSAJ_effect_"..tostring(idx)] or 0) == 0) or (ignore_flag == true and math.random(1000) > 500)then
				if auxi.check_rand(player.Luck,15,5,12) or ignore_flag then
					make_DOSAJ_tear(1,ent)
				end
			else
				if auxi.check_rand(player.Luck,20,15,9) or ignore_flag then
					make_DOSAJ_tear(2,ent)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	if d.is_despia_2 then 
		if d.now_target and d.now_target:Exists() and not d.now_target:IsDead() then
			local res = auxi.check_for_the_same(d.now_target,col)
			if res then
				local player = auxi.check_spawner_player(ent)
				Game():BombExplosionEffects(ent.Position,ent.CollisionDamage * 2,0,Color(0,-1,-1,1),player,(ent:GetSprite().Scale:Length()) * 0.4,true,false)
				ent:Remove()
			else
				return false
			end
		end
	end
	if d.is_despia_1 then
		return false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_despia_1 then
		local player = auxi.check_spawner_player(ent)
		local ggdir = auxi.ggdir(player,true,true)
		if player then
			if ggdir:Length() > 0.05 then 
				d.start_rotation = auxi.checkrounded(d.start_rotation,ggdir:GetAngleDegrees() - 90,0.8,0.2,360)
			else
				d.start_rotation = auxi.checkrounded(d.start_rotation,0,0.8,0.2,360)
			end
			if d.despia_state == 1 then
				if ent.Height > - item.tear1_height then 
					ent.Height = math.max(ent.Height * 1.1,ent.Height - 5)
					if ggdir:Length() > 0.05 then 
						ent.Velocity = (ent.Velocity:Length() * 0.96 + player.ShotSpeed * 7 * 0.04) * 0.96 * (ent.Velocity + player.ShotSpeed * 7 * ggdir * 0.1):Normalized()
					else
						ent.Velocity = ent.Velocity * 0.96 
					end
					-- (ent.Velocity:Length() * 0.9 + player.ShotSpeed * 7 * 0.1) * 0.96 * (ent.Velocity + player.ShotSpeed * 7 * ggdir):Normalized()
				else
					d.despia_state = 2
				end
			end
			if d.despia_state == 2 then
				if ggdir:Length() > 0.05 then 
					ent.Height = ent.Height * 0.95
					if ent.Height < - 30 then
						s.Scale = s.Scale:Normalized() * math.max(math.min(s.Scale:Length() * 1.1,3),s.Scale:Length()* 1.01)
						ent.Velocity = (ent.Velocity:Length() * 0.9 + player.ShotSpeed * 7 * 0.1) * (ent.Velocity + player.ShotSpeed * 7 * ggdir):Normalized()
					else
						d.despia_state = 3
						s:Play("Idle3",true)
						d.record_damage = ent.CollisionDamage
						ent.CollisionDamage = 0
					end
				else
					ent.Height = math.min(-30,ent.Height * 0.9 + (-item.tear1_height) * 0.1)
					ent.Velocity = ent.Velocity * 0.9
				end
			end
			if d.despia_state == 3 then
				ent.Height = - 30
				ent.Velocity = ent.Velocity * 0.5
				if s:IsEventTriggered("Explode") == true then
					Game():BombExplosionEffects(ent.Position,(d.record_damage or 5) * 5,0,Color(1,0,0,1),player,(s.Scale:Length()) * 0.4,true,false)
				end
				if s:IsFinished("Idle3") then
					ent:Remove()
				end
			end
			s.Rotation = d.start_rotation
		end
	end
	if d.is_despia_2 then
		local player = auxi.check_spawner_player(ent)
		if player then
			if d.now_target == nil then 
				local tg = auxi.get_by_farest_enemy(player.Position)
				if tg then d.now_target = tg end
			end
			if d.now_target and d.now_target:Exists() and not d.now_target:IsDead() then
				local tg = d.now_target
				d.start_rotation = auxi.checkrounded(d.start_rotation,(tg.Position - ent.Position):GetAngleDegrees() - 90,0.9,0.1,360)
				ent.Velocity = (ent.Velocity:Length() * 0.9 + 0.1 * player.ShotSpeed * 7) * (ent.Velocity + (tg.Position - ent.Position):Normalized() * 5):Normalized()
				ent.Height = ent.Height * 0.9 + (- item.tear2_height) * 0.1
				s.Scale = s.Scale:Normalized() * math.max(math.min(s.Scale:Length() * 1.1,2),s.Scale:Length()* 1.01)
			else
				d.now_target = nil
				d.start_rotation = auxi.checkrounded(d.start_rotation,0,0.9,0.1,360)
				ent.Velocity = ent.Velocity * 0.9
				ent.Height = ent.Height * 0.95
				s.Scale = s.Scale:Normalized() * math.min(math.max(s.Scale:Length() * 0.9,1),s.Scale:Length()* 0.99)
			end
			s.Rotation = d.start_rotation
		end
	end
	if ent.TearFlags & BitSet128(0,1<<(127-64)) == BitSet128(0,1<<(127-64)) then
		local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
		if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if ent.FrameCount % 10 == 1 then
				if ent.Velocity:Length() > 0.5 then
					try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(60) - 30 + ent.Velocity:GetAngleDegrees()) * (math.random(1000)/1000 * 3 + 3))
				else
					try_fire_DOSAJ_tear(player,ent.Position,ent.Velocity + auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 3 + 3))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_KNIFE_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.DOSAJ_counter then d.DOSAJ_counter = d.DOSAJ_counter - 1 end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = nil
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 3 and ent.SpawnerEntity:ToFamiliar() then player = ent.SpawnerEntity:ToFamiliar().Player end
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		if d.DOSAJ_counter == nil then d.DOSAJ_counter = 0 end
		d.DOSAJ_counter = d.DOSAJ_counter - 1
		if d.DOSAJ_counter <= 0 and col:IsVulnerableEnemy() and col:IsActiveEnemy() and (not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and col:CanShutDoors() == true then
			d.DOSAJ_counter = 12
			try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 4 + 3))
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_QINGS_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = nil
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 3 and ent.SpawnerEntity:ToFamiliar() then player = ent.SpawnerEntity:ToFamiliar().Player end
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		if d.DOSAJ_counter == nil then d.DOSAJ_counter = 0 end
		d.DOSAJ_counter = d.DOSAJ_counter - 1
		if d.DOSAJ_counter <= 0 and col and col:IsVulnerableEnemy() and col:IsActiveEnemy() and (not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and col:CanShutDoors() == true then
			d.DOSAJ_counter = 12
			try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 4 + 3))
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_BOMB_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = nil
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 3 and ent.SpawnerEntity:ToFamiliar() then player = ent.SpawnerEntity:ToFamiliar().Player end
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) and ent.IsFetus == true then
		if s:IsPlaying("Explode") and s:GetFrame() == 0 then
			local rnd = math.random(3) + 1
			for i = 1,rnd do
				try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 6 + 2))
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = 1000,
Function = function(_,ent)
	if ent.Variant == EffectVariant.ROCKET then
		local d = ent:GetData()
		local s = ent:GetSprite()
		local player = Game():GetPlayer(0)
		if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
		if ent.SpawnerEntity and ent.SpawnerEntity.Type == 3 and ent.SpawnerEntity:ToFamiliar() then player = ent.SpawnerEntity:ToFamiliar().Player end
		if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
			local rnd = math.random(3) + 1
			for i = 1,rnd do
				try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 6 + 2))
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local player = nil
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 1 and ent.SpawnerEntity:ToPlayer() then player = ent.SpawnerEntity:ToPlayer() end
	if ent.SpawnerEntity and ent.SpawnerEntity.Type == 3 and ent.SpawnerEntity:ToFamiliar() then player = ent.SpawnerEntity:ToFamiliar().Player end
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		if ent.FrameCount == 5 then
			local cnt = 1
			if ent.Variant == 1 or ent.Variant == 3 or ent.Variant == 5 or ent.Variant == 6 or ent.Variant == 9 or ent.Variant == 11 or ent.Variant == 12 or ent.Variant == 14 or ent.Variant == 15 then cnt = cnt + 2 end
			if ent.Variant == 6 or ent.Variant == 9 or ent.Variant == 11 or ent.Variant == 12 or ent.Variant == 14 or ent.Variant == 15 then cnt = cnt + 2 end
			if ent.MaxDistance > 0 then 
				if ent.MaxDistance <= 35 then cnt = math.max(1,cnt - 2) end
				if ent.MaxDistance <= 100 then cnt = math.max(1,cnt - 1) end
			end
			for i = 1,cnt do
				if ent:IsCircleLaser() then 
					try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(math.random(36000)/100) * (math.random(1000)/1000 * 3 + 4))
				else
					try_fire_DOSAJ_tear(player,ent.Position,auxi.MakeVector(ent.Angle + math.random(60) - 30) * (math.random(1000)/1000 * 3 + 4))
				end
			end
		end
	end
end,
})

return item