local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local dropping_holder = require("Qing_Extra_scripts.others.Dropping_holder")
local item_displaying_holder = require("Qing_Extra_scripts.callbacks.item_displaying_holder")
local displaying_data2 = require("Qing_Extra_scripts.translations.data2")

local item = {
	ToCall = {},
	entity = enums.Items.Mental_Hypnosis,
	now_render = {},
	offset = Vector(52,46),
	del_offset = Vector(0,10),
	words = {
		buff = {
			zh = {
				[1] = {
					Name = "攻击上升",
					Description = "经验+3",
				},
				[2] = {
					Name = "射速上升",
					Description = "哭吧哭吧我的孩子",
				},
				[3] = {
					Name = "弹速上升",
					Description = "现在，要加速了！",
				},
				[4] = {
					Name = "射程上升",
					Description = "一寸长，一寸强",
				},
				[5] = {
					Name = "移速上升",
					Description = "你的双脚变得轻盈",
				},
				[6] = {
					Name = "幸运上升",
					Description = function(wd,player) 
						local rng = player:GetCollectibleRNG(33)
						rng = auxi.rng_for_sake(rng)
						local language = auxi.get_language_map(Options.Language)
						if displaying_data2[language] then
							local rnd = rng:RandomInt(8) + 1
							local data = displaying_data2[language]["#Entry_"..tostring(rnd)]
							if data then
								return data
							else
								return "恭喜！"
							end
						end
					end,
				},
				[7] = {
					Name = "身体变小了",
					Description = "享受这一刻吧！",
				},
			},
			en = {
				[1] = {
					Name = "Damage Up",
					Description = "Level UP!!!",
				},
				[2] = {
					Name = "Tear Up",
					Description = "Cry as you wish.",
				},
				[3] = {
					Name = "Shot Speed Up",
					Description = "Acceleration!!",
				},
				[4] = {
					Name = "Range Up",
					Description = "Larger reaches more.",
				},
				[5] = {
					Name = "Speed Up",
					Description = "May you be as swift as meteors.",
				},
				[6] = {
					Name = "Luck Up",
					Description = function(wd,player) 
						local rng = player:GetCollectibleRNG(33)
						rng = auxi.rng_for_sake(rng)
						local language = auxi.get_language_map(Options.Language)
						if displaying_data2[language] then
							local rnd = rng:RandomInt(8) + 1
							local data = displaying_data2[language]["#Entry_"..tostring(rnd)]
							if data then
								return data
							else
								return "That's good！"
							end
						end
					end,
				},
				[7] = {
					Name = "Size Down",
					Description = "I Reward You A Smaller Body",
				},
			},
		},
		debuff = {
			zh = {
				[1] = {
					Name = "攻击下降",
					Description = "平角裤平角裤",
				},
				[2] = {
					Name = "射速下降",
					Description = "失去就是力量",
				},
				[3] = {
					Name = "弹速下降",
					Description = "伪装成负面的正面效果",
				},
				[4] = {
					Name = "射程下降",
					Description = "一寸短，一寸险",
				},
				[5] = {
					Name = "移速下降",
					Description = "是时候表演不动的战斗了",
				},
				[6] = {
					Name = "幸运下降",
					Description = function(wd,player) 
						local rng = player:GetCollectibleRNG(33)
						rng = auxi.rng_for_sake(rng)
						local language = auxi.get_language_map(Options.Language)
						if displaying_data2[language] then
							local rnd = rng:RandomInt(8) + 1
							local data = displaying_data2[language]["#Entry_"..tostring(rnd)]
							if data then
								return data
							else
								return "幸运值：E-"
							end
						end
					end,
				},
				[7] = {
					Name = "身体变大了",
					Description = "享受这一刻吧！",
				},
			},
			en = {
				[1] = {
					Name = "Damage Down",
					Description = "Level Down!!!",
				},
				[2] = {
					Name = "Tear Down",
					Description = "Stop crying,now!",
				},
				[3] = {
					Name = "Shot Speed Down",
					Description = "Maybe it's not that bad?",
				},
				[4] = {
					Name = "Range Down",
					Description = "Future is close.",
				},
				[5] = {
					Name = "Speed Down",
					Description = "Cool down yourself!",
				},
				[6] = {
					Name = "Luck Down",
					Description = function(wd,player) 
						local rng = player:GetCollectibleRNG(33)
						rng = auxi.rng_for_sake(rng)
						local language = auxi.get_language_map(Options.Language)
						if displaying_data2[language] then
							local rnd = rng:RandomInt(8) + 1
							local data = displaying_data2[language]["#Entry_"..tostring(rnd)]
							if data then
								return data
							else
								return "That's bad！"
							end
						end
					end,
				},
				[7] = {
					Name = "Size Up",
					Description = "I Punish You A Bigger Body",
				},
			},
		},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if save.elses.has_MH and save.elses.has_MH == true and Game():GetFrameCount() > 1 then		--似乎有些小bug捏
		local idx = player:GetData().__Index
		if idx ~= nil then
			if cacheFlag == CacheFlag.CACHE_DAMAGE then
				if save.elses["MH_Buff_dmg_"..tostring(idx)] then
					player.Damage = player.Damage + save.elses["MH_Buff_dmg_"..tostring(idx)] * auxi.get_damage_multiplier(player)
				end
			end
			if cacheFlag == CacheFlag.CACHE_FIREDELAY then
				if save.elses["MH_Buff_tear_"..tostring(idx)] then
					player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay , auxi.get_mxdelay_multiplier(player) * save.elses["MH_Buff_tear_"..tostring(idx)])
				end
			end
			if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
				if save.elses["MH_Buff_shotspeed_"..tostring(idx)] then
					player.ShotSpeed = player.ShotSpeed + save.elses["MH_Buff_shotspeed_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_RANGE then
				if save.elses["MH_Buff_range_"..tostring(idx)] then
					player.TearRange = player.TearRange + save.elses["MH_Buff_range_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_SPEED then
				if save.elses["MH_Buff_speed_"..tostring(idx)] then
					player.MoveSpeed = player.MoveSpeed + save.elses["MH_Buff_speed_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_LUCK then
				if save.elses["MH_Buff_luck_"..tostring(idx)] then
					player.Luck = player.Luck + save.elses["MH_Buff_luck_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_SIZE then
				if save.elses["MH_Buff_size_"..tostring(idx)] then
					player.SpriteScale = player.SpriteScale * save.elses["MH_Buff_size_"..tostring(idx)]
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
			break
		end
	end
	for i = 1,20 do		--不可能有那么多特殊房间吧？
		save.elses["MH_target_"..tostring(i)] = nil
	end
	save.elses["MH_target_total"] = 0
	save.elses["MH_target_nowconter"] = 1
	item.now_render = {}
	if should_count == true then
		local level = Game():GetLevel()
		local rooms = level:GetRooms()
		local rng = RNG()
		rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
		local toprint = ""
		local tg = {}
		local tg_e = {}
		for i = 0, rooms.Size do
			local targ = rooms:Get(i)
			if targ ~= nil and targ.SafeGridIndex >= 0 then
				local tp = targ.Data.Type
				if tp ~= 1 and tp ~= 29 and tp ~= 23 then
					if Game():IsGreedMode() then
						if tp == 7 or tp == 8 then
							table.insert(tg,1,tp)
						else
							table.insert(tg,#tg + 1,tp)
						end
					else
						table.insert(tg,#tg + 1,tp)
					end
				end
			end
		end
		for i = 1,#tg do
			local rnd = rng:RandomInt(#tg - i + 1) + i
			save.elses["MH_target_"..tostring(i)] = tg[rnd]
			local name = auxi.GetNameByRoomType(tg[rnd])
			if name == nil then
				toprint = toprint .." " .. "No_name"..tg[rnd]
			else
				toprint = toprint .." " .. name
			end
			tg[rnd] = tg[i]
		end
		save.elses["MH_target_total"] = #tg
		--print(toprint)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if save.elses.has_MH ~= true then
			save.elses.has_MH = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Qing_HelpfulShader" and Game():GetHUD():IsVisible() then
		local should_count = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				should_count = true
			end
		end
		if should_count then
			if save.elses["MH_target_total"] and save.elses["MH_target_nowconter"] then
				if save.elses["MH_target_total"] > 0 and save.elses["MH_target_nowconter"] <= save.elses["MH_target_total"] then
					local s = Sprite()
					s:Load("gfx/to_be_ui_inventory.anm2",true)
					s:Play("Idle",true)
					if Game():IsPaused() == true then
						s.Color = Color(1,1,1,0.3)
					else
						s.Color = Color(1,1,1,1)
					end
					s:Render(item.offset + Vector(6,6),Vector(0,0),Vector(0,0))
					for i = 1,save.elses["MH_target_total"] do
						if i < save.elses["MH_target_nowconter"] then
							if item.now_render[i] ~= nil then		--先这样好了
								
							end
						else
							if item.now_render[i] == nil then
								local s = Sprite()
								s:Load("gfx/to_be_map_icons.anm2",true)
								local name = auxi.GetNameByRoomType(save.elses["MH_target_"..tostring(i)])
								if auxi.IsAmbushBoss() and save.elses["MH_target_"..tostring(i)] == 11 then
									name = "BossAmbushRoom"
								end
								s:Play("Icon"..name,true)
								item.now_render[i] = {sprite = s,pos = item.offset + (i - save.elses["MH_target_nowconter"])*item.del_offset,}
							end
							local s = item.now_render[i].sprite
							if item.now_render[i].pos ~= item.offset + (i - save.elses["MH_target_nowconter"])*item.del_offset then
								item.now_render[i].pos = (item.now_render[i].pos) * 0.9 + (item.offset + (i - save.elses["MH_target_nowconter"])*item.del_offset) * 0.1
							end
							if Game():IsPaused() == true then
								s.Color = Color(1,1,1,0.3 * (save.elses["MH_target_total"] - i + save.elses["MH_target_nowconter"])/save.elses["MH_target_total"])
							else
								s.Color = Color(1,1,1,1 * (save.elses["MH_target_total"] - i + save.elses["MH_target_nowconter"])/save.elses["MH_target_total"])
							end
							s:Render(item.now_render[i].pos,Vector(0,0),Vector(0,0))
						end
					end
				end
			end
		end
	end
end,
})

local function reward(player)
	local idx = player:GetData().__Index
	local room = Game():GetRoom()
	local rng = player:GetCollectibleRNG(item.entity)
	rng = auxi.rng_for_sake(rng)
	if idx ~= nil then
		local tg = {}
		if save.elses["MH_Buff_dmg_"..tostring(idx)] == nil then
			save.elses["MH_Buff_dmg_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "dmg",weight = 5})
		if save.elses["MH_Buff_tear_"..tostring(idx)] == nil then
			save.elses["MH_Buff_tear_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "tear",weight = 4})
		if save.elses["MH_Buff_shotspeed_"..tostring(idx)] == nil then
			save.elses["MH_Buff_shotspeed_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "shotspeed",weight = 5})
		if save.elses["MH_Buff_range_"..tostring(idx)] == nil then
			save.elses["MH_Buff_range_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "range",weight = 7})
		if save.elses["MH_Buff_speed_"..tostring(idx)] == nil then
			save.elses["MH_Buff_speed_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "speed",weight = 7})
		if save.elses["MH_Buff_luck_"..tostring(idx)] == nil then
			save.elses["MH_Buff_luck_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "luck",weight = 7})
		if save.elses["MH_Buff_size_"..tostring(idx)] == nil then
			save.elses["MH_Buff_size_"..tostring(idx)] = 1
		end
		table.insert(tg,#tg + 1,{name = "size",weight = 6})
		table.insert(tg,#tg + 1,{name = "money",weight = 8})
		table.insert(tg,#tg + 1,{name = "key",weight = 8})
		table.insert(tg,#tg + 1,{name = "bomb",weight = 8})
		table.insert(tg,#tg + 1,{name = "battery",weight = 4})
		table.insert(tg,#tg + 1,{name = "heart",weight = 10})
		table.insert(tg,#tg + 1,{name = "collectible",weight = 1})
		table.insert(tg,#tg + 1,{name = "card",weight = 4})
		table.insert(tg,#tg + 1,{name = "pill",weight = 4})
		table.insert(tg,#tg + 1,{name = "spider",weight = 3})
		table.insert(tg,#tg + 1,{name = "fly",weight = 3})
		table.insert(tg,#tg + 1,{name = "prettyfly",weight = 1})
		table.insert(tg,#tg + 1,{name = "dip",weight = 2})
		local stag = tg[1]
		local tot_wei = 0
		for u,v in pairs(tg) do
			tot_wei = tot_wei + v.weight
		end
		tot_wei = rng:RandomInt(tot_wei) + 1
		for i = 1,#tg do
			tot_wei = tot_wei - tg[i].weight
			if tot_wei <= 0 then
				stag = tg[i]
				break
			end
		end
		local Buff_holder_counter = 0
		if stag.name == "dmg" then
			save.elses["MH_Buff_dmg_"..tostring(idx)] = save.elses["MH_Buff_dmg_"..tostring(idx)] + 0.25
			Buff_holder_counter = 1
		elseif stag.name == "tear" then
			save.elses["MH_Buff_tear_"..tostring(idx)] = save.elses["MH_Buff_tear_"..tostring(idx)] + 0.25
			Buff_holder_counter = 2
		elseif stag.name == "shotspeed" then
			save.elses["MH_Buff_shotspeed_"..tostring(idx)] = save.elses["MH_Buff_shotspeed_"..tostring(idx)] + 0.1
			Buff_holder_counter = 3
		elseif stag.name == "range" then
			save.elses["MH_Buff_range_"..tostring(idx)] = save.elses["MH_Buff_range_"..tostring(idx)] + 1 * 20
			Buff_holder_counter = 4
		elseif stag.name == "luck" then
			save.elses["MH_Buff_luck_"..tostring(idx)] = save.elses["MH_Buff_luck_"..tostring(idx)] + 0.5
			Buff_holder_counter = 6
		elseif stag.name == "speed" then
			save.elses["MH_Buff_speed_"..tostring(idx)] = save.elses["MH_Buff_speed_"..tostring(idx)] + 0.1
			Buff_holder_counter = 5
		elseif stag.name == "size" then
			save.elses["MH_Buff_size_"..tostring(idx)] = save.elses["MH_Buff_size_"..tostring(idx)] * 0.92
			Buff_holder_counter = 7
		elseif stag.name == "money" then
			local rnd = rng:RandomInt(5) + 1
			for i = 1,rnd do
				local q = Isaac.Spawn(5,20,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "bomb" then
			local rnd = rng:RandomInt(2) + 1
			for i = 1,rnd do
				local q = Isaac.Spawn(5,40,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "key" then
			local rnd = rng:RandomInt(2) + 1
			for i = 1,rnd do
				local q = Isaac.Spawn(5,30,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "battery" then
			local rnd = rng:RandomInt(2) + 1
			for i = 1,rnd do
				local q = Isaac.Spawn(5,90,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "heart" then
			local rnd = rng:RandomInt(3) + 2
			for i = 1,rnd do
				local q = Isaac.Spawn(5,10,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "collectible" then
			local q = Isaac.Spawn(5,100,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
		elseif stag.name == "card" then
			local q = Isaac.Spawn(5,300,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
		elseif stag.name == "pill" then
			local rnd = rng:RandomInt(2) + 1
			for i = 1,rnd do
				local q = Isaac.Spawn(5,70,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "spider" then
			local rnd = rng:RandomInt(8) + 2
			for i = 1,rnd do
				local q = player:AddBlueSpider(player.Position)
			end
		elseif stag.name == "fly" then
			local rnd = rng:RandomInt(6) + 2
			for i = 1,rnd do
				local q = player:AddBlueFlies(1,player.Position,player)
			end
		elseif stag.name == "prettyfly" then
			player:AddPrettyFly()
		elseif stag.name == "dip" then
			local rnd = rng:RandomInt(5) + 2
			for i = 1,rnd do
				player:ThrowFriendlyDip(1,player.Position,Vector.Zero)
			end
		else
			print(stag.name)
		end
		if Buff_holder_counter ~= 0 then
			local language = Options.Language
			if item.words.buff[language] == nil then language = "en" end
			local word = item.words.buff[language][Buff_holder_counter]
			local name = word.Name
			local des = word.Description
			if type(name) == "function" then name = name(word,player) end
			if type(des) == "function" then des = des(word,player) end
			item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player,true)
		end
		if player:Exists() then
			player:AnimateHappy()
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end


local function punish(player)
	local idx = player:GetData().__Index
	local rng = player:GetCollectibleRNG(item.entity)
	rng = auxi.rng_for_sake(rng)
	if idx ~= nil then
		local tg = {}
		local room = Game():GetRoom()
		if save.elses["MH_Buff_dmg_"..tostring(idx)] == nil then
			save.elses["MH_Buff_dmg_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "dmg",weight = 10})
		if save.elses["MH_Buff_tear_"..tostring(idx)] == nil then
			save.elses["MH_Buff_tear_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "tear",weight = 10})
		if save.elses["MH_Buff_shotspeed_"..tostring(idx)] == nil then
			save.elses["MH_Buff_shotspeed_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "shotspeed",weight = 8})
		if save.elses["MH_Buff_range_"..tostring(idx)] == nil then
			save.elses["MH_Buff_range_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "range",weight = 10})
		if save.elses["MH_Buff_speed_"..tostring(idx)] == nil then
			save.elses["MH_Buff_speed_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "speed",weight = 10})
		if save.elses["MH_Buff_luck_"..tostring(idx)] == nil then
			save.elses["MH_Buff_luck_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "luck",weight = 10})
		if save.elses["MH_Buff_size_"..tostring(idx)] == nil then
			save.elses["MH_Buff_size_"..tostring(idx)] = 1
		end
		table.insert(tg,#tg + 1,{name = "size",weight = 10})
		if player:GetNumCoins() > 10 then
			table.insert(tg,#tg + 1,{name = "money10",weight = 5})
		else
			table.insert(tg,#tg + 1,{name = "money10",weight = math.ceil(player:GetNumCoins()/3)})
		end
		if player:HasGoldenBomb() == true then
			table.insert(tg,#tg + 1,{name = "goldenbomb",weight = 5})
		end
		if player:HasGoldenKey() == true then
			table.insert(tg,#tg + 1,{name = "goldenkey",weight = 5})
		end
		if player:GetNumBombs() >= 3 then
			table.insert(tg,#tg + 1,{name = "bomb",weight = 8})
		end
		if player:GetNumKeys() >= 3 then
			table.insert(tg,#tg + 1,{name = "key",weight = 8})
		end
		if player:GetNumCoins() > 1 then
			table.insert(tg,#tg + 1,{name = "luckycoin",weight = 5})
		end
		table.insert(tg,#tg + 1,{name = "trollbomb",weight = 7})
		table.insert(tg,#tg + 1,{name = "bigtrollbomb",weight = 2})
		table.insert(tg,#tg + 1,{name = "goldentrollbomb",weight = 4})
		local stag = tg[1]
		local tot_wei = 0
		for u,v in pairs(tg) do
			tot_wei = tot_wei + v.weight
		end
		tot_wei = rng:RandomInt(tot_wei) + 1
		for i = 1,#tg do
			tot_wei = tot_wei - tg[i].weight
			if tot_wei <= 0 then
				stag = tg[i]
				break
			end
		end
		local Debuff_holder_counter = 0
		if stag.name == "dmg" then
			save.elses["MH_Buff_dmg_"..tostring(idx)] = save.elses["MH_Buff_dmg_"..tostring(idx)] - 0.25
			Debuff_holder_counter = 1
		elseif stag.name == "tear" then
			save.elses["MH_Buff_tear_"..tostring(idx)] = save.elses["MH_Buff_tear_"..tostring(idx)] - 0.25
			Debuff_holder_counter = 2
		elseif stag.name == "shotspeed" then
			save.elses["MH_Buff_shotspeed_"..tostring(idx)] = save.elses["MH_Buff_shotspeed_"..tostring(idx)] - 0.1
			Debuff_holder_counter = 3
		elseif stag.name == "range" then
			save.elses["MH_Buff_range_"..tostring(idx)] = save.elses["MH_Buff_range_"..tostring(idx)] - 1 * 20
			Debuff_holder_counter = 4
		elseif stag.name == "speed" then
			save.elses["MH_Buff_speed_"..tostring(idx)] = save.elses["MH_Buff_speed_"..tostring(idx)] - 0.1
			Debuff_holder_counter = 5
		elseif stag.name == "luck" then
			save.elses["MH_Buff_luck_"..tostring(idx)] = save.elses["MH_Buff_luck_"..tostring(idx)] - 0.5
			Debuff_holder_counter = 6
		elseif stag.name == "size" then
			save.elses["MH_Buff_size_"..tostring(idx)] = save.elses["MH_Buff_size_"..tostring(idx)] * 1.10
			Debuff_holder_counter = 7
		elseif stag.name == "money10" then		--还需要试着处理动画
			player:AddCoins(-10)
			dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.023_dime.anm2",})
		elseif stag.name == "goldenbomb" then
			player:RemoveGoldenBomb()
			dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.043_golden bomb.anm2",})
		elseif stag.name == "goldenkey" then
			player:RemoveGoldenKey()
			dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.032_golden key.anm2",})
		elseif stag.name == "bomb" then
			player:AddBombs(-3)
			for i = 1,3 do
				dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.041_bomb.anm2",})
			end
		elseif stag.name == "key" then
			player:AddKeys(-3)
			for i = 1,3 do
				dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.031_key.anm2",})
			end
		elseif stag.name == "luckycoin" then
			player:AddCoins(-1)
			save.elses["MH_Buff_luck_"..tostring(idx)] = save.elses["MH_Buff_luck_"..tostring(idx)] - 1
			dropping_holder.try_drop(player.Position,nil,{load_name = "gfx/005.026_lucky penny.anm2",})
		elseif stag.name == "trollbomb" then
			for i = 1,4 do
				local q = Isaac.Spawn(5,40,3,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "bigtrollbomb" then
			for i = 1,2 do
				local q = Isaac.Spawn(5,40,6,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
			end
		elseif stag.name == "goldentrollbomb" then
			local q = Isaac.Spawn(4,17,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil)
		else
			print(stag.name)
		end
		if Debuff_holder_counter ~= 0 then
			local language = Options.Language
			if item.words.debuff[language] == nil then language = "en" end
			local word = item.words.debuff[language][Debuff_holder_counter]
			local name = word.Name
			local des = word.Description
			if type(name) == "function" then name = name(word,player) end
			if type(des) == "function" then des = des(word,player) end
			item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player,true)
		end
		if player:Exists() then
			player:AnimateSad()
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local should_count = false
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	if desc.Data.Type ~= 1 and desc.Data.Type ~= 29 and desc.Data.Type ~= 23 and desc.SafeGridIndex > 0 and room:IsFirstVisit() == true then
		local tp = desc.Data.Type
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				should_count = true
				break
			end
		end
		if should_count then
			if save.elses["MH_target_total"] and save.elses["MH_target_nowconter"] then
				if save.elses["MH_target_total"] > 0 and save.elses["MH_target_nowconter"] <= save.elses["MH_target_total"] then
					if tp == save.elses["MH_target_"..tostring(save.elses["MH_target_nowconter"])] then
						--print(save.elses["MH_target_nowconter"] .. "yes")
						for playerNum = 1, Game():GetNumPlayers() do
							local player = Game():GetPlayer(playerNum - 1)
							if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
								delay_buffer.addeffe(function(params)
									if player:Exists() then
										reward(player)
									end
								end,{},5)
							end
						end
					else
						for playerNum = 1, Game():GetNumPlayers() do
							local player = Game():GetPlayer(playerNum - 1)
							if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
								delay_buffer.addeffe(function(params)
									if player:Exists() then
										punish(player)
									end
								end,{},5)
							end
						end
					end
					save.elses["MH_target_nowconter"] = save.elses["MH_target_nowconter"] + 1
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.has_MH = false
		for j = 1,10 do
			save.elses["MH_Buff_dmg_"..tostring(j)] = 0
			save.elses["MH_Buff_tear_"..tostring(j)] = 0
			save.elses["MH_Buff_shotspeed_"..tostring(j)] = 0
			save.elses["MH_Buff_range_"..tostring(j)] = 0
			save.elses["MH_Buff_speed_"..tostring(j)] = 0
			save.elses["MH_Buff_luck_"..tostring(j)] = 0
			save.elses["MH_Buff_size_"..tostring(j)] = 1
		end
		for i = 1,20 do
			save.elses["MH_target_"..tostring(i)] = nil
		end
		save.elses["MH_target_nowconter"] = 1
		save.elses["MH_target_total"] = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		
	end
end,
})

return item