local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Air_Terror,
	familiar = enums.Familiars.Air_Terror,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
	if cacheFlag == CacheFlag.CACHE_FAMILIARS then
		player:CheckFamiliar(item.familiar, cnt, player:GetCollectibleRNG(item.entity), Isaac.GetItemConfig():GetCollectible(item.entity))
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	local player = ent.Player
	if (player == nil or player:Exists() == false) and ent.SpawnerEntity and ent.SpawnerEntity:ToPlayer() then
		player = ent.SpawnerEntity:ToPlayer()
	end
	local dir = player:GetFireDirection()
	local dr = auxi.GetfamiliarDir(ent,dir,false)

	local direction = auxi.GetDirectionByAngle(90)
	if dr:Length() > 1e-4 then
		direction = auxi.GetDirectionByAngle(dr:GetAngleDegrees())
	end
	
	local dist = (ent.Position - player.Position):Length()
	local target = d.target
	if target and target:Exists() and not target:IsDead() then
	else
	end
	
	if dist > 200 then
	else

	end
	
	local name = "Idle"
	if (direction ~= Direction.NO_DIRECTION) then
		s:Play(name..auxi.GetDirName(direction))
		ent.FlipX = (direction == Direction.LEFT)
	end
end,
})

return item