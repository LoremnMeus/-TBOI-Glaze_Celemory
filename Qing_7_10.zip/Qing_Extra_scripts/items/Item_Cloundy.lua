local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local gui = require("Qing_Extra_scripts.auxiliary.gui")

local item = {
	ToCall = {},
	entity = enums.Items.Cloundy,
	familiar = enums.Familiars.Cloundy,
	words = {
		zh = {
			[1] = "这个方向一定是隐藏房！",
			[2] = "我知道！这个房间里不可能有隐藏！",
			[3] = "我知道！叉石头会炸出石头底座",
			[4] = "别怂！打了！",		--挑战房
			[5] = "黑小孩，炸掉给基础！",
			[6] = "钥匙小孩，炸掉加开房率！",
			[7] = "卖血机没用，全部炸掉！",
			[8] = "没用，赶快炸了！",
			[9] = "小孩那么可爱，不要炸小孩！",
			[10] = "零元购喽！",
			[11] = "杀掉！必须杀掉！",
			[12] = "我教你一个白嫖陆夫人的技巧！",
			[13] = "roll机炸不坏的，我来帮忙！",
			[14] = "不！我不承认！你是如何找到隐藏房的！",
		},
		en = {
			[1] = "I know!The secret room!",
			[2] = "There can't the secret room here!",
			[3] = "Give me a Rock bottom!",
			[4] = "Take it!",		--挑战房
			[5] = "Blow up the black but!That offers pickups!",
			[6] = "Blow up key master and promote devil rate!",
			[7] = "Useless donate machine!I will bomb it up!",
			[8] = "Invalid slots!Leave it away!",
			[9] = "No!Don't blow up little beggars!",
			[10] = "Feel free to take!",
			[11] = "Kill it!We must kill it!",
			[12] = "I'm good at blow up bomb beggars!",
			[13] = "Rolling machine can't be blowed up!",
			[14] = "No!How do you find the secret room!",
		},
	},
	Talking_Pos_Offset = Vector(20,-40),
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
	if Game().Challenge == enums.Challenges.Pointing then cnt = cnt + 5 end
	if cacheFlag == CacheFlag.CACHE_FAMILIARS then
		player:CheckFamiliar(item.familiar, cnt, player:GetCollectibleRNG(item.entity), Isaac.GetItemConfig():GetCollectible(item.entity))
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = item.familiar,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	s:Play("Float",true)
end,
})

function local_try_speak(ent,id)
	local language = Options.Language
	if item.words[language] == nil then language = "en" end
	local word = item.words[language][id]
	local s_word = auxi.spilt_string(word)
	gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-(#s_word)/2,0),Vector(0,-30),word,25)
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	local rng = ent:GetDropRNG()
	rng = auxi.rng_for_sake(rng)
	local room = Game():GetRoom()
	local player = ent.Player
	if d.state == nil then d.state = 0 end
	if player == nil or player:Exists() == false then player = Game():GetPlayer(0) end
	if s:IsPlaying("Float") and s:IsEventTriggered("Check") then
		local rnd = rng:RandomInt(4)
		local act = d.last_action or ""
		d.last_action = nil
		if d.enemy_filter == nil then d.enemy_filter = 0 end
		if d.enemy_filter > 0 then d.enemy_filter = d.enemy_filter - 1 end
		local n_entity = Isaac.GetRoomEntities()
		local n_pickups = auxi.getpickups(n_entity,false)
		local tbl = {}
		for u,v in pairs(n_pickups) do
			if v.Variant ~= 340 and v.Variant ~= 370 and v.Variant ~= 100 then 
				table.insert(tbl,v)
			end
		end
		if act == "Enemy" or act == "Pickups" or #tbl > 0 then rnd = 2 end
		if act == "Prize" and ((d.prize_counter and d.prize_counter > 0.5) or (d.r_prize_counter and d.r_prize_counter > 0.5)) then rnd = 7 end
		if rnd == 1 then		--寻找隐藏
			if player:HasCollectible(CollectibleType.COLLECTIBLE_ROCKET_IN_A_JAR) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_ROCKET_IN_A_JAR) > 0 then
				s:ReplaceSpritesheet(2,"gfx/familiar/to_be_rocket.png")
			else
				s:ReplaceSpritesheet(2,"gfx/familiar/to_be_bomb.png")
			end
			s:LoadGraphics()
			s:Play("PutBomb",true)
			d.blow_type = nil
			local n_slot = auxi.getothers_in_table(n_entity,6,0,nil)
			--auxi.PrintTable(n_slot)
			for i = 1,3,2 do
				local slot = n_slot[i]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Machine"
					break
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[2]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Blood"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[17]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Machine"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[16]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Machine"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[10]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Roll"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[5]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Black"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[15]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Black"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[7]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Master"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[9]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Bomb"
				end
			end
			if d.blow_type == nil then
				local slot = n_slot[14]
				if slot and #slot > 0 then
					d.target = slot[math.random(#slot)]
					d.blow_type = "Isaac"
				end
			end
			if d.blow_type == nil then
				d.blow_type = "Door"
			end
		elseif rnd == 2 then	--吞噬敌人或基础掉落
			if #tbl > 0 then
				d.target = tbl[math.random(#tbl)]
			end
			if #tbl == 0 then --or act == "Enemy" then
				if d.enemy_filter <= 0 then 
					local n_enemy = auxi.getenemies(n_entity)
					local tbl = {}
					for u,v in pairs(n_enemy) do 
						if v:IsBoss() == false and v.Type ~= 996 then
							table.insert(tbl,v)
						end
					end
					if #tbl > 0 then
						d.target = tbl[math.random(#tbl)]
						d.last_action = "Enemy"
						d.enemy_filter = math.random(8) - 1
					end
				end
			else
				d.last_action = "Pickups"
			end
			if d.target then
				s:Play("Eat",true)
				d.should_remove = true
				d.state = 1
			elseif (d.prize_counter and d.prize_counter > 0.5) or (d.r_prize_counter and d.r_prize_counter > 0.5) then
				rnd = 7
			end
		end
		if rnd == 7 then		--提供奖励
			if (d.prize_counter and d.prize_counter > 0.5) or (d.r_prize_counter and d.r_prize_counter > 0.5) then
				s:Play("Prize",true)
				d.state = 0
				d.last_action = "Prize"
			end
		end
	end
	
	if s:IsPlaying("PutBomb") and s:IsEventTriggered("Throw") then
		if d.blow_type == nil or d.blow_type == "Door" then 
			local tbl = {}
			local roomtype = room:GetType()
			local tbl_r_door = {}
			local tbl_i_door = {}
			if roomtype == RoomType.ROOM_SECRET or roomtype == RoomType.ROOM_SUPERSECRET or roomtype == RoomType.ROOM_ULTRASECRET then
				local_try_speak(ent,14)
				local q = player:FireBomb(ent.Position,auxi.MakeVector(math.random(3600)/10) * 10)
				q.PositionOffset = Vector(0,-35)
				q.Velocity = auxi.MakeVector(math.random(3600)/10) * 10
				q.ExplosionDamage = player.Damage
			else
				for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do
					if room:IsDoorSlotAllowed(slot) then
						local door = room:GetDoor(slot)
						if door then
							if door:IsBusted() then
							else
								if door.TargetRoomType == RoomType.ROOM_SECRET or door.TargetRoomType == RoomType.ROOM_SUPERSECRET or door.TargetRoomType == RoomType.ROOM_ULTRASECRET then
									table.insert(tbl_i_door,slot)
								else
									table.insert(tbl_r_door,slot)
								end
							end
						else
							table.insert(tbl,slot)
						end
					end
				end
				if #tbl > 0 then
					local rnd = rng:RandomInt(#tbl) + 1
					local_try_speak(ent,1)
					local q = player:FireBomb(ent.Position,(room:GetDoorSlotPosition(tbl[rnd]) - ent.Position) * 0.05)
					q.PositionOffset = Vector(0,-35)
					q.Velocity = (room:GetDoorSlotPosition(tbl[rnd]) - ent.Position) * 0.05
					q.ExplosionDamage = player.Damage
				else
					local_try_speak(ent,2)
					if #tbl_r_door > 0 then
						local rnd = rng:RandomInt(#tbl_r_door) + 1
						local q = player:FireBomb(ent.Position,(room:GetDoorSlotPosition(tbl_r_door[rnd]) - ent.Position) * 0.05)
						q.PositionOffset = Vector(0,-35)
						q.Velocity = (room:GetDoorSlotPosition(tbl_r_door[rnd]) - ent.Position) * 0.05
						q.ExplosionDamage = player.Damage
					else
						local q = player:FireBomb(ent.Position,auxi.MakeVector(math.random(3600)/10) * 10)
						q.PositionOffset = Vector(0,-35)
						q.Velocity = auxi.MakeVector(math.random(3600)/10) * 10
						q.ExplosionDamage = player.Damage
					end
				end
			end
		else
			if d.target and d.target:Exists() and not d.target:IsDead() then
				local pos = d.target.Position
				local q = player:FireBomb(ent.Position,(pos - ent.Position) * 0.05)
				q.PositionOffset = Vector(0,-35)
				q.ExplosionDamage = player.Damage
				if d.blow_type == "Machine" then
					local_try_speak(ent,8)
				elseif d.blow_type == "Black" then
					local_try_speak(ent,5)
				elseif d.blow_type == "Roll" then
					local_try_speak(ent,13)
				elseif d.blow_type == "Master" then
					local_try_speak(ent,6)
				elseif d.blow_type == "Isaac" then
					local_try_speak(ent,11)
				elseif d.blow_type == "Bomb" then
					local_try_speak(ent,12)
				elseif d.blow_type == "Blood" then
					local_try_speak(ent,7)
				end
				d.target = nil
			end
		end
	end
	if s:IsPlaying("Eat") then
		if s:IsEventTriggered("Morph") then
		end
		if s:IsEventTriggered("Finish") then
			d.target = nil
			d.target_pos = nil
			d.state = 0
		end
		if s:IsEventTriggered("Remove") then
			if d.should_remove then
				if d.target and d.target:Exists() and not d.target:IsDead() then
					if d.target:ToPickup() then
						local pk = d.target:ToPickup()
						pk:PlayPickupSound()
						if pk:IsShopItem() then 
							local language = Options.Language
							if item.words[language] == nil then language = "en" end
							local word = item.words[language][10]
							local s_word = auxi.spilt_string(word)
							gui.draw_ch_with_time_to_dispair(ent.Position + item.Talking_Pos_Offset + Vector(-(#s_word)/2,0),Vector(0,-30),word,15)
						end
						d.r_prize_counter = (d.r_prize_counter or 0) + 1
					else
						d.prize_counter = (d.prize_counter or 0) + 1
						d.should_smash = true
					end
					d.target:Kill()
					d.target:Remove()
				end
				d.should_remove = nil
			end
		end
		if s:IsEventTriggered("Fart") then
			if d.should_fart then
				d.should_fart = nil
				Game():Fart(ent.Position,30,ent,1,0)
			else
				if d.should_smash then
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_DEATH_BURST_SMALL,1,1,false,0,2)
					d.should_smash = nil
				end
			end
		end
	end
	if s:IsPlaying("Prize") then
		if s:IsEventTriggered("Prize") then
			if d.prize_counter == nil then d.prize_counter = 0 end
			if d.r_prize_counter == nil then d.r_prize_counter = 0 end
			if d.prize_counter > 0.5 then
				local q = Isaac.Spawn(5,0,0,room:FindFreePickupSpawnPosition(ent.Position),Vector(0,0),nil):ToPickup()
				if q.Variant == 100 then q:Morph(5,40,7,true) end
				d.prize_counter = d.prize_counter - 1
			elseif d.r_prize_counter > 0.5 then
				local q = Isaac.Spawn(10,0,0,ent.Position,Vector(0,0),nil)
				Game():RerollEnemy(q)
				d.r_prize_counter = d.r_prize_counter - 1
			end
			if d.prize_counter < 0.5 and d.r_prize_counter < 0.5 then
				d.last_action = nil
			end
		end
	end
	if d.state == 0 then		--飘向角色
		ent:FollowPosition(player.Position)
	elseif d.state == 1 then
		if d.target and d.target:Exists() and not d.target:IsDead() then
			if (ent.Position - d.target.Position):Length() > 150 then
				ent:FollowPosition(d.target.Position)
			else
				ent.Velocity = (d.target.Position - ent.Position) * 0.2
			end
			d.target_pos = d.target.Position
		else
			d.target = nil
			d.state = 2
		end
	elseif d.state == 2 then
		if d.target_pos == nil then 
			d.state = 0
		else
			if (ent.Position - d.target_pos):Length() > 50 then
				ent:FollowPosition(d.target_pos)
			else
				ent.Velocity = (d.target_pos - ent.Position) * 0.1
			end
		end
	end
	if s:IsFinished("PutBomb") or s:IsFinished("Eat") or s:IsFinished("Prize") then
		s:Play("Float",true)
	end
end,
})

return item