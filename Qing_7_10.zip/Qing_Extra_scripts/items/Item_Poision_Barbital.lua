local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	post_ToCall = {},
	entity = enums.Items.Barbital,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,		--需要注意！这个函数的调用在playerupdate之后。
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_B_counter"..tostring(j)] = 0
		end
		save.elses.P_B_Effect = 0
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if collid == item.entity then
		if auxi.is_player_difficult(player) then
			player:AddBrokenHearts(count)
		else
			player:AddBrokenHearts(count * 3)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local bk_heart = player:GetBrokenHearts()
			local heart = player:GetBoneHearts() + math.ceil(player:GetSoulHearts()/2) + math.ceil(player:GetMaxHearts()/2)
			local red_heart = player:GetHearts()
			if heart > 0 then
				local rnd1 = math.ceil(bk_heart * player:GetSoulHearts()/heart)
				local rnd2 = math.floor(bk_heart * player:GetMaxHearts()/heart/2)
				local rnd3 = math.max(0,bk_heart - rnd1 - rnd2)				
				auxi.add_soul_heart(player,rnd1 - player:GetSoulHearts())
				player:AddBrokenHearts(-99)
				player:AddMaxHearts(rnd2 * 2 - player:GetMaxHearts(),false)
				player:AddHearts(red_heart - player:GetHearts())
				player:AddBoneHearts(rnd3 - player:GetBoneHearts())
				player:AddBrokenHearts(heart)
			end
		end
	end
end,
})

return item