local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Items.Tiramisu,
	record_it = {
		[1] = "dmg",
		[2] = "tear",
		[3] = "range",
		[4] = "speed",
		[5] = "luck",
		[6] = "shotspeed",
	},
	record_cache_flag = {
		[1] = CacheFlag.CACHE_DAMAGE,
		[2] = CacheFlag.CACHE_FIREDELAY,
		[3] = CacheFlag.CACHE_RANGE,
		[4] = CacheFlag.CACHE_SPEED,
		[5] = CacheFlag.CACHE_LUCK,
		[6] = CacheFlag.CACHE_SHOTSPEED,
	},
}

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local idx = player:GetData().__Index
		if idx ~= nil then
			if save.elses["Tiremisu_Save_lock_"..tostring(idx)] ~= nil then
				if cacheFlag == CacheFlag.CACHE_DAMAGE then
					if save.elses["Tiremisu_Buff_dmg_"..tostring(idx)] then
						player.Damage = player.Damage + save.elses["Tiremisu_Buff_dmg_"..tostring(idx)]
					end
				end
				if cacheFlag == CacheFlag.CACHE_FIREDELAY then
					if save.elses["Tiremisu_Buff_tear_"..tostring(idx)] then
						player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay , save.elses["Tiremisu_Buff_tear_"..tostring(idx)])
					end
				end
				if cacheFlag == CacheFlag.CACHE_RANGE then
					if save.elses["Tiremisu_Buff_range_"..tostring(idx)] then
						player.TearRange = player.TearRange + save.elses["Tiremisu_Buff_range_"..tostring(idx)]
					end
				end
				if cacheFlag == CacheFlag.CACHE_SPEED then
					if save.elses["Tiremisu_Buff_speed_"..tostring(idx)] then
						player.MoveSpeed = player.MoveSpeed + save.elses["Tiremisu_Buff_speed_"..tostring(idx)]
					end
				end
				if cacheFlag == CacheFlag.CACHE_LUCK then
					if save.elses["Tiremisu_Buff_luck_"..tostring(idx)] then
						player.Luck = player.Luck + save.elses["Tiremisu_Buff_luck_"..tostring(idx)]
					end
				end
				if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
					if save.elses["Tiremisu_Buff_shotspeed_"..tostring(idx)] then
						player.ShotSpeed = player.ShotSpeed + save.elses["Tiremisu_Buff_shotspeed_"..tostring(idx)]
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local idx = player:GetData().__Index
		if idx and save.elses["Tiremisu_Save_lock_"..tostring(idx)] ~= nil then
			local should_eval = false
			if save.elses["Tiremisu_Save_dmg_"..tostring(idx)] ~= nil and player.Damage > save.elses["Tiremisu_Save_dmg_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_dmg_"..tostring(idx)] = (save.elses["Tiremisu_Buff_dmg_"..tostring(idx)] or 0) + 0.3 * (player.Damage - save.elses["Tiremisu_Save_dmg_"..tostring(idx)])
				player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
				should_eval = true
			end
			if player.Damage ~= save.elses["Tiremisu_Save_dmg_"..tostring(idx)] then
				save.elses["Tiremisu_Save_dmg_"..tostring(idx)] = player.Damage
			end
			if save.elses["Tiremisu_Save_tear_"..tostring(idx)] ~= nil and 30 / (player.MaxFireDelay + 1) > save.elses["Tiremisu_Save_tear_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_tear_"..tostring(idx)] = (save.elses["Tiremisu_Buff_tear_"..tostring(idx)] or 0) + 0.3 * (30 / (player.MaxFireDelay + 1) - save.elses["Tiremisu_Save_tear_"..tostring(idx)])
				save.elses["Tiremisu_Save_tear_"..tostring(idx)] = 30 / (player.MaxFireDelay + 1)
				player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
				should_eval = true
			end
			if 30 / (player.MaxFireDelay + 1) ~= save.elses["Tiremisu_Save_tear_"..tostring(idx)] then
				save.elses["Tiremisu_Save_tear_"..tostring(idx)] = 30 / (player.MaxFireDelay + 1)
			end
			if save.elses["Tiremisu_Save_range_"..tostring(idx)] ~= nil and player.TearRange > save.elses["Tiremisu_Save_range_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_range_"..tostring(idx)] = (save.elses["Tiremisu_Buff_range_"..tostring(idx)] or 0) + 0.3 * (player.TearRange - save.elses["Tiremisu_Save_range_"..tostring(idx)])
				save.elses["Tiremisu_Save_range_"..tostring(idx)] = player.TearRange
				player:AddCacheFlags(CacheFlag.CACHE_RANGE)
				should_eval = true
			end
			if player.TearRange ~= save.elses["Tiremisu_Save_range_"..tostring(idx)] then
				save.elses["Tiremisu_Save_range_"..tostring(idx)] = player.TearRange
			end
			if save.elses["Tiremisu_Save_speed_"..tostring(idx)] ~= nil and player.MoveSpeed > save.elses["Tiremisu_Save_speed_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_speed_"..tostring(idx)] = (save.elses["Tiremisu_Buff_speed_"..tostring(idx)] or 0) + 0.3 * (player.MoveSpeed - save.elses["Tiremisu_Save_speed_"..tostring(idx)])
				save.elses["Tiremisu_Save_speed_"..tostring(idx)] = player.MoveSpeed
				player:AddCacheFlags(CacheFlag.CACHE_SPEED)
				should_eval = true
			end
			if player.MoveSpeed ~= save.elses["Tiremisu_Save_speed_"..tostring(idx)] then
				save.elses["Tiremisu_Save_speed_"..tostring(idx)] = player.MoveSpeed
			end
			if save.elses["Tiremisu_Save_luck_"..tostring(idx)] ~= nil and player.Luck > save.elses["Tiremisu_Save_luck_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_luck_"..tostring(idx)] = (save.elses["Tiremisu_Buff_luck_"..tostring(idx)] or 0) + 0.3 * (player.Luck - save.elses["Tiremisu_Save_luck_"..tostring(idx)])
				save.elses["Tiremisu_Save_luck_"..tostring(idx)] = player.Luck
				player:AddCacheFlags(CacheFlag.CACHE_LUCK)
				should_eval = true
			end
			if player.Luck ~= save.elses["Tiremisu_Save_luck_"..tostring(idx)] then
				save.elses["Tiremisu_Save_luck_"..tostring(idx)] = player.Luck
			end
			if save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] ~= nil and player.ShotSpeed > save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] then
				save.elses["Tiremisu_Buff_shotspeed_"..tostring(idx)] = (save.elses["Tiremisu_Buff_shotspeed_"..tostring(idx)] or 0) + 0.3 * (player.ShotSpeed - save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)])
				save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] = player.ShotSpeed
				player:AddCacheFlags(CacheFlag.CACHE_SHOTSPEED)
				should_eval = true
			end
			if player.ShotSpeed ~= save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] then
				save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] = player.ShotSpeed
			end
			if Game():GetFrameCount() % 10 == 1 then
				for i = 1,6 do
					if (save.elses["Tiremisu_Buff_"..item.record_it[i].."_"..tostring(idx)] or 0) > 0 then
						save.elses["Tiremisu_Buff_"..item.record_it[i].."_"..tostring(idx)] = (save.elses["Tiremisu_Buff_"..item.record_it[i].."_"..tostring(idx)] or 0) * 0.99
						player:AddCacheFlags(item.record_cache_flag[i])
						should_eval = true
					end
				end
			end
			if should_eval then
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,cnt,lastnumber)
	if cnt > 0 and lastnumber == 0 then
		local idx = player:GetData().__Index
		if idx then
			save.elses["Tiremisu_Save_dmg_"..tostring(idx)] = player.Damage
			save.elses["Tiremisu_Save_tear_"..tostring(idx)] = 30 / (player.MaxFireDelay + 1)
			save.elses["Tiremisu_Save_range_"..tostring(idx)] = player.TearRange
			save.elses["Tiremisu_Save_speed_"..tostring(idx)] = player.MoveSpeed
			save.elses["Tiremisu_Save_luck_"..tostring(idx)] = player.Luck
			save.elses["Tiremisu_Save_shotspeed_"..tostring(idx)] = player.ShotSpeed
			save.elses["Tiremisu_Save_lock_"..tostring(idx)] = true
		end
	end
	if cnt < 0 and lastnumber == cnt then
		save.elses["Tiremisu_Save_lock_"..tostring(idx)] = nil
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["Tiremisu_Save_dmg_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_tear_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_range_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_speed_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_luck_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_shotspeed_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_dmg_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_tear_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_range_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_speed_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_luck_"..tostring(j)] = 0
			save.elses["Tiremisu_Buff_shotspeed_"..tostring(j)] = 0
			save.elses["Tiremisu_Save_lock_"..tostring(j)] = nil
		end
	end
end,
})

return item