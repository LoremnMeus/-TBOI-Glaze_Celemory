local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Colorblindness,
	now_color = {
		Rrgba = {1,0,0},
		Grgba = {0,1,0},
		Brgba = {0,0,1},
		matter = 0,
	},
	list_now_color = {
		Rrgba = {1,0,0},
		Grgba = {0,1,0},
		Brgba = {0,0,1},
		matter = 0,
	},
	set_color = 0,
}

local rng = RNG()

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function()
	local lst_col = item.set_color
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
			item.set_color = item.set_color + 1 * cnt
		end
	end
	if math.ceil(((item.set_color + 90) % 360)/180) ~= math.ceil(((lst_col+90)%360)/180) then
		--print(math.ceil(((item.set_color + 90) % 360)/180))
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				player:AddCacheFlags(CacheFlag.CACHE_ALL)
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.color_blindness_counter = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if save.elses.color_blindness_counter == nil then save.elses.color_blindness_counter = 0 end
		if save.elses.color_blindness_counter < 10 then
			save.elses.color_blindness_counter = save.elses.color_blindness_counter + 1
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function()
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count == true then
		
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function()
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
		local col = math.ceil(((item.set_color + 90) % 360)/180)
		if save.elses.color_blindness_counter == nil then save.elses.color_blindness_counter = 0 end
		local mul = save.elses.color_blindness_counter/10
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			if col == 1 then
				player.Damage = player.Damage + 1 * auxi.get_damage_multiplier(player) * cnt * (1 - mul)
			end
        end
		if cacheFlag == CacheFlag.CACHE_TEARFLAG then
			if col == 1 then
				if save.elses.color_blindness_counter <= 1 then
					player.TearFlags = player.TearFlags | BitSet128(1<<62,0) 
				end
				if save.elses.color_blindness_counter <= 7 then
					player.TearFlags = player.TearFlags | BitSet128(0,1<<(67-64))
				end
			else
				if save.elses.color_blindness_counter <= 3 then
					player.TearFlags = player.TearFlags | BitSet128(1<<33,0)
				end
				if save.elses.color_blindness_counter <= 9 then
					player.TearFlags = player.TearFlags | BitSet128(1<<4,0)
				end
			end
        end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			if col == 2 then
				player.TearRange = player.TearRange + 2 * 40 * (1 - mul)
			end
        end
		if cacheFlag == CacheFlag.CACHE_TEARCOLOR then
			if col == 1 then
				player.TearColor = auxi.AddColor(player.TearColor,Color(1,0.5,0.5,1,1,0,0),0.3 + 0.7 * mul,0.7 * (1-mul))
				player.LaserColor = auxi.AddColor(player.LaserColor,Color(1,0.5,0.5,1,1,0,0),0.3 + 0.7 * mul,0.7 * (1-mul))
			else
				player.TearColor = auxi.AddColor(player.TearColor,Color(0.5,1,0.5,1,0,1,0),0.3 + 0.7 * mul,0.7 * (1-mul))
				player.LaserColor = auxi.AddColor(player.LaserColor,Color(0.5,1,0.5,1,0,1,0),0.3 + 0.7 * mul,0.7 * (1-mul))
			end
        end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Qing_ColorBlindness_Helper" then
		local should_count = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				should_count = true
			end
		end
		if should_count then
			if item.set_color == nil then item.set_color = 0 end
			if save.elses.color_blindness_counter == nil then save.elses.color_blindness_counter = 0 end
			local mul = save.elses.color_blindness_counter/10
			local ang = auxi.MakeVector(item.set_color)
			item.now_color = {
				Rrgba = {mul,(0.5 + ang.Y * 0.5) * 1.25 * (1 - mul),0,},
				Grgba = {(0.5 + ang.X * 0.5) * 1.25 * (1 - mul),mul,0,},
				Brgba = {0.3 + 0.7 * mul,(0.7 + ang.X * 0.3) * 0.5 * (1 - mul),(0.7 + ang.Y * 0.3) * 0.5 * (1 - mul),},
				matter = 1 - mul,
			}
		else
			item.now_color = item.list_now_color
		end
		return item.now_color
	end
end,
})

return item