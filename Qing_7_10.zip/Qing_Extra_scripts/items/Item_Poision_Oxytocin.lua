local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	myToCall = {},
	post_ToCall = {},
	entity = enums.Items.Oxytocin,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if cacheFlag == CacheFlag.CACHE_TEARCOLOR then
			local d = player:GetData()
			if d.P_O_timer and d.P_O_timer <= 0 then
				player.TearColor = auxi.AddColor(player.TearColor,Color(0,0,0,0.5,1,1,1),0,1)
				player.LaserColor = auxi.AddColor(player.LaserColor,Color(0,0,0,0.5,1,1,1),0,1)
			end
        end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = d.__Index
		if idx ~= nil then
		if d.P_O_timer == nil then d.P_O_timer = 0 end
			if d.P_O_timer <= 0 then
				if save.elses["P_O_buff"..idx] == nil then save.elses["P_O_buff"..idx] = 2 end
				if save.elses["P_O_buff"..idx] > 0 then 
					save.elses["P_O_buff"..idx] = save.elses["P_O_buff"..idx] - 1 
					save.elses["P_O_execute"..idx] = 1
				end
				d.P_O_timer = 5 * 60
				if auxi.is_player_difficult(player) then
					d.P_O_timer = 15 * 60
				end
			else
				d.P_O_timer = 5 * 60
				if auxi.is_player_difficult(player) then
					d.P_O_timer = 15 * 60
				end
			end
			d.P_O_should_alter = true
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,		--防止伤害
Function = function(_,ent,amt,flag,source,cooldown)
	if ent.Type ~= 1 then
		if source ~= nil and source.Entity ~= nil then
			local col = source.Entity
			local p_col = auxi.to_find_spawner(col)
			--print(col.Type.." "..col.Variant.." "..col.SubType.."P:"..p_col.Type.." "..p_col.Variant.." "..p_col.SubType)
			if p_col:ToPlayer() then
				local player = p_col:ToPlayer()
				if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
					local d = player:GetData()
					local idx = d.__Index
					if d.P_O_timer == nil then d.P_O_timer = 0 end
					if d.P_O_timer <= 0 then
						return false
					end
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_GAIN_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,cnt,touched)
	if touched ~= true then
		local d = player:GetData()
		local idx = d.__Index
		if idx then
			save.elses["P_O_execute"..idx] = 2
			player:UseCard(51,1 | (1<<8))		--免费送一次
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = d.__Index
		if idx ~= nil then
			if d.P_O_timer == nil then d.P_O_timer = 0 end
			if d.P_O_timer <= 0 then
				if d.P_O_rem == nil then
					local succ = Attribute_holder.try_hold_attribute(player,"GridCollisionClass",GridCollisionClass.COLLISION_WALL)		--一边委托，必须要有一边恢复。
					if succ > 0 then
						d.P_O_rem = succ
					end
					player:AddCacheFlags(CacheFlag.CACHE_TEARCOLOR)
					d.should_evaluate_on_update_once = true
				end
				local t_c = - d.P_O_timer/20
				player:SetColor(Color(1 - t_c,1 - t_c,1 - t_c,0.5 + (1 - t_c) * 0.5,t_c,t_c,t_c),5,70,false,false)			--加个特效
			end
			if d.P_O_should_alter and d.P_O_should_alter == true then
				d.P_O_should_alter = false
				if d.P_O_rem ~= nil then
					if d.P_O_rem > 0 then
						local succ = Attribute_holder.try_rewind_attribute(player,"GridCollisionClass",d.P_O_rem)
						d.P_O_rem = nil
					end
					player:AddCacheFlags(CacheFlag.CACHE_TEARCOLOR)
					d.should_evaluate_on_update_once = true
				end
				player:SetColor(Color(1,1,1,1,0,0,0),5,70,false,false)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = d.__Index
		if idx ~= nil then
			if d.P_O_timer == nil then d.P_O_timer = 0 end
			if d.P_O_timer <= 0 then
				if save.elses["P_O_execute"..idx] == 1 then
					save.elses["P_O_execute"..idx] = 2
					player:UseCard(51,1 | (1<<8))
				end
			end
			if d.P_O_timer > -20 then
				d.P_O_timer = d.P_O_timer - 1
			end
			local effects = player:GetEffects()
			local m_cnt = effects:GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_HOLY_MANTLE)
			local p_MantleCount = (d and d.P_O_mantle_cnt) or 0
			if (p_MantleCount ~= m_cnt) then
				if (p_MantleCount > m_cnt) then
					for i, ent in pairs(Isaac.FindByType(EntityType.ENTITY_EFFECT, EffectVariant.POOF02, 11)) do
						if ent.SpawnerEntity and ent.SpawnerEntity:ToPlayer() then
							local t_player = ent.SpawnerEntity:ToPlayer()
							local iddx = t_player:GetData().__Index
							if iddx and iddx == idx then
								if d.P_O_timer <= 0 then
									if save.elses["P_O_buff"..idx] == nil then save.elses["P_O_buff"..idx] = 2 end
									if m_cnt == 0 and save.elses["P_O_buff"..idx] > 0 then 		--盾破到没有了
										save.elses["P_O_buff"..idx] = save.elses["P_O_buff"..idx] - 1 
										save.elses["P_O_execute"..idx] = 1
									end
									d.P_O_timer = 5 * 60
									if auxi.is_player_difficult(player) then
										d.P_O_timer = 15 * 60
									end
								else
									d.P_O_timer = 5 * 60
									if auxi.is_player_difficult(player) then
										d.P_O_timer = 15 * 60
									end
								end
								d.P_O_should_alter = true
								break
							end
						end
					end
				end
				d.P_O_mantle_cnt = m_cnt
			end
		end
	end
end,
})

--[[
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for j = 1,10 do
		save.elses["P_O_execute"..j] = 1
	end
end,
})
--]]

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local d = player:GetData()
			local idx = d.__Index
			if idx ~= nil then
				save.elses["P_O_buff"..idx] = 2
			end
			d.P_O_timer = -20
			if save.elses["P_O_execute"..idx] == 2 then
				save.elses["P_O_execute"..idx] = 1
			end
		end
	end
end,
})

return item