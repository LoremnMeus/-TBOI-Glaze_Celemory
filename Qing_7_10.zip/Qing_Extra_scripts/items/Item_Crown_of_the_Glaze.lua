local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Crown_of_the_glaze,
	tear_flag_buff = {
		[0] = TearFlags.TEAR_BONE,			--分裂1
		[1] = TearFlags.TEAR_SLOW,			--减速2
		[2] = TearFlags.TEAR_HOMING,		--深紫色3
		[3] = TearFlags.TEAR_FEAR,			--深色4
		[4] = BitSet128(0,1<<(65-64)),		--冰5
		[5] = TearFlags.TEAR_POISON,		--毒6
		[6] = BitSet128(0,1<<(66-64)),		--磁力7
		[7] = TearFlags.TEAR_ACID,			--硫酸8
		[8] = BitSet128(1,0) | TearFlags.TEAR_PIERCING,			-- 双穿9
	},
	tear_color_buff = {
		[0] = Color(1,1,1,0.7,0,0,0),
		[1] = Color(1,0,0,0.7,0.5,0,0),
		[2] = Color(1,0.1,0.5,0.7,0.5,0,0.2),
		[3] = Color(1,0,1,0.7,0.2,0,0.2),
		[4] = Color(0.4,0,1,0.7,0,0,0.3),
		[5] = Color(0,0.5,1,0.7,0,0.2,0.5),
		[6] = Color(0.5,0.5,0,0.7,0.2,0.2,0),
		[7] = Color(0.4,0.6,0,0.8,0.1,0.3,0),
		[8] = Color(1,1,0,0.7,0.5,0.4,0),
		[9] = Color(1,0.7,0,0.7,0.5,0.2,0),
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			player.Damage = player.Damage + 2 * auxi.get_damage_multiplier(player) * (2 + cnt)/3
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			player.TearRange = player.TearRange * 1.5 + 3 * 40 * (1 + cnt)/2
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			player.Luck = player.Luck * 2 + 2 * (1 + cnt)/2
		end
		if cacheFlag == CacheFlag.CACHE_TEARFLAG then
			if player:GetData().counter_id == nil then player:GetData().counter_id = 0 end
			if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] == nil then save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] = 0 end
			for i = 0,8 do
				if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] & (1<<i) == (1<<i) then
					player.TearFlags = player.TearFlags | item.tear_flag_buff[i]
				end
			end
		end
		if cacheFlag == CacheFlag.CACHE_TEARCOLOR then
			if player:GetData().Glaze_Crown_Tear_Color == nil then player:GetData().Glaze_Crown_Tear_Color = 0 end
			player.TearColor = item.tear_color_buff[player:GetData().Glaze_Crown_Tear_Color]
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if flag & DamageFlag.DAMAGE_CLONES == 0 and amt ~= 0 then
			player:TakeDamage(1,flag | DamageFlag.DAMAGE_CLONES,EntityRef(player),cooldown)
			if player:GetData().counter_id == nil then player:GetData().counter_id = 0 end
			if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] == nil then save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] = 0 end
			local tg = -1
			local tot = 0
			for i = 0,8 do
				if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] & (1<<i) ~= (1<<i) then
					tot = tot + 1
					if math.random(tot) == 1 then
						tg = i
					end
				end
			end
			--print(tg)
			if tg >= 0 then
				save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] = save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] | (1<<tg)
			end
			player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			if player:GetData().Glaze_Crown_sprite == nil then 
				player:GetData().Glaze_Crown_sprite = Sprite()
				player:GetData().Glaze_Crown_sprite:Load("gfx/crown_of_glaze.anm2", true)
				player:GetData().Glaze_Crown_sprite:Play("FloatGlow",true)
			end
			player:GetData().Glaze_Crown_sprite:Render(Isaac.WorldToScreen(player.Position + Vector(0,-10) * player.SpriteScale.Y) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:GetData().counter_id == nil then player:GetData().counter_id = playerNum end
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if player:GetData().Glaze_Crown_sprite == nil then 
				player:GetData().Glaze_Crown_sprite = Sprite()
				player:GetData().Glaze_Crown_sprite:Load("gfx/crown_of_glaze.anm2", true)
				player:GetData().Glaze_Crown_sprite:Play("FloatGlow",true)
			end
			if Game():IsPaused() == false then
				player:GetData().Glaze_Crown_sprite:Update()
			end
			if player:GetData().Glaze_Crown_sprite:GetFrame() == 51 then
				if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] == nil then save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] = 0 end
				local tg = ""
				local tar = 0
				local tot = 1
				for i = 0,8 do
					if save.elses["glaze_crown_buff_"..tostring(player:GetData().counter_id)] & (1<<i) == (1<<i) then
						tot = tot + 1
						if math.random(tot) == 1 then
							tg = "_"..tostring(i+1)
							tar = i + 1
						end
					end
				end
				player:GetData().Glaze_Crown_sprite:ReplaceSpritesheet(0,"gfx/characters/costumes/crown_of_glaze"..tg..".png")
				player:GetData().Glaze_Crown_sprite:ReplaceSpritesheet(1,"gfx/characters/costumes/crown_of_glaze"..tg..".png")
				player:GetData().Glaze_Crown_sprite:LoadGraphics()
				player:GetData().Glaze_Crown_Tear_Color = tar
				player:AddCacheFlags(CacheFlag.CACHE_TEARCOLOR)
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for i = 0,6 do
			save.elses["glaze_crown_buff_"..tostring(i)] = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for i = 0,6 do
		save.elses["glaze_crown_buff_"..tostring(i)] = 0
	end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})

return item