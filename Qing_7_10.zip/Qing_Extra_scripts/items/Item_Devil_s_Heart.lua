local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Devil_s_Heart,
	revive_counter = 95,
	costumes = {
		enums.Costumes.Devil_s_Heart_Head,
		enums.Costumes.D_s_H_2,
		enums.Costumes.D_s_H_3,
		enums.Costumes.D_s_H_4,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	if coltyp == item.entity then
		local d = player:GetData()
		if d.is_holding_D_S_H_item ~= true then
			player:AnimateCollectible(item.entity,"LiftItem","PlayerPickup")
			d.is_holding_D_S_H_item = true
		else
			player:AnimateCollectible(item.entity,"HideItem","PlayerPickup")
			d.is_holding_D_S_H_item = false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local d = player:GetData()
	local room = Game():GetRoom()
	if d.is_holding_D_S_H_item == true then
		if player:IsHoldingItem() == false then
			d.is_holding_D_S_H_item = false
		else
			local dir = 0
			local ctrlid = player.ControllerIndex
			for i = 4,7 do
				if (Input.IsActionPressed(i,ctrlid) and input_holder.actionsData[tostring(ctrlid)] and input_holder.actionsData[tostring(ctrlid)][i] and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime == 1) then
					dir = i
				end
			end
			if dir > 0 then
				local vel = Vector(0,0)
				if room:IsMirrorWorld() == true and (dir == 4 or dir == 5) then dir = 9 - dir end
				if dir == 4 then vel = vel + Vector(-1,0)
				elseif dir == 5 then vel = vel + Vector(1,0)
				elseif dir == 6 then vel = vel + Vector(0,-1)
				elseif dir == 7 then vel = vel + Vector(0,1) end
				player:AnimateCollectible(item.entity,"HideItem","PlayerPickup")
				d.is_holding_D_S_H_item = false
				local q = Isaac.Spawn(2,1,0,player.Position + player.Velocity * 0.2 + vel * player.ShotSpeed * 5,vel * player.ShotSpeed * 10 + player.Velocity * 0.3,player):ToTear()
				local s = q:GetSprite()
				s:Load("gfx/Devil_s_Heart_Tear.anm2",true)
				s:Play("Idle",true)
				q.CollisionDamage = 0
				local d2 = q:GetData()
				d2.is_devil_seed = true
				d2.devil_seed_player = player
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_devil_seed and d.is_devil_seed == true then
		local s = ent:GetSprite()
		s.Rotation = ent.Velocity:GetAngleDegrees()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	if d.is_devil_seed and d.is_devil_seed == true then
		if col:IsVulnerableEnemy() and col:IsActiveEnemy() then
			local d2 = col:GetData()
			d2.devil_seeded = true
			d2.devil_seed_player = d.devil_seed_player
			d.is_devil_seed = false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	if d.devil_seeded and d.devil_seeded == true then
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			if d.devil_seed_to_render == nil then d.devil_seed_to_render = {} end
			for u,v in pairs(d.devil_seed_to_render) do
				if v.id <= 4 then
					local s = v.sprite
					if s:IsFinished(v.now_play) then
						table.remove(d.devil_seed_to_render,u)
					else
						s:Render(Isaac.WorldToScreen(ent.Position + v.offset),Vector(0,0),Vector(0,0))
						if Game():GetFrameCount() % 2 == 1 then
							if v.color then
								s.Color = auxi.AddColor(s.Color,v.color,0.9,0.1)
							end
							s:Update()
						end
					end
				end
			end
			for u,v in pairs(d.devil_seed_to_render) do
				if v.id > 4 then
					local s = v.sprite
					if s:IsFinished(v.now_play) then
						table.remove(d.devil_seed_to_render,u)
					else
						s:Render(Isaac.WorldToScreen(ent.Position + v.offset),Vector(0,0),Vector(0,0))
						if Game():GetFrameCount() % 2 == 1 then
							if v.color then
								s.Color = auxi.AddColor(s.Color,v.color,0.9,0.1)
							end
							s:Update()
						end
					end
				end
			end
			if Game():GetFrameCount() % 2 == 1 then
				local n_s = Sprite()
				n_s:Load("gfx/Dark_tentacle.anm2",true)
				local name = "Overlay"
				local rnd = math.random(10)
				if rnd > 4 then
					name = name .. tostring(rnd)
					n_s:Play(name,true)
					n_s.PlaybackSpeed = math.random(30, 100)/100
					n_s.FlipX = (math.random(2) > 1 and true or false)
					local offset = Vector(0,0)
					if rnd > 4 then
						offset.X = math.random(8)*(math.random(2) > 1 and -1 or 1)
						n_s.PlaybackSpeed = math.random(30, 100)/100
						local scale = math.random(100, 160)/100
						n_s.Scale = Vector(scale, scale)
						n_s.Color = Color(1,1,1,1,0.2 + math.random(100)/100 * 0.3,0,0)
					else
						offset.X = math.random(10)*(math.random(2) > 1 and -1 or 1)
						local scale = math.random(70, 110)/100
						n_s.Scale = Vector(scale, scale)
					end
					local tab = {sprite = n_s,now_play = name,offset = offset,id = rnd,}
					if rnd > 4 then
						tab.color = Color(1,1,1,1,0,0,0)
					end
					table.insert(d.devil_seed_to_render,tab)
				end
			end
		end
	end
end,
})

local function revive_player(player)
	local heart = player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 0
	local only_bone_hearts = auxi.is_player_only_bone_hearts(player)
	local only_red_hearts = auxi.is_player_only_red_hearts(player)
	if (playerType == PlayerType.PLAYER_THEFORGOTTEN_B) then
        if (player.EntityCollisionClass == 0) then
            player.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ALL
        end
    end
	if (not heart) then
		if(only_bone_hearts) then
			player:AddBoneHearts(1)
		elseif(only_red_hearts) then
			if (player:GetMaxHearts() <= 0) then
				player:AddMaxHearts(2)
			end
			player:AddHearts(2)
		end
		if (player:GetMaxHearts() > 0) then
			if (player:GetHearts() <= 0) then
				player:AddHearts(1-player:GetHearts())
			end
		else
			if (player:GetSoulHearts() <= 0) then
				auxi.add_soul_heart(player, 1)
			end
		end
	end
	player:SetMinDamageCooldown(60)
	local d = player:GetData()
	d.has_been_revive = false
	local ent = d.D_H_revive_ent
	if ent and ent:Exists() and not ent:IsDead() then
	else
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		for u,v in pairs(n_enemy) do
			if v:GetData().devil_seeded and v:GetData().devil_seed_player then
				local t_player = v:GetData().devil_seed_player
				local idx = d.__Index
				local t_idx = t_player:GetData().__Index
				if idx and t_idx and idx == t_idx then
					ent = v
					break
				end
			end
		end
	end
	if ent and ent:Exists() and not ent:IsDead() then
		player.Position = ent.Position
		local d2 = ent:GetData()
		d2.devil_seeded = false
		d2.devil_seed_player = nil
		local idx = d.__Index
		save.elses["D_H_Costume_"..tostring(idx)] = save.elses["D_H_Costume_"..tostring(idx)] + 1
		for i = 1,math.min(save.elses["D_H_Costume_"..tostring(idx)],#item.costumes) do
			player:AddNullCostume(item.costumes[i])
		end
		local rng = player:GetCollectibleRNG(item.entity)
		rng = auxi.rng_for_sake(rng)
		local hp = ent.HitPoints
		local rnd = rng:RandomInt(math.ceil(math.log(hp/3))) + save.elses["D_H_Costume_"..tostring(idx)] 
		if hp > 150 then
			rnd = rnd + rng:RandomInt(math.ceil(math.log(hp)))
		end
		if hp > 800 then
			rnd = rnd + rng:RandomInt(math.ceil(math.log(hp * 2)))
		end
		if hp > 3000 then
			rnd = math.max(rnd,wei + 3)
		end
		local n_entity = Isaac.GetRoomEntities()
		local wisps = auxi.getothers(n_entity,3,FamiliarVariant.WISP,item.entity)
		for i = 1,math.min(rnd,#wisps) do
			wisps[i]:Remove()
		end
		rnd = 0
		local pool = {}
		local itemConfig = Isaac.GetItemConfig()
		local sz = itemConfig:GetCollectibles().Size
		local wei = 0
		for id = 1,sz do
			local collectible = itemConfig:GetCollectible(id)
			if (collectible and player:HasCollectible(id) and id ~= item.entity) then
				if player:GetCollectibleNum(id) - player:GetEffects():GetCollectibleEffectNum(id) > 0 then
					table.insert(pool,{id = id,weigh = player:GetCollectibleNum(id) - player:GetEffects():GetCollectibleEffectNum(id)})
					wei = wei + player:GetCollectibleNum(id) - player:GetEffects():GetCollectibleEffectNum(id)
				end
			end
		end
		for k = 1,rnd do
			if #pool > 0 then
				local tg_item = pool[1].id
				local rwei = rng:RandomInt(wei) + 1
				for i = 1,#pool do
					rwei = rwei - pool[i].weigh
					if rwei <= 0 then
						tg_item = pool[i].id
						pool[i].weigh = pool[i].weigh - 1
						wei = wei - 1
						if pool[i].weigh <= 0 then
							table.remove(pool,i)
						end
						break
					end
				end
				player:RemoveCollectible(tg_item)
			else
				--player:RemoveCollectible(item.entity)
				player:AddBrokenHearts(math.min(player:GetHeartLimit() - 1,rnd - k))
				break
			end
		end
		ent:Kill()
		Game():GetRoom():EmitBloodFromWalls(60,5)
		sound_tracker.PlayStackedSound(SoundEffect.SOUND_HOLY,1,1,false,0,2)
		sound_tracker.PlayStackedSound(SoundEffect.SOUND_UNHOLY,1,1,false,0,2)
	else
		player:Kill()
	end
end

local function D_H_revive_cover(player)
	local d = player:GetData()
	if (d.D_H_should_revive and d.D_H_should_revive == true) then
		revive_player(player)
		player:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
	end
end

local function D_H_try_revive(player)
	local d = player:GetData()

    if (d.D_H_should_revive and d.D_H_should_revive == true) then
		if (d.D_H_revive_time and d.D_H_revive_counter > d.D_H_revive_time) or (d.D_H_revive_time == nil and d.D_H_revive_counter > item.revive_counter) then
			revive_player(player)

			d.D_H_should_revive = false
			d.D_H_revive_counter = 0
			player:StopExtraAnimation()
			player:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
			return
		end
    end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = 1,
Function = function(_,ent)
	if ent:ToPlayer() then
		local player = ent:ToPlayer()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local d = player:GetData()
			local should_revive = false
			local revive_ent = nil
			local n_entity = Isaac.GetRoomEntities()
			local n_enemy = auxi.getenemies(n_entity)
			for u,v in pairs(n_enemy) do
				if v:GetData().devil_seeded and v:GetData().devil_seed_player then
					local t_player = v:GetData().devil_seed_player
					local idx = d.__Index
					local t_idx = t_player:GetData().__Index
					if idx and t_idx and idx == t_idx then
						should_revive = true
						revive_ent = v
						break
					end
				end
			end
			if should_revive and not player:WillPlayerRevive() and d.has_been_revive ~= true then
				d.D_H_revive_ent = revive_ent
				d.has_been_revive = true
				d.D_H_should_revive = true
				d.D_H_animation_to_play = auxi.get_death_animation_to_play(player)
				if d.D_H_animation_to_play == "LostDeath" then
					d.D_H_revive_time = 60
				end
				local heart = player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 0
				local playerType = player:GetPlayerType()
				local isForgottenB = playerType == PlayerType.PLAYER_THEFORGOTTEN_B
				local has_add_heart_container = false
				local only_bone_hearts = auxi.is_player_only_bone_hearts(player)
				local only_red_hearts = auxi.is_player_only_red_hearts(player)
				if (not heart) then
					if(only_bone_hearts) then
						player:AddBoneHearts(1)
					elseif(only_red_hearts) then
						if (player:GetMaxHearts() <= 0) then
							player:AddMaxHearts(2)
							has_add_heart_container = true
						end
						player:AddHearts(2)
					end
				end
				player:Revive()		--假死
				if (isForgottenB) then
					if (not player.Visible) then
						player.Visible = true
					end
				end
				if(only_red_hearts and has_add_heart_container == true) then
					player:AddMaxHearts(-2)
				end
				if (not heart) then
					if (player:GetHearts() > 0) then
						player:AddHearts(-player:GetHearts())
					end
					if (player:GetBoneHearts() > 0) then
						player:AddBoneHearts(-player:GetBoneHearts())
					end
					local soulHearts = player:GetSoulHearts()
					if (player:GetSoulHearts() > 0) then
						auxi.add_soul_heart(player, -player:GetSoulHearts())
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local playerType = player:GetPlayerType()
	local d = player:GetData()
    if (d.D_H_animation_to_play) then
        d.animation_counter = d.animation_counter or -1
        if (d.animation_counter < 0) then
            player:PlayExtraAnimation(d.D_H_animation_to_play)
            d.D_H_animation_to_play = nil
        else
            d.animation_counter = d.animation_counter - 1
        end
    end
    if (d.D_H_should_revive and d.D_H_should_revive == true) then
        player:SetMinDamageCooldown(60)
        player:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
		if d.D_H_revive_counter == nil then d.D_H_revive_counter = 0 end
		d.D_H_revive_counter = d.D_H_revive_counter + 1
        if (player:GetSprite():IsEventTriggered("DeathSound")) then
            sound_tracker.PlayStackedSound(SoundEffect.SOUND_ISAACDIES,1,1,false,0,2)
        end
        player.Velocity = Vector(0,0)
        D_H_try_revive(player)
    end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PLAYER_COLLISION, params = nil,
Function = function(_,player, col, low)
	local d = player:GetData()
	if d.D_H_should_revive and d.D_H_should_revive == true then
		return false
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_INPUT_ACTION, params = InputHook.IS_ACTION_TRIGGERED,
Function = function(_,ent, hook, action)
	if ent ~= nil then
		local player = ent:ToPlayer()
		if player then
			local d = player:GetData()
			if d.D_H_should_revive and d.D_H_should_revive == true then
				if action <= ButtonAction.ACTION_DROP then
					return false
				end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_NPC_COLLISION, params = nil,
Function = function(_,ent, col, low)
	 if (col.Type == 1) and col:ToPlayer() then
        local player = col:ToPlayer()
        local d = player:GetData()
        if d.D_H_should_revive and d.D_H_should_revive == true then
            return false
        end
    end
	return nil
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	local d = player:GetData()
	local idx = d.__Index
	if idx then
		if Game():GetFrameCount() > 2 then
			if save.elses["D_H_Costume_"..tostring(idx)] then
				for i = 1,math.min(save.elses["D_H_Costume_"..tostring(idx)],#item.costumes) do
					player:AddNullCostume(item.costumes[i])
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,
Function = function(_,collid, itemRng, player, useFlags, activeSlot, customVarData)
	if collid == 283 or collid == 284 or collid == 703 then
		local d = player:GetData()
		local idx = d.__Index
		if idx then
			if save.elses["D_H_Costume_"..tostring(idx)] then
				for i = 1,math.min(save.elses["D_H_Costume_"..tostring(idx)],#item.costumes) do
					player:AddNullCostume(item.costumes[i])
				end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		D_H_revive_cover(player)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["D_H_Costume_"..tostring(j)] = 0
		end
	end
end,
})

return item