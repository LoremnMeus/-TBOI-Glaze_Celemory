local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")
local selection_holder = require("Qing_Extra_scripts.others.selection_holder")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local grid_entity = require("Qing_Extra_scripts.grids.grid_entity")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local ui = require("Qing_Extra_scripts.auxiliary.ui")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Squiresaga,
	targ = nil,
	targ_counter = 0,
	mx_rm = 0.05,
	now_display_rm = 0,
	now_display_pos = nil,
	stoped = false,
	render_sprite_pos = nil,
	now_display_dir = Vector(1,0),
	dir_time_limit = 20,
	unstopable = {
		[EntityType.ENTITY_PLAYER] = true,
		--[EntityType.ENTITY_TEAR] = true,
		[EntityType.ENTITY_LASER] = true,
		--[EntityType.ENTITY_MINECART] = true,
		[EntityType.ENTITY_KNIFE] = true,
		[EntityType.ENTITY_PROJECTILE] = true,
		[EntityType.ENTITY_TEXT] = true,
		[EntityType.ENTITY_EFFECT] = true,
	},
	uncheckable = {
		[EntityType.ENTITY_PLAYER] = true,
		[EntityType.ENTITY_TEAR] = true,
		[EntityType.ENTITY_LASER] = true,
		--[EntityType.ENTITY_MINECART] = true,
		[EntityType.ENTITY_KNIFE] = true,
		[EntityType.ENTITY_PROJECTILE] = true,
		[EntityType.ENTITY_TEXT] = true,
		[EntityType.ENTITY_EFFECT] = true,
	},
	grid_filter = {
		[1] = true,
		[15] = true,
	},
	changeable_state = {
		[2] = {	--normal
			[1] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "生命：",})
					local d = ent:GetData()
					d.saga_modifier_hitpoint_vr = d.saga_modifier_hitpoint_vr or 1
					local vr = d.saga_modifier_hitpoint_vr
					local offset = Vector(0,0)
					
					local wd1 = tostring(math.ceil(ent.HitPoints * 10)/10)
					if choosed and vr == 1 then wd1 = "<="..wd1.."=>" offset = offset + Vector(-5,0) end
					local wd2 = tostring(math.ceil(ent.MaxHitPoints * 10)/10)
					if choosed and vr == 2 then wd2 = "<="..wd2.."=>" offset = offset + Vector(-5,0) end
					local wd = wd1.."/"..wd2
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local vr = d.saga_modifier_hitpoint_vr
					if dir == 1 then 
						if vr == 1 then
							if ent.HitPoints < ent.MaxHitPoints then
								ent.HitPoints = math.min(ent.MaxHitPoints,ent.HitPoints + ent.MaxHitPoints * 0.01)
								return 0
							else
								return -1
							end
						elseif vr == 2 then
							ent.MaxHitPoints = math.max(ent.MaxHitPoints + 1,ent.MaxHitPoints * 1.01)
							return 0
						end
					elseif dir == -1 then
						if vr == 1 then
							local isboss = ent:IsBoss()
							if (isboss == false and ent.HitPoints > ent.MaxHitPoints * 0.3) or (isboss == true and ent.HitPoints > ent.MaxHitPoints * 0.7) then
								ent.HitPoints = ent.HitPoints - ent.MaxHitPoints * 0.01
								return 0
							else
								return -1
							end
						elseif vr == 2 then
							if ent.MaxHitPoints > ent.HitPoints * 1.2 then
								ent.MaxHitPoints = ent.MaxHitPoints / 1.01
								return 0
							else
								return -1
							end
						end
					elseif dir == 2 or dir == -2 then
						d.saga_modifier_hitpoint_vr = 3 - d.saga_modifier_hitpoint_vr
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					if ent.MaxHitPoints == 0 then return false end
					return true
				end,
			},
			[2] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "大小：",})
					local d = ent:GetData()
					d.saga_modifier_size_vr = d.saga_modifier_size_vr or 1
					local vr = d.saga_modifier_size_vr
					
					local offset = Vector(0,0)
					local wd1 = tostring(math.floor(ent.SpriteScale.X * 100)/100)
					if choosed and vr == 2 then wd1 = "<="..wd1.."=>" offset = offset + Vector(-5,0) end
					local wd2 = tostring(math.floor(ent.SpriteScale.Y * 100)/100)
					if choosed and vr == 3 then wd2 = "<="..wd2.."=>" offset = offset + Vector(-5,0) end
					local wd = wd1.."X"..wd2
					if choosed and vr == 1 then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local succc = ent:GetData().saga_modifier_sprite_size
					local succc2 = ent:GetData().saga_modifier_size
					local spritesize = ent.SpriteScale
					if dir == 1 then 
						if d.saga_modifier_size_vr == 1 then
							local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",ent.Size * 1.04)
							if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
							d.saga_modifier_size = succ2
							spritesize = spritesize * 1.05
						elseif d.saga_modifier_size_vr == 2 then
							local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",ent.Size * math.sqrt(1.04))
							if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
							d.saga_modifier_size = succ2
							spritesize = Vector(spritesize.X * 1.05,spritesize.Y)
						elseif d.saga_modifier_size_vr == 3 then
							local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",ent.Size * math.sqrt(1.04))
							if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
							d.saga_modifier_size = succ2
							spritesize = Vector(spritesize.X,spritesize.Y * 1.05)
						end
						local succ = Attribute_holder.try_hold_attribute(ent,"SpriteScale",spritesize)
						if succc then Attribute_holder.try_rewind_attribute(ent,"SpriteScale",succc) end
						d.saga_modifier_sprite_size = succ
						return 0
					elseif dir == -1 then
						if d.saga_modifier_size_vr == 1 then
							if spritesize.X - 0.00001 > 0.2 and spritesize.Y - 0.00001 > 0.2 then
								local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",math.max(math.min(0.2,ent.Size),ent.Size/1.04))
								if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
								d.saga_modifier_size = succ2
								spritesize = math.max(math.min(0.2 * math.sqrt(2),ent.SpriteScale:Length()),ent.SpriteScale:Length() / 1.05) * ent.SpriteScale:Normalized()
							else
								return -1
							end
						elseif d.saga_modifier_size_vr == 2 then
							if spritesize.X - 0.00001 > 0.2 then
								local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",math.max(math.min(0.2,ent.Size),ent.Size/ math.sqrt(1.04)))
								if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
								d.saga_modifier_size = succ2
								spritesize = Vector(math.max(math.min(0.2,spritesize.X),spritesize.X / 1.05),spritesize.Y)
							else
								return -1
							end
						elseif d.saga_modifier_size_vr == 3 then
							if spritesize.Y - 0.00001 > 0.2 then
								local succ2 = Attribute_holder.try_hold_attribute(ent,"Size",math.max(math.min(0.2,ent.Size),ent.Size/ math.sqrt(1.04)))
								if succc2 then Attribute_holder.try_rewind_attribute(ent,"Size",succc2) end
								d.saga_modifier_size = succ2
								spritesize = Vector(spritesize.X,math.max(math.min(0.2,spritesize.Y),spritesize.Y / 1.05))
							else
								return -1
							end
						end
						local succ = Attribute_holder.try_hold_attribute(ent,"SpriteScale",spritesize)
						if succc then Attribute_holder.try_rewind_attribute(ent,"SpriteScale",succc) end
						d.saga_modifier_sprite_size = succ
						return 0
					elseif dir == 2 then
						d.saga_modifier_size_vr = d.saga_modifier_size_vr % 3 + 1
						return 0
					elseif dir == -2 then
						d.saga_modifier_size_vr = (d.saga_modifier_size_vr + 3 - 2) % 3 + 1
						return 0
					end
					return 1
				end,
			},
			[3] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "滑动性：",})
					local wd = tostring(math.floor(ent.Friction * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local succc = ent:GetData().saga_modifier_friction
					local fri = ent.Friction
					if dir == 1 then 
						if ent.Friction < 1.2 then
							local succ = Attribute_holder.try_hold_attribute(ent,"Friction",fri + 0.01)
							if succc then Attribute_holder.try_rewind_attribute(ent,"Friction",succc) end
							d.saga_modifier_friction = succ
							return 0
						else
							return -1
						end
					elseif dir == -1 then
						if ent.Friction > 0.8 then
							local succ = Attribute_holder.try_hold_attribute(ent,"Friction",math.max(0,fri - 0.01))
							if succc then Attribute_holder.try_rewind_attribute(ent,"Friction",succc) end
							d.saga_modifier_friction =succ
							return 0
						else
							return -1
						end
					end
					return 1
				end,
			},
			[4] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "颜色：",})
					local d = ent:GetData()
					d.saga_modifier_color_vr = d.saga_modifier_color_vr or 1
					local vr = d.saga_modifier_color_vr
					for i = 1,7 do
						local wd = info.colormap[i]..":"..tostring(math.floor((ent.Color[info.colormap[i]]) * 255))
						local offset = Vector(0,0)
						if choosed and vr == i then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
						table.insert(ret,#ret + 1,{wd = wd,offset = offset,col = auxi.AddColor(info.colorsmap[i],Color(0.5,0.5,0.5,1),ent.Color[info.colormap[i]],1-ent.Color[info.colormap[i]]),})
					end
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					d.saga_modifier_color_vr = d.saga_modifier_color_vr or 1
					local succc = ent:GetData().saga_modifier_color
					if dir == 1 then
						local col = ent.Color
						col[info.colormap[d.saga_modifier_color_vr]] = col[info.colormap[d.saga_modifier_color_vr]] + 5/255
						local succ = Attribute_holder.try_hold_attribute(ent,"Color",col)
						if succc then Attribute_holder.try_rewind_attribute(ent,"Color",succc) end
						d.saga_modifier_color = succ
						return 0
					elseif dir == -1 then
						local col = ent.Color
						col[info.colormap[d.saga_modifier_color_vr]] = col[info.colormap[d.saga_modifier_color_vr]] - 5/255
						local succ = Attribute_holder.try_hold_attribute(ent,"Color",col)
						if succc then Attribute_holder.try_rewind_attribute(ent,"Color",succc) end
						d.saga_modifier_color = succ
						return 0
					elseif dir == 2 then
						d.saga_modifier_color_vr = d.saga_modifier_color_vr % 7 + 1
						return 0
					elseif dir == -2 then
						d.saga_modifier_color_vr = (d.saga_modifier_color_vr + 7 - 2) % 7 + 1
						return 0
					end
					return 1
				end,
				colormap = {
					[1] = "R",
					[2] = "G",
					[3] = "B",
					[4] = "A",
					[5] = "RO",
					[6] = "GO",
					[7] = "BO",
				},
				colorsmap = {
					[1] = Color(1,0,0,1),
					[2] = Color(0,1,0,1),
					[3] = Color(0,0,1,1),
					[4] = Color(1,1,1,0.5),
					[5] = Color(1,0.5,0.5,1),
					[6] = Color(0.5,1,0.5,1),
					[7] = Color(0.5,0.5,1,1),
				},
			},
			[5] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "旋转角：",})
					local wd = tostring(math.floor(ent.SpriteRotation * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local val = ent.SpriteRotation
					if dir == 1 then 
						ent.SpriteRotation = val + 5
						return 0
					elseif dir == -1 then
						ent.SpriteRotation = val - 5
						return 0
					end
					return 1
				end,
			},
			[6] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "碰撞伤害：",})
					local wd = tostring(math.floor(ent.CollisionDamage * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local val = ent.CollisionDamage
					if dir == 1 then 
						ent.CollisionDamage = (ent.CollisionDamage)% 6 + 1
						return 0
					elseif dir == -1 then
						ent.CollisionDamage = (ent.CollisionDamage + 4)% 6 + 1
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					if ent:ToFamiliar() == nil and ent:ToBomb() == nil and ent.CollisionDamage > 0 then return true end
					return false
				end,
			},
			[7] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "碰撞类型：",})
					local wd = info.collisionmap[ent.EntityCollisionClass] or "？"
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local val = ent.EntityCollisionClass
					
					if dir == 1 then 
						ent.EntityCollisionClass = (val + 1) % 5
						return 0
					elseif dir == -1 then
						ent.EntityCollisionClass = (val + 4) % 5
						return 0
					end
					return 1
				end,
				collisionmap = {
					[EntityCollisionClass.ENTCOLL_NONE] = "与世无争",
					[EntityCollisionClass.ENTCOLL_PLAYERONLY] = "仅玩家",
					[EntityCollisionClass.ENTCOLL_PLAYEROBJECTS] = "友方",
					[EntityCollisionClass.ENTCOLL_ENEMIES] = "敌方",
					[EntityCollisionClass.ENTCOLL_ALL] = "一切实体",
				},
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				return true
			end,
		},
		[3] = {	--enemy
			[1] = {
				name = function(info,ent,choosed)
					ent = ent:ToNPC()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "变异：",})
					local wd = tostring(info.champions[ent:GetChampionColorIdx()])
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToNPC()
					local d = ent:GetData()
					local succc = ent:GetData().saga_modifier_friction
					local val = ent:GetChampionColorIdx()
					if dir == 1 then 
						val = val + 1
						if val > 25 then val = 0 end
						local mxhp = ent.MaxHitPoints
						ent:MakeChampion(-1,val,true)
						ent.MaxHitPoints = mxhp
						return 0
					elseif dir == -1 then
						val = val - 1
						if val < 0 then val = 25 end
						local mxhp = ent.MaxHitPoints
						ent:MakeChampion(-1,val,true)
						ent.MaxHitPoints = mxhp
						return 0
					end
					return 1
				end,
				champions = {
					[-1] = "无",
					[0] = "红色",
					[1] = "黄色",
					[2] = "绿色",
					[3] = "橙色",
					[4] = "深蓝色",
					[5] = "深绿色",
					[6] = "纯白色",
					[7] = "灰色",
					[8] = "透明白色",
					[9] = "黑色",
					[10] = "粉色",
					[11] = "紫色",
					[12] = "深红色",
					[13] = "浅蓝色",
					[14] = "保护色",
					[15] = "闪烁绿色",
					[16] = "闪烁灰色",
					[17] = "浅白色",
					[18] = "小",
					[19] = "大",
					[20] = "闪烁红色",
					[21] = "大小变",
					[22] = "皇冠",
					[23] = "骷髅",
					[24] = "棕色",
					[25] = "彩虹",
				},
			},
			[2] = {
				name = function(info,ent,choosed)
					ent = ent:ToNPC()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "负面状态：",})
					local d = ent:GetData()
					d.saga_modifier_buff_vr = d.saga_modifier_buff_vr or 1
					local vr = d.saga_modifier_buff_vr
					
					for i = 1,#(info.buffs) do
						local v = info.buffs[i]
						local wd = tostring(v.tm).."秒"..v.name.."："
						local wd1 = ent:HasEntityFlags(v.val)
						if wd1 then wd1 = "是" else wd1 = "否" end
						local offset = Vector(-10,0)
						if choosed and vr == i then wd1 = "<="..wd1.."=>" offset = offset + Vector(-5,0) end
						wd = wd..wd1
						table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					end
					
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToNPC()
					local d = ent:GetData()
					local succc = ent:GetData().saga_modifier_friction
					local val = ent:GetChampionColorIdx()
					local vr = d.saga_modifier_buff_vr
					local buff = info.buffs[vr]
					
					if dir == 1 then 
						if ent:HasEntityFlags(buff.val) == false then
							d["saga_buff_"..tostring(vr).."_succ"] = Attribute_holder.try_hold_and_rewind_attribute(ent,"EntityFlag_"..buff.flagname,true,buff.tm * 30,{toget = function(ent) return ent:HasEntityFlags(buff.val) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(buff.val) else ent:AddEntityFlags(buff.val) end end,})
							return 0
						else
							return -1
						end
					elseif dir == -1 then
						if ent:HasEntityFlags(buff.val) then
							if d["saga_buff_"..tostring(vr).."_succ"] then
								Attribute_holder.try_rewind_attribute(ent,"EntityFlag_"..buff.flagname,d["saga_buff_"..tostring(vr).."_succ"],{toget = function(ent) return ent:HasEntityFlags(buff.val) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(buff.val) else ent:AddEntityFlags(buff.val) end end,})
							end
							ent:ClearEntityFlags(buff.val)
							return 0
						else
							return -1
						end
					elseif dir == 2 then
						d.saga_modifier_buff_vr = d.saga_modifier_buff_vr % #(info.buffs) + 1
						return 0
					elseif dir == -2 then
						d.saga_modifier_buff_vr = (d.saga_modifier_buff_vr + #(info.buffs) - 2) % #(info.buffs) + 1
						return 0
					end
					return 1
				end,
				buffs = {
					--[1] = {name = "中毒",val = EntityFlag.FLAG_POISON,tm = 10,flagname = "FLAG_POISON",},
					[1] = {name = "魅惑",val = EntityFlag.FLAG_CHARM,tm = 10,flagname = "FLAG_CHARM",},
					[2] = {name = "混乱",val = EntityFlag.FLAG_CONFUSION,tm = 10,flagname = "FLAG_CONFUSION",},
					--[3] = {name = "点金",val = EntityFlag.FLAG_MIDAS_FREEZE,tm = 5,flagname = "FLAG_MIDAS_FREEZE",special_tochange = function(ent,tm) ent:AddMidasFreeze(EntityRef(ent),tm) end},
					[3] = {name = "恐惧",val = EntityFlag.FLAG_FEAR,tm = 10,flagname = "FLAG_FEAR",},
					--[6] = {name = "燃烧",val = EntityFlag.FLAG_BURN,tm = 10,flagname = "FLAG_BURN",},
					--[4] = {name = "收缩",val = EntityFlag.FLAG_SHRINK,tm = 10,flagname = "FLAG_SHRINK",},
					[4] = {name = "硫磺印",val = EntityFlag.FLAG_BRIMSTONE_MARKED,tm = 10,flagname = "FLAG_BRIMSTONE_MARKED",},
					--[8] = {name = "无奖励",val = EntityFlag.FLAG_NO_REWARD,tm = 20,flagname = "FLAG_NO_REWARD",},
				},
				check = function(info,ent)
					if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() then return true end
					return false
				end,
			},
			[3] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = info.mindtype(ent)
					local wd = (info.hearttype[vr] or {name = "未知火堆",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local s = ent:GetSprite()
					local vr = info.mindtype(ent)
					local val = (info.hearttype[vr] or {id = 0,}).id or vr
					local vval = info.tpmap[val] or val
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
					end
					if dir == 1 or dir == -1 then
						if (info.hearttype[vval].special_toturn) then
							info.hearttype[vval].special_toturn(ent,false)
						end
						if (info.hearttype[val].special_toturn) then
							info.hearttype[val].special_toturn(ent,true)
						else
							ent.Variant = val
						end
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					if ent.Type == 33 and ent.Variant <= 8 then return true end
					return false
				end,
				hearttype = {
					[0] = {name = "火堆",id = 1,loadname = "gfx/033.000_fireplace.anm2",},
					[1] = {name = "红火堆",id = 2,loadname = "gfx/033.001_red fireplace.anm2",},
					[2] = {name = "蓝火堆",id = 3,loadname = "gfx/033.002_blue fireplace.anm2",},
					[3] = {name = "紫火堆",id = 4,loadname = "gfx/033.003_purple fireplace.anm2",},
					[4] = {name = "白火堆",id = 5,loadname = "gfx/033.004_white fireplace.anm2",},
				},
				mindtype = function(ent)
					return ent.Variant
				end,
				tpmap = {
					[1] = 0,
					[2] = 1,
					[3] = 2,
					[4] = 3,
					[5] = 4,
				},
				mxn = 5,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				if ent:ToNPC() then return true end
				return false
			end,
		},
		[1] = {	--pickup
			[16] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "价格：",})
					local price = ent.Price
					if info.price_map[price] then price = info.price_map[price] else price = tostring(price) end
					local wd = price
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local price = ent.Price
					ent.AutoUpdatePrice = false
					if dir == 1 then 
						if price == -1000 then
							return -1
						elseif price == -6 then
							return -1
						elseif price == 0 then
							price = 1
						elseif price >= 999 then
							price = -1000
						elseif price < 0 then 
							price = -((-price) % 5 + 1)
						else
							price = math.min(999,price + math.max(math.floor(price * 0.05),1))
						end
						ent.Price = price
						return 0
					elseif dir == -1 then
						if price == -1000 then
							return -1
						elseif price == 1 then
							return -1
						elseif price == -6 then
							return -1
						elseif price < 0 then 
							price = -((-price + 3) % 5 + 1)
						else
							price = price - math.max(math.floor(price * 0.05),1)
						end
						ent.Price = price
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					--return true
					if ent.Price ~= 0 then return true end
					return false
				end,
				price_map = {
					[-1] = "一颗红心",
					[-2] = "两颗红心",
					[-3] = "三颗魂心",
					[-4] = "一红心两魂心",
					[-5] = "被刺扎",
					[-6] = "小罗",
					[-1000] = "零元购！",
				},
			},
			[2] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "道具编号：",})
					local val = ent.SubType
					
					local wd = val
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.SubType
					local config = Isaac.GetItemConfig()
					local sz = config:GetCollectibles().Size
					
					if dir == 1 then 
						val = val + 1
						while((val < sz or (val > 2^31 and val < 2^32)) and (config:GetCollectible(val) == nil or config:GetCollectible(val).Hidden or config:GetCollectible(val).Tags & ItemConfig.TAG_QUEST == ItemConfig.TAG_QUEST)) do
							val = val + 1
						end
					elseif dir == -1 then
						val = val - 1
						while(val > 0 and val < sz and (config:GetCollectible(val) == nil or config:GetCollectible(val).Hidden or config:GetCollectible(val).Tags & ItemConfig.TAG_QUEST == ItemConfig.TAG_QUEST)) do
							val = val - 1
						end
					elseif dir == 2 then
						if (val > 2^31 and val < 2^32) then return -1 end
						val = val + 100
						while((val < sz or (val > 2^31 and val < 2^32)) and (config:GetCollectible(val) == nil or config:GetCollectible(val).Hidden or config:GetCollectible(val).Tags & ItemConfig.TAG_QUEST == ItemConfig.TAG_QUEST)) do
							val = val + 1
						end
					elseif dir == -2 then
						if (val > 2^31 and val < 2^32) then return -1 end
						val = val - 100
						if val <= 0 then return -1 end
						while(val > 0 and val < sz and (config:GetCollectible(val) == nil or config:GetCollectible(val).Hidden or config:GetCollectible(val).Tags & ItemConfig.TAG_QUEST == ItemConfig.TAG_QUEST)) do
							val = val - 1
						end
					end
					if dir == 1 or dir == -1 or dir == 2 or dir == -2 then
						local col = config:GetCollectible(val)
						local pcol = config:GetCollectible(ent.SubType)
						if col then
							local mxcharge = col.MaxCharges
							local pmxcharge = pcol.MaxCharges
							local charge = ent.Charge
							ent.SubType = val
							s:ReplaceSpritesheet(1,config:GetCollectible(val).GfxFileName)
							s:LoadGraphics()
							ent.Charge = math.floor(charge/math.max(1,pmxcharge) * mxcharge)
							return 0
						else
							return -1
						end
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 100 and ent.SubType ~= 0 then return true end
					return false
				end,
			},
			[3] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "充能：",})
					local val = ent.SubType
					local config = Isaac.GetItemConfig()
					local col = config:GetCollectible(val)
					
					local wd = ent.Charge
					local wd1 = col.MaxCharges
					if wd1 > 12 then wd = math.floor(wd/wd1 * 100)/100 wd1 = 1 end
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					wd = wd .."/".. tostring(wd1)
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.Charge
					local config = Isaac.GetItemConfig()
					local col = config:GetCollectible(ent.SubType)
					local mxval = col.MaxCharges
					
					if dir == 1 then 
						if val < mxval * 2 then 
							val = math.min(mxval * 2,val + math.max(1,math.floor(mxval/12))) 
						else
							return -1
						end
						ent.Charge = val
						return 0
					elseif dir == -1 then
						if val > 0 then 
							val = math.max(0,val - math.max(1,math.floor(mxval/12))) 
						else
							return -1
						end
						ent.Charge = val
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 100 and ent.SubType ~= 0 then 
						local config = Isaac.GetItemConfig()
						local col = config:GetCollectible(ent.SubType)
						if col then
							if col.MaxCharges > 0 then
								return true 
							end
						end
					end
					return false
				end,
			},
			[4] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "摸过：",})
					local val = ent.Touched
					
					local wd = "否"
					if val == true then wd = "是" end
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.Touched
					
					if dir == 1 then 
						ent.Touched = not ent.Touched
						return 0
					elseif dir == -1 then
						ent.Touched = not ent.Touched
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 100 and ent.SubType ~= 0 then 
						return true
					end
					return false
				end,
			},
			[5] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知心",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 10 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "红心",loadname = "gfx/005.011_heart.anm2",},
					[2] = {name = "半红心",loadname = "gfx/005.012_heart (half).anm2",},
					[3] = {name = "魂心",loadname = "gfx/005.013_heart (soul).anm2",},
					[4] = {name = "白心",loadname = "gfx/005.014_heart (eternal).anm2",},
					[5] = {name = "双红心",loadname = "gfx/005.015_double heart.anm2",},
					[6] = {name = "黑心",loadname = "gfx/005.016_black heart.anm2",},
					[7] = {name = "金心",loadname = "gfx/005.017_goldheart.anm2",},
					[8] = {name = "半魂心",loadname = "gfx/005.018_heart (halfsoul).anm2",},
					[9] = {name = "胆小心",loadname = "gfx/005.020_scared heart.anm2",},
					[10] = {name = "混合心",loadname = "gfx/005.019_blended heart.anm2",},
					[11] = {name = "骨心",loadname = "gfx/005.01a_bone heart.anm2",},
					[12] = {name = "腐心",loadname = "gfx/005.01b_rotten heart.anm2",},
					[enums.Pickups.Glaze_heart.SubType] = {name = "琉璃之心",id = 13,loadname = "gfx/glaze_heart.anm2",},
					[enums.Pickups.Glaze_heart_half.SubType] = {name = "琉璃之半心",id = 14,loadname = "gfx/glaze_heart_half.anm2",},
				},
				tpmap = {
					[13] = enums.Pickups.Glaze_heart.SubType,
					[14] = enums.Pickups.Glaze_heart_half.SubType,
				},
				mxn = 14,
			},
			[7] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "饰品编号：",})
					local val = ent.SubType % 32768
					
					local wd = val
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.SubType % 32768
					local golden = math.floor(ent.SubType / 32768)
					local config = Isaac.GetItemConfig()
					local sz = config:GetTrinkets().Size
					
					if dir == 1 then 
						val = val + 1
						while((val < sz) and (config:GetTrinket(val) == nil or config:GetTrinket(val).Hidden)) do
							val = val + 1
						end
					elseif dir == -1 then
						val = val - 1
						while(val > 0 and val < sz and (config:GetTrinket(val) == nil or config:GetTrinket(val).Hidden)) do
							val = val - 1
						end
					elseif dir == 2 then
						val = val + 20
						while((val < sz) and (config:GetTrinket(val) == nil or config:GetTrinket(val).Hidden)) do
							val = val + 1
						end
					elseif dir == -2 then
						val = val - 20
						while(val > 0 and val < sz and (config:GetTrinket(val) == nil or config:GetTrinket(val).Hidden)) do
							val = val - 1
						end
					end
					if dir == 1 or dir == -1 or dir == 2 or dir == -2 then
						if config:GetTrinket(val) then
							ent.SubType = val + golden * 32768
							s:ReplaceSpritesheet(0,config:GetTrinket(val).GfxFileName)
							s:LoadGraphics()
							return 0
						else
							return -1
						end
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 350 then return true end
					return false
				end,
			},
			[6] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "金饰品：",})
					local val = math.floor(ent.SubType / 32768)
					
					local wd = "否"
					if val > 0 then wd = "是" end
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.SubType % 32768
					local golden = math.floor(ent.SubType / 32768)
					local config = Isaac.GetItemConfig()
					local sz = config:GetTrinkets().Size
					
					if dir == 1 or dir == -1 then
						golden = 1 - golden
						if config:GetTrinket(val) then
							local anima
							ent.SubType = val + golden * 32768
							local Animation = s:GetAnimation()
							local frame = s:GetFrame()
							ent:Morph(ent.Type,ent.Variant,ent.SubType,true,true,true)
							ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ALL
							s:SetFrame(Animation,frame)
							s:Play(Animation)
							return 0
						else
							return -1
						end
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 350 then return true end
					return false
				end,
			},
			[1] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知钥匙",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 30 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "钥匙",loadname = "gfx/005.031_key.anm2",},
					[2] = {name = "金钥匙",loadname = "gfx/005.032_golden key.anm2",},
					[3] = {name = "双钥匙",loadname = "gfx/005.033_keyring.anm2",},
					[4] = {name = "充能钥匙",loadname = "gfx/005.034_chargedkey.anm2",},
					[enums.Pickups.Glaze_key.SubType] = {name = "琉璃钥匙",id = 5,loadname = "gfx/glaze_key.anm2",},
				},
				tpmap = {
					[5] = enums.Pickups.Glaze_key.SubType,
				},
				mxn = 5,
			},
			[8] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知炸弹",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 40 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "炸弹",loadname = "gfx/005.041_bomb.anm2",},
					[2] = {name = "双炸弹",loadname = "gfx/005.042_double bomb.anm2",},
					[4] = {name = "金炸弹",id = 3,loadname = "gfx/005.043_golden bomb.anm2",},
					[7] = {name = "超大炸弹",id = 4,loadname = "gfx/005.047_giga bomb.anm2",},
					[enums.Pickups.Glaze_bomb.SubType] = {name = "琉璃炸弹",id = 5,loadname = "gfx/glaze_bomb.anm2",},
				},
				tpmap = {
					[3] = 4,
					[4] = 7,
					[5] = enums.Pickups.Glaze_bomb.SubType,
				},
				mxn = 5,
			},
			[9] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知福袋",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 69 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "福袋",loadname = "gfx/005.069_grabbag.anm2",},
					[2] = {name = "黑福袋",loadname = "gfx/005.069_black sack.anm2",},
					[enums.Pickups.Glaze_grabbag.SubType] = {name = "琉璃福袋",id = 3,loadname = "gfx/glaze_grabbag.anm2",},
				},
				tpmap = {
					[3] = enums.Pickups.Glaze_grabbag.SubType,
				},
				mxn = 3,
			},
			[10] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知电池",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 90 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "中电池",loadname = "gfx/005.090_littlebattery.anm2",},
					[2] = {name = "小电池",loadname = "gfx/005.090_microbattery.anm2",},
					[3] = {name = "大电池",loadname = "gfx/005.090_megabattery.anm2",},
					[4] = {name = "金电池",loadname = "gfx/005.090_golden battery.anm2",},
					[enums.Pickups.Glaze_battery.SubType] = {name = "琉璃电池",id = 5,loadname = "gfx/glaze_littlebattery.anm2",},
				},
				tpmap = {
					[5] = enums.Pickups.Glaze_battery.SubType,
				},
				mxn = 5,
			},
			[12] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "药丸颜色：",})
					local vr = ent.SubType % 2048
					local wd = (info.hearttype[vr] or {name = "未知药丸",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local vr = ent.SubType % 2048
					local large = math.floor(ent.SubType / 2048)
					local val = (info.hearttype[vr] or {id = 0,}).id or vr
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
					end
					if dir == 1 or dir == -1 then
						ent.SubType = val + large * 2048
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						local name = info.hearttype[val].loadname or ""
						if large and large > 0 then name = name .."horse " end
						name = name .. (info.hearttype[val].loadname2 or "")
						s:Load(name,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 70 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "蓝-蓝",loadname = "gfx/005.071_",loadname2 = "pill blue-blue.anm2",},
					[2] = {name = "白-蓝",loadname = "gfx/005.072_",loadname2 = "pill white-blue.anm2",},
					[3] = {name = "橙-橙",loadname = "gfx/005.073_",loadname2 = "pill orange-orange.anm2",},
					[4] = {name = "白-白",loadname = "gfx/005.074_",loadname2 = "pill white-white.anm2",},
					[5] = {name = "点-红",loadname = "gfx/005.075_",loadname2 = "pill dots-red.anm2",},
					[6] = {name = "粉-红",loadname = "gfx/005.076_",loadname2 = "pill pink-red.anm2",},
					[7] = {name = "蓝-深蓝",loadname = "gfx/005.077_",loadname2 = "pill blue-cadetblue.anm2",},
					[8] = {name = "黄-橙",loadname = "gfx/005.078_",loadname2 = "pill yellow-orange.anm2",},
					[9] = {name = "点-白",loadname = "gfx/005.079_",loadname2 = "pill dots-white.anm2",},
					[10] = {name = "白-天蓝",loadname = "gfx/005.080_",loadname2 = "pill white-azure.anm2",},
					[11] = {name = "黑-黄",loadname = "gfx/005.081_",loadname2 = "pill black-yellow.anm2",},
					[12] = {name = "白-黑",loadname = "gfx/005.082_",loadname2 = "pill white-black.anm2",},
					[13] = {name = "白-黄",loadname = "gfx/005.083_",loadname2 = "pill white-yellow.anm2",},
					[14] = {name = "金色",loadname = "gfx/005.084_",loadname2 = "pill gold-gold.anm2",},
				},
				tpmap = {
				},
				mxn = 14,
			},
			[11] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "药丸形态：",})
					local vr = math.floor(ent.SubType / 2048)
					local wd = "小"
					if vr and vr > 0 then wd = "大" end
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local vr = ent.SubType % 2048
					local large = math.floor(ent.SubType / 2048)
					local val = (info.hearttype[vr] or {id = 0,}).id or vr
					
					if dir == 1 or dir == -1 then
						large = 1 - large
						ent.SubType = val + large * 2048
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						local name = info.hearttype[val].loadname or ""
						if large and large > 0 then name = name .."horse " end
						name = name .. (info.hearttype[val].loadname2 or "")
						s:Load(name,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 70 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "蓝-蓝",loadname = "gfx/005.071_",loadname2 = "pill blue-blue.anm2",},
					[2] = {name = "白-蓝",loadname = "gfx/005.072_",loadname2 = "pill white-blue.anm2",},
					[3] = {name = "橙-橙",loadname = "gfx/005.073_",loadname2 = "pill orange-orange.anm2",},
					[4] = {name = "白-白",loadname = "gfx/005.074_",loadname2 = "pill white-white.anm2",},
					[5] = {name = "点-红",loadname = "gfx/005.075_",loadname2 = "pill dots-red.anm2",},
					[6] = {name = "粉-红",loadname = "gfx/005.076_",loadname2 = "pill pink-red.anm2",},
					[7] = {name = "蓝-深蓝",loadname = "gfx/005.077_",loadname2 = "pill blue-cadetblue.anm2",},
					[8] = {name = "黄-橙",loadname = "gfx/005.078_",loadname2 = "pill yellow-orange.anm2",},
					[9] = {name = "点-白",loadname = "gfx/005.079_",loadname2 = "pill dots-white.anm2",},
					[10] = {name = "白-天蓝",loadname = "gfx/005.080_",loadname2 = "pill white-azure.anm2",},
					[11] = {name = "黑-黄",loadname = "gfx/005.081_",loadname2 = "pill black-yellow.anm2",},
					[12] = {name = "白-黑",loadname = "gfx/005.082_",loadname2 = "pill white-black.anm2",},
					[13] = {name = "白-黄",loadname = "gfx/005.083_",loadname2 = "pill white-yellow.anm2",},
					[14] = {name = "金色",loadname = "gfx/005.084_",loadname2 = "pill gold-gold.anm2",},
				},
				tpmap = {
				},
				mxn = 14,
			},
			[13] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.SubType
					local wd = (info.hearttype[vr] or {name = "未知便便",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.SubType]
					local val = (info.hearttype[ent.SubType] or {id = 0,}).id or ent.SubType
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.SubType = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 42 then 
						return true
					end
					return false
				end,
				hearttype = {
					[0] = {name = "小便便",id = 1,loadname = "gfx/005.042_poop nugget.anm2",},
					[1] = {name = "大便便",id = 2,loadname = "gfx/005.042_big poop nugget.anm2",},
					[enums.Pickups.Glaze_big_poop.SubType] = {name = "琉璃便便",id = 3,loadname = "gfx/glaze_big poop nugget.anm2",},
				},
				tpmap = {
					[1] = 0,
					[2] = 1,
					[3] = enums.Pickups.Glaze_big_poop.SubType,
				},
				mxn = 3,
			},
			[14] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = info.mindtype(ent)
					local wd = (info.hearttype[vr] or {name = "未知硬币",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local vr = info.mindtype(ent)
					local val = (info.hearttype[vr] or {id = 0,}).id or vr
					local vval = info.tpmap[val] or val
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
					end
					if dir == 1 or dir == -1 then
						if (info.hearttype[vval].special_toturn) then
							info.hearttype[vval].special_toturn(ent,false)
						end
						if (info.hearttype[val].special_toturn) then
							info.hearttype[val].special_toturn(ent,true)
						else
							ent.SubType = val
						end
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 20 then 
						return true
					end
					return false
				end,
				hearttype = {
					[1] = {name = "硬币",loadname = "gfx/005.021_penny.anm2",},
					[2] = {name = "5分币",loadname = "gfx/005.022_nickel.anm2",},
					[3] = {name = "10分币",loadname = "gfx/005.023_dime.anm2",},
					[4] = {name = "双币",loadname = "gfx/005.024_double penny.anm2",},
					[5] = {name = "幸运币",loadname = "gfx/005.026_lucky penny.anm2",},
					[6] = {name = "粘币",loadname = "gfx/005.025_sticky nickel.anm2",},
					[7] = {name = "金金币",loadname = "gfx/005.027_golden penny.anm2",},
					[8] = {name = "琉璃硬币",loadname = "gfx/glaze_coin.anm2",special_toturn = function(ent,inout)
						if inout == true then ent.SubType = 4 end
						auxi.special_turn(ent,enums.Pickups.Glaze_coin,inout)
					end,},
				},
				mindtype = function(ent)
					if ent.SubType == 4 and enums.Pickups.Glaze_coin.special_to_check(ent) then return 8 end
					return ent.SubType
				end,
				tpmap = {
				},
				mxn = 8,
			},
			[15] = {
				name = function(info,ent,choosed)
					ent = ent:ToPickup()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "卡牌编号：",})
					local vr = ent.SubType
					local wd = ({name = tostring(vr),} or {name = "未知卡牌",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToPickup()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local val = ent.SubType
					local config = Isaac.GetItemConfig()
					local sz = config:GetCards().Size
					
					if dir == 1 then 
						val = val + 1
						while((val < sz) and (config:GetCard(val) == nil or config:GetCard(val).Hidden)) do
							val = val + 1
						end
					elseif dir == -1 then
						val = val - 1
						while(val > 0 and val < sz and (config:GetCard(val) == nil or config:GetCard(val).Hidden)) do
							val = val - 1
						end
					elseif dir == 2 then
						val = val + 20
						while((val < sz) and (config:GetCard(val) == nil or config:GetCard(val).Hidden)) do
							val = val + 1
						end
					elseif dir == -2 then
						val = val - 20
						while(val > 0 and val < sz and (config:GetCard(val) == nil or config:GetCard(val).Hidden)) do
							val = val - 1
						end
					end
					if dir == 1 or dir == -1 or dir == 2 or dir == -2 then
						if config:GetCard(val) and val > 0 then
							ent.SubType = val
							local Animation = s:GetAnimation()
							local frame = s:GetFrame()
							ent:Morph(ent.Type,ent.Variant,ent.SubType,true,true,true)
							ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ALL
							s:SetFrame(Animation,frame)
							s:Play(Animation)
							return 0
						else
							return -1
						end
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToPickup()
					if ent.Variant == 300 then 
						return true
					end
					return false
				end,
				hearttype = {
				},
				tpmap = {
				},
				mxn = 14,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				if ent:ToPickup() == nil then return false end
				return true
			end,
		},
		[4] = {	--bomb
			[2] = {
				name = function(info,ent,choosed)
					ent = ent:ToBomb()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "爆炸伤害：",})
					local wd = tostring(math.floor(ent.ExplosionDamage * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToBomb()
					local d = ent:GetData()
					local dmg = ent.ExplosionDamage
					
					if dir == 1 then 
						ent.ExplosionDamage = math.max(dmg + 1,dmg * 1.05)
						return 0
					elseif dir == -1 then
						if ent.ExplosionDamage > 0.00001 then
							ent.ExplosionDamage = math.max(0,math.min(dmg - 1,dmg / 1.05))
						else
							return -1
						end
						return 0
					end
					return 1
				end,
			},
			[3] = {
				name = function(info,ent,choosed)
					ent = ent:ToBomb()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "爆炸范围：",})
					local wd = tostring(math.floor(ent.RadiusMultiplier * 100))
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToBomb()
					local d = ent:GetData()
					local val = ent.RadiusMultiplier
					
					if dir == 1 then 
						ent.RadiusMultiplier = math.max(val + 0.05,val * 1.05)
						return 0
					elseif dir == -1 then
						if ent.RadiusMultiplier > 0.10001 then
							ent.RadiusMultiplier = math.max(0.1,math.min(val - 0.05,val / 1.05))
						else
							return -1
						end
						return 0
					end
					return 1
				end,
			},
			[4] = {
				name = function(info,ent,choosed)
					ent = ent:ToBomb()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "碰撞伤害：",})
					local wd = tostring(math.floor(ent.CollisionDamage * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToBomb()
					local d = ent:GetData()
					local val = ent.CollisionDamage
					
					if dir == 1 then 
						ent.CollisionDamage = math.max(val + 1,val * 1.05)
						return 0
					elseif dir == -1 then
						if val > 0.10001 then
							ent.CollisionDamage = math.max(0,math.min(val - 1,val / 1.05))
						else
							return -1
						end
						return 0
					end
					return 1
				end,
			},
			[1] = {
				name = function(info,ent,choosed)
					ent = ent:ToBomb()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local vr = ent.Variant
					local wd = (info.hearttype[vr] or {name = "未知陆夫人",}).name
					
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToBomb()
					local d = ent:GetData()
					local s = ent:GetSprite()
					local heart = info.hearttype[ent.Variant]
					local val = (info.hearttype[ent.Variant] or {id = 0,}).id or ent.Variant
					
					if dir == 1 then 
						val = val % info.mxn + 1
						val = info.tpmap[val] or val
						ent.Variant = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 2) % info.mxn + 1
						val = info.tpmap[val] or val
						ent.Variant = val
						local Animation = s:GetAnimation()
						local frame = s:GetFrame()
						s:Load(info.hearttype[val].loadname,true)
						s:SetFrame(Animation,frame)
						s:Play(Animation)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					ent = ent:ToBomb()
					if info.hearttype[ent.Variant] ~= nil then 
						return true
					end
					return false
				end,
				hearttype = {
					[3] = {name = "陆夫人",id = 1,loadname = "gfx/004.003_troll bomb.anm2",},
					[4] = {name = "跟踪陆夫人",id = 2,loadname = "gfx/004.004_megatroll bomb.anm2",},
					[15] = {name = "硫磺地雷",id = 3,loadname = "gfx/004.015_brimstone bomb.anm2",},
					[16] = {name = "血泪炸弹",id = 4,loadname = "gfx/004.016_bloody sad bomb.anm2",},
					[18] = {name = "金色陆夫人",id = 5,loadname = "gfx/004.018_golden troll bomb.anm2",},
				},
				tpmap = {
					[1] = 3,
					[2] = 4,
					[3] = 15,
					[4] = 16,
					[5] = 18,
				},
				mxn = 5,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				if ent:ToBomb() == nil then return false end
				return true
			end,
		},
		[5] = {	--slot
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				if ent.Type == 6 then return true end
				return false
			end,
		},
		[6] = {	--familiar
			[1] = {
				name = function(info,ent,choosed)
					ent = ent:ToFamiliar()
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "碰撞伤害：",})
					local wd = tostring(math.floor(ent.CollisionDamage * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					ent = ent:ToFamiliar()
					local d = ent:GetData()
					local val = ent.CollisionDamage
					
					if dir == 1 then 
						ent.CollisionDamage = math.max(val + 1,val * 1.05)
						return 0
					elseif dir == -1 then
						if val > 0.10001 then
							ent.CollisionDamage = math.max(0,math.min(val - 1,val / 1.05))
						else
							return -1
						end
						return 0
					end
					return 1
				end,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return false end
				if ent:ToFamiliar() then return true end
				return false
			end,
		},
		[8] = {	--grid
			[10] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "是地形！",})
					local wd = tostring(ent:get_grid():GetType())
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					--print(grid.State.." "..grid.Desc.VarData.." "..grid.Desc.State.." "..grid:GetSprite():GetAnimation())
					return 1
				end,
			},
			[1] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "大小：",})
					local d = ent:GetData()
					d.saga_modifier_size_vr = d.saga_modifier_size_vr or 1
					local vr = d.saga_modifier_size_vr
					
					local offset = Vector(0,0)
					local wd1 = tostring(math.floor(ent:GetSprite().Scale.X * 100)/100)
					if choosed and vr == 2 then wd1 = "<="..wd1.."=>" offset = offset + Vector(-5,0) end
					local wd2 = tostring(math.floor(ent:GetSprite().Scale.Y * 100)/100)
					if choosed and vr == 3 then wd2 = "<="..wd2.."=>" offset = offset + Vector(-5,0) end
					local wd = wd1.."X"..wd2
					if choosed and vr == 1 then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local succc = ent:GetData().saga_modifier_sprite_size
					local succc2 = ent:GetData().saga_modifier_size
					local spritesize = ent:GetSprite().Scale
					if dir == 1 then 
						if d.saga_modifier_size_vr == 1 then
							spritesize = spritesize * 1.05
						elseif d.saga_modifier_size_vr == 2 then
							spritesize = Vector(spritesize.X * 1.05,spritesize.Y)
						elseif d.saga_modifier_size_vr == 3 then
							spritesize = Vector(spritesize.X,spritesize.Y * 1.05)
						end
						ent:GetSprite().Scale = spritesize
						return 0
					elseif dir == -1 then
						if d.saga_modifier_size_vr == 1 then
							if spritesize.X - 0.00001 > 0.2 and spritesize.Y - 0.00001 > 0.2 then
								spritesize = math.max(math.min(0.2 * math.sqrt(2),spritesize:Length()),spritesize:Length() / 1.05) * spritesize:Normalized()
							else
								return -1
							end
						elseif d.saga_modifier_size_vr == 2 then
							if spritesize.X - 0.00001 > 0.2 then
								spritesize = Vector(math.max(math.min(0.2,spritesize.X),spritesize.X / 1.05),spritesize.Y)
							else
								return -1
							end
						elseif d.saga_modifier_size_vr == 3 then
							if spritesize.Y - 0.00001 > 0.2 then
								spritesize = Vector(spritesize.X,math.max(math.min(0.2,spritesize.Y),spritesize.Y / 1.05))
							else
								return -1
							end
						end
						ent:GetSprite().Scale = spritesize
						return 0
					elseif dir == 2 then
						d.saga_modifier_size_vr = d.saga_modifier_size_vr % 3 + 1
						return 0
					elseif dir == -2 then
						d.saga_modifier_size_vr = (d.saga_modifier_size_vr + 3 - 2) % 3 + 1
						return 0
					end
					return 1
				end,
			},
			[2] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "颜色：",})
					local d = ent:GetData()
					d.saga_modifier_color_vr = d.saga_modifier_color_vr or 1
					local vr = d.saga_modifier_color_vr
					for i = 1,7 do
						local wd = info.colormap[i]..":"..tostring(math.floor((ent:GetSprite().Color[info.colormap[i]]) * 255))
						local offset = Vector(0,0)
						if choosed and vr == i then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
						table.insert(ret,#ret + 1,{wd = wd,offset = offset,col = auxi.AddColor(info.colorsmap[i],Color(0.5,0.5,0.5,1),ent:GetSprite().Color[info.colormap[i]],1-ent:GetSprite().Color[info.colormap[i]]),})
					end
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					d.saga_modifier_color_vr = d.saga_modifier_color_vr or 1
					local col = auxi.AddColor(ent:GetSprite().Color,Color(0,0,0,0),1,0)
					local succc = ent:GetData().saga_modifier_color
					
					if dir == 1 then
						col[info.colormap[d.saga_modifier_color_vr]] = col[info.colormap[d.saga_modifier_color_vr]] + 5/255
						local succ = Attribute_holder.try_hold_attribute(ent,"Color",col,{toget = function(ent) return ent:GetSprite().Color end,tochange = function(ent,value) ent:GetSprite().Color = value end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"Color",succc,{toget = function(ent) return ent:GetSprite().Color end,tochange = function(ent,value) ent:GetSprite().Color = value end,}) end
						d.saga_modifier_color = succ
						return 0
					elseif dir == -1 then
						col[info.colormap[d.saga_modifier_color_vr]] = col[info.colormap[d.saga_modifier_color_vr]] - 5/255
						local succ = Attribute_holder.try_hold_attribute(ent,"Color",col,{toget = function(ent) return ent:GetSprite().Color end,tochange = function(ent,value) ent:GetSprite().Color = value end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"Color",succc,{toget = function(ent) return ent:GetSprite().Color end,tochange = function(ent,value) ent:GetSprite().Color = value end,}) end
						d.saga_modifier_color = succ
						return 0
					elseif dir == 2 then
						d.saga_modifier_color_vr = d.saga_modifier_color_vr % 7 + 1
						return 0
					elseif dir == -2 then
						d.saga_modifier_color_vr = (d.saga_modifier_color_vr + 7 - 2) % 7 + 1
						return 0
					end
					return 1
				end,
				colormap = {
					[1] = "R",
					[2] = "G",
					[3] = "B",
					[4] = "A",
					[5] = "RO",
					[6] = "GO",
					[7] = "BO",
				},
				colorsmap = {
					[1] = Color(1,0,0,1),
					[2] = Color(0,1,0,1),
					[3] = Color(0,0,1,1),
					[4] = Color(1,1,1,0.5),
					[5] = Color(1,0.5,0.5,1),
					[6] = Color(0.5,1,0.5,1),
					[7] = Color(0.5,0.5,1,1),
				},
			},
			[3] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "旋转角：",})
					local wd = tostring(math.floor(ent:GetSprite().Rotation * 100)/100)
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					local val = ent:GetSprite().Rotation
					
					if dir == 1 then 
						val = val + 5
						ent:GetSprite().Rotation = val
						return 0
					elseif dir == -1 then
						val = val - 5
						ent:GetSprite().Rotation = val
						return 0
					end
					return 1
				end,
			},
			[4] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "碰撞类型：",})
					local wd = info.collisionmap[ent:get_grid().CollisionClass] or "？"
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local d = ent:GetData()
					--print(ent:get_grid().CollisionClass)
					Attribute_holder.assign_attribute()
					--print(ent:get_grid().CollisionClass)
					local val = ent:get_grid().CollisionClass
					local succc = d.saga_modifier_collisionclass
					local vval = val
					
					if dir == 1 then 
						val = (val + 1) % info.mxn
						local succ = Attribute_holder.try_hold_attribute(ent,"CollisionClass",val,{toget = function(ent) return ent:get_grid().CollisionClass end,tochange = function(ent,value) ent:get_grid().CollisionClass = value end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"CollisionClass",succc,{toget = function(ent) return ent:get_grid().CollisionClass end,tochange = function(ent,value) ent:get_grid().CollisionClass = value end,}) end
						d.saga_modifier_collisionclass = succ
						return 0
					elseif dir == -1 then
						val = (val + info.mxn - 1) % info.mxn
						local succ = Attribute_holder.try_hold_attribute(ent,"CollisionClass",val,{toget = function(ent) return ent:get_grid().CollisionClass end,tochange = function(ent,value) ent:get_grid().CollisionClass = value end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"CollisionClass",succc,{toget = function(ent) return ent:get_grid().CollisionClass end,tochange = function(ent,value) ent:get_grid().CollisionClass = value end,}) end
						d.saga_modifier_collisionclass = succ
						return 0
					end
					return 1
				end,
				collisionmap = {
					[GridCollisionClass.COLLISION_NONE] = "与世无争",
					[GridCollisionClass.COLLISION_PIT] = "陷坑",
					[GridCollisionClass.COLLISION_OBJECT] = "实物",
					[GridCollisionClass.COLLISION_SOLID] = "固体",
					[GridCollisionClass.COLLISION_WALL] = "墙",
					[GridCollisionClass.COLLISION_WALL_EXCEPT_PLAYER] = "可通行墙",
				},
				mxn = 6,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return true end
				return false
			end,
		},
		[7] = {	--grid
			[1] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "类型：",})
					local desc = info.hearttype[ent:get_grid():GetVariant()]
					local wd = desc.name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local val = ent:get_grid():GetVariant()
					local vval = val
					local s = ent:get_grid():GetSprite()
					
					if dir == 1 then 
						val = (val + 1) % info.mxn
					elseif dir == -1 then
						val = (val + info.mxn - 1) % info.mxn
					end
					if dir == 1 or dir == -1 then
						ent:get_grid():SetVariant(val)
						local desc = info.hearttype[val]
						if info.hearttype[vval].special_toturn then info.hearttype[vval].special_toturn(ent,false) end
						if (desc.special_toturn) then desc.special_toturn(ent,true) end
						s:ReplaceSpritesheet(0,auxi.random_in_table(desc.pngname))
						s:LoadGraphics()
						ent:get_grid():Init(ent:get_grid().Desc.SpawnSeed)
						ent:get_grid():PostInit()
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					if ent:get_grid():ToPoop() then return true end
					return false
				end,
				hearttype = {
					[0] = {name = "便便",id = 1,pngname = {"gfx/grid/grid_poop_1.png","gfx/grid/grid_poop_2.png","gfx/grid/grid_poop_3.png",},},
					[1] = {name = "红便便",id = 2,pngname = {"gfx/grid/grid_poop_red_1.png","gfx/grid/grid_poop_red_2.png","gfx/grid/grid_poop_red_3.png",},},
					[2] = {name = "棕便便",id = 3,pngname = "gfx/grid/grid_poop_corn.png",},
					[3] = {name = "金便便",id = 4,pngname = "gfx/grid/grid_poop_gold.png",},
					[4] = {name = "彩虹便便",id = 5,pngname = "gfx/grid/grid_poop_rainbow.png",},
					[5] = {name = "黑便便",id = 6,pngname = "gfx/grid/grid_poop_black.png",},
					[6] = {name = "神圣便便",id = 7,pngname = {"gfx/grid/grid_poop_white_1.png","gfx/grid/grid_poop_white_2.png","gfx/grid/grid_poop_white_3.png",},},
				},
				mxn = 7,
			},
			[2] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "状态：",})
					local desc = info.statemap[ent:GetSprite():GetAnimation()]
					local wd = desc.name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local desc = info.statemap[ent:GetSprite():GetAnimation()]
					local val = desc.id
					local vval = val
					local s = ent:get_grid():GetSprite()
					
					if dir == 1 then 
						val = val + 1
						if val > info.mxn then return -1 end
					elseif dir == -1 then
						val = val - 1
						if val < 1 then return -1 end
					end
					if dir == 1 or dir == -1 then
						--print(ent:get_grid().State.." "..ent:get_grid().Desc.VarData.." "..ent:get_grid().Desc.State)
						ent:get_grid().State = (val - 1) * 250
						ent:get_grid().Desc.State = ent:get_grid().State
						if val == info.mxn or vval == info.mxn then 
							ent:get_grid():Init(ent:get_grid().Desc.SpawnSeed)
							ent:get_grid():PostInit()
						end
						s:Play(info.tpmap[val].name,true)
						return 0
					end
					return 1
				end,
				check = function(info,ent)
					if ent:get_grid():ToPoop() then return true end
					return false
				end,
				statemap = {
					["Appear"] = {name = "出现",id = 0,},
					["State1"] = {name = "完好",id = 1,},
					["State2"] = {name = "小破",id = 2,},
					["State3"] = {name = "半破",id = 3,},
					["State4"] = {name = "大破",id = 4,},
					["State5"] = {name = "毁坏",id = 5,},
				},
				tpmap = {
					[0] = {name = "Appear",},
					[1] = {name = "State1",},
					[2] = {name = "State2",},
					[3] = {name = "State3",},
					[4] = {name = "State4",},
					[5] = {name = "State5",},
				},
				mxn = 5,
			},
			[3] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "状态：",})
					local desc = info.state_check(info,ent:get_grid())
					local wd = tostring(info.statemap[desc] or "")
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = info.state_check(info,grid)
					local succc = ent:GetData().saga_modifier_door_open
					--print(ent:get_grid().State.." "..ent:get_grid().Desc.VarData.." "..ent:get_grid().Desc.State)
					if dir == 1 then 
						if desc == 1 then return -1 end
						desc = 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = 0
					end
					if dir == 1 or dir == -1 then
						if desc == 1 then
							if grid:CanBlowOpen() then grid:TryBlowOpen(false,nil) end
							grid:TryUnlock(Game():GetPlayer(0),true)
							local succ = Attribute_holder.try_hold_attribute(ent,"Door_Open",true,{toget = function(ent) return ent:get_grid():IsOpen() end,tochange = function(ent,val) if val == true then ent:get_grid():Open() else ent:get_grid():GetSprite():Play("Close",true) ent:get_grid():GetSprite():SetLastFrame() ent:get_grid():Close() end end,})
							if succc then Attribute_holder.try_rewind_attribute(ent,"Door_Open",succc,{toget = function(ent) return ent:get_grid():IsOpen() end,tochange = function(ent,val) if val == true then ent:get_grid():Open() else ent:get_grid():GetSprite():Play("Close",true) ent:get_grid():GetSprite():SetLastFrame() ent:get_grid():Close() end end,}) end
							ent:GetData().saga_modifier_door_open = succ
						else
							local succ = Attribute_holder.try_hold_attribute(ent,"Door_Open",false,{toget = function(ent) return ent:get_grid():IsOpen() end,tochange = function(ent,val) if val == true then ent:get_grid():Open() else ent:get_grid():GetSprite():Play("Close",true) ent:get_grid():GetSprite():SetLastFrame() ent:get_grid():Close() end end,})
							if succc then Attribute_holder.try_rewind_attribute(ent,"Door_Open",succc,{toget = function(ent) return ent:get_grid():IsOpen() end,tochange = function(ent,val) if val == true then ent:get_grid():Open() else ent:get_grid():GetSprite():Play("Close",true) ent:get_grid():GetSprite():SetLastFrame() ent:get_grid():Close() end end,}) end
							ent:GetData().saga_modifier_door_open = succ
						end
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = "关闭",
					[1] = "开启",
				},
				check = function(info,ent)
					if ent:get_grid():ToDoor() then return true end
					return false
				end,
				state_check = function(info,grid)
					local ret = 0
					if grid:IsOpen() then ret = ret | 1 end
					return ret
				end,
			},
			[4] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "梯子：",})
					local desc = tostring(ent:get_grid().HasLadder)
					local wd = tostring(info.statemap[desc] or "")
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().HasLadder
					--print(ent:get_grid().State.." "..ent:get_grid().Desc.VarData.." "..ent:get_grid().Desc.State)
					if dir == 1 then 
						if desc == true then return -1 end
						desc = true
					elseif dir == -1 then
						if desc == false then return -1 end
						desc = false
					end
					if dir == 1 or dir == -1 then
						if desc then 
							ent:get_grid():SetLadder(true)
							local q = Isaac.Spawn(1000,8,0,ent:get_grid().Position,Vector(0,0),nil)
							ent:GetData().Ladder = q
						else
							if ent:GetData().Ladder and ent:GetData().Ladder:Exists() then
								ent:GetData().Ladder:Remove()
								ent:GetData().Ladder = nil
							end
						end
						ent:get_grid().HasLadder = desc
						return 0
					end
					return 1
				end,
				statemap = {
					["true"] = "有",
					["false"] = "无",
				},
				check = function(info,ent)
					if ent:get_grid():ToPit() then return true end
					return false
				end,
			},
			[5] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "按钮状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					--print(grid.State.." "..grid.Desc.VarData.." "..grid.Desc.State.." "..grid.NextGreedAnimation.." "..grid:GetSprite():GetAnimation())
					if dir == 1 then 
						if desc == 3 then return -1 end
						desc = 3
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = 0
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						grid:GetSprite():Play(descinfo.playname,true)
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "未按下",playname = "Off",},
					[1] = {name = "未知",},
					[2] = {name = "未知",},
					[3] = {name = "已按下",playname = "On",},
				},
				mxn = 4,
				check = function(info,ent)
					if ent:get_grid():ToPressurePlate() and ent:get_grid().NextGreedAnimation == "" then return true end
					return false
				end,
			},
			[6] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "TNT状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					--print(grid.State.." "..grid.Desc.VarData.." "..grid.Desc.State.." "..grid:GetSprite():GetAnimation().." "..grid.FrameCnt)
					if dir == 1 then 
						if desc == 4 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						if desc < 4 then grid.FrameCnt = 3 end
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "正常",playname = "Idle",},
					[1] = {name = "小破",playname = "Idle",},
					[2] = {name = "膨胀",playname = "IdleMedium",},
					[3] = {name = "即将引爆",playname = "ReadyToExplode",},
					[4] = {name = "已引爆",playname = "Blown",},
				},
				mxn = 5,
				check = function(info,ent)
					if ent:get_grid():ToTNT() then return true end
					return false
				end,
			},
			[7] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "锁状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					if dir == 1 then 
						if desc == info.mxn - 1 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						grid:GetSprite():Play(descinfo.playname,true)
						grid.CollisionClass = descinfo.collision
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "未开启",playname = "Idle",collision = GridCollisionClass.COLLISION_WALL,},
					[1] = {name = "开启",playname = "Broken",collision = GridCollisionClass.COLLISION_NONE,},
				},
				mxn = 2,
				check = function(info,ent)
					if ent:get_grid():GetType() == 11 then return true end
					return false
				end,
			},
			[8] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "下层通道状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					local succc = ent:GetData().saga_modifier_trap_door_open
					local succc2 = ent:GetData().saga_modifier_trap_door_open_sprite
					
					if dir == 1 then 
						if desc == info.mxn - 1 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						grid:GetSprite():Play(descinfo.playname,true)
						local succ = Attribute_holder.try_hold_attribute(ent,"Trap_Open",desc,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"Trap_Open",succc,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,}) end
						ent:GetData().saga_modifier_trap_door_open = succ
						local succ2 = Attribute_holder.try_hold_attribute(ent,"Trap_Open_Sprite",descinfo.playname,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,})
						if succc2 then Attribute_holder.try_rewind_attribute(ent,"Trap_Open_Sprite",succc2,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,}) end
						ent:GetData().saga_modifier_trap_door_open_sprite = succ2
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "关闭",playname = "Closed",},
					[1] = {name = "开启",playname = "Opened",},
				},
				mxn = 2,
				check = function(info,ent)
					if ent:get_grid():GetType() == 17 then return true end
					return false
				end,
			},
			[9] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "地下室通道状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					local succc = ent:GetData().saga_modifier_trap_door_open
					local succc2 = ent:GetData().saga_modifier_trap_door_open_sprite
					
					if dir == 1 then 
						if desc == info.mxn - 1 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						grid:GetSprite():Play(descinfo.playname,true)
						local succ = Attribute_holder.try_hold_attribute(ent,"Trap_Open",desc,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"Trap_Open",succc,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,}) end
						ent:GetData().saga_modifier_trap_door_open = succ
						local succ2 = Attribute_holder.try_hold_attribute(ent,"Trap_Open_Sprite",descinfo.playname,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,})
						if succc2 then Attribute_holder.try_rewind_attribute(ent,"Trap_Open_Sprite",succc2,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,}) end
						ent:GetData().saga_modifier_trap_door_open_sprite = succ2
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "关闭",playname = "Closed",},
					[1] = {name = "开启",playname = "Opened",},
				},
				mxn = 2,
				check = function(info,ent)
					if ent:get_grid():GetType() == 18 then return true end
					return false
				end,
			},
			[10] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "蛛网状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[grid.State] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = ent:get_grid().State
					if dir == 1 then 
						if desc == info.mxn - 1 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						grid.State = desc
						grid.Desc.State = desc
						local descinfo = info.statemap[desc]
						grid:GetSprite():Play(descinfo.playname,true)
						return 0
					end
					return 1
				end,
				statemap = {
					[0] = {name = "正常",playname = "Idle",},
					[1] = {name = "损坏",playname = "Bombed",},
				},
				mxn = 2,
				check = function(info,ent)
					if ent:get_grid():GetType() == 10 then return true end
					return false
				end,
			},
			[11] = {
				name = function(info,ent,choosed)
					local ret = {}
					table.insert(ret,#ret + 1,{wd = "刺状态：",})
					local grid = ent:get_grid()
					local wd = (info.statemap[info.tpmap[grid.State]] or {name = "",}).name
					local offset = Vector(0,0)
					if choosed then wd = "<="..wd.."=>" offset = offset + Vector(-5,0) end
					table.insert(ret,#ret + 1,{wd = wd,offset = offset,})
					return ret
				end,
				move = function(info,ent,dir)
					local grid = ent:get_grid()
					local desc = info.tpmap[grid.State]
					local succc = ent:GetData().saga_modifier_spike_open
					local succc2 = ent:GetData().saga_modifier_spike_open_sprite
					
					if dir == 1 then 
						if desc == info.mxn - 1 then return -1 end
						desc = desc + 1
					elseif dir == -1 then
						if desc == 0 then return -1 end
						desc = desc - 1
					end
					if dir == 1 or dir == -1 then
						local descinfo = info.statemap[desc]
						local str = grid:GetSprite():GetAnimation()
						local playname = descinfo.playname
						if string.find(str,"Womb") then playname = playname.."Womb" end
						grid:GetSprite():Play(playname,true)
						local succ = Attribute_holder.try_hold_attribute(ent,"Spike_Open",descinfo.id,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,})
						if succc then Attribute_holder.try_rewind_attribute(ent,"Spike_Open",succc,{toget = function(ent) return ent:get_grid().State end,tochange = function(ent,val) ent:get_grid().Desc.State = val ent:get_grid().State = val end,}) end
						ent:GetData().saga_modifier_spike_open = succ
						local succ2 = Attribute_holder.try_hold_attribute(ent,"Spike_Open_Sprite",playname,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,})
						if succc2 then Attribute_holder.try_rewind_attribute(ent,"Spike_Open_Sprite",succc2,{toget = function(ent) return ent:get_grid():GetSprite():GetAnimation() end,tochange = function(ent,val) ent:get_grid():GetSprite():Play(val,true) ent:get_grid():GetSprite():SetLastFrame() end,}) end
						ent:GetData().saga_modifier_spike_open_sprite = succ2
						return 0
					end
					return 1
				end,
				statemap = {
					[1] = {name = "探出",id = 0,playname = "Summon",},
					[0] = {name = "缩回",id = 1,playname = "Unsummon",},
				},
				tpmap = {
					[1] = 0,
					[0] = 1,
				},
				mxn = 2,
				check = function(info,ent)
					if ent:get_grid():ToSpikes() then return true end
					return false
				end,
			},
			check = function(info,ent)
				if ent.IsGrid ~= nil then return true end
				return false
			end,
		},
	},
	eventlist = {
		"Explosion",
		"Shoot",
		"Jump",
		"Land",
		"BloodStart",
		"BloodStop",
		--"Heartbeat",
		"Lift",
		"Stop",
		"Slide",
		"Spawn",
		"Shoot2",
		"DeathSound",
		"DropSound",
		"Disappear",
		"Prize",
		--"Shuffle",
		--"CoinInsert",
	},
	color_offset = {
		[0] = Color(1,1,1,1,1,1,1),
		[1] = Color(1,1,1,0.7,1,1,1),
		[2] = Color(1,1,1,0.5,1,1,1),
		[3] = Color(1,1,1,0.4,1,1,1),
		[4] = Color(1,1,1,0.3,1,1,1),
		[5] = Color(1,1,1,0.2,1,1,1),
		[6] = Color(1,1,1,0.1,1,1,1),
	},
	type_priority = {
		[EntityType.ENTITY_BOMB] = -2,
		[EntityType.ENTITY_SLOT] = 2,
		[EntityType.ENTITY_PICKUP] = 3,
		[EntityType.ENTITY_FAMILIAR] = 4,
	},
}

local function check_screen_size(v)
	local screensize = ui.GetScreenSize()
	while(screensize.X > 256) do 
		screensize.X = screensize.X / 2 
		v.X = v.X / 2
	end
	while(screensize.Y > 256) do 
		screensize.Y = screensize.Y / 2 
		v.Y = v.Y / 2
	end
	return v
end

local function check_screen_multi(v)
	local screensize = ui.GetScreenSize()
	while(screensize.X > 256) do 
		screensize.X = screensize.X / 2 
		v.X = v.X * 2
	end
	while(screensize.Y > 256) do 
		screensize.Y = screensize.Y / 2 
		v.Y = v.Y * 2
	end
	return v
end
	
local function get_screensize_multi()
	local ret = 4
	local screensize = ui.GetScreenSize()
	while(screensize.X > 256) do 
		screensize.X = screensize.X / 2 
		ret = ret / 2
	end 
	return ret
end
--l local q = Isaac.Spawn(5,40,1,Vector(200,200),Vector(0,0),nil) q.SubType = 2
local function get_type_priority(ent)
	local ret = item.type_priority[ent.Type] or 0
	return ret
end

local function get_color_offset(idx)
	if item.color_offset[idx] then return item.color_offset[idx]
	else return item.color_offset[#item.color_offset] end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	if coltyp == item.entity then
		local d = player:GetData()
		if d.is_holding_S_Q_item ~= true then
			player:AnimateCollectible(item.entity,"LiftItem","PlayerPickup")
			d.is_holding_S_Q_item = true
		else
			player:AnimateCollectible(item.entity,"HideItem","PlayerPickup")
			d.is_holding_S_Q_item = false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	item.targ = nil
	item.render_sprite_pos = nil
end,
})

local function try_find_target(pos,dir)
	local n_entity = Isaac.GetRoomEntities()
	local ret = nil
	local dis = -1
	for u,v in pairs(n_entity) do
		if (v.Position - (pos + dir)):Length() < 50 and (ret == nil or (v.Position - (pos + dir)):Length() < dis) then
			dis = (v.Position - (pos + dir)):Length()
			ret = v
		end
	end
	return ret
end

local function makelist(ent)
	local d = ent:GetData()
	d.saga_list = {}
	local idx = 1
	for k = 1,#(item.changeable_state) do
		local v = item.changeable_state[k]
		if v.check == nil or v.check(v,ent) == true then
			for i = 1,#(v) do
				if v[i].check == nil or v[i].check(v[i],ent) == true then
					d.saga_list[idx] = {tp = k,vr = i,}
					idx = idx + 1
				end
			end
		end
	end
	d.saga_now_tp_id = math.max(1,math.min(idx - 1,d.saga_now_tp_id or 1))
	d.saga_mx_tp = idx - 1
end

local function get_safe_name(ent,name)
	local ret = ent[name]
	if type(ret) == "function" then ret = ret(ent) end
	return ret
end

local function get_saga_grid_info(pos,dir)
	local ret = {}
	dir = dir or 120
	if dir < 0 then dir = - dir end
	if pos ~= nil then
		dir = math.ceil(dir/40)
		local room = Game():GetRoom()
		local orig_idx = room:GetGridIndex(pos)
		local orig_pos = room:GetGridPosition(orig_idx)
		local dx = 1
		local dy = room:GetGridIndex(orig_pos + Vector(0,40)) - orig_idx
		local lr = orig_idx - dx * dir - dy * dir
		for i = 1,dir * 2 do
			for j = 1,dir * 2 do
				local grididx = lr + dx * (i - 1) + dy * (j - 1)
				if grididx >= 0 then
					local grid = room:GetGridEntity(grididx)
					if grid and item.grid_filter[grid:GetType()] == nil then
						table.insert(ret,{grid = grid,idx = grididx,})
					end
				end
			end
		end
	end
	return ret
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local ctrlid = player.ControllerIndex
	local d = player:GetData()
	local room = Game():GetRoom()
	if d.is_holding_S_Q_item == true then
		if player:IsHoldingItem() == false then
			d.is_holding_S_Q_item = false
		else
			local dir = 0
			for i = 4,7 do
				if (Input.IsActionPressed(i,ctrlid) and input_holder.actionsData[tostring(ctrlid)] and input_holder.actionsData[tostring(ctrlid)][i] and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime == 1) then
					dir = i
				end
			end
			if dir > 0 then
				local vel = Vector(0,0)
				if room:IsMirrorWorld() == true and (dir == 4 or dir == 5) then dir = 9 - dir end
				if dir == 4 then vel = vel + Vector(-1,0)
				elseif dir == 5 then vel = vel + Vector(1,0)
				elseif dir == 6 then vel = vel + Vector(0,-1)
				elseif dir == 7 then vel = vel + Vector(0,1) end
				local vel_adder = player.Velocity
				if vel_adder:Length() < 0.3 then 
					vel_adder = Vector(0,0) 
				else
					vel_adder = vel_adder:Normalized()
				end
				vel = (vel:Normalized() * 2 + vel_adder):Normalized()
				player:AnimateCollectible(item.entity,"HideItem","PlayerPickup")
				d.is_holding_S_Q_item = false
				local q = auxi.fire_dowhatknife(nil,player.Position + player.Velocity,vel/1000,0,"AttackUp","AttackUp2",{source = nil,cooldown = 8,player = player,list = {saga = 1,},saga = true,no_repel = true,no_open = true,no_grid = true,})
				d.Saga_should_flip = 1 - (d.Saga_should_flip or 0)
			end
		end
	end
	if selection_holder.check_select(player,"Squiresaga") and Game():IsPaused() == false and item.targ ~= nil and item.now_display_rm * 20 > 0.5 then
		if (Input.IsActionTriggered(11,ctrlid) or Input.IsActionPressed(11,ctrlid)) then
			item.should_remove_targ = true
		end
		local dir = nil
		for u,i in pairs({4,5,6,7,9,10,13}) do
			if (Input.IsActionTriggered(i,ctrlid) or Input.IsActionPressed(i,ctrlid)) then
				dir = i
			end
		end
		local should_count = false
		if dir then
			if dir == item.last_open_dir then
				item.last_open_dir_counter = (item.last_open_dir_counter or 0) + 1
				if item.last_open_dir_counter > item.dir_time_limit and item.last_open_dir_counter % 8 == 1 then
					should_count = true
				end
			else
				item.last_open_dir_counter = 0
				should_count = true
			end
		end
		item.last_open_dir = dir
		if should_count then
			local d = item.targ:GetData()
			if d.saga_list == nil then makelist(item.targ) end
			d.saga_now_tp_id = d.saga_now_tp_id or 1
			local info = item.changeable_state[d.saga_list[d.saga_now_tp_id].tp][d.saga_list[d.saga_now_tp_id].vr]
			if dir == 4 then
				local succ = info.move(info,item.targ,-1)
				if succ == 0 then sound_tracker.PlayStackedSound(195,1,1,false,0,2)
				elseif succ == -1 then sound_tracker.PlayStackedSound(187,1,1,false,0,2) end
			elseif dir == 5 then
				local succ = info.move(info,item.targ,1)
				if succ == 0 then sound_tracker.PlayStackedSound(194,1,1,false,0,2)
				elseif succ == -1 then sound_tracker.PlayStackedSound(187,1,1,false,0,2) end
			elseif dir == 6 then
				local succ = info.move(info,item.targ,-3)
				if succ == 1 then
					if d.saga_now_tp_id == 1 then
						d.saga_now_tp_id = d.saga_mx_tp
					else
						d.saga_now_tp_id = d.saga_now_tp_id - 1
					end
					sound_tracker.PlayStackedSound(195,0.8,1,false,0,2)
				end
			elseif dir == 7 then
				local succ = info.move(info,item.targ,3)
				if succ == 1 then
					if d.saga_now_tp_id == d.saga_mx_tp then
						d.saga_now_tp_id = 1
					else
						d.saga_now_tp_id = d.saga_now_tp_id + 1
					end
					sound_tracker.PlayStackedSound(194,0.8,1,false,0,2)
				end
			elseif dir == 13 then
				local succ = info.move(info,item.targ,2)
				if succ == 0 then sound_tracker.PlayStackedSound(195,1,1.05,false,0,2)
				elseif succ == -1 then sound_tracker.PlayStackedSound(187,1,1,false,0,2) end
			elseif dir == 10 then
				local succ = info.move(info,item.targ,-2)
				if succ == 0 then sound_tracker.PlayStackedSound(194,1,0.95,false,0,2)
				elseif succ == -1 then sound_tracker.PlayStackedSound(187,1,1,false,0,2) end
			elseif dir == 9 then
				info.move(info,item.targ,0)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_KNIFE_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if ent.Variant == enums.Entities.StabberKnife then
		if d.params and d.params.saga then
			if (s:IsPlaying("AttackUp") and s:IsFinished("AttackUp") == false) or (s:IsPlaying("AttackUp2") and s:IsFinished("AttackUp2") == false) then
				if d.inner_frame == 6 then
					if item.targ == nil then
						local n_entity = Isaac.GetRoomEntities()
						local player = Game():GetPlayer(0)
						if d.player then
							player = d.player
						elseif d.params and d.params.player then
							player = d.params.player
						end
						local nearest = nil
						local range = ent:GetSprite().Scale:Length()
						
						for u,v in pairs(n_entity) do
							if (ent.Position - v.Position):Length() < 55 * range and auxi.MakeVector((ent.Position - v.Position):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
								if item.uncheckable[v.Type] == nil and (nearest == nil or get_type_priority(nearest) > get_type_priority(v) or ((nearest.Position - player.Position):Length() > (v.Position - player.Position):Length() and get_type_priority(nearest) >= get_type_priority(v)))then
									nearest = v
								end
							end
						end
						
						if nearest == nil then
							local room = Game():GetRoom()
							local grids = get_saga_grid_info(ent.Position,55 * range)
							for u,v in pairs(grids) do
								if (ent.Position - room:GetGridPosition(v.idx)):Length() < 55 * range and auxi.MakeVector((ent.Position - room:GetGridPosition(v.idx)):GetAngleDegrees() - ent.RotationOffset).X < 0.05 then
									if nearest == nil or (ent.Position - room:GetGridPosition(v.idx)):Length() < ((ent.Position - room:GetGridPosition(nearest.idx)):Length()) then
										nearest = v
									end
								end
							end
							if nearest then nearest = grid_entity.get_grid_entity(nearest.grid,nearest.idx) end
						end
						
						if nearest then
							item.targ = nearest
							makelist(nearest)
							local dir = (get_safe_name(nearest,"Position") - player.Position):Normalized()
							for i = 1,3 do
								if dir.Y > 0 then 
									dir.Y = dir.Y + 2
								else 
									dir.Y = dir.Y - 2
								end
								dir = dir:Normalized()
							end
							local fk_dir = auxi.SafeVector(auxi.MakeVector(dir:GetAngleDegrees() - 90 + math.random(1000)/1000 * 4 - 2))
							item.now_display_dir = fk_dir
							sound_tracker.PlayStackedSound(SoundEffect.SOUND_TOOTH_AND_NAIL,math.random(1000)/10000 + 0.95,math.random(1000)/10000 + 0.95,false,0,2)
						end
						--d2.saga_has_modified = true
					end
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
	end
	item.now_display_rm = 0
	item.now_display_pos = nil
	item.now_display_pos_r = nil
	item.now_display_dir = Vector(1,0)
	item.stoped = false
	item.should_remove_targ = nil
end,
})

local function time_stop()
	local n_entity = Isaac.GetRoomEntities() 
	for u,v in pairs(n_entity) do 
		if item.unstopable[v.Type] == nil then
			--print(v.Type.." "..v.Variant)
			local s = v:GetSprite()
			for u,v in pairs(item.eventlist) do
				if s:IsEventTriggered(v) ~= false then 
					s:Update()
				end
			end
			local d = v:GetData()
			if d.saga_flag_freeze_succ == nil then
				d.saga_flag_freeze_succ = Attribute_holder.try_hold_attribute(v,"EntityFlag_FLAG_FREEZE",true,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_FREEZE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_FREEZE) else ent:AddEntityFlags(EntityFlag.FLAG_FREEZE) end end,})
			end
			if d.saga_flag_no_sprite_update_succ == nil then
				d.saga_flag_no_sprite_update_succ = Attribute_holder.try_hold_attribute(v,"EntityFlag_FLAG_NO_SPRITE_UPDATE",true,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) else ent:AddEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) end end,})
			end
			if d.saga_flag_position_succ == nil then
				d.saga_flag_position_succ = Attribute_holder.try_hold_attribute(v,"Position",Vector(v.Position.X,v.Position.Y),{tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
			end
			if d.saga_flag_velocity_succ == nil then
				d.saga_flag_velocity_succ = Attribute_holder.try_hold_attribute(v,"Velocity",Vector(0,0),{tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
			end
		end
	end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local d = player:GetData()
		if d.saga_flag_entitycollisionclass_none_succ == nil then
			d.saga_flag_entitycollisionclass_none_succ = Attribute_holder.try_hold_attribute(player,"EntityCollisionClass",EntityCollisionClass.ENTCOLL_NONE)
		end
		if d.saga_data_should_not_attack_succ == nil then
			d.saga_data_should_not_attack_succ = Attribute_holder.try_hold_attribute(player,"Data_should_not_attack",true,{toget = function(ent) return ent:GetData().should_not_attack end,tochange = function(ent,value) ent:GetData().should_not_attack = value end,})
		end
	end
end

local function time_free()
	local n_entity = Isaac.GetRoomEntities() 
	for u,v in pairs(n_entity) do 
		if item.unstopable[v.Type] == nil then
			local d = v:GetData()
			if d.saga_flag_freeze_succ then
				Attribute_holder.try_rewind_attribute(v,"EntityFlag_FLAG_FREEZE",d.saga_flag_freeze_succ,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_FREEZE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_FREEZE) else ent:AddEntityFlags(EntityFlag.FLAG_FREEZE) end end,})
				d.saga_flag_freeze_succ = nil
			end
			if d.saga_flag_no_sprite_update_succ then
				Attribute_holder.try_rewind_attribute(v,"EntityFlag_FLAG_NO_SPRITE_UPDATE",d.saga_flag_no_sprite_update_succ,{toget = function(ent) return ent:HasEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) end,tochange = function(ent,value) if value ~= true then ent:ClearEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) else ent:AddEntityFlags(EntityFlag.FLAG_NO_SPRITE_UPDATE) end end,})
				d.saga_flag_no_sprite_update_succ = nil
			end
			if d.saga_flag_position_succ then
				Attribute_holder.try_rewind_attribute(v,"Position",d.saga_flag_position_succ,{tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
				d.saga_flag_position_succ = nil
			end
			if d.saga_flag_velocity_succ then
				Attribute_holder.try_rewind_attribute(v,"Velocity",d.saga_flag_velocity_succ,{tocompare = function(v1,v2) return (v1 - v2):Length() < 0.001 end,})
				d.saga_flag_velocity_succ = nil
			end
		end
	end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local d = player:GetData()
		if d.saga_flag_entitycollisionclass_none_succ then
			Attribute_holder.try_rewind_attribute(player,"EntityCollisionClass",d.saga_flag_entitycollisionclass_none_succ)
			d.saga_flag_entitycollisionclass_none_succ = nil
		end
		if d.saga_data_should_not_attack_succ then
			Attribute_holder.try_rewind_attribute(player,"Data_should_not_attack",d.saga_data_should_not_attack_succ,{toget = function(ent) return ent:GetData().should_not_attack end,tochange = function(ent,value) ent:GetData().should_not_attack = value end,})
			d.saga_data_should_not_attack_succ = nil
		end
	end
end

local function renderbox(offset,alpha)
	local render_idx = 1
	--local move_dir = check_screen_size(Vector(- item.now_display_dir.Y / item.now_display_dir.X * 1.8,1)):Normalized() * 10
	local move_dir = check_screen_multi(Vector(- item.now_display_dir.Y / item.now_display_dir.X,1)):Normalized() * 10
	if item.targ == nil then return end
	local d = item.targ:GetData()
	if d.saga_list == nil then makelist(item.targ) end
	local idx = d.saga_now_tp_id or 1
	for i = idx,d.saga_mx_tp do
		local selected = (i == idx)
		local info = item.changeable_state[d.saga_list[i].tp][d.saga_list[i].vr]
		local names = info.name(info,item.targ,selected)
		for j = 1,#names do
			local word = names[j].wd or ""
			local offset2 = names[j].offset or Vector(0,0)
			local col = names[j].col or Color(1,1,1,1)
			col = auxi.MulColor(col,get_color_offset(math.abs(i - idx)))
			local real_pos = offset + render_idx * move_dir + offset2
			d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)] = (d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)] or real_pos) * 0.9 + real_pos * 0.1
			d["saga_render_box_col_"..tostring(i).."_"..tostring(j)] = auxi.AddColor((d["saga_render_box_col_"..tostring(i).."_"..tostring(j)] or col),col,0.9,0.1)
			gui.draw_ch(d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)],word,1,1,auxi.AddColor(d["saga_render_box_col_"..tostring(i).."_"..tostring(j)],Color(0,0,0,0),alpha,1-alpha,true),true)
			render_idx = render_idx + 1
		end
		render_idx = render_idx + 0.5
	end
	for i = 1,idx - 1 do
		local selected = (i == idx)
		local info = item.changeable_state[d.saga_list[i].tp][d.saga_list[i].vr]
		local names = info.name(info,item.targ,selected)
		for j = 1,#names do
			local word = names[j].wd
			local offset2 = names[j].offset or Vector(0,0)
			local col = names[j].col or Color(1,1,1,1)
			col = auxi.MulColor(col,get_color_offset(math.abs(d.saga_mx_tp + i - idx)))
			local real_pos = offset + render_idx * move_dir + offset2
			d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)] = (d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)] or real_pos) * 0.9 + real_pos * 0.1
			d["saga_render_box_col_"..tostring(i).."_"..tostring(j)] = auxi.AddColor((d["saga_render_box_col_"..tostring(i).."_"..tostring(j)] or col),col,0.9,0.1)
			gui.draw_ch(d["saga_render_box_pos_"..tostring(i).."_"..tostring(j)],word,1,1,auxi.AddColor(d["saga_render_box_col_"..tostring(i).."_"..tostring(j)],Color(0,0,0,0),alpha,1-alpha,true),true)
			render_idx = render_idx + 1
		end
		render_idx = render_idx + 0.5
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,		--记录数字
Function = function(_,name)
	if name == "Squiresaga" then
		if item.targ and (item.targ:Exists() == false or item.targ:IsDead() == true) then
			item.targ = nil
			item.render_sprite_pos = nil
		end
		local should_render = (item.targ ~= nil and Game():IsPaused() == false and item.should_remove_targ == nil)
		local screensize = ui.GetScreenSize()
		if should_render then
			item.now_display_pos = Isaac.WorldToScreen(get_safe_name(item.targ,"Position") + item.targ.PositionOffset)
			item.now_display_pos_r = (item.now_display_pos_r or item.now_display_pos) * 0.96 + item.now_display_pos * 0.04
			local delta = item.now_display_pos_r.Y - screensize.Y * 0.1
			item.render_sprite_pos = (item.render_sprite_pos or item.now_display_pos_r) * 0.94 + Vector(item.now_display_pos_r.X + delta * item.now_display_dir.Y / item.now_display_dir.X,screensize.Y * 0.1) * 0.06
			item.now_display_rm = item.now_display_rm * 0.96 + item.mx_rm * 0.04
		else
			item.now_display_rm = item.now_display_rm * 0.92 + 0 * 0.08
			if item.targ then
				item.now_display_pos = Isaac.WorldToScreen(get_safe_name(item.targ,"Position") + item.targ.PositionOffset)
				item.now_display_pos_r = (item.now_display_pos_r or item.now_display_pos) * 0.92 + item.now_display_pos * 0.08
				local delta = item.now_display_pos.Y - screensize.Y * 0.2
				item.render_sprite_pos = (item.render_sprite_pos or item.now_display_pos_r) * 0.9 + item.now_display_pos_r * 0.1
			end
		end
		if item.now_display_rm > 0.001 then
			local player = Game():GetPlayer(0)
			local succ = selection_holder.check_and_try_select(player,"Squiresaga")
			if succ then
				item.stoped = true
				time_stop()
				local r_pos = item.now_display_pos_r
				if r_pos then
					local t_pos = check_screen_size(r_pos/256)
					--print(t_pos)
					local A = item.now_display_dir.X
					local B = item.now_display_dir.Y
					local C = -(t_pos.X * A + t_pos.Y * B)
					local D = item.now_display_rm * get_screensize_multi()
					--print(tostring(A).." "..B.." "..C.." "..D)
					local ret_info = {A,B,C,D,}
					local mul = ret_info[4]/(ret_info[1] * ret_info[1] + ret_info[2] * ret_info[2])
					local ret_info2 = {ret_info[1] * mul,ret_info[2] * mul,0,0,}
					if item.targ then
						renderbox(item.render_sprite_pos + Vector(-20,0),item.now_display_rm * 20)
						local s = item.targ:GetSprite()
						--print(s.Offset)
						local offset = Vector(0,math.min(0,s.Offset.Y * 0.5))
						if item.targ.IsGrid ~= nil then offset = offset + Vector(0,-10) end
						s:Render(item.render_sprite_pos + offset,Vector(0,0),Vector(0,0))
					end
					return {
						info1 = ret_info,
						info2 = ret_info2,
						should_work = 1,
					}
				end
			end
		else
			item.now_display_pos = nil
			item.now_display_pos_r = nil
			if item.should_remove_targ ~= nil then
				item.targ = nil
				item.render_sprite_pos = nil
				item.should_remove_targ = nil
			end
		end
		if item.stoped then
			selection_holder.remove_select(player,"Squiresaga")
			time_free()
		end
		return {
			info1 = {0,0,0,0,},
			info2 = {0,0,0,0,},
			should_work = 0,
		}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_INPUT_ACTION, params = nil,
Function = function(_,ent,hook,button)
	if ent ~= nil then
		local player = ent:ToPlayer()
		if player then
			if player:HasCollectible(item.entity) and selection_holder.check_select(player,"Squiresaga") then
				for u,i in pairs({4,5,6,7,8,9,11,13}) do
					if button == i and (hook == InputHook.IS_ACTION_TRIGGERED or hook == InputHook.IS_ACTION_PRESSED) then
						return false
					end
				end
			end
		end
	end
end,
})

--l local n_entity = Isaac.GetRoomEntities() for u,v in pairs(n_entity) do v:AddEntityFlags(EntityFlag.FLAG_FREEZE | EntityFlag.FLAG_NO_SPRITE_UPDATE) end

return item