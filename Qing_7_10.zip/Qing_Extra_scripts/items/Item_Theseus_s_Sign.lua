local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Items.Theseus_s_Sign,
}

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player then
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = player:GetData().__Index
			if idx then
				save.elses["Theseus_s_Sign_effect_1_"..tostring(idx)] = (save.elses["Theseus_s_Sign_effect_1_"..tostring(idx)] or 0) + 1
				if save.elses["Theseus_s_Sign_effect_1_"..tostring(idx)] >= (save.elses["Theseus_s_Sign_effect_1_mx_"..tostring(idx)] or 4) then
					local room = Game():GetRoom()
					save.elses["Theseus_s_Sign_effect_1_"..tostring(idx)] = 0
					save.elses["Theseus_s_Sign_effect_1_mx_"..tostring(idx)] = (save.elses["Theseus_s_Sign_effect_1_mx_"..tostring(idx)] or 4) + 1
					local q = Isaac.Spawn(5,100,0,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_BASIC, params = nil,
Function = function(_,player,changetype,count)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local idx = player:GetData().__Index
		if idx then
			if count > 0 and (changetype == "sl_heart" or changetype == "rd_heart" or changetype == "et_heart" or changetype == "bn_heart") then
				save.elses["Theseus_s_Sign_effect_2_"..tostring(idx)] = (save.elses["Theseus_s_Sign_effect_2_"..tostring(idx)] or 0) + count
				if save.elses["Theseus_s_Sign_effect_2_"..tostring(idx)] >= (save.elses["Theseus_s_Sign_effect_2_mx_"..tostring(idx)] or 5) then
					local room = Game():GetRoom()
					save.elses["Theseus_s_Sign_effect_2_"..tostring(idx)] = 0
					save.elses["Theseus_s_Sign_effect_2_mx_"..tostring(idx)] = (save.elses["Theseus_s_Sign_effect_2_mx_"..tostring(idx)] or 5) + 1
					player:GetData().should_theseus_remove_sign = true
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if player:IsExtraAnimationFinished() then
			if player:GetData().should_theseus_remove_sign and player:GetData().should_theseus_remove_sign == true then
				local id = auxi.get_random_item_that_player_has(player,player:GetCollectibleRNG(item.entity),false)
				if id ~= -1 then
					local q = auxi.spawn_item_dust(player,player.Position,id,Color(-1,-1,-1,1),nil,nil)
					player:RemoveCollectible(id)
					player:AnimateSad()
				end
				player:GetData().should_theseus_remove_sign = nil
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["Theseus_s_Sign_effect_1_"..tostring(j)] = 0
			save.elses["Theseus_s_Sign_effect_2_"..tostring(j)] = 0
			save.elses["Theseus_s_Sign_effect_1_mx_"..tostring(j)] = 4
			save.elses["Theseus_s_Sign_effect_2_mx_"..tostring(j)] = 5
		end
	end
end,
})

return item