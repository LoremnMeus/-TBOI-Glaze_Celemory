local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Heart_Change,
	costumes = {
		[1] = enums.Costumes.Heart_Change_1,
		[2] = enums.Costumes.Heart_Change_2,
		[3] = enums.Costumes.Heart_Change_3,
		[4] = enums.Costumes.Heart_Change_4,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if cacheFlag == CacheFlag.CACHE_FLYING then
			local idx = player:GetData().__Index
			if idx then
				if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
				if save.elses["Heart_Change_State"..tostring(idx)] == 0 then
					player.CanFly = true
				end
			end
		end
	end
end,
})

local function check_costume(player)
	for i = 1,4 do
		player:TryRemoveNullCostume(item.costumes[i])
	end
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
		player:AddNullCostume(item.costumes[save.elses["Heart_Change_State"..tostring(idx)] + 1])
	end
end

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,count,lastnumber)
	if count < 0 and player:HasCollectible(item.entity) == false and player:GetEffects():GetCollectibleEffectNum(item.entity) == 0 then
		for i = 1,4 do
			player:TryRemoveNullCostume(item.costumes[i])
		end
	end
	if count > 0 and player:GetCollectibleNum(item.entity,true) == count then
		local idx = player:GetData().__Index
		if idx then
			if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
			player:AddNullCostume(item.costumes[save.elses["Heart_Change_State"..tostring(idx)] + 1])
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["Heart_Change_State"..tostring(j)] = 0
		end
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	if room:IsFirstVisit() and desc then
		if desc.Data.Type == 14 then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
					local idx = player:GetData().__Index
					if idx then
						if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
						if save.elses["Heart_Change_State"..tostring(idx)] & 1 == 0 then
							save.elses["Heart_Change_State"..tostring(idx)] = save.elses["Heart_Change_State"..tostring(idx)] | 1
							player:AddCacheFlags(CacheFlag.CACHE_FLYING)
							player:GetData().should_evaluate_on_update_once = true
							local q = Isaac.Spawn(5,10,6,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						end
					end
					check_costume(player)
				end
			end
		end
		if desc.Data.Type == 15 then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
					local idx = player:GetData().__Index
					if idx then
						if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
						if save.elses["Heart_Change_State"..tostring(idx)] & 2 == 0 then
							save.elses["Heart_Change_State"..tostring(idx)] = save.elses["Heart_Change_State"..tostring(idx)] | 2
							player:AddCacheFlags(CacheFlag.CACHE_FLYING)
							player:GetData().should_evaluate_on_update_once = true
							local q = Isaac.Spawn(5,10,4,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
						end
					end
					check_costume(player)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = player:GetData().__Index
			if idx then
				if save.elses["Heart_Change_State"..tostring(idx)] == nil then save.elses["Heart_Change_State"..tostring(idx)] = 0 end
				if save.elses["Heart_Change_State"..tostring(idx)] == 3 then
					local room = Game():GetRoom()
					save.elses["Heart_Change_State"..tostring(idx)] = 0
					player:AddCacheFlags(CacheFlag.CACHE_FLYING)
					player:GetData().should_evaluate_on_update_once = true
					check_costume(player)
					player:AnimateHappy()
					local rng = player:GetCollectibleRNG(item.entity)
					rng = auxi.rng_for_sake(rng)
					local itempool = Game():GetItemPool()
					local col1 = itempool:GetCollectible (3,true,rng:GetSeed())
					rng:Next()
					local col2 = itempool:GetCollectible (4,true,rng:GetSeed())
					rng:Next()
					local q = Isaac.Spawn(5,100,col1,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
					local q2 = Isaac.Spawn(5,100,col2,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),player):ToPickup()
				end
			end
		end
	end
end,
})

return item