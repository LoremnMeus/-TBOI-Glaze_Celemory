local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	entity = enums.Items.Brimstream,
	familiar = enums.Familiars.Brimstream,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		cnt = cnt + player:GetCollectibleNum(118) + player:GetEffects():GetCollectibleEffectNum(118)
	end
	if cacheFlag == CacheFlag.CACHE_FAMILIARS then
		player:CheckFamiliar(item.familiar, cnt, player:GetCollectibleRNG(item.entity), Isaac.GetItemConfig():GetCollectible(item.entity))
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local n_entity = Isaac.GetRoomEntities()
	local n_brim = auxi.getothers(n_entity,3,item.familiar,nil)
	for u,v in pairs(n_brim) do
		v.Velocity = Vector(0,0)
		if v:GetData().follow_brim then
			v:GetData().rotate_angle = math.random(2) * 2 - 3
			v:GetData().follow_brim:Remove()
			v:GetData().follow_brim = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	if ent.SpawnerEntity and ent.SpawnerEntity:ToPlayer() then
		player = ent.SpawnerEntity:ToPlayer()
	end
	if s:IsFinished("Appear") then
		s:Play("Idle")
	end
	if s:IsPlaying("Idle") then
		if (d.follow_brim == nil or d.follow_brim:Exists() == false) then
			local dmg = 0.5
			local tp = 1
			if player:HasCollectible(247) then 
				dmg = dmg * 1.5
				if player:HasCollectible(68) or player:HasCollectible(152) or player:HasCollectible(enums.Items.Tech_9) then
					tp = 14
					dmg = dmg * 1.5
				else
					tp = 11 
				end
			elseif player:HasCollectible(68) or player:HasCollectible(152) or player:HasCollectible(enums.Items.Tech_9) then
				dmg = dmg * 1.5
				tp = 9
			end
			local q = Isaac.Spawn(7,tp,0,ent.Position,ent.Velocity,ent)
			q.CollisionDamage = dmg
			d.mx_brim_lgth = 5
			q.Parent = ent
			d.follow_brim = q:ToLaser()
		end
		if d.follow_brim then
			d.follow_brim.Angle = ent.Velocity:GetAngleDegrees() + 180
			s.Rotation = ent.Velocity:GetAngleDegrees() + 90
			d.follow_brim.MaxDistance = d.mx_brim_lgth
			d.mx_brim_lgth = math.min(1000,d.mx_brim_lgth * 1.2 + 5)
			if d.target == nil or d.target:Exists() == false then
				local n_entity = Isaac.GetRoomEntities()
				local n_enemy = auxi.getenemies(n_entity)
				local targ = nil
				for u,v in pairs(n_enemy) do
					if targ == nil or (targ.Position - ent.Position):Length() > (v.Position - ent.Position):Length() then
						targ = v
					end
				end
				d.target = targ
			end
			
			if d.target == nil or d.target:Exists() == false or d.target:IsActiveEnemy() == false or d.target:IsVulnerableEnemy() == false or d.target:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) then
				local vel = math.min(20,math.max(3,ent.Velocity:Length() * 1.3))
				local dis = player.Position - ent.Position
				if dis:Length() > 80 then
					local dg_angle = 85
					if dis:Length() > 260 then dg_angle = 75 end
					if d.rotate_angle == nil then d.rotate_angle = math.random(2) * 2 - 3 end
					ent.Velocity = auxi.MakeVector(dg_angle * d.rotate_angle + (player.Position - ent.Position):GetAngleDegrees()) * vel
				else
					if ent.Velocity:Length() < 0.05 then
						ent.Velocity = auxi.MakeVector(math.random(36000)/100) * 0.1
					end
					ent.Velocity = ent.Velocity:Normalized() * math.min(15,1.3 * ent.Velocity:Length())
				end
			else
				if ent.Velocity:Length() < 0.05 then
					ent.Velocity = auxi.MakeVector(math.random(36000)/100) * 3
				end
				local dis = (ent.Velocity + (d.target.Position - ent.Position)/80)
				if math.abs(dis:GetAngleDegrees() - (d.target.Position - ent.Position):GetAngleDegrees()) > 60 and (d.target.Position - ent.Position):Length() < 135 then
					dis = (ent.Velocity + (d.target.Position - ent.Position)/40)
				end
				if math.abs(dis:GetAngleDegrees() - (d.target.Position - ent.Position):GetAngleDegrees()) > 45 and (d.target.Position - ent.Position):Length() < 110 then
					dis = (ent.Velocity + (d.target.Position - ent.Position)/28)
				end
				if math.abs(dis:GetAngleDegrees() - (d.target.Position - ent.Position):GetAngleDegrees()) > 30 and (d.target.Position - ent.Position):Length() < 75 then
					dis = (ent.Velocity + (d.target.Position - ent.Position)/16)
				end
				if math.abs(dis:GetAngleDegrees() - (d.target.Position - ent.Position):GetAngleDegrees()) > 15 and (d.target.Position - ent.Position):Length() < 50 then
					dis = (ent.Velocity + (d.target.Position - ent.Position)/8)
				end
				if math.abs(dis:GetAngleDegrees() - (d.target.Position - ent.Position):GetAngleDegrees()) > 5 and (d.target.Position - ent.Position):Length() < 35 then
					dis = (ent.Velocity + (d.target.Position - ent.Position)/2)
				end
				if (d.target.Position - ent.Position):Length() < 30 or (d.invi and d.invi >= 0) then 
					if (d.target.Position - ent.Position):Length() > 150 and d.invi and d.invi >= 0 then
						d.invi = d.invi - 1
					end
					if ent.Velocity:Length() > 0.05 then
						dis = ent.Velocity * 1.1
					else
						dis = auxi.MakeVector(math.random(36000)/100)
					end
				end
				ent.Velocity = dis:Normalized() *  math.min(20,dis:Length())
			end
		end
	end
	if d.delay and d.delay >= 0 then
		d.delay = d.delay - 1
	end
	if s:IsFinished("Crush_to_Idle") then
		s:Play("Idle",true)
	end
	if s:IsPlaying("Idle_Crush") then
		if d.crush_time_out == nil or d.crush_time_out < 0 then
			s:Play("Crush_to_Idle",true)
		end
	end
	if s:IsFinished("Crush") then
		s:Play("Idle_Crush",true)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = item.familiar,
Function = function(_,ent,col,low)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	local player = Game():GetPlayer(0)
	if ent.SpawnerEntity and ent.SpawnerEntity:ToPlayer() then
		player = ent.SpawnerEntity:ToPlayer()
	end
	if s:IsPlaying("Idle") and (d.invi == nil or d.invi < 0) and room:GetFrameCount() >= 15 and (d.delay == nil or d.delay < 0) then
		s:Play("Crush")
		if d.follow_brim then
			d.follow_brim:Remove()
			d.follow_brim = nil
		end
		d.target = nil
		ent.Velocity = Vector(0,0)
		Game():BombExplosionEffects(ent.Position,3 + player.Damage * 0.2,player.TearFlags,Color(1,0,0,1),player,ent:GetSprite().Scale:Length()/math.sqrt(2),false,true)
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		local tbl = {}
		for u,v in pairs(n_enemy) do
			if (v.Position - ent.Position):Length() < 50 then
				table.insert(tbl,v)
			end
		end
		delay_buffer.addeffe(function(params)
			local n_enemy = params.n_enemy
			for u,v in pairs(n_enemy) do
				if v and v:Exists() and v:IsDead() == false then
					v:AddEntityFlags(EntityFlag.FLAG_BRIMSTONE_MARKED)
				end
			end
		end,{n_enemy = tbl,},18)
		local rnd = math.random(6) + 6
		local range = math.random(50) + 50
		local st_ang = math.random(36000)/100
		local dmg = 0.5
		local tp = 1
		if player:HasCollectible(247) then 
			dmg = dmg * 1.5
			if player:HasCollectible(68) or player:HasCollectible(152) or player:HasCollectible(enums.Items.Tech_9) then
				tp = 14
				dmg = dmg * 1.5
			else
				tp = 11 
			end
			range = range + 25 + math.random(25)
		elseif player:HasCollectible(68) or player:HasCollectible(152) or player:HasCollectible(enums.Items.Tech_9) then
			dmg = dmg * 1.5
			tp = 9
		end
		for i = 1,rnd do
			local q = Isaac.Spawn(7,tp,0,ent.Position,Vector(0,0),player):ToLaser()
			local d2 = q:GetData()
			d2.should_ignore_modifier = true
			if player:HasCollectible(118) == false then
				q.MaxDistance = range
			end
			q.CollisionDamage = dmg
			q:SetTimeout(9)
			q.Angle = st_ang + 360/rnd * (i-1)
		end
		d.invi = 0
		d.delay = 15
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = item.familiar,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	ent.GridCollisionClass = GridCollisionClass.COLLISION_WALL
	ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ENEMIES
	s:Play("Appear",true)
end,
})

return item