local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Items.Pareidolia,
	lim = 10,
	sprite_list = {
		[0] = 3,
		[1] = 3,
		[2] = 2,
		[3] = 2,
		[4] = 2,
		[5] = 2,
	},
	special_list = {
		CollectibleType.COLLECTIBLE_INNER_EYE,
		CollectibleType.COLLECTIBLE_MOMS_EYE,
		--CollectibleType.COLLECTIBLE_XRAY_VISION,
		--CollectibleType.COLLECTIBLE_MOMS_CONTACTS,
		--CollectibleType.COLLECTIBLE_MUTANT_SPIDER,
		CollectibleType.COLLECTIBLE_PEEPER,
		CollectibleType.COLLECTIBLE_POLYPHEMUS,
		CollectibleType.COLLECTIBLE_20_20,
		CollectibleType.COLLECTIBLE_PROPTOSIS,
		CollectibleType.COLLECTIBLE_CURSED_EYE,
		CollectibleType.COLLECTIBLE_CAINS_OTHER_EYE,
		CollectibleType.COLLECTIBLE_LUDOVICO_TECHNIQUE,
		CollectibleType.COLLECTIBLE_DIPLOPIA,
		--CollectibleType.COLLECTIBLE_THE_WIZ,
		CollectibleType.COLLECTIBLE_DEAD_EYE,
		CollectibleType.COLLECTIBLE_TECH_X,
		CollectibleType.COLLECTIBLE_EVIL_EYE,
		--CollectibleType.COLLECTIBLE_EYE_OF_GREED,
		--CollectibleType.COLLECTIBLE_HEAD_OF_THE_KEEPER,
		--CollectibleType.COLLECTIBLE_GLAUCOMA,
		CollectibleType.COLLECTIBLE_EYE_OF_BELIAL,
		CollectibleType.COLLECTIBLE_BLOODSHOT_EYE,
		CollectibleType.COLLECTIBLE_SPRINKLER,
		CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO,
		CollectibleType.COLLECTIBLE_POP,
		CollectibleType.COLLECTIBLE_LACHRYPHAGY,
		CollectibleType.COLLECTIBLE_EYE_SORE,
		--CollectibleType.COLLECTIBLE_EYE_OF_THE_OCCULT,
		CollectibleType.COLLECTIBLE_OCULAR_RIFT,
		CollectibleType.COLLECTIBLE_EVIL_CHARM,
		CollectibleType.COLLECTIBLE_TROPICAMIDE,
		CollectibleType.COLLECTIBLE_GUPPYS_EYE,
		CollectibleType.COLLECTIBLE_GLITCHED_CROWN,
		CollectibleType.COLLECTIBLE_GLASS_EYE,
		enums.Items.Assassin_s_Eye,
		enums.Items.Colorblindness,
		enums.Items.Wavering_Eyes,
		enums.Items.Book_of_Vision,
	},
	costumes = {
		[1] = enums.Costumes.Pareidolia_1,
	},
	costume_list = {
		[1] = enums.Items.Pareidolia,
		[2] = CollectibleType.COLLECTIBLE_EVIL_CHARM,
		[3] = CollectibleType.COLLECTIBLE_CURSED_EYE,
	},
	description = {
		[CollectibleType.COLLECTIBLE_INNER_EYE] = {desc = "最前端额外多2颗妖心眼泪作为环绕",},
		[CollectibleType.COLLECTIBLE_MOMS_EYE] = {desc = "向后发射一条独立弹道的妖心眼泪",},
		[CollectibleType.COLLECTIBLE_PEEPER] = {desc = "从宝宝处追加一条妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_POLYPHEMUS] = {desc = "最前端的妖心眼泪额外继承角色伤害的10%",},
		[CollectibleType.COLLECTIBLE_20_20] = {desc = "+1妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_PROPTOSIS] = {desc = "最前端的妖心眼泪继承突眼特效",},
		[CollectibleType.COLLECTIBLE_CURSED_EYE] = {desc = "+3妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_CAINS_OTHER_EYE] = {desc = "从宝宝处追加一条妖心眼泪弹道",},
		--[CollectibleType.COLLECTIBLE_LUDOVICO_TECHNIQUE] = {desc = "同时从悬浮眼泪处发射妖心眼泪",},
		[CollectibleType.COLLECTIBLE_DIPLOPIA] = {desc = "持有时视为额外拥有一个#{{Collectible"..tostring(enums.Items.Pareidolia).."}} ",},
		[CollectibleType.COLLECTIBLE_DEAD_EYE] = {desc = "最前端的妖心眼泪命中敌人时计入累计量#未命中时不计入耗散量",},
		[CollectibleType.COLLECTIBLE_TECH_X] = {desc = "最前端的妖心眼泪拥有激光环绕圈",},
		--[CollectibleType.COLLECTIBLE_EVIL_EYE] = {desc = "有概率由眼球额外发射一颗妖心眼泪",},
		[CollectibleType.COLLECTIBLE_EYE_OF_BELIAL] = {desc = "最前端的妖心眼泪具有双穿",},
		[CollectibleType.COLLECTIBLE_BLOODSHOT_EYE] = {desc = "从宝宝处追加一条妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_SPRINKLER] = {desc = "从宝宝处追加一条妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO] = {desc = "最前端的妖心眼泪会电击周围敌人",},
		[CollectibleType.COLLECTIBLE_POP] = {desc = "最前端的妖心眼泪会推动周围的眼泪",},
		[CollectibleType.COLLECTIBLE_LACHRYPHAGY] = {desc = "最前端的妖心眼泪会吸纳周围的眼泪",},
		[CollectibleType.COLLECTIBLE_EYE_SORE] = {desc = "最前端额外多1颗妖心眼泪作为环绕",},
		--[CollectibleType.COLLECTIBLE_EYE_OF_THE_OCCULT] = {desc = "妖心眼泪严格遵循上一发妖心眼泪的动作",},
		[CollectibleType.COLLECTIBLE_OCULAR_RIFT] = {desc = "最前端的妖心眼泪具有较大吸引力",},
		[CollectibleType.COLLECTIBLE_EVIL_CHARM] = {desc = "+2妖心眼泪弹道",},
		[CollectibleType.COLLECTIBLE_TROPICAMIDE] = {desc = "最前端的妖心眼泪继承煤块特效",},
		[CollectibleType.COLLECTIBLE_GUPPYS_EYE] = {desc = "最前端的妖心眼泪具有橡胶特效",},
		[CollectibleType.COLLECTIBLE_GLITCHED_CROWN] = {desc = "最前端的妖心眼泪具有随机特效",},
		[CollectibleType.COLLECTIBLE_GLASS_EYE] = {desc = "最前端的妖心眼泪可以反弹敌人子弹",},
		[enums.Items.Assassin_s_Eye] = {desc = "最前端的妖心眼泪拥有暗杀能力",},
		[enums.Items.Colorblindness] = {desc = "最前端的妖心眼泪获得穿透",},
		[enums.Items.Wavering_Eyes] = {desc = "最前端的妖心眼泪命中敌人时计入累计量#未命中时不计入耗散量",},
		[enums.Items.Book_of_Vision] = {desc = "持有时妖心眼泪弹道+1",},
		[enums.Items.Pareidolia] = {desc = "所有弹道额外+1",},
	},
	adder_list = {
		[1] = function(player)
			local ret = 0
			
		end,
	},
	worklist = {
		[FamiliarVariant.PEEPER] = true,
		[FamiliarVariant.CAINS_OTHER_EYE] = true,
		[FamiliarVariant.BLOODSHOT_EYE] = true,
		[FamiliarVariant.SPRINKLER] = true,
	},
	tear_flag_buff = {
		[1] = TearFlags.TEAR_BONE,
		[2] = TearFlags.TEAR_SLOW,
		[3] = TearFlags.TEAR_HOMING,
		[4] = TearFlags.TEAR_FEAR,
		[5] = BitSet128(0,1<<(65-64)),
		[6] = TearFlags.TEAR_POISON,
		[7] = BitSet128(0,1<<(66-64)),
		[8] = TearFlags.TEAR_ACID,
	},
	tear_color_buff = {
		[1] = Color(1,0,0,0.7,0.5,0,0),
		[2] = Color(1,0.1,0.5,0.7,0.5,0,0.2),
		[3] = Color(1,0,1,0.7,0.2,0,0.2),
		[4] = Color(0.4,0,1,0.7,0,0,0.3),
		[5] = Color(0,0.5,1,0.7,0,0.2,0.5),
		[6] = Color(0.5,0.5,0,0.7,0.2,0.2,0),
		[7] = Color(0.4,0.6,0,0.8,0.1,0.3,0),
		[8] = Color(1,1,0,0.7,0.5,0.4,0),
	},
	start_radius = 5,
}

local function check_pareidolia_list_num(player)
	local ret = 0
	for u,v in pairs(item.costume_list) do
		ret = ret + player:GetCollectibleNum(v)
	end
	return ret
end

local function check_info(ent)
	local ret = {
		cnt = 1,
		front = 1,
		special_detail = {},
		mul = 1,
		def_angle = 7,
		delay = 10,
		rot_angle = 10,
		rot_dis = 30,
		damage = 0.66,
	}
	if ent.Type == 1 and ent:ToPlayer() then
		local player = ent:ToPlayer()
		if player:HasCollectible(CollectibleType.COLLECTIBLE_INNER_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_INNER_EYE) > 0 then
			ret.front = ret.front + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_INNER_EYE) + 1
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_EYE_SORE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_EYE_SORE) > 0 then
			ret.front = ret.front + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_EYE_SORE)
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_20_20) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_20_20) > 0 then
			ret.cnt = ret.cnt + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_20_20)
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_EVIL_CHARM) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_EVIL_CHARM) > 0 then
			ret.cnt = ret.cnt + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_EVIL_CHARM) + 1
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_CURSED_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_CURSED_EYE) > 0 then
			ret.cnt = ret.cnt + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_CURSED_EYE) + 2
			ret.def_angle = 15
			ret.delay = 20
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_DIPLOPIA) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_DIPLOPIA) > 0 then
			ret.mul = ret.mul + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_DIPLOPIA)
		end
		if player:HasCollectible(CollectibleType.COLLECTIBLE_MOMS_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_MOMS_EYE) > 0 then
			ret.cnt = ret.cnt + player:GetCollectibleNum(CollectibleType.COLLECTIBLE_MOMS_EYE)
			table.insert(ret.special_detail,#ret.special_detail + 1,{angle = 180,})
		end
		if player:HasCollectible(enums.Items.Book_of_Vision) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Book_of_Vision) > 0 then
			ret.cnt = ret.cnt + player:GetCollectibleNum(enums.Items.Book_of_Vision)
		end
		if player:HasCollectible(enums.Items.Pareidolia) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Pareidolia) > 0 then
			ret.mul = ret.mul + player:GetCollectibleNum(enums.Items.Pareidolia) - 1
		end
		return ret
	elseif ent.Type == 3 and item.worklist[ent.Variant] then
		ret.delay = 15
		local player = ent.Player
		if player then
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				return ret
			end
		end
	end
	return nil
end

local function work_on_pareidolia_list(ent)
	local info = check_info(ent)
	if info == nil then return end
	local player = auxi.check_player(ent)
	local ggdir = auxi.ggdir(player,true,true)
	if player == nil then return end
	local d = ent:GetData()
	d.Pareidolia_tear_list = d.Pareidolia_tear_list or {}
	local normal_cnt = (info.cnt - #(info.special_detail)) * info.mul 
	for i = 1,normal_cnt + #(info.special_detail) do
		d.Pareidolia_tear_list[i] = d.Pareidolia_tear_list[i] or {}
		local v = d.Pareidolia_tear_list[i]
		local detail = {angle = ((i - (normal_cnt + 1) * 0.5) * info.def_angle),rot_angle = info.rot_angle}
		if i > normal_cnt then
			detail = info.special_detail[i - normal_cnt]
		end
		local gdir = Vector(0,0)
		if ggdir:Length() > 0.05 then gdir = auxi.MakeVector(ggdir:GetAngleDegrees() + (detail.angle or info.angle or 0)) end
		v.Pareidolia_counter = (v.Pareidolia_counter or 0) + 1
		v.Pareidolia_tear = v.Pareidolia_tear or {}
		if v.Pareidolia_counter > (detail.delay or info.delay or 10) then
			if ggdir:Length() > 0.05 then
				local q = Isaac.Spawn(2,0,0,ent.Position,gdir:Normalized() * 5,player)
				local d2 = q:GetData()
				local s2 = q:GetSprite()
				s2:Load("gfx/Pareidolia_Tear.anm2",true)
				s2:Play("Idle1",true)
				d2.Ignore_me_flag = true
				d2.is_pareidolia_tear = true
				d2.collision_damage = (detail.damage or info.damage or 0.666)
				q.CollisionDamage = d2.collision_damage
				table.insert(v.Pareidolia_tear,#(v.Pareidolia_tear) + 1,q)
				v.Pareidolia_counter = 0
			end
		end
		if #(v.Pareidolia_tear) > 0 then
			for i = #(v.Pareidolia_tear),1,-1 do
				if v.Pareidolia_tear[i] == nil or v.Pareidolia_tear[i]:Exists() == false or v.Pareidolia_tear[i]:IsDead() then table.remove(v.Pareidolia_tear,i) end
			end
			if #v.Pareidolia_tear > 0 then
				local front = info.front or 1
				local q = v.Pareidolia_tear[1]
				local d2 = q:GetData()
				local s2 = q:GetSprite()
				d2.pareidolia_target_pos = (d2.pareidolia_target_pos or (q.Position + gdir * 35 * player.ShotSpeed)) * 0.2 + (q.Position + gdir * 35 * player.ShotSpeed) * 0.8
				d2.pareidolia_target_pos2 = d2.pareidolia_target_pos
				d2.pareidolia_id = 0
				d2.pareidolia_flush = 5
				local sl_pos_z = q.Position
				local sl_pos = q.Position
				if front > 1 then
					local split = math.min(front,#v.Pareidolia_tear) - 1
					local ang = detail.rot_angle or info.rot_angle or 10
					local dist = detail.rot_dis or info.rot_dis or 15
					v.Pareidolia_tear_angle = (v.Pareidolia_tear_angle or 0) + ang
					for i = 2,split + 1 do
						local q = v.Pareidolia_tear[i]
						local d2 = q:GetData()
						local s2 = q:GetSprite()
						d2.pareidolia_target_pos = (d2.pareidolia_target_pos or (sl_pos + gdir * 35 * player.ShotSpeed) + auxi.MakeVector(v.Pareidolia_tear_angle + 360/split * (i - 2)) * dist) * 0.2 + (sl_pos + gdir * 35 * player.ShotSpeed + auxi.MakeVector(v.Pareidolia_tear_angle + 360/split * (i - 2)) * dist) * 0.8
						d2.pareidolia_target_pos2 = d2.pareidolia_target_pos
						d2.pareidolia_id = 1
						d2.pareidolia_flush = 5
					end
				end
				if front < #v.Pareidolia_tear then
					for i = front + 1,#v.Pareidolia_tear do
						local q = v.Pareidolia_tear[i]
						local d2 = q:GetData()
						local s2 = q:GetSprite()
						d2.pareidolia_target_pos = (d2.pareidolia_target_pos or (sl_pos + gdir * 2 * player.ShotSpeed)) * 0.2 + (sl_pos + gdir * 2 * player.ShotSpeed) * 0.8
						d2.pareidolia_target_pos2 = (d2.pareidolia_target_pos2 or (sl_pos_z + gdir * 2 * player.ShotSpeed)) * 0.2 + (sl_pos_z + gdir * 2 * player.ShotSpeed) * 0.8
						sl_pos = q.Position
						d2.pareidolia_id = (i - front + 1)
						d2.pareidolia_flush = 5
						if (i - front + 1) > item.lim then
							sl_pos_z = v.Pareidolia_tear[i - item.lim].Position
						end
					end
				end
			end
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local d = player:GetData()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		work_on_pareidolia_list(player)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = nil,
Function = function(_,ent)
	local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		work_on_pareidolia_list(ent)
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if player:HasCollectible(item.entity) and check_pareidolia_list_num(player) > 1 then
		player:AddNullCostume(item.costumes[1])
	else
		player:TryRemoveNullCostume(item.costumes[1])
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_TEAR_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_pareidolia_tear then
		local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
		ent.Height = ent.Height * 0.9 + (-20) * 0.1
		ent.FallingSpeed = 0
		if ent.Velocity:Length() > 1 then
			d.Pareidolia_record_angle = ent.Velocity:GetAngleDegrees()
			s.Rotation = d.Pareidolia_record_angle
		else
			s.Rotation = (d.Pareidolia_record_angle or 0)
		end
		d.pareidolia_id = (d.pareidolia_id or 1)
		if item.sprite_list[d.pareidolia_id] then
			s:Play("Idle"..tostring(item.sprite_list[d.pareidolia_id]),true)
		else
			s:Play("Idle1",true)
		end
		if d.tail and d.tail:Exists() and d.tail:IsDead() ~= true then
			d.tail.Position = ent.Position + Vector(0,-24)
		else
			local q = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.SPRITE_TRAIL, 0, ent.Position, Vector(0,0), ent):ToEffect()
			d.tail = q
			q.MinRadius = 0.07
			q.MaxRadius = 0.07
			q.SpriteScale = Vector(1,1)
			q.Parent = ent
			q:SetColor(auxi.AddColor(s.Color,Color(1, 1, 0, 0.25, 1, 1, 0),0,1), -1, 0)
			ent.Child = q
		end
		if d.pareidolia_target_pos then
			local dir = d.pareidolia_target_pos - ent.Position
			--if d.pareidolia_target_pos2 then dir = dir * 0.9 + (d.pareidolia_target_pos2 - ent.Position) * 0.1 end
			local mx = math.max(10,ent.Velocity:Length() * 1.1)
			if d.pareidolia_id < 5 then mx = mx + 5 end
			local leg = math.min(mx,math.max(0,dir:Length() - 20))
			--if (leg > -5 and leg < 5) or (leg < -15) then leg = 0 end
			ent.Velocity = ent.Velocity * 0.7 + 0.3 * dir:Normalized() * leg
		end
		if d.pareidolia_id == 0 then
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local dmg = d.collision_damage
				if player:HasCollectible(CollectibleType.COLLECTIBLE_POLYPHEMUS) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_POLYPHEMUS) > 0 then
					dmg = dmg + player.Damage * 0.1
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_PROPTOSIS) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_PROPTOSIS) > 0 then
					dmg = dmg * math.max(0.05,(1 - ((player.Position - ent.Position):Length() - 100)/50))
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_TECH_X) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_TECH_X) > 0 then
					if d.Pareidolia_link_tech_x == nil or d.Pareidolia_link_tech_x:Exists() == false or d.Pareidolia_link_tech_x:IsDead() then
						local q = Isaac.Spawn(7,2,3,ent.Position,ent.Velocity,player):ToLaser()
						local d2 = q:GetData()
						q.PositionOffset = ent.PositionOffset
						q.Parent = ent
						q.Radius = item.start_radius
						d.Pareidolia_link_tech_x = q
						q.CollisionDamage = ent.CollisionDamage
						d2.radius_vel = 10
						d2.radius_acc = -1
						d2.is_pareidolia_laser = true
					end
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_EYE_OF_BELIAL) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_EYE_OF_BELIAL) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<0,0) | BitSet128(1<<1,0)
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_TECHNOLOGY_ZERO) > 0 then
					if ent.FrameCount % 15 == 1 then
						local n_entity = Isaac.FindInRadius(ent.Position,120,1<<3)
						local n_enemy = auxi.getenemies(n_entity)
						for u,v in pairs(n_enemy) do
							local q = Isaac.Spawn(7,10,4,ent.Position,Vector(0,0),player):ToLaser()
							q.AngleDegrees = (v.Position - ent.Position):GetAngleDegrees()
							q.TearFlags = BitSet128(0,0)
							q.PositionOffset = ent.PositionOffset
							q:SetTimeout(2)
							q.Parent = ent
							q.CollisionDamage = ent.CollisionDamage * 0.5
							q:SetOneHit(true)
							q:SetMaxDistance((v.Position - ent.Position):Length())
						end
					end
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_POP) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_POP) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<58,0)
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_LACHRYPHAGY) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_LACHRYPHAGY) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<59,0)
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_OCULAR_RIFT) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_OCULAR_RIFT) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<23,0)
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_TROPICAMIDE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_TROPICAMIDE) > 0 then
					dmg = dmg * math.max(0.05,(((player.Position - ent.Position):Length() - 100)/100))
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_GUPPYS_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_GUPPYS_EYE) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<19,0)
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_GLITCHED_CROWN) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_GLITCHED_CROWN) > 0 then
					if ent.FrameCount % 10 == 1 then
						for u,v in pairs(item.tear_flag_buff) do
							if math.random(1000) > 700 then 
								ent.TearFlags = ent.TearFlags | v
								ent.Color = auxi.AddColor(ent.Color,item.tear_color_buff[u] or Color(1,1,1,1),0.3,0.7)
							else
								ent.TearFlags = ent.TearFlags & (~v)
							end
						end
					end
				end
				if player:HasCollectible(CollectibleType.COLLECTIBLE_GLASS_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_GLASS_EYE) > 0 then
					local n_entity = Isaac.GetRoomEntities()
					local n_proj = auxi.getothers(n_entity,9)
					for u,v in pairs(n_proj) do
						if (v.Position - ent.Position):Length() < 20 then
							v = v:ToProjectile()
							local q = Isaac.Spawn(2,0,0,v.Position,-v.Velocity,nil):ToTear()
							local s2 = v:GetSprite()
							local s3 = q:GetSprite()
							s3:Load(s2:GetFilename(),true)
							s3:Play(s2:GetAnimation(),true)
							s3.Color = s2.Color
							s3.Scale = s2.Scale
							q.Height = v.Height
							q.FallingSpeed = v.FallingSpeed
							q.FallingAcceleration = v.FallingAccel
							v:Remove()
						end
					end
				end
				if player:HasCollectible(enums.Items.Assassin_s_Eye) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Assassin_s_Eye) > 0 then
					d.is_assassin = true
				end
				if player:HasCollectible(enums.Items.Colorblindness) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Colorblindness) > 0 then
					ent.TearFlags = ent.TearFlags | BitSet128(1<<0,0)
				end
				if player:HasCollectible(enums.Items.Wavering_Eyes) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Wavering_Eyes) > 0 then
					d.should_count_waver_eye = true
				end
				ent.CollisionDamage = dmg
			end
		end
		d.pareidolia_flush = (d.pareidolia_flush or 5) - 1
		if d.pareidolia_flush <= 0 then ent:Remove() end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,
Function = function(_,ent,col,low)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_pareidolia_tear then
		local player = auxi.check_spawner_player(ent) or Game():GetPlayer(0)
		if d.pareidolia_id and d.pareidolia_id == 0 then
			if d.pareidolia_deadeye == nil then
				if player:HasCollectible(CollectibleType.COLLECTIBLE_DEAD_EYE) or player:GetEffects():GetCollectibleEffectNum(CollectibleType.COLLECTIBLE_DEAD_EYE) > 0 then
					player:AddDeadEyeCharge()
					d.pareidolia_deadeye = true
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_pareidolia_laser then
		local s = ent:GetSprite()
		ent.Radius = ent.Radius + (d.radius_vel or 0)
		d.radius_vel = math.max(0,(d.radius_vel or 0) + (d.radius_acc or -1))
	end
end,
})

if EID then
	EID:addDescriptionModifier("qing_item_sync"..tostring(item.entity), function(desc) local ret = auxi.have_player_has_collectible(item.entity) return ret end, function(desc)
		local tp = desc.ObjType
		local vr = desc.ObjVariant
		local st = desc.ObjSubType
		if (tp == 5 and vr == 100 and item.description[st]) then
			local info = item.description[st].desc
			if (info) then
				info = "#"..info
				local repl = "#{{Collectible"..tostring(item.entity).."}} "
				info = string.gsub(info, "#", repl)
				EID:appendToDescription(desc, info)
			end
		end
		return desc
	end)
end

return item