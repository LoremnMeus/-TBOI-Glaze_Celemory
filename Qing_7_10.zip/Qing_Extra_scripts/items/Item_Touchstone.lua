local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Touchstone,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local d = ent:GetData()
	local player = auxi.check_spawner_player(ent)
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) and d.Ignore_me_flag == nil then
		if ent.TearFlags & BitSet128(0,1<<(123-64)) ~= BitSet128(0,1<<(123-64)) then
			local list = auxi.get_qing_list(player)
			local rnd = math.random(1000)
			if rnd > 750 then
				local gdir = ent.Velocity/10--auxi.ggdir(player,true)
				local q1 = auxi.fire_dowhatknife(nil,ent.Position + ent.Velocity,player.Velocity + gdir * 10,ent.CollisionDamage * 0.8,"StabDown","StabDown2",{source = nil,player = player,tearflags = player.TearFlags,color = player.TearColor,repel = gdir * 10,Entitycollision = EntityCollisionClass.ENTCOLL_ALL,list = list})
				ent.Position = Vector(2000,2000)
				ent:Remove()
				return
			elseif rnd > 600 then
				local gdir = ent.Velocity/10
				local q1 = auxi.fire_dowhatknife(nil,ent.Position + ent.Velocity,ent.Velocity,ent.CollisionDamage * 0.5,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = false,Accerate = math.random(1000)/1000 + 1.5,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = player:HasCollectible(68)})
				ent.Position = Vector(2000,2000)
				ent:Remove()
			end
		end
	end
end,
})

return item