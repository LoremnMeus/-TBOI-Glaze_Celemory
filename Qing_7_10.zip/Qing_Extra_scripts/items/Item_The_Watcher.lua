local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.The_Watcher,
}

local s = Sprite()
s:Load("gfx/the_watcher.anm2", true)
s:Play("Idle",true)
local s2 = Sprite()
s2:Load("gfx/the_watcher.anm2", true)
s2:Play("Shoot",true)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent,offset)
	local room = Game():GetRoom()
	local to_player = Game():GetPlayer(0)
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() then
			if Game():IsPaused() == false then
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
						to_player = player
						if (player.Position - ent.Position):Length() < 100 then
							if ent:GetData().render_alpha == nil then ent:GetData().render_alpha = 0 end
							ent:GetData().render_alpha = math.min(255,ent:GetData().render_alpha + 5)
						else
							if ent:GetData().render_alpha ~= nil and ent:GetData().render_alpha > 0 then
								ent:GetData().render_alpha = math.max(0,ent:GetData().render_alpha - 5)
							end
						end
					end
				end
				if ent:GetData().render_alpha and ent:GetData().render_alpha == 255 and ent:GetData().should_be_shoot ~= true then
					ent:GetData().should_be_shoot = true
					ent:GetData().should_be_shoot_frame = 0
				end
				if ent:GetData().should_be_shoot and ent:GetData().should_be_shoot == true then
					if ent:GetData().should_be_shoot_frame == nil then ent:GetData().should_be_shoot_frame = 0 end
					s2:SetFrame("Shoot",ent:GetData().should_be_shoot_frame)
					s2:Render(Isaac.WorldToScreen(ent.Position + Vector(0,-10)) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					ent:GetData().should_be_shoot_frame = ent:GetData().should_be_shoot_frame + 1
					if ent:GetData().should_be_shoot_frame >= 70 then
						ent:GetData().should_be_shoot = false
						ent:GetData().should_be_shoot_frame = 0
						ent:GetData().render_alpha = 0
					end
					if ent:GetData().should_be_shoot_frame == 35 then
						Game():BombExplosionEffects(ent.Position,to_player.Damage * 5,TearFlags.TEAR_NORMAL,Color(1,1,1,1,-1,-1,-1),to_player,0.5,false,false,0)
					end
				elseif ent:GetData().render_alpha and ent:GetData().render_alpha > 0 then
					s.Color = Color(1,1,1,ent:GetData().render_alpha/255)
					s:Render(Isaac.WorldToScreen(ent.Position + Vector(0,-10) - ent.Velocity * (3 - ent:GetData().render_alpha/100)) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
			if Game():IsPaused() == false then
				if player:GetData().render_alpha == nil then player:GetData().render_alpha = 0 end
				if player.Velocity:Length() > 4 then
					player:GetData().render_alpha = math.max(0,player:GetData().render_alpha - 1)
				else
					player:GetData().render_alpha = math.min(255,player:GetData().render_alpha + 1)
				end
				
				if player:GetData().render_alpha and player:GetData().render_alpha == 255 and player:GetData().should_be_shoot ~= true then
					player:GetData().should_be_shoot = true
					player:GetData().should_be_shoot_frame = 0
				end
				if player:GetData().should_be_shoot and player:GetData().should_be_shoot == true then
					if player:GetData().should_be_shoot_frame == nil then player:GetData().should_be_shoot_frame = 0 end
					s2:SetFrame("Shoot",player:GetData().should_be_shoot_frame)
					s2:Render(Isaac.WorldToScreen(player.Position + Vector(0,-10)) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					player:GetData().should_be_shoot_frame = player:GetData().should_be_shoot_frame + 1
					if player:GetData().should_be_shoot_frame >= 70 then
						player:GetData().should_be_shoot = false
						player:GetData().should_be_shoot_frame = 0
						player:GetData().render_alpha = 0
					end
					if player:GetData().should_be_shoot_frame == 35 then
						Game():BombExplosionEffects(player.Position,player.Damage * 5,TearFlags.TEAR_NORMAL,Color(1,1,1,1,-1,-1,-1),player,0.5,false,true,0)
					end
				else
					s.Color = Color(1,1,1,player:GetData().render_alpha/255)
					s:Render(Isaac.WorldToScreen(player.Position + Vector(0,-10) - player.Velocity * (6 - player:GetData().render_alpha/50)) - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,		--这个效果类似于石头底座。
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if player.MoveSpeed < 1.5 then 
			player.MoveSpeed = 1.5
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	s:Update()
	--s2:Update()
end,
})

return item