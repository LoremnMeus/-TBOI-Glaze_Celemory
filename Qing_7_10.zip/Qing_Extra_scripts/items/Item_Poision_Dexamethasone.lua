local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Dexamethasone,
}

local rng = RNG()

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if save.elses.P_D_rng_counter == nil then save.elses.P_D_rng_counter = 0 end
	if continue then
	else
		save.elses.P_D_rng_counter = 0
	end
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	if save.elses.P_D_rng_counter > 0 then
		for i = 1,save.elses.P_D_rng_counter do
			rng:Next()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	save.elses.P_D_rng_counter = 0
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	if should_count == true then
		delay_buffer.addeffe(function(params)
			local level = Game():GetLevel()
			level:SetStateFlag(LevelStateFlag.STATE_REDHEART_DAMAGED,true)
		end,{},1,true)
	end
end,
})


table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent, amt, flag, source, cooldown)
	if ent:ToPlayer() then
		if amt > 0 then
			local player = ent:ToPlayer()
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				if rng:RandomInt(5) == 1 then
					local level = Game():GetLevel()
					level:SetStateFlag(LevelStateFlag.STATE_REDHEART_DAMAGED,false)
				end
				if save.elses.P_D_rng_counter ~= nil then save.elses.P_D_rng_counter = 0 end
				save.elses.P_D_rng_counter = save.elses.P_D_rng_counter + 1
			end
		else
			
		end
	end
end,
})

return item