local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Tech_9,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local room = Game():GetRoom()
	local d = ent:GetData()
	local player = auxi.check_spawner_player(ent)
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) and d.Ignore_me_flag == nil then
		if ent.TearFlags & BitSet128(0,1<<(123-64)) ~= BitSet128(0,1<<(123-64)) then
			local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity) 
			local rand = math.random(1000)
			if rand > math.max(600,1000 - cnt *60 - player.Luck * 10) then
				local sz = math.random(50) + 20
				local q = player:FireTechXLaser(ent.Position,ent.Velocity * (auxi.random_1() + 1)/2,sz,player,sz/70,player,math.random(1000)/1000 * 0.4 + 0.3)
				q:GetData().is_tech_9_laser = true
				ent.Position = Vector(2000,2000)
				ent:Remove()
				return
			end
			rand = math.random(1000)
			if rand > math.max(800,1000 - cnt * 100 - player.Luck * 5) then
				local q = player:FireTechLaser(ent.Position,1,ent.Velocity,false,false,player,0.75)
				ent.Position = Vector(2000,2000)
				ent:Remove()
				return
			end
			rand = math.random(1000)
			if rand > math.max(900,1000 - cnt * 30 - player.Luck * 3) then
				local q = player:FireTechLaser(ent.Position,1,ent.Velocity,true,false,player,0.75)
				ent.Position = Vector(2000,2000)
				ent:Remove()
				return
			end
			rand = math.random(1000)
			if rand > math.max(500,1000 - cnt * 50 - player.Luck * 35) then
				local q = player:FireTechLaser(ent.Position,1,ent.Velocity,false,true,player,1.3)
				ent.Position = Vector(2000,2000)
				ent:Remove()
				return
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_tech_9_laser then
		if ent.Velocity:Length() < 0.3 then
			ent:Remove()
		end
	end
end,
})

return item