local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	pre_ToCall = {},
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Lofty,
	time_counter = 90,
	mode_vel = {
		[1] = 4,
		[3] = 10,
		[2] = 20,
	},
	mode_addvel = {
		[1] = -0.08,
		[3] = 0.2,
		[2] = -0.4,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	local s = player:GetSprite()
	local d = player:GetData()
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if d["Lofty_counter"] == nil then d["Lofty_counter"] = 0 end
			if (d["Lofty_counter"] > 5) then
				if d["Lofty_sprite"] == nil then 
					d["Lofty_sprite"] = Sprite()
					d["Lofty_sprite"]:Load("gfx/chargebar_Lofty.anm2",true)
					d["Lofty_sprite"]:Play("Charging",true)
				end
				if d["Lofty_counter"] > item["time_counter"] then
					if d["Lofty_sprite"]:IsPlaying("Charging") or d["Lofty_sprite"]:IsFinished("Charging") then
						d["Lofty_sprite"]:Play("StartCharged",true)
					elseif d["Lofty_sprite"]:IsFinished("StartCharged") then
						d["Lofty_sprite"]:Play("Charged",true)
						d["Lofty_active"] = true
					end
					if Game():GetFrameCount() % 2 == 1 then
						d["Lofty_sprite"]:Update()
					end
				else
					d["Lofty_sprite"]:SetFrame("Charging",math.ceil(d["Lofty_counter"]/item["time_counter"] * 100))
				end
				local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Lofty",true)
				d["Lofty_sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
			else
				if d["Lofty_sprite"] == nil then
					d["Lofty_sprite"] = Sprite()
					d["Lofty_sprite"]:Load("gfx/chargebar_Lofty.anm2",true)
					d["Lofty_sprite"]:SetFrame("Disappear",8)
				end
				if d["Lofty_sprite"]:IsPlaying("Disappear") == false and d["Lofty_sprite"]:IsFinished("Disappear") == false then
					d["Lofty_sprite"]:Play("Disappear",true)
				end
				if d["Lofty_sprite"]:IsPlaying("Disappear") == true then
					local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Lofty",true)
					d["Lofty_sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					if Game():GetFrameCount() % 2 == 1 then
						d["Lofty_sprite"]:Update()
					end
				else
					Charging_Bar_holder.remove_charge_bar(player,"Lofty")
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,count)
	if count < 0 then
		Charging_Bar_holder.remove_charge_bar(player,"Lofty")
	end
end,
})

local function start_lofty(player,mode,dmg)
	local d = player:GetData()
	if d.Lofty_holder == nil then d.Lofty_holder = {} end
	local q = Isaac.Spawn(7,5,3,player.Position,Vector(0,0),player):ToLaser()
	q.Parent = player
	q.Radius = 0
	local d2 = q:GetData()
	d2.basic_damage = (dmg or player.Damage)
	q.CollisionDamage = d2.basic_damage
	local s = q:GetSprite()
	s:Load("gfx/to_be_laser_concerter.anm2",true)
	s:ReplaceSpritesheet(0,"gfx/effects/lasers/lofty_brim.png")
	s:LoadGraphics()
	s:Play("LargeRedLaser",true)
	table.insert(d.Lofty_holder,{ent = q,mode = mode,Radius_adder = item.mode_vel[mode],Radius_vel_adder = item.mode_addvel[mode]})
	return q
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local d = player:GetData()
	if d.Lofty_holder ~= nil then
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		local n_proj = auxi.getothers(n_entity,9)
		local tbl = {}
		for u,v in pairs(d.Lofty_holder) do
			local ent = v.ent
			if ent == nil or ent:Exists() == false then 
				table.remove(d.Lofty_holder,u)
			else
				ent.Radius = ent.Radius + (v.Radius_adder or 3)
				v.Radius_adder = math.max(0,(v.Radius_adder or 3) + (v.Radius_vel_adder or 0))
				local s = ent:GetSprite()
				if v.mode == 1 then
					s.Color = Color(1,1,1,math.max(0,math.min(s.Color.A - 0.015,s.Color.A * 0.96)))
				else
					s.Color = Color(1,1,1,math.max(0,math.min(s.Color.A - 0.01,s.Color.A * 0.97)))
				end
				ent.CollisionDamage = (ent:GetData().basic_damage or 7) * s.Color.A
				if s.Color.A < 0.05 then
					ent:Remove()
				end
				if s.Color.A > 0.15 then
					for u2,v2 in pairs(n_proj) do
						if math.abs((v2.Position - ent.Position):Length() - ent.Radius) < 30 then
							v2:Remove()
							table.remove(n_proj,u2)
						end
					end
				end
				if s.Color.A > 0.15 then
					for u2,v2 in pairs(n_enemy) do
						if math.abs((v2.Position - ent.Position):Length() - ent.Radius) < 30 then
							table.insert(tbl,{ent = v2,colorA = s.Color.A,dmg = ent.CollisionDamage})
						end
					end
				end
			end
		end
		for u,v in pairs(tbl) do
			local d2 = v.ent:GetData()
			if d2.Lofty_holdit == nil or d2.Lofty_holdit:Exists() == false then
				local q = start_lofty(player,2,v.dmg)
				local n_t = auxi.fire_nil(v.ent.Position,v.ent.Velocity)
				n_t:GetData().follower = v.ent
				d2.Lofty_holdit = q
				q.Parent = n_t
				q.Position = v.ent.Position
				q.Color = Color(1,1,1,math.max(0.7,v.colorA - 0.1))
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if amt > 0 and auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
		if player and player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = player:GetData().__Index
			if idx then
				if (save.elses["Lofty_limit_"..tostring(idx)] or 1) > 0 then
					start_lofty(player,2,player.Damage * 1.5)
					save.elses["Lofty_limit_"..tostring(idx)] = (save.elses["Lofty_limit_"..tostring(idx)] or 1) - 1
					local e1 = Isaac.Spawn(1000,16,2,player.Position + Vector(0,1),Vector(0,0),player)
					local e2 = Isaac.Spawn(1000,16,1,player.Position + Vector(0,1),Vector(0,0),player)
					e1:GetSprite().Scale = Vector(2,2)
					e2:GetSprite().Scale = Vector(2,2)
					player:SetMinDamageCooldown(cooldown)
					return false
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local ctrlid = player.ControllerIndex
		local d = player:GetData()
		local act = false
		for i = 4,7 do
			if (Input.IsActionTriggered(i,ctrlid)) or (Input.IsActionPressed(i,ctrlid)) then
				act = true
			end
		end
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = d.__Index
			if idx then
				if act == true and (save.elses["Lofty_limit_"..tostring(idx)] or 1) > 0 then
					if d["Lofty_counter"] == nil then d["Lofty_counter"] = 0 end
					d["Lofty_counter"] = d["Lofty_counter"] + 1
				else
					if d["Lofty_active"] == true then
						d["Lofty_active"] = false
						start_lofty(player,1,player.Damage * 2.5)
					end
					d["Lofty_counter"] = 0
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = player:GetData().__Index
			if idx then
				save.elses["Lofty_limit_"..tostring(idx)] = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["Lofty_limit_"..tostring(j)] = 1
		end
	end
end,
})

--l local player = Game():GetPlayer(0); local q = Isaac.Spawn(7,5,3,Vector(200,200),Vector(1,1),player):ToLaser();q.Parent = player; local s = q:GetSprite(); s:Load("gfx/to_be_laser_concerter.anm2",true);s:ReplaceSpritesheet(0,"gfx/effects/lasers/lofty_brimstone2.png");s:LoadGraphics();s:Play("LargeRedLaser",true);
--l local player = Game():GetPlayer(0); local q = Isaac.Spawn(7,3,3,Vector(200,200),Vector(1,1),player):ToLaser();q.Parent = player; local s = q:GetSprite(); print(s:GetAnimation())

return item
