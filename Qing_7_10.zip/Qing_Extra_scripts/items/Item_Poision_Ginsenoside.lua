local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Ginsenoside,
	revive_counter = 95,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if save.elses.has_P_G and save.elses.has_P_G == true and Game():GetFrameCount() > 1 then
		local idx = player:GetData().__Index
		if idx ~= nil then
			if cacheFlag == CacheFlag.CACHE_DAMAGE then
				if save.elses["P_G_Buff_dmg_"..tostring(idx)] then
					player.Damage = player.Damage + save.elses["P_G_Buff_dmg_"..tostring(idx)] * auxi.get_damage_multiplier(player)
				end
			end
			if cacheFlag == CacheFlag.CACHE_FIREDELAY then
				if save.elses["P_G_Buff_tear_"..tostring(idx)] then
					player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay ,auxi.get_mxdelay_multiplier(player) * save.elses["P_G_Buff_tear_"..tostring(idx)])
				end
			end
			if cacheFlag == CacheFlag.CACHE_SHOTSPEED then
				if save.elses["P_G_Buff_shotspeed_"..tostring(idx)] then
					player.ShotSpeed = player.ShotSpeed + save.elses["P_G_Buff_shotspeed_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_RANGE then
				if save.elses["P_G_Buff_range_"..tostring(idx)] then
					player.TearRange = player.TearRange + save.elses["P_G_Buff_range_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_SPEED then
				if save.elses["P_G_Buff_speed_"..tostring(idx)] then
					player.MoveSpeed = player.MoveSpeed + save.elses["P_G_Buff_speed_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_LUCK then
				if save.elses["P_G_Buff_luck_"..tostring(idx)] then
					player.Luck = player.Luck + save.elses["P_G_Buff_luck_"..tostring(idx)]
				end
			end
			if cacheFlag == CacheFlag.CACHE_SIZE then
				if save.elses["P_G_Buff_size_"..tostring(idx)] then
					player.SpriteScale = player.SpriteScale * save.elses["P_G_Buff_size_"..tostring(idx)]
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_G_Buff_dmg_"..tostring(j)] = 0
			save.elses["P_G_Buff_tear_"..tostring(j)] = 0
			save.elses["P_G_Buff_shotspeed_"..tostring(j)] = 0
			save.elses["P_G_Buff_range_"..tostring(j)] = 0
			save.elses["P_G_Buff_speed_"..tostring(j)] = 0
			save.elses["P_G_Buff_luck_"..tostring(j)] = 0
			save.elses["P_G_Buff_size_"..tostring(j)] = 1
			save.elses["P_G_counter"..tostring(j)] = 1
		end
		save.elses.has_P_G = nil
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for j = 1,10 do
		save.elses["P_G_counter"..tostring(j)] = 1
	end
end,
})

local function revive_player(player)
	local heart = player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 0
	local only_bone_hearts = auxi.is_player_only_bone_hearts(player)
	local only_red_hearts = auxi.is_player_only_red_hearts(player)
	if (playerType == PlayerType.PLAYER_THEFORGOTTEN_B) then
        if (player.EntityCollisionClass == 0) then
            player.EntityCollisionClass = EntityCollisionClass.ENTCOLL_ALL
        end
    end
	if (not heart) then
		if(only_bone_hearts) then
			player:AddBoneHearts(1)
		elseif(only_red_hearts) then
			if (player:GetMaxHearts() <= 0) then
				player:AddMaxHearts(2)
			end
			player:AddHearts(2)
		end
		if (player:GetMaxHearts() > 0) then
			if (player:GetHearts() <= 0) then
				player:AddHearts(1-player:GetHearts())
			end
		else
			if (player:GetSoulHearts() <= 0) then
				auxi.add_soul_heart(player, 1)
			end
		end
	end
	player:SetMinDamageCooldown(60)
	player:GetData().has_been_revive = false
end

local function P_G_revive_cover(player)
	local d = player:GetData()
	if (d.P_G_should_revive and d.P_G_should_revive == true) then
		revive_player(player)
		player:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
	end
end

local function P_G_try_revive(player)
	local d = player:GetData()

    if (d.P_G_should_revive and d.P_G_should_revive == true) then
		if (d.P_G_revive_time and d.P_G_revive_counter > d.P_G_revive_time) or (d.P_G_revive_time == nil and d.P_G_revive_counter > item.revive_counter) then
			revive_player(player)

			d.P_G_should_revive = false
			d.P_G_revive_counter = 0
			player:StopExtraAnimation()
			player:ClearEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
			return
		end
    end
end

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = 1,		--保证是最后一个道具
Function = function(_,ent)
	if ent:ToPlayer() then
		local player = ent:ToPlayer()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local d = player:GetData()
			if not player:WillPlayerRevive() and d.has_been_revive ~= true then
				d.has_been_revive = true
				d.P_G_should_revive = true
				d.P_G_animation_to_play = auxi.get_death_animation_to_play(player)
				if d.P_G_animation_to_play == "LostDeath" then
					d.P_G_revive_time = 60
				end
				local heart = player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 0
				local playerType = player:GetPlayerType()
				local isForgottenB = playerType == PlayerType.PLAYER_THEFORGOTTEN_B
				local has_add_heart_container = false
				local only_bone_hearts = auxi.is_player_only_bone_hearts(player)
				local only_red_hearts = auxi.is_player_only_red_hearts(player)
				if (not heart) then
					if(only_bone_hearts) then
						player:AddBoneHearts(1)
					elseif(only_red_hearts) then
						if (player:GetMaxHearts() <= 0) then
							player:AddMaxHearts(2)
							has_add_heart_container = true
						end
						player:AddHearts(2)
					end
				end
				player:Revive()		--假死
				if (isForgottenB) then
					if (not player.Visible) then
						player.Visible = true
					end
				end
				if(only_red_hearts and has_add_heart_container == true) then
					player:AddMaxHearts(-2)
				end
				if (not heart) then
					if (player:GetHearts() > 0) then
						player:AddHearts(-player:GetHearts())
					end
					if (player:GetBoneHearts() > 0) then
						player:AddBoneHearts(-player:GetBoneHearts())
					end
					local soulHearts = player:GetSoulHearts()
					if (player:GetSoulHearts() > 0) then
						auxi.add_soul_heart(player, -player:GetSoulHearts())
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local playerType = player:GetPlayerType()
	local d = player:GetData()
    if (d.P_G_animation_to_play) then
        d.animation_counter = d.animation_counter or -1
        if (d.animation_counter < 0) then
            player:PlayExtraAnimation(d.P_G_animation_to_play)
            d.P_G_animation_to_play = nil
        else
            d.animation_counter = d.animation_counter - 1
        end
    end
    if (d.P_G_should_revive and d.P_G_should_revive == true) then
        player:SetMinDamageCooldown(60)
        player:AddEntityFlags(EntityFlag.FLAG_NO_DAMAGE_BLINK)
		if d.P_G_revive_counter == nil then d.P_G_revive_counter = 0 end
		d.P_G_revive_counter = d.P_G_revive_counter + 1
        if (player:GetSprite():IsEventTriggered("DeathSound")) then
            sound_tracker.PlayStackedSound(SoundEffect.SOUND_ISAACDIES,1,1,false,0,2)
        end
        player.Velocity = Vector(0,0)
        P_G_try_revive(player)
    end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PLAYER_COLLISION, params = nil,
Function = function(_,player, col, low)
	local d = player:GetData()
	if d.P_G_should_revive and d.P_G_should_revive == true then
		return false
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_NPC_COLLISION, params = nil,
Function = function(_,ent, col, low)
	 if (col.Type == 1) and col:ToPlayer() then
        local player = col:ToPlayer()
        local d = player:GetData()
        if d.P_G_should_revive and d.P_G_should_revive == true then
            return false
        end
    end
	return nil
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_INPUT_ACTION, params = InputHook.IS_ACTION_TRIGGERED,
Function = function(_,ent, hook, action)
	if ent ~= nil then
		local player = ent:ToPlayer()
		if player then
			local d = player:GetData()
			if d.P_G_should_revive and d.P_G_should_revive == true then
				if action <= ButtonAction.ACTION_DROP then
					return false
				end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		P_G_revive_cover(player)
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent, amt, flag, source, cooldown)
	if ent:ToPlayer() then
		if auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
			local player = ent:ToPlayer()
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["P_G_counter"..tostring(idx)] == nil then save.elses["P_G_counter"..tostring(idx)] = 1 end
					save.elses["P_G_counter"..tostring(idx)] = save.elses["P_G_counter"..tostring(idx)] + 1
				end
			end
		else
			
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if save.elses.has_P_G == nil then save.elses.has_P_G = true end
		local idx = player:GetData().__Index
		if idx ~= nil then
			if save.elses["P_G_counter"..tostring(idx)] == nil then save.elses["P_G_counter"..tostring(idx)] = 1 end
			local should_update = false
			if player.FrameCount % math.ceil(60/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				local rnd = math.random(100)/100 * 6
				save.elses["P_G_Buff_dmg_"..tostring(idx)] = save.elses["P_G_Buff_dmg_"..tostring(idx)] - 0.0003 * rnd
				should_update = true
			end
			if player.FrameCount % math.ceil(120/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				local rnd = math.random(100)/100 * 4
				save.elses["P_G_Buff_tear_"..tostring(idx)] = save.elses["P_G_Buff_tear_"..tostring(idx)] - 0.001 * rnd
				should_update = true
			end
			if player.FrameCount % math.ceil(150/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				local rnd = math.random(100)/100 * 10
				save.elses["P_G_Buff_range_"..tostring(idx)] = save.elses["P_G_Buff_range_"..tostring(idx)] - 0.0003 * rnd * 40
				should_update = true
			end
			if player.FrameCount % math.ceil(200/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				local rnd = math.random(100)/100 * 3
				save.elses["P_G_Buff_speed_"..tostring(idx)] = save.elses["P_G_Buff_speed_"..tostring(idx)] - 0.001 * rnd
				should_update = true
			end
			if player.FrameCount % math.ceil(200/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				local rnd = math.random(100)/100 * 5
				save.elses["P_G_Buff_luck_"..tostring(idx)] = save.elses["P_G_Buff_luck_"..tostring(idx)] - 0.001 * rnd
				should_update = true
			end
			if player.FrameCount % math.ceil(100/save.elses["P_G_counter"..tostring(idx)]) == 1 then
				save.elses["P_G_Buff_size_"..tostring(idx)] = save.elses["P_G_Buff_size_"..tostring(idx)] * 1.001
				should_update = true
			end
			if should_update then
				player:AddCacheFlags(CacheFlag.CACHE_ALL)
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})


return item