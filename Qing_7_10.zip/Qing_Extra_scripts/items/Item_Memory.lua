local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	myToCall = {},
	ToCall = {},
	entity = enums.Items.Memory,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,collect,rng,player,useFlags,activeSlot,varData)
	if collect == item.entity then
		save.elses.memory_should_change = true
		Game():Darken(1,300)
		Game():ShakeScreen(150)
		return {Remove = true, ShowAnim = true}
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.memory_should_change = false
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GET_COLLECTIBLE, params = nil,
Function = function(_,pool,decrease,seed)
	local should_change = save.elses.memory_should_change
	if should_change and should_change == true and Game():GetFrameCount() > 5 then		--防止EID乱搞
		local rng = RNG()
		rng:SetSeed(seed,1)
		local ret = auxi.get_random_item_that_player_has(nil,rng,false)
		if ret ~= -1 then 
			return ret 
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack =enums.Callbacks.POST_GAIN_COLLECTIBLE, params = nil,
Function = function(_,player,collid,cnt,touched)
	if save.elses.memory_should_change and save.elses.memory_should_change == true and touched == false then
		if player:GetCollectibleNum(collid,true) ~= cnt then
			local n_wisp = auxi.get_wisps(player,item.entity)
			if #n_wisp > 0 then 
				for u,v in pairs(n_wisp) do
					local d = v:GetData()
					local s = v:GetSprite()
					d.Memory_mul = (d.Memory_mul or 0) + cnt
					v.MaxHitPoints = v.MaxHitPoints + (cnt * 2)
					v.HitPoints = v.HitPoints + (cnt * 2)
					d.Memory_scale = (d.Memory_scale or Vector(0,0)) * 1.5
					s.Color = Color(1,1,1,1,1,1,1)
					local e = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.POOF02,2,v.Position,Vector(0,0),nil)
					local s2 = e:GetSprite()
					s2.Scale = s.Scale
					s2.Color = Color(-1,-1,-1,1)
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = nil,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		if save.elses.memory_should_change == true then
			Game():Darken(1,300)
			Game():ShakeScreen(60)
			save.elses.memory_should_change = false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = FamiliarVariant.WISP,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local d = ent:GetData()
		local s = ent:GetSprite()
		local mul = d.Memory_mul or 0
		d.Memory_scale = (d.Memory_scale or Vector(1,1)) * 0.98 + Vector(mul * 0.05 + 1,mul * 0.05 + 1) * 0.02
		s.Scale = d.Memory_scale
		s.Color = auxi.AddColor(s.Color,Color(1,1,1,1),0.98,0.02)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local n_wisp = auxi.get_wisps(nil,item.entity)
	if #n_wisp > 0 then 
		for u,v in pairs(n_wisp) do
			v.HitPoints = v.MaxHitPoints
		end
	end
end,
})

return item