local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Gold_Rush,
	familiar = {Variant = 73,SubType = 0,},
}

local rng = RNG()

function can_change(grid)
	local tp = grid:GetType()
	local coll = grid.CollisionClass
	if (tp == GridEntityType.GRID_ROCK or tp == GridEntityType.GRID_ROCKB or tp == GridEntityType.GRID_ROCKT or tp == GridEntityType.GRID_ROCK_ALT or tp == GridEntityType.GRID_ROCK_SPIKED or tp == GridEntityType.GRID_ROCK_ALT2) then
        if (coll == GridCollisionClass.COLLISION_SOLID or coll == GridCollisionClass.COLLISION_OBJECT) then
            return true;
        end
    end
    return false;
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	if room:IsFirstVisit() then
		local has_ent = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0  then
				has_ent = true
			end
		end
		if has_ent == true then
			local size = room:GetGridSize()
			for i = 0,size - 1 do
				local gent = room:GetGridEntity(i)
				if (gent) then
					local s = gent:GetSprite()
					if s:IsPlaying("big") == false and can_change(gent) == true then
						local rand = rng:RandomInt(60)
						if save.elses.Gold_Rush_rng_counter ~= nil then save.elses.Gold_Rush_rng_counter = 0 end
						save.elses.Gold_Rush_rng_counter = save.elses.Gold_Rush_rng_counter + 1
						if rand < 3 then
							gent:SetType(GridEntityType.GRID_ROCK_GOLD)
							s:SetFrame("foolsgold",rand)
						end
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,rng,pos)
	local room = Game():GetRoom()
	local cnt = 0
	local player = Game():GetPlayer(0)
	for playerNum = 1, Game():GetNumPlayers() do
		local to_player = Game():GetPlayer(playerNum - 1)
		if to_player:HasCollectible(item.entity) or to_player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			cnt = cnt + to_player:GetCollectibleNum(item.entity) + to_player:GetEffects():GetCollectibleEffectNum(item.entity)
			player = to_player
		end
	end
	if cnt > 0 then
		local size = room:GetGridSize()
		for i = 0,size - 1 do
			local gent = room:GetGridEntity(i)
			if (gent) then
				local s = gent:GetSprite()
				if (s:IsPlaying("foolsgold") or s:IsFinished("foolsgold")) and gent:GetType() == GridEntityType.GRID_ROCK_GOLD then
					rng = auxi.rng_for_sake(rng)
					local rnd = rng:RandomInt(10)
					if rnd < 4 + cnt then
						local q = player:AddBlueSpider(room:FindFreeTilePosition(gent.Position,10))
						local s2 = q:GetSprite()
						local d2 = q:GetData()
						d2.is_golden = true
						s2.Color = Color(1,1,1,1,0.8,0.8,0)
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = item.familiar.Variant,
Function = function(_,ent, col, low)
	if ent.Variant == item.familiar.Variant then
		local d = ent:GetData()
		if d.is_golden and d.is_golden == true then
			if col:IsVulnerableEnemy() and col:IsActiveEnemy() and (not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and col:CanShutDoors() == true then
				col:AddMidasFreeze(EntityRef(ent),150)
				d.is_golden = false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	save.elses.Gold_Rush_rng_counter = 0
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if save.elses.Gold_Rush_rng_counter == nil then save.elses.Gold_Rush_rng_counter = 0 end
	if continue then
	else
		save.elses.Gold_Rush_rng_counter = 0
	end
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	if save.elses.Gold_Rush_rng_counter > 0 then
		for i = 1,save.elses.Gold_Rush_rng_counter do
			rng:Next()
		end
	end
end,
})

--l local player = Game():GetPlayer(0);local spider = player:AddBlueSpider(player.Position);local s = spider:GetSprite();spider:SetColor(Color(1,1,1,1,1,1,0),-1,99,false,false);

return item