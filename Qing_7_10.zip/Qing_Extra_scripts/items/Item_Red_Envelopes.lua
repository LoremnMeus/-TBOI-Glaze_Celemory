local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	entity = enums.Items.Red_Envelopes,
	controler = {},
	cent = 0,
	cent1 = 0,
	cent2 = 0,
	low_time = 0,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	for u,v in pairs(item.controler) do
		if v.entity and v.entity:Exists() then
			if v.should_do then
				v.should_do(v.params)
			end
		else
			if v.should_not_do then
				v.should_not_do(v.params)
			end
			table.remove(item.controler,u)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	if item.low_time == 0 and item.cent == 36 then		--眼泪表演
		local room = Game():GetRoom()
		item.low_time = 1
		item.cent = 0
		for i = 1,36 do
			local q = Isaac.Spawn(2,1,0,room:GetCenterPos(),auxi.MakeVector(360/36*i) * 5,player):ToTear()
			q.Height = -60
			q.FallingSpeed = -0.3
			q.FallingAcceleration = - 0.15
			q.TearFlags = q.TearFlags | BitSet128(1<<7,0) | BitSet128(1<<31,0) | BitSet128(1<<38,0) | BitSet128(1,0)
			q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
			table.insert(item.controler,#item.controler + 1,{should_do = function(params)
				if params.ent then 
					local ent = params.ent
					if ent.Height < -200 then
						q.TearFlags = BitSet128(1<<7,0) | BitSet128(1<<31,0) | BitSet128(1,0)
						item.cent1 = item.cent1 + 1
					end
				end
			end,entity = q,params = {ent = q}})
			--q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
		end
		for i = 1,18 do
			local q = Isaac.Spawn(2,6,0,room:GetCenterPos(),auxi.MakeVector(360/18*i + 360/10) * 8,player):ToTear()
			q.Height = -30
			q.FallingSpeed = -0.05
			q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
			q.TearFlags = q.TearFlags | BitSet128(1<<7,0) | BitSet128(1,0)
		end
		for i = 1,9 do
			local q = Isaac.Spawn(2,20,0,room:GetCenterPos(),auxi.MakeVector(360/9*i) * 13,player):ToTear()
			q.Height = -20
			q.FallingSpeed = -0.2
			q.TearFlags = q.TearFlags | BitSet128(1<<8,0) | BitSet128(1,0) | BitSet128(1<<19,0)
			q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
		end
		delay_buffer.addeffe(function(params)
			for i = 1,36 do
				local q = Isaac.Spawn(2,18,0,room:GetCenterPos() + auxi.MakeVector(360/36*i) * 300,- auxi.MakeVector(360/36*i) * 9,player):ToTear()
				q.Height = -60
				q.FallingSpeed = -1
				q.FallingAcceleration = - 0.1
				q.TearFlags = q.TearFlags | BitSet128(1,0) | BitSet128(1<<10,0)
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
			end
		end,{},8)
		for i = 1,360 do
			delay_buffer.addeffe(function(params)
				local q = Isaac.Spawn(2,47,0,room:GetCenterPos() + auxi.MakeVector(360/60*i) * (300 - i/2), -auxi.MakeVector(360/60*i - 45) * 15,player):ToTear()
				q.Height = -120
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.1
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0) | BitSet128(8,0) 
				local q = Isaac.Spawn(2,47,0,room:GetCenterPos() - auxi.MakeVector(360/60*i) * (300 - i/2), auxi.MakeVector(360/60*i + 45) * 15,player):ToTear()
				q.Height = -120
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.1
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0) | BitSet128(8,0) 
			end,{},35 + i)
		end
	elseif item.low_time == 1 and item.cent1 > 3 then		--友情出演
		local room = Game():GetRoom()
		item.low_time = 2
		item.cent1 = 0
		for j = 1, 3 do
			delay_buffer.addeffe(function(params)
			for i = 1,12 do
				local q = Isaac.Spawn(1000,28,0,room:GetCenterPos() + auxi.MakeVector(360/12*i) * (100 + j * 50), Vector(0,0),player):ToEffect()
			end
			end,{},j * 3)
		end
		for i = 1,18 do
			delay_buffer.addeffe(function(params)
				local q = Isaac.Spawn(3,224,0,room:GetCenterPos() + auxi.MakeVector(360/36*i) * 200, Vector(0,0),player)
				local q = Isaac.Spawn(3,224,0,room:GetCenterPos() + auxi.MakeVector(-360/36*i) * 200, Vector(0,0),player)
				table.insert(item.controler,#item.controler + 1,{should_not_do = function(params)
					item.cent2 = item.cent2 + 1
				end,entity = q,params = {ent = q}})
			end,{},20 + i * 5)
		end
	elseif item.low_time == 2 and item.cent2 >= 12 then		--焰火表演
		local room = Game():GetRoom()
		item.low_time = 3
		item.cent2 = 0
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(20),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.control_flip_method = false
		d.control_flip = true
		d.always_sing = true
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(24),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.always_sing = true
		d.control_flip_method = true
		d.control_flip = true
		item.cent = 0
		item.low_time = 0
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(21),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.control_flip_method = false
		d.control_flip = true
		d.always_sing = true
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(23),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.always_sing = true
		d.control_flip_method = true
		d.control_flip = true
		item.cent = 0
		item.low_time = 0
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		for i = 1,6 do
			local q = Isaac.Spawn(1000,71,0,room:GetCenterPos(),auxi.MakeVector(360/6*i + 90) * 10,nil)
			local d = q:GetData()
			local s = q:GetSprite()
			table.insert(item.controler,#item.controler + 1,{should_not_do = function(params)
				for i = 1,12 do
					local q = Isaac.Spawn(2,7,0,params.tg_pos,auxi.MakeVector(360/12 * i) * 6,nil):ToTear()
					q.Height = -60
					q.FallingSpeed = -1
					q.FallingAcceleration = - 0.1
					q.TearFlags = q.TearFlags | BitSet128(1,0) | BitSet128(1<<60,0) | BitSet128(1<<6,0) | BitSet128(1<<8,0)
					q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				end
			end,should_do = function(params)
				if params.ent then
					local ent = params.ent
					local pos = params.tg_pos
					if (ent.Position - pos):Length() > 10 then
						local dir = ent.Position - pos
						local tg_vel = ent.Velocity - dir * 0.05
						ent.Velocity = tg_vel:Normalized() * math.min(3,tg_vel:Length())
					else
						ent.Velocity = ent.Velocity * 0.5
					end
				end
			end,entity = q,params = {ent = q,tg_pos = room:GetCenterPos() + auxi.MakeVector(360/6*i) * 150}})
		end
		for i = 1,120 do
			local q = Isaac.Spawn(2,20,0,room:GetCenterPos() + auxi.MakeVector(360/6*i + 90) * 150,Vector(0,0),nil):ToTear()
			q.Height = -5
			q.FallingSpeed = -8
			q.FallingAcceleration = - 0.1
			q.TearFlags = q.TearFlags | BitSet128(1,0)
			q:GetSprite().Scale = Vector(3,3)
			--q:SetColor(Color(1,0,0,1,1,0,0),-1,99,true,false)
		end
	end
end,
})

--[[
	也许有用的眼泪：
5 火焰
6 暗物质
7 绿毒
18 钻石
20 金币
21 多维
29 骨头
31 针
32 彼列
33 眼球
35、37 血泪
36 小胖子
39 拳头
41 冰
43、44 钥匙
46 蓝火
47、49 剑气
50 婴儿
	也许有用的特效：
28 戳戳
49 红心
71 反重力硫磺火
101 向上的硫磺火
108 小偷盒
113 硫磺火球
126 反重力科技
141 毒云
142 旋涡
147 焰火
148 火焰波
159 小小鬼
162 召唤阵
164 塞壬歌声
180 黑洞
197 死鸟
199 超大镰刀
--]]

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,collect,rng,player,useFlags,activeSlot,varData)
	if collect == item.entity then		--硫磺火表演
		local room = Game():GetRoom()
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(16),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.control_flip_method = false
		d.control_flip = true
		d.always_sing = true
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(28),Vector(0,0),nil)
		local d = q:GetData()
		local s = q:GetSprite()
		s:Play("Prize",true)
		d.always_sing = true
		d.control_flip_method = true
		d.control_flip = true
		item.cent = 0
		item.low_time = 0
		q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
		delay_buffer.addeffe(function(params)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(17),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.always_sing = true
			d.control_flip_method = false
			d.control_flip = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(27),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.always_sing = true
			d.control_flip_method = true
			d.control_flip = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
		end,{},120)
		delay_buffer.addeffe(function(params)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(18),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.always_sing = true
			d.control_flip_method = false
			d.control_flip = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(26),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.always_sing = true
			d.control_flip_method = true
			d.control_flip = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(19),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.control_flip_method = false
			d.control_flip = true
			d.always_sing = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
			local q = Isaac.Spawn(enums.Slots.Bard_beggar.Type,enums.Slots.Bard_beggar.Variant,0,room:GetGridPosition(25),Vector(0,0),nil)
			local d = q:GetData()
			local s = q:GetSprite()
			d.always_sing = true
			d.control_flip_method = true
			d.control_flip = true
			q.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE 
			s:Play("Prize",true)
		end,{},240)
		for i = 106,118,2 do
			local q = Isaac.Spawn(1000,104,0,room:GetGridPosition(i),Vector(0,0),nil)
		end
		delay_buffer.addeffe(function(params)
			for i = 107,117,2 do
				local q = Isaac.Spawn(1000,104,0,room:GetGridPosition(i),Vector(0,0),nil)
			end
		end,{},15)
		delay_buffer.addeffe(function(params)
			for i = 1,4 do
				local q = Isaac.Spawn(7,1,0,room:GetCenterPos(),Vector(0,0),player):ToLaser()
				q.Angle = 360/4*i
				q.MaxDistance = 0
				table.insert(item.controler,#item.controler + 1,{should_do = function(params)
					if params.ent then 
						local ent = params.ent 
						ent.Angle = ent.Angle + 3 * (1 + 2 * ent.MaxDistance/500)
						local d = ent:GetData()
						if d.reflect == nil then
							ent.MaxDistance = ent.MaxDistance + 5
						else
							ent.MaxDistance = ent.MaxDistance - 5
						end
						if ent.MaxDistance >= 400 then
							d.reflect = true
						end
						if d.reflect and d.reflect == true and ent.MaxDistance < 10 then
							ent:Remove()
						end
					end
				end,entity = q,params = {ent = q}})
			end
		end,{},15)
		delay_buffer.addeffe(function(params)
			for j = 1,6 do
				for i = 1,6 do
					local q = Isaac.Spawn(7,2,0,room:GetCenterPos() + auxi.MakeVector(360/6*j) * 100,Vector(0,0),player):ToLaser()
					q.Angle = 360/6*i
					q.MaxDistance = 0
					table.insert(item.controler,#item.controler + 1,{should_do = function(params)
						if params.ent then 
							local ent = params.ent 
							ent.Angle = ent.Angle + 3 * (0.5 + ent.MaxDistance/500)
							local d = ent:GetData()
							if d.reflect == nil then
								ent.MaxDistance = ent.MaxDistance + 5
							else
								ent.MaxDistance = ent.MaxDistance - 5
							end
							if ent.MaxDistance >= 400 then
								d.reflect = true
							end
							if d.reflect and d.reflect == true and ent.MaxDistance < 10 then
								ent:Remove()
								item.cent = item.cent + 1
							end
						end
					end,entity = q,params = {ent = q}})
				end
			end
		end,{},15)
		for i = 1,240 do
			delay_buffer.addeffe(function(params)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos(),auxi.MakeVector(360/60*i) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos(),-auxi.MakeVector(360/60*i) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
			end,{},75 + i * 2)
		end
		for i = 1,150 do
			delay_buffer.addeffe(function(params)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos() + auxi.MakeVector(360/30*i) * 100,auxi.MakeVector(360/60*i+60) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos() - auxi.MakeVector(360/30*i) * 100,-auxi.MakeVector(360/60*i+60) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
			end,{},255 + i * 2)
		end
		for i = 1,150 do
			delay_buffer.addeffe(function(params)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos() + auxi.MakeVector(360/30*i) * 100,-auxi.MakeVector(360/60*i+60) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
				local q = Isaac.Spawn(2,6,0,room:GetCenterPos() - auxi.MakeVector(360/30*i) * 100,auxi.MakeVector(360/60*i+60) * 12,player):ToTear()
				q.Height = -15
				q.FallingSpeed = -0.05
				q.FallingAcceleration = -0.2
				q:SetColor(Color(1,0,0,1,1,0,0),-1,99,false,false)
				q.TearFlags = q.TearFlags | BitSet128(1,0)
			end,{},255 + i * 2)
		end
		return true
	end
end,
})

return item