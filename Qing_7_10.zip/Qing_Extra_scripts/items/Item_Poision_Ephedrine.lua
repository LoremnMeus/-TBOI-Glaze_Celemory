local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	entity = enums.Items.Ephedrine,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_E_pre_effect"..tostring(j)] = nil
			save.elses["P_E_golden_heart_counter"..tostring(j)] = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_E_pre_effect"..tostring(j)] = nil
		end
		save.elses.P_E_counter = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count == true then
		if save.elses.P_E_counter > 0 then save.elses.P_E_counter = math.max(0,save.elses.P_E_counter - 2) end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = nil,
Function = function(_,ent)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count == true then
		local room = Game():GetRoom()
		local d = ent:GetData()
		if ent.Type ~= 5 or (ent.Type == 5 and (ent.Variant == 10 and (ent.SubType == 7 or room:GetType() == RoomType.ROOM_SUPERSECRET)) or (ent.Variant == 100) or (ent.Variant == 110) or (ent.Variant == 41) or (ent.Variant <= 69 and ent.Variant >= 50)) then
		else
			if save.elses.P_E_counter == nil then save.elses.P_E_counter = 0 end
			local lim = save.elses.P_E_counter * 5 + 15
			local rng = RNG()
			rng:SetSeed(ent.DropSeed,0)
			rng = auxi.rng_for_sake(rng)
			local rnd = rng:RandomInt(100)
			if rnd < lim then
				ent:Morph(5,10,7,true,true,false)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = d.__Index
		if idx ~= nil then
			if save.elses["P_E_pre_effect"..tostring(idx)] == nil then
				save.elses["P_E_pre_effect"..tostring(idx)] = true
				local heart = player:GetBoneHearts() + player:GetSoulHearts()/2 + player:GetMaxHearts()/2
				local r_heart = player:GetBoneHearts() + player:GetSoulHearts() + player:GetMaxHearts()
				local only_bone_hearts = auxi.is_player_only_bone_hearts(player)
				local only_red_hearts = auxi.is_player_only_red_hearts(player)
				if heart < 3 then
					if only_bone_hearts then
						player:AddBoneHearts(3 - player:GetBoneHearts())
					elseif only_red_hearts then
						player:AddMaxHearts(6 - r_heart,true)
					else
						auxi.add_soul_heart(player,6 - r_heart)
					end
				end
				if player:CanPickGoldenHearts() then
					player:AddGoldenHearts(3 - player:GetGoldenHearts())
				end
			end
			local golden = player:GetGoldenHearts()
			if save.elses["P_E_golden_heart_counter"..tostring(idx)] == nil then save.elses["P_E_golden_heart_counter"..tostring(idx)] = golden end
			if save.elses["P_E_golden_heart_counter"..tostring(idx)] ~= golden then
				if save.elses["P_E_golden_heart_counter"..tostring(idx)] > golden then
					if save.elses.P_E_counter == nil then save.elses.P_E_counter = 0 end
					save.elses.P_E_counter = save.elses.P_E_counter - golden + save.elses["P_E_golden_heart_counter"..tostring(idx)]
				end
				save.elses["P_E_golden_heart_counter"..tostring(idx)] = golden
			end
			--print(save.elses.P_E_counter)
		end
	end
end,
})

return item