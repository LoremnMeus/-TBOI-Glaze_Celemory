local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local dropping_holder = require("Qing_Extra_scripts.others.Dropping_holder")
local option_index_holder = require("Qing_Extra_scripts.others.Option_Index_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local item_displaying_holder = require("Qing_Extra_scripts.callbacks.item_displaying_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	entity = enums.Items.Book_of_Voice,
	words = {
		zh = {
			[1] = {
				Name = "声之书：",
				Description = function(value) return "还有"..tostring(value).."层" end,
			},
			[2] = {
				Name = "声之书：",
				Description = "谢谢你，现在解脱我吧。",
			},
			[3] = {
				Name = "声之书：",
				Description = "我想要那个...给我！！！！",
			},
			[4] = {
				Name = "不..你怎么能..",
				Description = "",
			},
			[5] = {
				Name = "声之书：",
				Description = "不够..赶快..喂饱我！！！",
			},
		},
		en = {
			[1] = {
				Name = "Book of Voice：",
				Description = function(value) return tostring(value).."levels left!" end,
			},
			[2] = {
				Name = "Book of Voice：",
				Description = "Thank you a lot.Now, free us!",
			},
			[3] = {
				Name = "Book of Voice：",
				Description = "That...Give that to me!",
			},
			[4] = {
				Name = "NO!!YOU CAN'T...",
				Description = "",
			},
			[5] = {
				Name = "Book of Voice：",
				Description = "Not enough..More！！！",
			},
		},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	local ret = true
	if coltyp == item.entity then
		if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		else
			local tg = {}
			if player:GetNumCoins() > 10 then
				table.insert(tg,#tg + 1,{name = "money10",weight = 10})
			elseif player:GetNumCoins() > 5 then
				table.insert(tg,#tg + 1,{name = "money5",weight = 5})
			end
			if player:HasGoldenBomb() == true then
				table.insert(tg,#tg + 1,{name = "goldenbomb",weight = 10})
			end
			if player:HasGoldenKey() == true then
				table.insert(tg,#tg + 1,{name = "goldenkey",weight = 10})
			end
			if player:GetNumBombs() >= 1 then
				table.insert(tg,#tg + 1,{name = "bomb",weight = 5})
			end
			if player:GetNumKeys() >= 1 then
				table.insert(tg,#tg + 1,{name = "key",weight = 5})
			end
			if #tg == 0 then 
				player:AnimateSad()
				local language = Options.Language
				if item.words[language] == nil then language = "en" end
				local word = item.words[language][5]
				local name = word.Name
				local des = word.Description
				item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player)
			else
				local s = Sprite()
				local stag = tg[1]
				local tot_wei = 0
				for u,v in pairs(tg) do
					tot_wei = tot_wei + v.weight
				end
				rng = auxi.rng_for_sake(rng)
				tot_wei = rng:RandomInt(tot_wei) + 1
				for i = 1,#tg do
					tot_wei = tot_wei - tg[i].weight
					if tot_wei <= 0 then
						stag = tg[i]
						break
					end
				end
				local todo = function(player) end
				if stag.name == "money10" then
					s:Load("gfx/005.023_dime.anm2",true)
					todo = function(player) player:AddCoins(-10) sound_tracker.PlayStackedSound(SoundEffect.SOUND_CASH_REGISTER,1,1,false,0,2) end
				elseif stag.name == "money5" then 
					s:Load("gfx/005.022_nickel.anm2",true)
					todo = function(player) player:AddCoins(-5) sound_tracker.PlayStackedSound(SoundEffect.SOUND_CASH_REGISTER,1,1,false,0,2) end
				elseif stag.name == "goldenbomb" then 
					s:Load("gfx/005.043_golden bomb.anm2",true)
					todo = function(player) player:RemoveGoldenBomb() end
				elseif stag.name == "goldenkey" then 
					s:Load("gfx/005.032_golden key.anm2",true)
					todo = function(player) player:RemoveGoldenKey() end
				elseif stag.name == "bomb" then 
					s:Load("gfx/005.041_bomb.anm2",true)
					todo = function(player) player:AddBombs(-1) end
				elseif stag.name == "key" then 
					s:Load("gfx/005.031_key.anm2",true)
					todo = function(player) player:AddKeys(-1) end
				end
				todo(player)
				s:Play("Idle",true)
				player:AnimatePickup(s)
				local q2 = Isaac.Spawn(1000,EffectVariant.CRACK_THE_SKY,0,player.Position + Vector(0,5),Vector(0,0),player):ToEffect()
				q2.CollisionDamage = 0
				local s2 = q2:GetSprite()
				s2.Color = Color(-2,-2,-2,2,-2,-2,-2)
				s2.Scale = Vector(1.5,1)
				local language = Options.Language
				if item.words[language] == nil then language = "en" end
				local word = item.words[language][3]
				local name = word.Name
				local des = word.Description
				item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player)
				if save.elses.Book_of_Voice == nil then save.elses.Book_of_Voice = 0 end
				delay_buffer.addeffe(function(params)
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_SATAN_STOMP,1,1.2 + math.random(1000)/1000 * 0.6,false,math.random(3) - 2,2)
				end,{},math.random(3))
				delay_buffer.addeffe(function(params)
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_SATAN_RISE_UP,1,1.2 + math.random(1000)/1000 * 0.6,false,math.random(3) - 2,2)
				end,{},math.random(3))
				save.elses.Book_of_Voice = math.min(15,save.elses.Book_of_Voice + 1)
				if auxi.should_spawn_wisp(player,useFlags) then
					player:AddWisp(item.entity,player.Position,false,false)
				end
			end
		end
		ret = false
		return ret
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if collid == item.entity and count < 0 then
		local language = Options.Language
		if item.words[language] == nil then language = "en" end
		local word = item.words[language][4]
		local name = word.Name
		local des = word.Description
		delay_buffer.addeffe(function(params)
			item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player)
		end,{},30)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = 5,
Function = function(_,ent)
	ent = ent:ToPickup()
	local room = Game():GetRoom()
	if ent and ent.Variant == 100 and ent.SubType == item.entity then
		local ndx = option_index_holder.find_a_new_index()
		if save.elses.Book_of_Voice == nil then save.elses.Book_of_Voice = 0 end
		for i = 1,4 + save.elses.Book_of_Voice do
			local q = Isaac.Spawn(5,100,0,room:FindFreePickupSpawnPosition(ent.Position,10,true),Vector(0,0),nil):ToPickup()
			q:ClearEntityFlags(EntityFlag.FLAG_ITEM_SHOULD_DUPLICATE)
			q.OptionsPickupIndex = ndx
		end
		save.elses.Book_of_Voice = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,rng,pos)
	local check = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) then
			check = true
		end
	end
	if check then 
	else
		if (save.elses.Book_of_Voice_level or 0) > 0 then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				player:AnimateSad()
			end
		end
		save.elses.Book_of_Voice_level = 0
		save.elses.Book_of_Voice_level_room = 1
	end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local n_wisp = auxi.get_wisps(player,item.entity)
		for u,v in pairs(n_wisp) do
			local rng = v:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			if rng:RandomInt(1000) > 750 then
				for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   
					if player:GetActiveItem(slot) > 0 then 
						local collid = player:GetActiveItem(slot)
						local col = Isaac.GetItemConfig():GetCollectible(collid)
						if player:GetActiveCharge(slot) > 0 and col.MaxCharges <= 12 then
							player:SetActiveCharge(player:GetActiveCharge(slot) + player:GetBatteryCharge(slot) - 1, slot)
						elseif player:GetActiveCharge(slot) > 0 then
							player:SetActiveCharge(0,slot)
						end
						local d = v:GetData()
						d.voice_mul = (v:GetData().voice_mul or 0) + 1
						d.voice_scale = d.voice_scale * 1.5
						local e = Isaac.Spawn(EntityType.ENTITY_EFFECT,EffectVariant.POOF02,2,v.Position,Vector(0,0),nil)
						local s = e:GetSprite()
						s.Color = Color(0.4,0.4,1,1)
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_BLACK_POOF,1,1,false,0,2)
						break
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = nil,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local d = ent:GetData()
		local s = ent:GetSprite()
		local mul = d.voice_mul or 0
		d.voice_scale = (d.voice_scale or Vector(1,1)) * 0.98 + Vector(mul * 0.2 + 1,mul * 0.2 + 1) * 0.02
		s.Scale = d.voice_scale
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = nil,
Function = function(_,ent)
	if ent.Type == 3 and ent.Variant == FamiliarVariant.WISP and ent.SubType == item.entity then
		local room = Game():GetRoom()
		local d = ent:GetData()
		local mul = d.voice_mul or 0
		if mul == 0 and math.random(1000) > 800 then mul = 1 end
		local ndx = option_index_holder.find_a_new_index()
		for i = 1,mul do
			local q = Isaac.Spawn(5,0,0,room:FindFreePickupSpawnPosition(ent.Position,10,true),Vector(0,0),player):ToPickup()
			q:ClearEntityFlags(EntityFlag.FLAG_ITEM_SHOULD_DUPLICATE)
			q.OptionsPickupIndex = ndx
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:IsExtraAnimationFinished() then
		for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do   
			if (player:GetActiveItem(slot) == item.entity) then
				if player:GetActiveCharge(slot) >= 2 then
					player:SetActiveCharge(player:GetBatteryCharge(slot), slot)
					player:UseActiveItem(item.entity,4,slot)
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.Book_of_Voice = 0
		save.elses.Book_of_Voice_level = 0
		save.elses.Book_of_Voice_level_room = 0
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	if save.elses.Book_of_Voice_level_room ~= 1 then
		local check = false
		local player = Game():GetPlayer(0)
		for playerNum = 1, Game():GetNumPlayers() do
			local t_player = Game():GetPlayer(playerNum - 1)
			if t_player:HasCollectible(item.entity) then
				player = t_player
				check = true
			end
		end
		if check then
			local language = Options.Language
			if item.words[language] == nil then language = "en" end
			local room = Game():GetRoom()
			save.elses.Book_of_Voice_level = save.elses.Book_of_Voice_level + 1
			if save.elses.Book_of_Voice_level == 3 then
				local q = Isaac.Spawn(5,300,41,room:FindFreePickupSpawnPosition(player.Position,10,true),Vector(0,0),nil):ToPickup()
				save.elses.Book_of_Voice_level = 0
				local word = item.words[language][2]
				local name = word.Name
				local des = word.Description
				delay_buffer.addeffe(function(params)
					item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player)
				end,{},30)
			elseif save.elses.Book_of_Voice_level <= 2 then
				local word = item.words[language][1]
				local name = word.Name
				local des = word.Description(3 - save.elses.Book_of_Voice_level)
				delay_buffer.addeffe(function(params)
					item_displaying_holder.check_and_description("ItemDesc",item.entity,name,des,player)
				end,{},30)
			end
		end
	end
	save.elses.Book_of_Voice_level_room = 0
end,
})

return item