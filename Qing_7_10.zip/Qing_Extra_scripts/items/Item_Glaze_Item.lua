local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local ui = require("Qing_Extra_scripts.auxiliary.ui")

local item = {
	ToCall = {},
	entity = enums.Items.It_s_a_trick,
	delay_time = nil,
}

local gl_s = Sprite()
local frame = 0
gl_s:Load("gfx/glazed_item.anm2", true)
gl_s:Play("Idle",true)
local gl_s_2 = Sprite()
local frame = 0
gl_s_2:Load("gfx/glazed_item.anm2", true)
gl_s_2:Play("Idle",true)
gl_s_2.Scale = Vector(0.5,0.5)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GET_COLLECTIBLE, params = nil,
Function = function(_,coltyp,pooltyp,decrease,seed)
	if coltyp == item.entity then
		if Game():GetFrameCount() > 3 and (item.delay_time ~= nil and Game():GetFrameCount() > item.delay_time + 3) then
			--print(item.delay_time)
			local rng = RNG()
			rng:SetSeed(seed,0)
			rng = auxi.rng_for_sake(rng)
			local trk = Game():GetItemPool():GetCollectible(pooltyp, true, seed)
			local player = Game():GetPlayer(0)
			if pooltyp ~= 6 then
				for i = 1,10 do
					if Isaac.GetItemConfig():GetCollectible(trk).Type == ItemType.ITEM_ACTIVE then
						trk = Game():GetItemPool():GetCollectible(pooltyp, true,rng:Next())
					else
						break
					end
				end
			else
				trk = 584
			end
			if Isaac.GetItemConfig():GetCollectible(trk).Type == ItemType.ITEM_ACTIVE then
				save.elses.glazed_trick = 32
			else
				save.elses.glazed_trick = trk
			end
			if EID then
				local language = "en_us"
				if EID.Config["Language"] then
					language = EID.Config["Language"]
					if language == "auto" then		--什么时候新加的！！！
						language = Options and EID.LanguageMap[Options.Language] or "en_us"
					end
				end
				local tg = nil
				if tg == nil and EID.descriptions[language] and EID.descriptions[language].collectibles then tg = EID.descriptions[language].collectibles[save.elses.glazed_trick] end
				if tg == nil and EID.descriptions[language] and EID.descriptions[language].custom then tg = EID.descriptions[language].custom["5.100." ..tostring(save.elses.glazed_trick)] end
				if tg == nil and EID.descriptions["en_us"] and EID.descriptions["en_us"].custom then tg = EID.descriptions["en_us"].custom["5.100." ..tostring(save.elses.glazed_trick)] end
				if tg == nil then tg = {tostring(save.elses.glazed_trick),"Unknown Item","Unknown Item Has Been Found, Please contact Meus!"} end
				if tg ~= nil then
					EID.descriptions[language].custom["5.100." .. item.entity] = tg
					EID.descriptions[language].collectibles[item.entity] = tg
				end
			end
			--print(save.elses.glazed_trick)
		else
			
		end
	end
end,
})

--l local trk = 33;local rng = RNG();rng:SetSeed(1,0);for i = 1,10 do if Isaac.GetItemConfig():GetCollectible(trk).Type == ItemType.ITEM_ACTIVE then trk = Game():GetItemPool():GetCollectible(6, true,rng:Next()); print(trk); end; end;
--l local player = Game():GetPlayer(0);local effe = player:GetEffects();effe:AddTrinketEffect(88,false);print(Game():GetItemPool():GetCollectible(6, false, 1));effe:RemoveTrinketEffect(88)

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_RENDER, params = 100,
Function = function(_,pickup)
	if pickup.Variant == 100 and pickup.SubType == item.entity then
		if auxi.isBlindPickup(pickup) == false then
			if pickup:GetData().has_render ~= true then
				local s = pickup:GetSprite()
				s:ReplaceSpritesheet(1, Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
				s:LoadGraphics()
				pickup:GetData().has_render = true
				if pickup:IsShopItem() then
					pickup:GetData().pre_autoupdateprice = pickup.AutoUpdatePrice
					pickup.AutoUpdatePrice = false
				end
			end
			if pickup:IsShopItem() and pickup:GetData().pre_autoupdateprice ~= nil then
				if pickup.Price < 0 then
					local price = - Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).DevilPrice
					for playerNum = 1, Game():GetNumPlayers() do
						local player = Game():GetPlayer(playerNum - 1)
						if player:HasTrinket(TrinketType.TRINKET_YOUR_SOUL) then
							price = -6
						end
					end
					if price ~= -6 then
						for playerNum = 1, Game():GetNumPlayers() do
							local player = Game():GetPlayer(playerNum - 1)
							if player:HasTrinket(TrinketType.TRINKET_JUDAS_TONGUE) then
								price = -1
							end
						end
						local player = Game():GetPlayer(0)
						if(price == -1 or price == -2) and player:GetMaxHearts() + player:GetBoneHearts() == 0 or auxi.is_soul_player(player) == true then
							price = -3
						end
						if price == -2 and player:GetMaxHearts() + player:GetBoneHearts() == 2 then
							price = -4
						end
					end
					pickup.Price = price
				end
			end
		end
	else
		pickup:GetData().has_render = false
		if pickup:GetData().pre_autoupdateprice ~= nil then
			pickup.AutoUpdatePrice = pickup:GetData().pre_autoupdateprice
			pickup:GetData().pre_autoupdateprice = nil
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if Game():IsPaused() == false then
		frame = frame + 1
	else
		frame = frame - 1
	end
	if frame > 47 then frame = 0 end
	if frame < 0 then frame = 48 end
	local player = Game():GetPlayer(0)
	local act = player:GetActiveItem(1)
	if act and act == item.entity then
		--print(Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
		gl_s_2:ReplaceSpritesheet(0, Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
		gl_s_2:LoadGraphics()
		local pos = ui.UIActivePos(0,false,true)
		gl_s_2:SetFrame(frame)
		gl_s_2:Render(pos,Vector(0,0),Vector(0,0))
	end
	if Game():GetNumPlayers() > 1 then
		local player = Game():GetPlayer(1)
		if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
			local act = player:GetActiveItem(1)
			if act and act == item.entity then
				--print(Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
				gl_s_2:ReplaceSpritesheet(0, Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
				gl_s_2:LoadGraphics()
				local pos = ui.UIActivePos(1,false,true)
				gl_s_2:SetFrame(frame)
				gl_s_2:Render(pos,Vector(0,0),Vector(0,0))
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
		item.delay_time = Game():GetFrameCount()
		--print(1)
	else
		item.delay_time = 0
		save.elses.glazed_trick = 32
	end
	if EID then
		local language = "en_us"
		if EID.Config["Language"] then
			language = EID.Config["Language"]
			if language == "auto" then
				language = Options and EID.LanguageMap[Options.Language] or "en_us"
			end
		end
		local tg = nil
		if tg == nil and EID.descriptions[language] and EID.descriptions[language].collectibles then tg = EID.descriptions[language].collectibles[save.elses.glazed_trick] end
		if tg == nil and EID.descriptions[language] and EID.descriptions[language].custom then tg = EID.descriptions[language].custom["5.100." ..tostring(save.elses.glazed_trick)] end
		if tg == nil and EID.descriptions["en_us"] and EID.descriptions["en_us"].custom then tg = EID.descriptions["en_us"].custom["5.100." ..tostring(save.elses.glazed_trick)] end
		if tg == nil then tg = {tostring(save.elses.glazed_trick),"Unknown Item","Unknown Item Has Been Found, Please contact Meus!"} end
		if tg ~= nil then
			EID.descriptions[language].custom["5.100." .. item.entity] = tg
			EID.descriptions[language].collectibles[item.entity] = tg
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.delay_time = nil
	--print(3)
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Qing_HelpfulShader" and Game():GetHUD():IsVisible() then
		local player = Game():GetPlayer(0)
		local act = player:GetActiveItem(0)
		if act and act == item.entity then
			--print(Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
			gl_s:ReplaceSpritesheet(0, Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
			gl_s:LoadGraphics()
			local pos = ui.UIActivePos(0,false)
			if (player:HasCollectible(584) and act ~= 584) or (player:HasCollectible(59) and act ~= 59)then
				pos = pos + Vector(0,-4)
			end
			gl_s:SetFrame(frame)
			gl_s:Render(pos,Vector(0,0),Vector(0,0))
		end
		if Game():GetNumPlayers() > 1 then
			local player = Game():GetPlayer(1)
			if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
				local act = player:GetActiveItem(0)
				if act and act == item.entity then
					--print(Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
					gl_s:ReplaceSpritesheet(0, Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName)
					gl_s:LoadGraphics()
					local pos = ui.UIActivePos(1,false)
					if (player:HasCollectible(584) and act ~= 584) or (player:HasCollectible(59) and act ~= 59)then
						pos = pos + Vector(0,-4)
					end
					gl_s:SetFrame(frame)
					gl_s:Render(pos,Vector(0,0),Vector(0,0))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = item.entity,
Function = function(_,coltyp,rng,player,useFlags,activeSlot,customVarData)
	if coltyp == item.entity then
		rng = auxi.rng_for_sake(rng)
		local rnd = rng:RandomInt(20)
		if rnd == 1 then
			player:AddCollectible(save.elses.glazed_trick)
			player:RemoveCollectible(item.entity)
		else
			local effe = player:GetEffects()
			effe:AddCollectibleEffect(save.elses.glazed_trick,true)
		end
		if auxi.should_spawn_wisp(player,useFlags) then
			local rnd = rng:RandomInt(20)
			if rnd == 1 then
				player:AddItemWisp(save.elses.glazed_trick,player.Position,true)
			end
		end
		player:AnimateCollectible(save.elses.glazed_trick,"UseItem", "PlayerPickupSparkle")
		return false
	end
end,
})

--l local player = Game():GetPlayer(0);local effe = player:GetEffects();effe:AddCollectibleEffect(313,true);

return item