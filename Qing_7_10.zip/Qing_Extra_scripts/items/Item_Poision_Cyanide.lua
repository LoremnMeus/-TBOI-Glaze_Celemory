local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Cyanide,
}

local rng = RNG()

function reward(player,count)
	local idx = player:GetData().__Index
	for i = 1,count do
		local tg = {}
		if save.elses["P_C_Buff_dmg_"..tostring(idx)] == nil then
			save.elses["P_C_Buff_dmg_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "dmg",weight = 5})
		if save.elses["P_C_Buff_tear_"..tostring(idx)] == nil then
			save.elses["P_C_Buff_tear_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "tear",weight = 4})
		if save.elses["P_C_Buff_range_"..tostring(idx)] == nil then
			save.elses["P_C_Buff_range_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "range",weight = 7})
		if save.elses["P_C_Buff_speed_"..tostring(idx)] == nil then
			save.elses["P_C_Buff_speed_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "speed",weight = 7})
		if save.elses["P_C_Buff_luck_"..tostring(idx)] == nil then
			save.elses["P_C_Buff_luck_"..tostring(idx)] = 0
		end
		table.insert(tg,#tg + 1,{name = "luck",weight = 7})
		local stag = tg[1]
		local tot_wei = 0
		for u,v in pairs(tg) do
			tot_wei = tot_wei + v.weight
		end
		tot_wei = rng:RandomInt(tot_wei) + 1
		for i = 1,#tg do
			tot_wei = tot_wei - tg[i].weight
			if tot_wei <= 0 then
				stag = tg[i]
				break
			end
		end
		if stag.name == "dmg" then
			save.elses["P_C_Buff_dmg_"..tostring(idx)] = save.elses["P_C_Buff_dmg_"..tostring(idx)] + 1
		elseif stag.name == "tear" then
			save.elses["P_C_Buff_tear_"..tostring(idx)] = save.elses["P_C_Buff_tear_"..tostring(idx)] + 1
		elseif stag.name == "range" then
			save.elses["P_C_Buff_range_"..tostring(idx)] = save.elses["P_C_Buff_range_"..tostring(idx)] + 1
		elseif stag.name == "luck" then
			save.elses["P_C_Buff_luck_"..tostring(idx)] = save.elses["P_C_Buff_luck_"..tostring(idx)] + 1
		elseif stag.name == "speed" then
			save.elses["P_C_Buff_speed_"..tostring(idx)] = save.elses["P_C_Buff_speed_"..tostring(idx)] + 1
		end
	end
	player:AddCacheFlags(CacheFlag.CACHE_ALL)
	player:GetData().should_evaluate_on_update_once = true
end

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_CURSE_EVAL, params = nil,
Function = function(_,curse)
	local level = Game():GetLevel()
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count then
		local cnt = auxi.Count_Flags(curse)
		local new_cnt = rng:RandomInt(3) + 2
		local tgs = {}
		for i = 0,6 do
			if curse & (1<<i) ~= (1<<i) then
				if i == 4 then
					local rnd = rng:RandomInt(4)
					if rnd == 1 and auxi.has_difficult_player() == false then
						table.insert(tgs,#tgs + 1,{id = i,})
					end
				elseif i == 1 then
					if level:CanStageHaveCurseOfLabyrinth(level:GetStage()) then
						table.insert(tgs,#tgs + 1,{id = i,})
					end
				else
					table.insert(tgs,#tgs + 1,{id = i,})
				end
			end
		end
		for i = 1,new_cnt do
			if #tgs > 0 then
				local tg = rng:RandomInt(#tgs) + 1
				curse = curse | (1<<(tgs[tg].id))
				table.remove(tgs,tg)
			end
		end
		return curse
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local idx = player:GetData().__Index
	if idx ~= nil then
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			if save.elses["P_C_Buff_dmg_"..tostring(idx)] then
				player.Damage = player.Damage + save.elses["P_C_Buff_dmg_"..tostring(idx)] * auxi.get_damage_multiplier(player) * 0.5
			end
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			if save.elses["P_C_Buff_tear_"..tostring(idx)] then
				player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay , auxi.get_mxdelay_multiplier(player) * save.elses["P_C_Buff_tear_"..tostring(idx)] * 0.5)
			end
		end
		if cacheFlag == CacheFlag.CACHE_RANGE then
			if save.elses["P_C_Buff_range_"..tostring(idx)] then
				player.TearRange = player.TearRange + save.elses["P_C_Buff_range_"..tostring(idx)] * 20
			end
		end
		if cacheFlag == CacheFlag.CACHE_SPEED then
			if save.elses["P_C_Buff_speed_"..tostring(idx)] then
				player.MoveSpeed = player.MoveSpeed + save.elses["P_C_Buff_speed_"..tostring(idx)] * 0.1
			end
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			if save.elses["P_C_Buff_luck_"..tostring(idx)] then
				player.Luck = player.Luck + save.elses["P_C_Buff_luck_"..tostring(idx)] * 0.5
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_C_Buff_dmg_"..tostring(j)] = 0
			save.elses["P_C_Buff_tear_"..tostring(j)] = 0
			save.elses["P_C_Buff_range_"..tostring(j)] = 0
			save.elses["P_C_Buff_speed_"..tostring(j)] = 0
			save.elses["P_C_Buff_luck_"..tostring(j)] = 0
			save.elses["P_C_Should_count"..tostring(j)] = nil
		end
		save.elses.P_C_counter = 1
		rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function()
	rng:SetSeed(Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()),0)
	local total_health = 0
	local tbl = {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = player:GetData().__Index
			if idx then
				save.elses["P_C_Should_count"..tostring(idx)] = true
				total_health = total_health + player:GetSoulHearts() + player:GetHearts() + player:GetBoneHearts() - 1
				table.insert(tbl,{id = idx,count = player:GetSoulHearts() + player:GetHearts() + player:GetBoneHearts() - 1,})
			end
		end
	end
	if total_health > 0 then
		local level = Game():GetLevel()
		local curses = level:GetCurses()
		local cnt = auxi.Count_Flags(curses)
		if save.elses.P_C_counter == nil then save.elses.P_C_counter = 1 end
		local total = cnt + save.elses.P_C_counter
		if total <= total_health then
			save.elses.P_C_counter = save.elses.P_C_counter + 1
			save.elses.P_C_succ = true
			for u,v in pairs(tbl) do
				save.elses["P_C_health_"..tostring(v.id)] = math.min(total,v.count)
				total = total - v.count
			end
		else
			save.elses.P_C_succ = false
			save.elses.P_C_counter = math.max(0,save.elses.P_C_counter - 1)
		end
	end
	for j = 1,10 do
		save.elses["P_C_Buff_dmg_"..tostring(j)] = 0
		save.elses["P_C_Buff_tear_"..tostring(j)] = 0
		save.elses["P_C_Buff_range_"..tostring(j)] = 0
		save.elses["P_C_Buff_speed_"..tostring(j)] = 0
		save.elses["P_C_Buff_luck_"..tostring(j)] = 0
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	local s = player:GetSprite()
	local d = player:GetData()
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local idx = d.__Index
			if idx and save.elses["P_C_Should_count"..tostring(idx)] then
				if d["P_C_sprite"] == nil then 
					d["P_C_sprite_counter"] = 0
					d["P_C_sprite"] = Sprite()
					d["P_C_sprite"]:Load("gfx/Poision_C_Effect.anm2",true)
					d["P_C_sprite"]:Play("Idle")
				end
				d["P_C_sprite"]:Render(room:WorldToScreenPosition(player.Position),Vector(0,0),Vector(0,0))
				if d["P_C_sprite_update"] == nil then
					d["P_C_sprite"]:Update()
					d["P_C_sprite_update"] = true
				else
					d["P_C_sprite_update"] = nil
				end
				if d["P_C_sprite"]:IsFinished("Idle") then
					d["P_C_sprite_counter"] = d["P_C_sprite_counter"] + 1
					if d["P_C_sprite_counter"] > 1 then
						if save.elses.P_C_succ then
							d["P_C_sprite"]:Play("Success",true)
						else
							d["P_C_sprite"]:Play("Fail",true)
						end
					else
						d["P_C_sprite"]:Play("Idle",true)
					end
				end
				if d["P_C_sprite"]:IsFinished("Success") then
					save.elses["P_C_Should_count"..tostring(idx)] = nil
					d["P_C_sprite"] = nil
				elseif d["P_C_sprite"]:IsFinished("Fail") then
					save.elses["P_C_Should_count"..tostring(idx)] = nil
					d["P_C_sprite"] = nil
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local idx = d.__Index
		if idx and d["P_C_sprite"] and save.elses["P_C_Should_count"..tostring(idx)] then
			if d["P_C_sprite"]:IsPlaying("Success") and d["P_C_sprite"]:IsEventTriggered("Finish") then
				local level = Game():GetLevel()
				for i = 1,(save.elses["P_C_health_"..tostring(idx)] or 0) do
					player:TakeDamage(1,DamageFlag.DAMAGE_INVINCIBLE | DamageFlag.DAMAGE_NO_PENALTIES| DamageFlag.DAMAGE_NOKILL |DamageFlag.DAMAGE_ISSAC_HEART | DamageFlag.DAMAGE_NO_MODIFIERS,EntityRef(player),0)
					player:ResetDamageCooldown()
				end
				level:RemoveCurses(-1)
				player:AnimateHappy()
				reward(player,save.elses["P_C_health_"..tostring(idx)])
				save.elses["P_C_health_"..tostring(idx)] = 0
			end
			if d["P_C_sprite"]:IsPlaying("Fail") and d["P_C_sprite"]:IsEventTriggered("Poof") then
				player:AnimateSad()
			end
		end
	end
end,
})

--l local player = Game():GetPlayer(0) for i = 1,3 do player:TakeDamage(1,DamageFlag.DAMAGE_INVINCIBLE | DamageFlag.DAMAGE_NO_PENALTIES| DamageFlag.DAMAGE_NOKILL |DamageFlag.DAMAGE_ISSAC_HEART | DamageFlag.DAMAGE_NO_MODIFIERS,EntityRef(player),0) player:ResetDamageCooldown() end

return item