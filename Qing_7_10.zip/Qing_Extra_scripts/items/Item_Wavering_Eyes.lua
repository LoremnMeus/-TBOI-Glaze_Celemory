local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	pre_ToCall = {},
	ToCall = {},
	entity = enums.Items.Wavering_Eyes,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local idx = player:GetData().__Index
		if idx then
			if save.elses["Wavering_Eyes_"..tostring(idx)] == nil then save.elses["Wavering_Eyes_"..tostring(idx)] = 0 end
			if cacheFlag == CacheFlag.CACHE_FIREDELAY then
				player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay,auxi.get_mxdelay_multiplier(player) * 0.5 * math.sqrt(math.floor(save.elses["Wavering_Eyes_"..tostring(idx)]/3)))
			end
			if cacheFlag == CacheFlag.CACHE_TEARFLAG then
				if save.elses["Wavering_Eyes_"..tostring(idx)] >= 5 then
					player.TearFlags = player.TearFlags | BitSet128(0,1<<(68-64))
				end
				if save.elses["Wavering_Eyes_"..tostring(idx)] >= 8 then
					player.TearFlags = player.TearFlags | BitSet128(1<<2,0)
				end
				if save.elses["Wavering_Eyes_"..tostring(idx)] >= 13 then
					player.TearFlags = player.TearFlags | BitSet128(1<<30,0)
				end
				if save.elses["Wavering_Eyes_"..tostring(idx)] >= 21 then
					player.TearFlags = player.TearFlags | BitSet128(1<<19,0)
				end
			end
			if cacheFlag == CacheFlag.CACHE_TEARCOLOR then
				local mul = math.max(0,math.min(1,math.sqrt(save.elses["Wavering_Eyes_"..tostring(idx)])/10))
				player.TearColor = auxi.AddColor(player.TearColor,Color(0.8,0.3,0.7,1,0.7,0,0.7),-0.5 + 1.5 * (1 - mul),1.5 * mul)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_FIRE_TEAR, params = nil,
Function = function(_,ent)
	local player = auxi.check_spawner_player(ent)
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		local idx = player:GetData().__Index
		if idx then
			local d = ent:GetData()
			local rng = player:GetCollectibleRNG(item.entity)
			rng = auxi.rng_for_sake(rng)
			d.count_waver_eye = true
			local rnd_flg = math.floor(save.elses["Wavering_Eyes_"..tostring(idx)]/2) * 5
			local dir_rnd = rng:RandomInt(rnd_flg * 2 + 1) - rnd_flg
			ent.Velocity = auxi.MakeVector(ent.Velocity:GetAngleDegrees() + dir_rnd) * ent.Velocity:Length()
		end
	end
end,
})

function item.add_waver_eye_charge(player)
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Wavering_Eyes_"..tostring(idx)] == nil then save.elses["Wavering_Eyes_"..tostring(idx)] = 0 end
		save.elses["Wavering_Eyes_"..tostring(idx)] = save.elses["Wavering_Eyes_"..tostring(idx)] + 1
		if save.elses["Wavering_Eyes_r_c"..tostring(idx)] == nil then save.elses["Wavering_Eyes_r_c"..tostring(idx)] = 0 end
		if save.elses["Wavering_Eyes_r_c"..tostring(idx)] > 0 then save.elses["Wavering_Eyes_r_c"..tostring(idx)] = save.elses["Wavering_Eyes_r_c"..tostring(idx)] - 0.3 end
		if save.elses["Wavering_Eyes_"..tostring(idx)] % 3 == 0 then
			player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
		end
		if save.elses["Wavering_Eyes_"..tostring(idx)] == 5 or save.elses["Wavering_Eyes_"..tostring(idx)] == 8 or save.elses["Wavering_Eyes_"..tostring(idx)] == 13 or save.elses["Wavering_Eyes_"..tostring(idx)] == 21 then
			player:AddCacheFlags(CacheFlag.CACHE_TEARFLAG)
		end
		player:AddCacheFlags(CacheFlag.CACHE_TEARCOLOR)
		player:GetData().should_evaluate_on_update_once = true
	end
end

function item.clear_waver_eye_charge(player)
	local idx = player:GetData().__Index
	if idx then
		if save.elses["Wavering_Eyes_r_c"..tostring(idx)] == nil then save.elses["Wavering_Eyes_r_c"..tostring(idx)] = 0 end
		save.elses["Wavering_Eyes_r_c"..tostring(idx)] = save.elses["Wavering_Eyes_r_c"..tostring(idx)] + 1
		if save.elses["Wavering_Eyes_r_c"..tostring(idx)] >= 4 then
			save.elses["Wavering_Eyes_"..tostring(idx)] = 0
			player:AddCacheFlags(CacheFlag.CACHE_TEARCOLOR | CacheFlag.CACHE_TEARFLAG | CacheFlag.CACHE_FIREDELAY)
			player:GetData().should_evaluate_on_update_once = true
			save.elses["Wavering_Eyes_r_c"..tostring(idx)] = 0
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_TEAR_COLLISION, params = nil,
Function = function(_,ent,col,low)
	if ent.SpawnerType == 1 and ent.Parent then
		local player = ent.Parent:ToPlayer()
		if player and col:IsVulnerableEnemy() and col:IsActiveEnemy() then
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local d = ent:GetData()
				if d.count_waver_eye or d.should_count_waver_eye then
					d.count_waver_eye = nil
					d.should_count_waver_eye = nil
					item.add_waver_eye_charge(player)
				end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = nil,
Function = function(_,ent)
	if ent.Type == 2 then
		local d = ent:GetData()
		if d.count_waver_eye and ent.Parent then
			local player = ent.Parent:ToPlayer()
			if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
				item.clear_waver_eye_charge(player)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for i = 1,10 do
			save.elses["Wavering_Eyes_"..tostring(i)] = 0
			save.elses["Wavering_Eyes_r_c"..tostring(i)] = 0
		end
	end
end,
})

return item