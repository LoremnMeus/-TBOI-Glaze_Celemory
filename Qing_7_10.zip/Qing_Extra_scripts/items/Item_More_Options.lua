local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local option_index_holder = require("Qing_Extra_scripts.others.Option_Index_holder")

local item = {
	ToCall = {},
	entity = enums.Items.More_Options___,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count then
		local room = Game():GetRoom()
		if room:IsFirstVisit() then
			local n_entity = Isaac.GetRoomEntities()
			local n_shop_pickups = auxi.getothers(n_entity,5)
			for u,v in pairs(n_shop_pickups) do
				local vv = v:ToPickup()
				if vv:IsShopItem() then
					local q = Isaac.Spawn(5,150,0,room:FindFreePickupSpawnPosition(vv.Position + Vector(-20,0),10,true),Vector(0,0),nil):ToPickup()
					if vv.Price ~= -5 then
						vv.Position = room:FindFreePickupSpawnPosition(vv.Position + Vector(20,0),10,true)
					end
					local ndx = option_index_holder.find_a_new_index()
					q.OptionsPickupIndex = ndx
					vv.OptionsPickupIndex = ndx
					q.AutoUpdatePrice = false
					vv.AutoUpdatePrice = false
					if q.Price > 0 then
						local rng = q:GetDropRNG()
						rng = auxi.rng_for_sake(rng)
						local rnd = rng:RandomInt(math.ceil(q.Price * 0.35)) + 1
						q.Price = q.Price + rnd
					end
					if vv.Price > 0 then
						local rng = vv:GetDropRNG()
						rng = auxi.rng_for_sake(rng)
						local rnd = rng:RandomInt(math.ceil(vv.Price * 0.35)) + 1
						vv.Price = vv.Price + rnd
					end
					if q.Price < 0 and q.Price > -10 and q.Price ~= -5 then
						local rng = q:GetDropRNG()
						rng = auxi.rng_for_sake(rng)
						local rnd = rng:RandomInt(1000)
						if rnd < 350 then
							local price = -2
							for playerNum = 1, Game():GetNumPlayers() do
								local player = Game():GetPlayer(playerNum - 1)
								if player:HasTrinket(TrinketType.TRINKET_YOUR_SOUL) then
									price = -6
								end
							end
							if price ~= -6 then
								local player = Game():GetPlayer(0)
								if(price == -1 or price == -2) and player:GetMaxHearts() + player:GetBoneHearts() == 0 or auxi.is_soul_player(player) == true then
									price = -3
								end
								if price == -2 and player:GetMaxHearts() + player:GetBoneHearts() == 2 then
									price = -4
								end
							end
							q.Price = price
						end
					end
					if vv.Price < 0 and vv.Price > -10 and vv.Price ~= -5 then
						local rng = vv:GetDropRNG()
						rng = auxi.rng_for_sake(rng)
						local rnd = rng:RandomInt(1000)
						if rnd < 350 then
							local price = -2
							for playerNum = 1, Game():GetNumPlayers() do
								local player = Game():GetPlayer(playerNum - 1)
								if player:HasTrinket(TrinketType.TRINKET_YOUR_SOUL) then
									price = -6
								end
							end
							if price ~= -6 then
								local player = Game():GetPlayer(0)
								if(price == -1 or price == -2) and player:GetMaxHearts() + player:GetBoneHearts() == 0 or auxi.is_soul_player(player) == true then
									price = -3
								end
								if price == -2 and player:GetMaxHearts() + player:GetBoneHearts() == 2 then
									price = -4
								end
							end
							vv.Price = price
						end
					end
				end
			end
		end
	end
end,
})

return item