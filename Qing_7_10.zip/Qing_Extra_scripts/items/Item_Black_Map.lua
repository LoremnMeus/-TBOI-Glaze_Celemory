local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.Black_Map,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count == true then
		local level = Game():GetLevel()
		local rooms = level:GetRooms()
		local desc = level:GetCurrentRoomDesc()
		if desc.ListIndex then
			save.elses["black_map"..tostring(desc.ListIndex)] = 2
		end
		for i = 0, rooms.Size do
			local targ = rooms:Get(i)
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and save.elses["black_map"..tostring(targ.ListIndex)] == nil then save.elses["black_map"..tostring(targ.ListIndex)] = 0 end
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and targ.DisplayFlags ~= 5 and save.elses["black_map"..tostring(targ.ListIndex)] == 0 then
				local desc = level:GetRoomByIdx(targ.SafeGridIndex)
				if desc ~= nil and desc.SafeGridIndex >= 0 and desc.ListIndex == targ.ListIndex and desc.DisplayFlags ~= 5 then
					desc.DisplayFlags = 5
					save.elses["black_map"..tostring(targ.ListIndex)] = 1
				end
			end
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and targ.DisplayFlags ~= 0 and save.elses["black_map"..tostring(targ.ListIndex)] == 2 then
				local desc = level:GetRoomByIdx(targ.SafeGridIndex)
				if desc ~= nil and desc.SafeGridIndex >= 0 and desc.ListIndex == targ.ListIndex and desc.DisplayFlags ~= 0 then
					desc.DisplayFlags = 0
				end
			end
		end
		level:UpdateVisibility()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for i = 0,300 do
			save.elses["black_map"..tostring(i)] = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for i = 0,300 do
		save.elses["black_map"..tostring(i)] = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local room = Game():GetRoom()
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
		end
	end
	if should_count then
		local level = Game():GetLevel()
		local desc = level:GetCurrentRoomDesc()
		if desc.ListIndex then
			save.elses["black_map"..tostring(desc.ListIndex)] = 2
		end
		local rooms = level:GetRooms()
		for i = 0, rooms.Size do
			local targ = rooms:Get(i)
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and save.elses["black_map"..tostring(targ.ListIndex)] == nil then save.elses["black_map"..tostring(targ.ListIndex)] = 0 end
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and targ.DisplayFlags ~= 5 and save.elses["black_map"..tostring(targ.ListIndex)] == 0 then
				local desc = level:GetRoomByIdx(targ.SafeGridIndex)
				if desc ~= nil and desc.SafeGridIndex >= 0 and desc.ListIndex == targ.ListIndex and desc.DisplayFlags ~= 5 then
					desc.DisplayFlags = 5
					save.elses["black_map"..tostring(targ.ListIndex)] = 1
				end
			end
			if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 and targ.DisplayFlags ~= 0 and save.elses["black_map"..tostring(targ.ListIndex)] == 2 then
				local desc = level:GetRoomByIdx(targ.SafeGridIndex)
				if desc ~= nil and desc.SafeGridIndex >= 0 and desc.ListIndex == targ.ListIndex and desc.DisplayFlags ~= 0 then
					desc.DisplayFlags = 0
				end
			end
		end
		level:UpdateVisibility()
	end
end,
})

--l local level = Game():GetLevel();local desc = level:GetCurrentRoomDesc();print(desc.ListIndex);


return item