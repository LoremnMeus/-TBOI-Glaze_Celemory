local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	entity = enums.Items.Heroisch,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if save.elses.has_P_H and save.elses.has_P_H == true and Game():GetFrameCount() > 1 then
		local idx = player:GetData().__Index
		if idx ~= nil then
			if cacheFlag == CacheFlag.CACHE_SIZE then
				if save.elses["P_H_Buff_size_"..tostring(idx)] then
					player.SpriteScale = player.SpriteScale * save.elses["P_H_Buff_size_"..tostring(idx)]
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["P_H_Buff_size_"..tostring(j)] = 1
		end
		save.elses.has_P_H = nil
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent, amt, flag, source, cooldown)
	if ent:ToPlayer() then
		if auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
			local player = ent:ToPlayer()
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["P_H_Buff_size_"..tostring(idx)] == nil then save.elses["P_H_Buff_size_"..tostring(idx)] = 1 end
					save.elses["P_H_Buff_size_"..tostring(idx)] = save.elses["P_H_Buff_size_"..tostring(idx)] + 0.07
					player:AddCacheFlags(CacheFlag.CACHE_SIZE)
					player:GetData().should_evaluate_on_update_once = true
				end
			end
		end
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent, amt, flag, source, cooldown)
	if ent:ToPlayer() then
		local player = ent:ToPlayer()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local scale = player.SpriteScale:Length() / math.sqrt(2)
			if source and source.Entity and source.Entity.Type == 9 then
				if scale > 2 then
					local rng = player:GetCollectibleRNG(item.entity)
					rng = auxi.rng_for_sake(rng)
					local rnd = (scale - 2) * 100 + rng:RandomInt(math.ceil(scale * 50))
					if rnd > 250 then
						return false
					end
				end
			end
			if source and source.Entity and source.Entity.Type >= 10 then
				if scale > 15 then
					return false 
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if save.elses.has_P_H == nil then save.elses.has_P_H = true end
	end
end,
})

return item

--l local n_ent = Isaac.GetRoomEntities();for u,v in pairs(n_ent) do if v.Type ~= 1 then v.SpriteScale = Vector(1,0.75);v:AddEntityFlags(EntityFlag.FLAG_RENDER_FLOOR | EntityFlag.FLAG_RENDER_WALL);end end