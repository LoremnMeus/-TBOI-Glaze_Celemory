local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	entity = enums.Items.Fate_s_Draw,
	cards = {},
	g_cards = {},
	i_cards = {},
	runes = {},
	g_runes = {},
	i_runes = {},
}

local should_change_now = false

if true then
	local ic = Isaac.GetItemConfig()
	local sz = ic:GetCards().Size - 1
	local pt = ""
	for i = 1,sz do
		local card = ic:GetCard(i)
		if (card.ID >= 1 and card.ID < 32) or (card.ID >= 42 and card.ID <= 48) or (card.ID >= 51 and card.ID <= 54) or (card.ID >= 56 and card.ID <= 80 and card.ID ~= 78) then
			table.insert(item.cards,#item.cards + 1,card.ID)
			item.i_cards[card.ID] = true
			if card.GreedModeAllowed == true then
				table.insert(item.g_cards,#item.g_cards + 1,card.ID)
			end
		end
		if (card.ID >= 32 and card.ID <= 41) or (card.ID == 55) or (card.ID >= 81 and card.ID <= 97) or (card.ID == enums.Cards.Qing_s_Soul) then
			table.insert(item.runes,#item.runes + 1,card.ID)
			item.i_runes[card.ID] = true
			if card.GreedModeAllowed == true then
				table.insert(item.g_runes,#item.g_runes + 1,card.ID)
			end
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if Game():IsPaused() then
		should_change_now = true
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		if d.F_S_D_counter == nil then d.F_S_D_counter = 0 end
		d.F_S_D_counter = d.F_S_D_counter + 1
		if should_change_now then 
			local rng = player:GetCollectibleRNG(item.entity)
			rng = auxi.rng_for_sake(rng)
			local cnt = player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
			if rng:RandomInt(2) <= cnt - 2 then		--2个的时候有50%概率。3个的时候有100%概率。1个的时候概率为0%。
				should_change_now = false
			end
		end
		if d.F_S_D_counter % 10 == 1 or should_change_now then
			if should_change_now then 
				should_change_now = false 
				d.F_S_D_counter = 2
			end
			for i = 0,3 do
				local card = player:GetCard(i)
				if card and card > 0 and (item.i_cards[card] ~= nil or item.i_runes[card] ~= nil)then
					local rng = player:GetCardRNG(card)
					local tg = item.cards
					if Game():IsGreedMode() then
						if item.i_cards[card] then
							tg = item.g_cards
						else
							tg = item.g_runes
						end
					else
						if item.i_cards[card] then
							tg = item.cards
						else
							tg = item.runes
						end
					end
					local rnd = rng:RandomInt(#tg) + 1
					player:SetCard(i,tg[rnd])
				end
			end
		end
	end
end,
})

return item