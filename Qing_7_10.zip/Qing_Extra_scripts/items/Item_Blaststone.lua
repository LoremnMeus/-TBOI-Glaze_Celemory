local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local Charging_Bar_holder = require("Qing_Extra_scripts.others.Charging_Bar_holder")

local item = {
	ToCall = {},
	myToCall = {},
	entity = enums.Items.Blaststone,
	ls = {},
}

function item.fire_blast_stone(player,dir)
	if player == nil then player = Game():GetPlayer(0) end
	if player:AreControlsEnabled() == false then return end
	if player:IsExtraAnimationFinished() == false or player.Visible == false then return end
	local frdr = player:GetFireDirection()
	if frdr == Direction.NO_DIRECTION then return end
	local d = player:GetData()
	if d.blast_stone_delay == nil then d.blast_stone_delay = 0 end
	if d.blast_stone_delay > 0 then return end
	d.blast_stone_delay = player.MaxFireDelay * 35 + 3
	d.blast_stone_maxdelay = player.MaxFireDelay * 35 + 3
	local vel = player.Velocity/3
	local room = Game():GetRoom()
	if room:IsMirrorWorld() == true and (dir == 4 or dir == 5) then dir = 9 - dir end
	if dir == 4 then vel = vel + Vector(-4,0)
	elseif dir == 5 then vel = vel + Vector(4,0)
	elseif dir == 6 then vel = vel + Vector(0,-4)
	elseif dir == 7 then vel = vel + Vector(0,4) end
	local q = Isaac.Spawn(1000,enums.Entities.Blaststone,0,player.Position+Vector(0,-10),vel,player)
	q:SetColor(player.LaserColor,60,99,true,false)
	sound_tracker.PlayStackedSound(278,1,1,false,0,2)
	player:AddVelocity(-vel:Normalized() * 5)
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = enums.Entities.Blaststone,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	if s:WasEventTriggered("Shoot") == false then
		local n_entity = Isaac.GetRoomEntities()
		local n_enemy = auxi.getenemies(n_entity)
		for u,v in pairs(n_enemy) do
			local dir = ent.Position - v.Position
			if v.Velocity:Length() > 5 then
				if dir:Length() < 100 then
					v.Velocity = (v.Velocity + dir:Normalized()*math.min(2000/dir:Length()/v.Mass,5)):Normalized() * v.Velocity:Length()
				else
					v.Velocity = (v.Velocity + dir:Normalized()*math.min(2000/dir:Length()/v.Mass,math.min(dir:Length()/v.Mass/8,4))):Normalized() * v.Velocity:Length()
				end
			elseif dir:Length() < 100 then
				v:AddVelocity(dir:Normalized()*math.min(2000/dir:Length()/v.Mass,5))
			else
				v:AddVelocity(dir:Normalized()*math.min(2000/dir:Length()/v.Mass,math.min(dir:Length()/v.Mass/8,4)))
			end
			if s:GetFrame() < 37 and (v.Position - ent.Position):Length() < 30 then
				d.first_stop = true
			end
		end
		if ent.Velocity:Length() > 0 then 
			if (d.first_stop == nil or d.first_stop ~= true) then
				ent.Velocity = ent.Velocity:Normalized() * math.min(10,ent.Velocity:Length() * 1.03)
			elseif ent.Velocity:Length() > 0.05 then
				ent.Velocity = ent.Velocity:Normalized() * 0.98
			end
		end
	end

	if s:IsEventTriggered("Shoot") == true then
		local spwn = nil
		if ent.SpawnerEntity then spwn = ent.SpawnerEntity end
		local player = Game():GetPlayer(0)
		if spwn and spwn:ToPlayer() then player = spwn:ToPlayer() end
		local rnd = math.random(4) + 6
		local stag1 = math.random(360)
		local stag2 = 100
		local timeout = math.random(15)+25
		local bonu1 = (math.random(2)*2-3) * (3+math.random(3))
		local bonu2 = 0
		local bonu3 = 0
		local bonu4 = 0.5 + math.random(1000)/1000/4
		local bonu5 = rnd + 5 + math.random(4)
		local dmg = 2
		local tgfl = BitSet128(0,0)
		local col = Color(1,1,1,1)
		if player then 
			dmg = player.Damage / 6
			col = player.LaserColor
			tgfl = player.TearFlags
			if tgfl & BitSet128(1<<17,0) == BitSet128(1<<17,0) then
				tgfl = tgfl ~ BitSet128(1<<17,0)
			end
		end
		for i = 1,3 do
			delay_buffer.addeffe(function(params)
				if ent and ent:Exists() then
					for id = 1,rnd do
						local q = Isaac.Spawn(7,1,0,ent.Position,Vector(0,0),spwn):ToLaser()
						q:SetTimeout(timeout)
						q.CollisionDamage = dmg
						local d2 = q:GetData()
						d2.bonus_angle3 = bonu3
						d2.bonus_angle2 = bonu2
						d2.bonus_angle = bonu1
						d2.start_angle = stag1 + (id-1) * 360/rnd
						d2.start_leng = stag2
						d2.bonus_leng = stag2 * bonu4
						d2.bonus_leng2 = bonu5
						d2.time = 0
						q.Angle = d2.start_angle
						q.MaxDistance = 0
						q.Parent = ent
						q.TearFlags = tgfl
						q:SetColor(col,-1,99,false,false)
						if d.brimstone == nil then
							d.brimstone = {}
						end
						table.insert(d.brimstone,q)
					end
				end
			end,{},(i-1) * 7)
		end
	end
	if s:WasEventTriggered("Shoot") == true then
		if d.brimstone == nil then
			d.brimstone = {}
		end
		if ent.Velocity:Length() > 0.005 then
			ent.Velocity = ent.Velocity * 0.9
		end
		for u,v in pairs(d.brimstone) do
			if v:Exists() then
				local d2 = v:GetData()
				if d2.time == nil then d2.time = 0 end
				d2.time = d2.time + 1
				if d2.bonus_angle2 and d2.bonus_angle and d2.start_angle and d2.bonus_angle3 then
					v.Angle = d2.start_angle + d2.bonus_angle * d2.time + d2.bonus_angle3 * math.sin(math.rad(d2.time * d2.bonus_angle2))
					v.MaxDistance = d2.start_leng * math.min(d2.time/5,1) + d2.bonus_leng * math.sin(math.rad(d2.time * d2.bonus_leng2))
				end
			elseif false then
				local q = Isaac.Spawn(7,1,0,ent.Position,Vector(0,0),spwn):ToLaser()
				q:SetTimeout(math.random(7)+2)
				q.CollisionDamage = 1
				local d2 = q:GetData()
				d2.bonus_angle = math.random(10) - 5
				d2.start_angle = math.random(360)
				d2.should_ignore_modifier = true
				q.Angle = d2.start_angle
				q.Parent = ent
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player,offset)
	local room = Game():GetRoom()
	local s = player:GetSprite()
	local d = player:GetData()
	if (Game():GetRoom():GetRenderMode() ~= RenderMode.RENDER_WATER_REFLECT) then
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if d["blast_stone_maxdelay"] == nil then d["blast_stone_maxdelay"] = player.MaxFireDelay * 35 + 3 end
			local mx_cnt = d["blast_stone_maxdelay"]
			if d["blast_stone_delay"] == nil then d["blast_stone_delay"] = 0 end
			local cnt = mx_cnt + 5 - d["blast_stone_delay"]
			if (cnt > 30) then
				if d["Blaststone_Charge_Sprite"] == nil then 
					d["Blaststone_Charge_Sprite"] = Sprite()
					d["Blaststone_Charge_Sprite"]:Load("gfx/chargebar_Blaststone.anm2",true)
					d["Blaststone_Charge_Sprite"]:Play("Charging",true)
				end
				if cnt > mx_cnt then
					if d["Blaststone_Charge_Sprite"]:IsPlaying("Charging") or d["Blaststone_Charge_Sprite"]:IsFinished("Charging") then
						d["Blaststone_Charge_Sprite"]:Play("StartCharged",true)
					elseif d["Blaststone_Charge_Sprite"]:IsFinished("StartCharged") then
						d["Blaststone_Charge_Sprite"]:Play("Charged",true)
						d["Ingestion2n_active"] = true
					end
					if Game():GetFrameCount() % 2 == 1 then
						d["Blaststone_Charge_Sprite"]:Update()
					end
				else
					d["Blaststone_Charge_Sprite"]:SetFrame("Charging",math.ceil(cnt/math.max(mx_cnt/100,0.001)))
				end
				local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Blaststone",true)
				d["Blaststone_Charge_Sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
			else
				if d["Blaststone_Charge_Sprite"] == nil then
					d["Blaststone_Charge_Sprite"] = Sprite()
					d["Blaststone_Charge_Sprite"]:Load("gfx/chargebar_Blaststone.anm2",true)
					d["Blaststone_Charge_Sprite"]:SetFrame("Disappear",8)
				end
				if d["Blaststone_Charge_Sprite"]:IsPlaying("Disappear") == false and d["Blaststone_Charge_Sprite"]:IsFinished("Disappear") == false then
					d["Blaststone_Charge_Sprite"]:Play("Disappear",true)
				end
				if d["Blaststone_Charge_Sprite"]:IsPlaying("Disappear") == true then
					local pos = Charging_Bar_holder.try_get_charge_bar_pos(player,"Blaststone",true)
					d["Blaststone_Charge_Sprite"]:Render(room:WorldToScreenPosition(player.Position) + pos - Game().ScreenShakeOffset,Vector(0,0),Vector(0,0))
					if Game():GetFrameCount() % 2 == 1 then
						d["Blaststone_Charge_Sprite"]:Update()
					end
				else
					Charging_Bar_holder.remove_charge_bar(player,"Blaststone")
				end
			end
		end
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = nil,
Function = function(_,player,collid,count)
	if collid == item.entity and count < 0 then
		Charging_Bar_holder.remove_charge_bar(player,"Blaststone")
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	 for playerNum = 1, Game():GetNumPlayers() do
        local player = Game():GetPlayer(playerNum - 1)
		local ctrlid = player.ControllerIndex
		local d = player:GetData()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			for i = 4,7 do
				if (false and Input.IsActionTriggered(i,ctrlid)) or (Input.IsActionPressed(i,ctrlid) and input_holder.actionsData[tostring(ctrlid)] and input_holder.actionsData[tostring(ctrlid)][i] and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime and input_holder.actionsData[tostring(ctrlid)][i].ActionHoldTime == 1) then
					if item.ls[ctrlid] and item.ls[ctrlid] == i and item.ls["time"..ctrlid] > 0 then
						item.fire_blast_stone(player,i)
					end
					item.ls[ctrlid] = i
					item.ls["time"..ctrlid] = 10
				end
			end
		end
		if item.ls["time"..ctrlid] == nil then item.ls["time"..ctrlid] = 0 end
		if item.ls["time"..ctrlid] > 0 then item.ls["time"..ctrlid] = item.ls["time"..ctrlid] - 1 end
		if d.blast_stone_delay == nil then d.blast_stone_delay = 0 end
		if d.blast_stone_delay == 1 then 
			player:SetColor(Color(1.0,1.0,1.0,1.0,1,0.0,0.0),5,-1,true,false)
			sound_tracker.PlayStackedSound(171,1,0.8,false,0,2)
		end
		if d.blast_stone_delay > 0 then d.blast_stone_delay = d.blast_stone_delay - 1 end
	end
end,
})

return item