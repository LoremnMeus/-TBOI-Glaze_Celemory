local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local item_displaying_holder = require("Qing_Extra_scripts.callbacks.item_displaying_holder")
local data4 = require("Qing_Extra_scripts.translations.data4")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local ui = require("Qing_Extra_scripts.auxiliary.ui")
local Record_holder = require("Qing_Extra_scripts.others.Record_holder")
local consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	pre_myToCall = {},
	myToCall = {},
	post_myToCall = {},
	entity = enums.Items.Live_Broadcast,
	color_offset = {
		[1] = Color(1,1,1,1),
		[2] = Color(0.4,1,0.8,1),
		[3] = Color(0.4,0.76,0.87,1),
		[4] = Color(0.3,0.38,1,1),
		[5] = Color(0.57,0.38,1,1),
		[6] = Color(0.73,0.34,0.52,1),
		[7] = Color(1,0.54,0.09,1),
		[8] = Color(1,1,0.1,1),
	},
	heat_list = {
		[1] = {delay = 250,bust = 1,steak = 0.02,buff = 0.5,},
		[2] = {delay = 75,bust = 3,steak = 0.1,buff = 0.8,},
		[3] = {delay = 30,bust = 12,steak = 0.25,buff = 1,},
		[4] = {delay = 15,bust = 60,steak = 0.65,buff = 1.5,},
		[5] = {delay = 7,bust = 360,steak = 0.90,buff = 2,},
		[6] = {delay = 5,bust = 2520,steak = 0.98,buff = 5,},
		[7] = {delay = 3,bust = 20160,steak = 0.99,buff = 10,},
	},
	event_list = {			--事件的消散一般总是悄无声息，因此不需要对remove进行处理
		[1] = {								--运气不错
			normal_ret = function()
				local ret = {tp = 5,vr = 1,}
				local rnd =  math.random(1000)
				if rnd > 980 then ret.vr = 2
				elseif rnd > 950 then ret.vr = 3
				elseif rnd > 925 then ret.vr = 4
				elseif rnd > 900 then ret.vr = 5
				elseif rnd > 850 then ret.tp = 3;ret.vr = 4
				end
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(10) + 10
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 5,vr = 1,counter = rnd,})
				hht(nil,rnd)
				if params.typename == "item" then
					local rnd = math.random(3) + 5
					table.insert(buf,{tp = 3,vr = 5,counter = rnd,params = {name = params.itemname,}})
					hht(nil,rnd)
				end
				return true
			end,
		},
		[2] = {								--操作优秀
			normal_ret = function()
				local ret = {tp = 6,}
				return ret
			end,
			on_update = nil,
			on_pickup = nil,
		},
		[3] = {								--运气不佳
			normal_ret = function()
				local ret = {tp = 1,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				if math.random(1000) > 950 then
					local rnd = math.random(3) + 5
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 1,counter = rnd,})
					hht(nil,rnd)
				else
					local rnd = math.random(1) + 1
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 1,counter = rnd,})
					hht(nil,rnd)
				end
				if params.typename == "pill" then
					local rnd = math.random(3)
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 4,vr = 5,counter = rnd,})
					hht(nil,rnd)
				end
				return true
			end,
		},
		[4] = {								--操作不佳
			normal_ret = function()
				local ret = {tp = 1,}
				if math.random(1000) > 800 then 
					ret = {tp = 3,vr = auxi.random_in_table({1,3,4,6,7})}
				end
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				if math.random(1000) > 950 then
					local rnd = math.random(3) + 5
					rnd = math.ceil(buff * rnd)
					for i = 1,rnd do
						table.insert(buf,{tp = 3,vr = auxi.random_in_table({1,3,4,6,7}),counter = 1,})
					end
					hht(nil,rnd)
				else
					local rnd = math.random(1) + 1
					rnd = math.ceil(buff * rnd)
					for i = 1,rnd do
						table.insert(buf,{tp = 3,vr = auxi.random_in_table({1,3,4,6,7}),counter = 1,})
					end
					hht(nil,rnd)
				end
				return true
			end,
		},
		[5] = {								--考试开始
			normal_ret = function()
				local ret = {tp = 8,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				if math.random(1000) > 500 then
					local rnd = math.random(3) + 5
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 8,counter = rnd,})
					hht(nil,rnd)
				else
					local rnd = math.random(1) + 1
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 8,counter = rnd,})
					hht(nil,rnd)
				end
				return true
			end,
		},
		[6] = {								--危机时刻
			normal_ret = function()
				local ret = {tp = 7,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				if params.weigh > 4 then 
					local rnd = math.random(4) + 4
					rnd = math.ceil(buff * rnd)
					table.insert(buf,{tp = 7,counter = rnd,})
					hht(nil,rnd)
				end
			end,
		},
		[7] = {								--开始直播
			normal_ret = function()
				local ret = {tp = 2,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(10) + 10
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 2,counter = rnd,})
				hht(nil,rnd)
				return true
			end,
		},
		[8] = {								--结束直播
			normal_ret = function()
				local ret = {tp = 14,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(15) + 10
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 14,counter = rnd,})
				hht(nil,rnd)
				return true
			end,
		},
		[9] = {								--角色死亡
			normal_ret = function()
				local ret = {tp = 11,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(10) + 10
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 11,counter = rnd,})
				hht(nil,rnd)
				return true
			end,
		},
		[10] = {							--为何不拿
			normal_ret = function()
				local ret = {tp = 5,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(3) + 3
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 5,vr = 1,counter = rnd,})
				hht(nil,rnd)
				if params.typename == "item" then
					local rnd = math.random(5) + 7
					table.insert(buf,{tp = 3,vr = 2,counter = rnd,params = {name = params.itemname,}})
					hht(nil,rnd)
				end
				return true
			end,
		},
		[11] = {							--麦片事件
			normal_ret = function()
				local ret = {tp = 9,vr = auxi.random_in_table({2,3})}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(3)
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 9,vr = 1,counter = rnd,})
				hht(nil,rnd)
				local cnt = 5
				cnt = math.ceil(buff * cnt)
				for i = 1,cnt do
					delay_buffer.addeffe(function(params)
						local rnd = math.random(3)
						table.insert(buf,{tp = 9,vr = auxi.random_in_table({2,3}),counter = rnd,})
						hht(nil,rnd)
					end,{},(i - 0.5) * 10)
				end
				return true
			end,
		},
		[12] = {							--问路事件
			normal_ret = function()
				local ret = {tp = 4,vr = auxi.random_in_table({3,4})}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				local rnd = math.random(2)
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 4,vr = auxi.random_in_table({1,2}),counter = rnd,})
				hht(nil,rnd)
				local cnt = 3
				cnt = math.ceil(buff * cnt)
				for i = 1,cnt do
					delay_buffer.addeffe(function(params)
						local rnd = math.random(3)
						table.insert(buf,{tp = 4,vr = auxi.random_in_table({3,4}),counter = rnd,})
						hht(nil,rnd)
					end,{},(i - 0.5) * 10)
				end
				return true
			end,
		},
		[13] = {							--投喂事件
			normal_ret = function()
				local ret = {tp = 13,vr = 1}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				params = params or {}
				table.insert(buf,{tp = 13,vr = 2,params = {name = params.name,word = params.word,}})
				local rnd = math.random(2)
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 13,vr = 1,counter = rnd,params = {name = params.name,}})
				hht(nil,rnd + 1)
				return true
			end,
		},
		[14] = {							--特殊道具
			normal_ret = function()
				local ret = {tp = 5,vr = 1}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				params = params or {}
				local rnd = math.random(10) + 5
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 15,counter = rnd,params = {name = params.name,}})
				hht(nil,rnd)
				return true
			end,
		},
		[15] = {							--小罗死亡
			normal_ret = function()
				local ret = {tp = 12,}
				return ret
			end,
			on_update = nil,
			on_pickup = function(buf,hht,params,buff)
				params = params or {}
				local rnd = math.random(5) + 2
				rnd = math.ceil(buff * rnd)
				table.insert(buf,{tp = 12,counter = rnd,})
				hht(nil,rnd)
				return true
			end,
		},
		[16] = {							--长期不操作
			normal_ret = function()
				local ret = {tp = 10,}
				return ret
			end,
			on_update = nil,
			on_pickup = nil,
		},
	},
	event_name_list = {
		["GoodLuck"] = 1,
		["GoodOperate"] = 2,
		["BadLuck"] = 3,
		["BadOperate"] = 4,
		["RedKey"] = 5,
		["Dangerous"] = 6,
		["Start"] = 7,
		["End"] = 8,
		["Death"] = 9,
		["Whynot"] = 10,
	},
	event_weigh = {
		100,50,20,10,5,3,3,2,2,2,1,1,1,1,1,
	},
	feed_name = {
		[1] = "小心心",
		[2] = "小花花",
		[3] = "这个好诶",
		[4] = "小电池",
	},
	record_items = {
		[CollectibleType.COLLECTIBLE_GENESIS] = {word = "创",},
		[CollectibleType.COLLECTIBLE_MAGIC_SKIN] = {word = "磨",},
		[CollectibleType.COLLECTIBLE_D100] = {word = "Roll",},
		[CollectibleType.COLLECTIBLE_D4] = {word = "Roll",},
		[CollectibleType.COLLECTIBLE_DAMOCLES] = {word = "达摩",},
		[CollectibleType.COLLECTIBLE_WIRE_COAT_HANGER] = {word = "鸭架",},
		[CollectibleType.COLLECTIBLE_C_SECTION] = {word = "剖",},
		[CollectibleType.COLLECTIBLE_LIBRA] = {word = "风",},
		[CollectibleType.COLLECTIBLE_EDENS_BLESSING] = {word = "玫瑰",},
		[CollectibleType.COLLECTIBLE_R_KEY] = {word = "R",},
	},
	event_buffer = {},
	tp_buffer = {},
	block_map = {},
	focus_entity = enums.Entities.Feeding_gift,
}

if true then
	item.live_sprite = Sprite()
	item.live_sprite:Load("gfx/Live_sign.anm2",true)
	item.live_sprite:Play("Idle",true)
end

local function get_heat(hea)
	hea = hea or save.elses.Live_heat_counter
	return math.ceil(hea/10)
end

local function get_something_from_heat(hea,sth,offset)
	offset = offset or 1
	sth = sth or "delay"
	hea = get_heat(hea)
	local i = math.log(math.max(1,hea))/math.log(10)
	local ii = math.ceil(i)
	local ret = offset
	if math.random(1000)/1000 > ii - i then
		if item.heat_list[ii] then
			ret = item.heat_list[ii][sth]
		end
	else
		if item.heat_list[ii - 1] then
			ret = item.heat_list[ii - 1][sth]
		end
	end
	return ret
end

local function get_fire_bullet_position(word)
	local sz = auxi.get_string_display_length(word or "")
	local uf = ui.GetScreenTopRight()
	local limit = math.ceil(ui.GetScreenCenter().Y * 0.8 / 10)
	local id = math.random(limit)
	if id > limit / 2 then id = math.random(id) end
	--id = 1
	if (item.block_map[id] or -1000) > Game():GetFrameCount() then
		for i = 1,limit do
			if (item.block_map[i] or -1000) < (item.block_map[id] or -1000) then 
				id = i
				if (item.block_map[id] or -1000) <= Game():GetFrameCount() then break end
			end
		end
	end
	local del_pos_x = math.max(0,(item.block_map[id] or -1000) - Game():GetFrameCount()) * 1.5
	--print(del_pos_x .. " " .. sz)
	if del_pos_x < 60 then
		local ret = Vector(del_pos_x + uf.X,uf.Y + (id - 0.5) * 10)
		item.block_map[id] = math.max(item.block_map[id] or -1000,Game():GetFrameCount()) + sz
		--print(item.block_map[id] .. " " .. Game():GetFrameCount() .. " ".. tostring(sz))
		return ret
	else
		return nil
	end
end

local function get_color_by_level(level,rand)
	local p_level = math.ceil((level + 1)/5)
	if p_level > 8 then p_level = 8 end
	if rand then p_level = math.random(p_level) end
	return item.color_offset[p_level]
end

local function get_level_by_popularity(pop)
	pop = pop or math.max(0,save.elses.Live_popularity_counter)
	cnt1 = math.ceil(math.log(pop + 2)/math.log(2))
	if cnt1 > 10 and math.random(1000) > 900 then cnt1 = cnt1 + 20 end
	local rnd = math.max(0,math.min(40,math.random(cnt1)))
	return rnd
end

local function fire_bullet_screen(player,level,language,tp,vr,params)			--10帧可以生成3个字符
	level = level or 0
	local wd = data4.get_a_word(language,tp,vr,params) or ""
	local col = get_color_by_level(level)
	local pos = get_fire_bullet_position(wd)
	if pos == nil then
		return nil
	else
		gui.draw_ch_with_time_to_move_out(pos,Vector(-1.5 - math.random(1000)/1000 * 0,0),wd,nil,nil,col.R,col.G,col.B,math.max(0,math.min(1,((1 - pos.Y / ui.GetScreenCenter().Y) + 0.2))))
		local idx = player:GetData().__Index
		if idx then
			
		end
	end
end

local function hit_heat_burst(cnt1,cnt2)
	cnt1 = cnt1 or 100
	cnt2 = cnt2 or 3
	cnt1 = cnt1 * get_something_from_heat(nil,"bust",1)
	save.elses.Live_popularity_adder = (save.elses.Live_popularity_adder or 0) + cnt1
	save.elses.Live_add_offset = (save.elses.Live_add_offset or 0) + cnt2
end

local function cause_event(tp,weigh,params)
	params = params or {}
	weigh = weigh or math.random(12)
	params.weigh = params.weigh or weigh
	if type(tp) == "string" then tp = item.event_name_list[tp] or 1 end
	local info = item.event_list[tp]
	local buff = get_something_from_heat(nil,"buff",1)
	buff = (math.random(1000)/1000 * 0.3 + 0.85) * buff
	local should_cause = true
	if info.on_pickup then should_cause = info.on_pickup(item.tp_buffer,hit_heat_burst,params,buff) end
	if should_cause then
		table.insert(item.event_buffer,1,{tp = tp,weigh = weigh,params = params})
		if math.random(1000) > math.max(100,950 - weigh * 3 * buff) and params.no_gift ~= true then
			local id = auxi.random_in_table(auxi.GetItemList())
			local col = Isaac.GetItemConfig():GetCollectible(id)
			local info = {}
			if col then info = item_displaying_holder.check_description("UnItem",id,auxi.check_name_data(col.Name),auxi.check_name_data(col.Description),player) end
			local rnd = math.random(math.ceil(buff * 5))
			local rnd_c = math.random(4)
			local room = Game():GetRoom()
			local rnd_work = math.random(5)
			if rnd_c == 4 then rnd = math.random(rnd) end
			for i = 1,rnd do
				local q = Isaac.Spawn(1000,item.focus_entity,0,room:GetRandomPosition(10),Vector(0,0),nil)
				local s = q:GetSprite()
				local d = q:GetData()
				if rnd_work > 1 then
					d.type_state = rnd_c
					s:Play("Idle"..tostring(d.type_state),true)
				end
			end
			local tbl = {name = data4.get_a_description("zh") .. "的" .. info.Name,}
			if rnd_work > 1 then tbl.word = tostring(rnd) .. "个" .. item.feed_name[rnd_c] end
			cause_event(13,10,tbl)
		end
	end
	if #item.event_buffer > 7 then table.remove(item.event_buffer,8) end
end

local function reward(player,tp)
	local ret = false
	local idx = player:GetData().__Index
	if idx then
		if tp == 1 then			--小心心：加幸运
			save.elses["L_B_Buff_luck_"..tostring(idx)] = (save.elses["L_B_Buff_luck_"..tostring(idx)] or 0) + math.random(1000)/1000 * 1 + 1
			player:AddCacheFlags(CacheFlag.CACHE_LUCK)
			player:GetData().should_evaluate_on_update_once = true
			ret = true
		elseif tp == 2 then		--花花：加射速
			save.elses["L_B_Buff_tear_"..tostring(idx)] = (save.elses["L_B_Buff_tear_"..tostring(idx)] or 0) + math.random(1000)/1000 * 1 + 1
			player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY)
			player:GetData().should_evaluate_on_update_once = true
			ret = true
		elseif tp == 3 then		--点赞：攻击力加成
			save.elses["L_B_Buff_dmg_"..tostring(idx)] = (save.elses["L_B_Buff_dmg_"..tostring(idx)] or 0) + math.random(1000)/1000 * 1 + 1
			player:AddCacheFlags(CacheFlag.CACHE_DAMAGE)
			player:GetData().should_evaluate_on_update_once = true
			ret = true
		elseif tp == 4 then		--电池
			for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do
				if player:NeedsCharge(slot) then
					local rnd = math.random(3)
					player:SetActiveCharge(player:GetActiveCharge(slot) + player:GetBatteryCharge(slot) + rnd, slot)
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_ITEMRECHARGE,1,1,false,0,2)
					ret = true
					break
				end
			end
		end
	end
	return ret
end

local function get_normal_pr()
	local ret = {tp = 1}
	if math.random(1000) > 900 then ret = {tp = 2} end
	if math.random(1000) > 900 then ret = {tp = 6} end
	if math.random(1000) > 900 then ret = {tp = 3,vr = auxi.random_in_table({1,4,6})} end
	return ret
end

local function get_pr_from_event(mul)
	mul = mul or 5
	local tbl = {}
	local t_wei = 0
	for i = 1,#item.event_buffer do
		local v = item.event_buffer[i]
		local wei = v.weigh * (item.event_weigh[i] or 1)
		t_wei = t_wei + wei
		table.insert(tbl,{tp = v.tp,weigh = wei,params = v.params,id = i})
	end
	t_wei = math.floor(t_wei)
	if t_wei == 0 then 
	else
		for i = 1,mul do
			local stag = {tp = 1}
			local rnd = math.random(t_wei)
			for i = 1,#tbl do
				local v = tbl[i]
				rnd = rnd - v.weigh
				if rnd <= 0 then
					stag = v
					break
				end
			end
			local id = stag.tp
			if item.event_list[id] == nil then id = 1 end
			local ret = item.event_list[id].normal_ret or get_normal_pr()
			if type(ret) == "function" then ret = ret() end
			if item.event_list[id] and item.event_list[id].on_update then item.event_list[id].on_update(item.tp_buffer,hit_heat_burst) end		--事件被选中的时候可能会提升热度，同时降低自身热度。
			item.event_buffer[stag.id].weigh = item.event_buffer[stag.id].weigh - 1
			table.insert(item.tp_buffer,ret)
		end
		for i = #item.event_buffer,1,-1 do
			if item.event_buffer[i].weigh <= 0 then table.remove(item.event_buffer,i) end
		end
	end
end

local function get_bullet_by_random()
	if #item.tp_buffer == 0 then
		get_pr_from_event()
	end
	if item.tp_buffer[1] then
		local info = item.tp_buffer[1]
		item.tp_buffer[1].counter = (item.tp_buffer[1].counter or 0) - 1
		if item.tp_buffer[1].counter <= 0 then
			table.remove(item.tp_buffer,1)
		end
		return info
	else
		return get_normal_pr()
	end
end

local function fire_bullet(player)
	local ret = get_bullet_by_random()
	fire_bullet_screen(player,get_level_by_popularity(),"zh",ret.tp or 1,ret.vr,ret.params)
end

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	item.block_map = {}
	save.elses.Live_heat_counter = 0
	save.elses.Live_heat_delay = 0
	save.elses.Live_popularity_adder = 0
	save.elses.Live_add_offset = 0
	item.event_buffer = {}
	item.record_good_item = {}
	item.tp_buffer = {}
	if continue then
		local should_count = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
				should_count = true
				break
			end
			player:AddCacheFlags(CacheFlag.CACHE_ALL)
			player:GetData().should_evaluate_on_update_once = true
		end
		if should_count == true then
			cause_event(7)
		end
	else
		for j = 1,10 do
			save.elses["L_B_Buff_dmg_"..tostring(j)] = 0
			save.elses["L_B_Buff_tear_"..tostring(j)] = 0
			save.elses["L_B_Buff_luck_"..tostring(j)] = 0
		end
		save.elses.Live_popularity_counter = math.min(100,(save.elses.Live_popularity_counter or 0)/100)				--模式1
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	local idx = player:GetData().__Index
	if idx ~= nil then
		if cacheFlag == CacheFlag.CACHE_DAMAGE then
			if save.elses["L_B_Buff_dmg_"..tostring(idx)] then
				player.Damage = player.Damage + (math.sqrt(save.elses["L_B_Buff_dmg_"..tostring(idx)] + 4) - 2) * auxi.get_damage_multiplier(player)
			end
		end
		if cacheFlag == CacheFlag.CACHE_FIREDELAY then
			if save.elses["L_B_Buff_tear_"..tostring(idx)] then
				player.MaxFireDelay = auxi.TearsUp(player.MaxFireDelay , auxi.get_mxdelay_multiplier(player) * (math.sqrt(save.elses["L_B_Buff_tear_"..tostring(idx)] + 9) - 3))
			end
		end
		if cacheFlag == CacheFlag.CACHE_LUCK then
			if save.elses["L_B_Buff_luck_"..tostring(idx)] then
				player.Luck = player.Luck + (save.elses["L_B_Buff_luck_"..tostring(idx)]) * 0.33
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_INIT, params = item.focus_entity,
Function = function(_,ent)
	if ent.Variant == item.focus_entity then
		local s = ent:GetSprite()
		local d = ent:GetData()
		ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_PLAYERONLY
		ent.PositionOffset = Vector(0,-600)
		d.type_state = math.random(4)
		d.rotate_dir = math.random(2) * 2 - 3
		d.rotate_ang = 10 + math.random(1000)/1000 * 5
		s:Play("Idle"..tostring(d.type_state),true)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_EFFECT_UPDATE, params = item.focus_entity,
Function = function(_,ent)
	if ent.Variant == item.focus_entity then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if ent.PositionOffset.Y < 0 then
			ent.PositionOffset = ent.PositionOffset + Vector(0,10)
		else
			d.rotate_ang = (d.rotate_ang or 10) * 0.9
		end
		s.Rotation = s.Rotation + (d.rotate_dir or 1) * (d.rotate_ang or 10)
		s:Play("Idle"..tostring(d.type_state or 1),true)
		if ent.PositionOffset.Y >= 0 and (d.rotate_ang or 10) < 3 then
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if (player.Position - ent.Position):Length() < 15 then
					local ret = reward(player,d.type_state or 1)
					if ret then 
						player:AnimateHappy()
						ent:Remove() 
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 110,
Function = function(_,ent)
	local should_count,player = auxi.check_should_count(item.entity)
	if should_count then
		consistance_holder.try_hold_entity(ent,"Live_Broadcast",{ignore_subtype = true,ignore_variant = true})
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 300,		--红隐
Function = function(_,ent)
	if ent.SubType == Card.CARD_CRACKED_KEY then
		local should_count,player = auxi.check_should_count(item.entity)
		if should_count then
			local checked = consistance_holder.try_check_entity(ent,"Live_Broadcast")
			if not checked then
				cause_event(5,math.random(6))
				consistance_holder.try_hold_entity(ent,"Live_Broadcast",{})
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 100,
Function = function(_,ent)
	local should_count,player = auxi.check_should_count(item.entity)
	if should_count then
		local id = ent.SubType
		if id > 0 and ent.Touched ~= true then
			local col = Isaac.GetItemConfig():GetCollectible(id)
			if (col and not col:HasTags(1<<15)) then
				local qual = col.Quality
				local checked = consistance_holder.try_check_entity(ent,"Live_Broadcast")
				if not checked then
					if id == CollectibleType.COLLECTIBLE_RED_KEY then
						cause_event(5,math.random(10) + 4)
					end
					if qual == 4 then
						if Game():GetLevel():GetCurses() & LevelCurse.CURSE_OF_BLIND ~= LevelCurse.CURSE_OF_BLIND then
							local info = item_displaying_holder.check_description("UnItem",id,auxi.check_name_data(col.Name),auxi.check_name_data(col.Description),player)
							cause_event(1,nil,{typename = "item",itemname = info.Name or "",itemDesc = info.Description or "",})
						end
					end
					Record_holder.try_hold(ent,{check = function(et) 
						if et.SubType ~= id then
							if et.SubType <= 0 then
								return true,"Lost"
							else
								return true,"Turn"
							end
						end
						return false,nil
					end,Function = function(tp,et)
						if tp ~= "Lost" then			--目前，还有永恒D6可以导致道具丢失，不过这非常少见，而且也勉强能圆过去。
							local should_count = true
							if tp == "Turn" then
								for playerNum = 1, Game():GetNumPlayers() do
									local player = Game():GetPlayer(playerNum - 1)
									if not player:IsItemQueueEmpty() then
										if player.QueuedItem.Item.ID == id then
											should_count = false
											break
										end
									end
								end
							end
							if ent:IsShopItem() and tp == "Remove" then
								for playerNum = 1, Game():GetNumPlayers() do
									local player = Game():GetPlayer(playerNum - 1)
									if not player:IsItemQueueEmpty() then
										if player.QueuedItem.Item.ID == id then
											should_count = false
											break
										end
									end
								end
							end
							if should_count then
								local player = Game():GetPlayer(0)
								local info = item_displaying_holder.check_description("UnItem",id,auxi.check_name_data(col.Name),auxi.check_name_data(col.Description),player)
								if Game():GetLevel():GetCurses() & LevelCurse.CURSE_OF_BLIND == LevelCurse.CURSE_OF_BLIND then info = {Name = "道具",Description = "不知道效果"} end
								cause_event(10,nil,{typename = "item",itemname = info.Name or "",itemDesc = info.Description or "",})
							end
						end
					end,})
					if item.record_items[id] and item.record_items[id].word then		--某些特殊道具存在特殊事件
						cause_event(14,8,{name = item.record_items[id].word})
					end
					consistance_holder.try_hold_entity(ent,"Live_Broadcast",{ignore_subtype = true})
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	local should_count,player = auxi.check_should_count(item.entity)
	if should_count then
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.POST_CHANGE_COLLECTIBLE, params = item.entity,
Function = function(_,player,collid,count)
	if count > 0 and player:GetCollectibleNum(item.entity,true) == count then
		cause_event(7)
	end
	if player:GetCollectibleNum(item.entity,true) == 0 then
		cause_event(8)
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	local player = ent:ToPlayer()
	if player then
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			local d = player:GetData()
			if auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
				cause_event(4,math.random(6) + 1)
				if math.random(1000) > 300 then
					cause_event(3,math.random(3))
				end
				d.Live_Broadcast_DMG_Token = 3600
			end
			local now_heart = auxi.get_absolute_heart(player)
			if now_heart - amt <= 1 then
				cause_event(6,math.random(6) + 1)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,rng,pos)
	local should_count,player = auxi.check_should_count(item.entity)
	if should_count then
		local level = Game():GetLevel()
		local room = Game():GetRoom()
		local desc = level:GetCurrentRoomDesc()
		if desc.Data.Type == 5 then
			cause_event(2,math.random(8) + 6)
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_PILL, params = nil,
Function = function(_,pill,player,flag)	
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		if auxi.is_bad_pill(pill) then 
			cause_event(3,math.random(6),{typename = "pill"})
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = FamiliarVariant.LOST_SOUL,
Function = function(_,ent)
	local player = ent.Player
	if player and (player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0) then
		local s = ent:GetSprite()
		if s:IsPlaying("Death") and s:GetFrame() == 1 then
			cause_event(15,10)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_KILL, params = 1,
Function = function(_,ent)
	if ent:ToPlayer() then
		local player = ent:ToPlayer()
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			if auxi.is_found_soul(player) then 
				cause_event(15,16)
			else
				cause_event(9,20)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
		local d = player:GetData()
		local s = player:GetSprite()
		if d.Live_Broadcast_DMG_Token == nil then d.Live_Broadcast_DMG_Token = 3600 end
		local room = Game():GetRoom()
		if room:IsClear() == false then d.Live_Broadcast_DMG_Token = d.Live_Broadcast_DMG_Token - 1 end
		if d.Live_Broadcast_DMG_Token <= 0 then 
			if math.random(1000) > 990 then
				cause_event(2,math.random(10) + 4)
			end
		end
		if input_holder.all_nill(player) == true then
			d.Live_Broadcast_No_Action_counter = (d.Live_Broadcast_No_Action_counter or 0) + 1
			if d.Live_Broadcast_No_Action_counter > 900 then
				if math.random(1000) > 800 then
					local tbl = {}
					if math.random(1000) > 100 then tbl.no_gift = true end
					cause_event(16,6,tbl)
				end
			end
		else
			d.Live_Broadcast_No_Action_counter = 0
		end
	end
	if Game():GetFrameCount() % 10 == 1 then
		local idx = player:GetData().__Index
		if idx then
			local should_check = false
			if (save.elses["L_B_Buff_dmg_"..tostring(idx)] or 0) > 0 then save.elses["L_B_Buff_dmg_"..tostring(idx)] = save.elses["L_B_Buff_dmg_"..tostring(idx)] * 0.99 player:AddCacheFlags(CacheFlag.CACHE_DAMAGE) should_check = true end
			if (save.elses["L_B_Buff_tear_"..tostring(idx)] or 0) > 0 then save.elses["L_B_Buff_tear_"..tostring(idx)] = save.elses["L_B_Buff_tear_"..tostring(idx)] * 0.99 player:AddCacheFlags(CacheFlag.CACHE_FIREDELAY) should_check = true end
			if (save.elses["L_B_Buff_luck_"..tostring(idx)] or 0) > 0 then save.elses["L_B_Buff_luck_"..tostring(idx)] = save.elses["L_B_Buff_luck_"..tostring(idx)] * 0.99 player:AddCacheFlags(CacheFlag.CACHE_LUCK) should_check = true end
			if should_check then
				player:GetData().should_evaluate_on_update_once = true
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local should_count = false
	local tg_player_1 = Game():GetPlayer(0)
	local tg_player_2 = nil
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
			tg_player_1 = player
		else
			tg_player_2 = player
		end
	end
	if should_count == true then
		local level = Game():GetLevel()
		local room = Game():GetRoom()
		local desc = level:GetCurrentRoomDesc()
		if Game():GetFrameCount() % 10 == 5 then
			save.elses.Live_popularity_counter = (save.elses.Live_popularity_counter or 0) + save.elses.Live_popularity_adder * 0.01
			save.elses.Live_heat_counter = ((save.elses.Live_heat_counter or 0) - save.elses.Live_popularity_counter) * 0.95 + save.elses.Live_popularity_counter + save.elses.Live_popularity_adder * 0.1
			save.elses.Live_popularity_adder = save.elses.Live_popularity_adder * 0.9
		end
		local heat = get_heat()
		if (save.elses.Live_heat_delay or -1) < 0 then
			save.elses.Live_heat_delay = math.random(get_something_from_heat(nil,"delay",600))
			fire_bullet(tg_player_1)
			save.elses.Live_popularity_counter = (save.elses.Live_popularity_counter or 0) + 1
		else
			if save.elses.Live_heat_delay > get_something_from_heat(nil,"delay",600) + 20 then save.elses.Live_heat_delay = math.random(get_something_from_heat(nil,"delay",600)) end
			save.elses.Live_heat_delay = save.elses.Live_heat_delay - 1
		end
		if (save.elses.Live_add_offset or 0) > 0 and Game():GetFrameCount() % 3 == 1 then		--爆发式的弹幕
			local cnt = math.ceil(save.elses.Live_add_offset / 10)
			for i = 1,cnt do
				fire_bullet(tg_player_1)
			end
			save.elses.Live_add_offset = (save.elses.Live_add_offset or 0) - cnt
			save.elses.Live_heat_counter = save.elses.Live_heat_counter + cnt * 10
		end
		if Game():GetFrameCount() % 60 == 5 or (Game():GetFrameCount() % 45 == 5 and desc.Data.Type == 5) then
			if auxi.is_player_lost(tg_player_1) then
				if auxi.is_player_has_mantle(tg_player_1) == false and math.random(1000) > 500 then 
					cause_event(6,math.random(3))
				end
			elseif auxi.get_absolute_heart(tg_player_1) <= 1 and math.random(1000) > 500 then cause_event(6,1) end
		end
		if save.elses.Live_heat_delay % 60 == 1 then
			if math.random(1000) > 999 then
				cause_event(11,math.random(10) + 10)
			end
		end
		if save.elses.Live_heat_delay % 35 == 1 then
			if math.random(1000) > 998 then
				cause_event(12,math.random(10) + 10)
			end
		end
		local cnt = auxi.get_stats_counter(tg_player_1)
		if save.elses.Live_heat_delay % 75 == 1 then
			if math.random(1000) < cnt then
				if math.random(1000) > 900 then
					cause_event(2,math.random(8))
				end
			end
		end
		if save.elses.Live_heat_delay % 65 == 1 then
			local should_test = false
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				for cardslot = 0,2 do
					local cd = player:GetCard(cardslot)
					if cd == Card.CARD_CRACKED_KEY then
						should_test = true
						break
					end
				end
				if should_test then break end
				for slot = ActiveSlot.SLOT_PRIMARY, ActiveSlot.SLOT_POCKET do
					if (player:GetActiveItem(slot) == CollectibleType.COLLECTIBLE_RED_KEY) then
						should_test = true
						break
					end
				end
				if should_test then break end
			end
			if should_test then
				if math.random(1000) > 900 then
					cause_event(5,math.random(3))
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	local should_count = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0 then
			should_count = true
			break
		end
	end
	if should_count then
		local pos = ui.GetScreenBottomLeft()
		item.live_sprite:Render(pos + Vector(10,-10),Vector(0,0),Vector(0,0))
		local counter = get_heat()
		local str = tostring(counter)
		gui.draw_ch(pos + Vector(20,-18) + Vector((#str) / 2,0),str,1,1,KColor(1,1,1,0.5),true)
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,str,params)
	if string.lower(str) == "live" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] then
			if args[1] and args[1] == "set" and args[2] and tonumber(args[2]) then
				save.elses.Live_popularity_counter = tonumber(args[2])
				print("Successfully set to "..tostring(save.elses.Live_popularity_counter))
			end
			if args[1] and args[1] == "mode" and args[2] and tonumber(args[2]) then
				local md = tonumber(args[2])
				print("Set to " .. tostring(md))
				if md >= 0 and md <= 1 then md = 1 - md end
				data4.set_mode(md)
			end
		end
	end
	if string.lower(str) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] then
			if string.lower(args[1]) == "please" then
				if args[2] and args[3] then
					if args[2] == "reset" and args[3] == "live" then
						print("Ok.")
						save.elses.Live_popularity_counter = 0
					end
					if args[2] == "set" and args[3] == "live" and args[4] then
						print("Ok.")
						local num = tonumber(args[4])
						if type(num) == "number" then 
							print("Successfully set it to "..tostring(num))
							save.elses.Live_popularity_counter = num
						end
					end
					if args[2] == "check" and args[3] == "live" then
						print("Ok. "..tostring(save.elses.Live_popularity_counter or 0) .. " " .. tostring(save.elses.Live_heat_counter or 0) .. " " .. tostring(save.elses.Live_popularity_adder or 0) )
					end
				end
			end
		end
	end
end,
})

--打招呼的场合：直播开始后概率逐渐降低
--表示快乐的场合：根据热度进行额外计算；运气不佳
--指指点点的场合：根据热度进行额外计算；血量充裕；见到道具但没有拾取
--云的场合：根据热度进行额外计算；
--发强的场合：残血无伤敌人、瞬间造成大量伤害等
--发问号的场合：遇见4级道具、星象房、低概率开恶魔、见到特殊红房间
--考试的场合：持有红钥匙、碎片、该隐符文等。
--危机的场合：丝血、罗斯特破盾
--小罗死亡的场合
--点播以及内容需要根据热度决定。
--投喂内容包括：小花花、牛哇牛哇、小心心等，拾取它们可以带来属性小幅提升。
--投喂火箭可以生成一个发射出去的火箭炸弹
--投喂打call可以提升弹幕量？
--点播内容是固定格式的，要求包括：1.给某一个道具 2.失去某个道具 还可以有更多？

return item