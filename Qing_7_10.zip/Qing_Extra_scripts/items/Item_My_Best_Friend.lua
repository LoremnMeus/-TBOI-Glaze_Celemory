local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	entity = enums.Items.My_Best_Friend,
	target = {
		4,38,42,50,145,188,215,361,429,599,729,
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GET_COLLECTIBLE, params = nil,
Function = function(_,pool,decrease,seed)
	local has_ent = 0
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(item.entity) or player:GetEffects():GetCollectibleEffectNum(item.entity) > 0  then
			has_ent = has_ent + player:GetCollectibleNum(item.entity) + player:GetEffects():GetCollectibleEffectNum(item.entity)
		end
	end
	if save.elses.has_spawn_head == nil then save.elses.has_spawn_head = 0 end
	if has_ent > 0 and pool == ItemPoolType.POOL_GOLDEN_CHEST and save.elses.has_spawn_head < (#item.target) and Game():GetFrameCount() > 5 then
		local tbl = {}
		for i = 1,#item.target do
			local has_col = false
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(item.target[i]) then
					has_col = true
				end
			end
			if has_col == false then
				table.insert(tbl,#tbl+1,item.target[i])
			end
		end
		if #tbl > 0 then
			local rng = RNG()
			rng:SetSeed(seed,0)
			local rnd = rng:RandomInt(math.ceil(160/(#tbl + has_ent * 10)))
			--print(#tbl.." "..math.ceil(160/(#tbl + has_ent * 10)).." "..rnd)
			--print(rnd)
			if rnd == 0 then
				if decrease == true then
					save.elses.has_spawn_head = save.elses.has_spawn_head + 1
				end
				local rnd = rng:RandomInt(#tbl)
				return tbl[rnd + 1]
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.has_spawn_head = 0
	end
end,
})

return item