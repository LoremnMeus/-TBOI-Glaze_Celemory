local g = require("Qing_Extra_scripts.core.globals")
local enums = require("Qing_Extra_scripts.core.enums")

local item = {
	ToCall = {},
	grid_table = {},
}

--为了保证统一性，我们需要将地形作为实体处理。
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	item.grid_table = {}
end,
})

local function full_change(grid)
	if grid:ToDoor() then grid = grid:ToDoor()
	elseif grid:ToPit() then grid = grid:ToPit()
	elseif grid:ToPoop() then grid = grid:ToPoop()
	elseif grid:ToRock() then grid = grid:ToRock()
	elseif grid:ToPressurePlate() then grid = grid:ToPressurePlate()
	elseif grid:ToSpikes() then grid = grid:ToSpikes()
	elseif grid:ToTNT() then grid = grid:ToTNT()
	end
	return grid
end

function item.get_grid_table()
	for u,v in pairs(item.grid_table) do
		if v:Exists() == false then table.remove(item.grid_table,u) end
	end
	return item.grid_table
end

function item.get_grid_entity(grid,grididx)
	grid = grid or Game():GetRoom():GetGridEntity(grididx)
	if grid then
		grididx = grididx or grid:GetGridIndex()
		if item.grid_table[grididx] == nil or item.grid_table[grididx]:get_grid() == nil or item.grid_table[grididx]:get_grid():GetVariant() == nil then 
			item.grid_table[grididx] = {
				IsGrid = true,get_grid = function(ent) return full_change(Game():GetRoom():GetGridEntity(ent.grididx)) end,grididx = grididx,GetData = function(ent) return ent.Data end,Data = {},
				PositionOffset = Vector(0,0),Position = function(ent) return (ent:get_grid() or {Position = Vector(200,200),}).Position or Vector(200,200) end,
				GetSprite = function(ent) local grid = ent:get_grid() if grid then return grid:GetSprite() else return Sprite() end end,
				Exists = function(ent) return ent:get_grid() ~= nil end,IsDead = function(ent) return false end,
			}
		end
	end
	return item.grid_table[grididx or 0]
end


return item