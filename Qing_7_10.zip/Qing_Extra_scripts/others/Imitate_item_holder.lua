local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
}

--这个委托器提供假道具的赋予与删除功能。
--使用后悔药、煲仔饭等方法前，必须提前移除所有魂火！

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	
end,
})

function item.assign_fake_item(player,collid,num)
end


return item