local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
}

--效果为记录所有需要被永久记录的事物。
--分为四类，下层后解除记录、小退后解除记录、结束游戏后解除记录、永久记录（不建议使用）
table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		save.elses.Consistance_holder = {}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	if save.elses.Consistance_holder then
		for u,v in pairs(save.elses.Consistance_holder) do
			if type(v) == "table" then
				if v.keep_level == nil then
					save.elses.Consistance_holder[u] = nil
				end
			end
		end
	end
end,
})

local function make_name(ent,params,checkname)
	checkname = checkname or ""
	if params == nil then params = {} end
	local ret = ""
	if params.ignore_type ~= true then 
		ret = ret..tostring(ent.Type).."_T_" 
		if params.ignore_variant ~= true then 
			ret = ret..tostring(ent.Variant).."_V_" 
			if params.ignore_subtype ~= true then 
				ret = ret..tostring(ent.Subtype).."_S_" 
			end
		end
	end
	ret = ret..tostring(ent.InitSeed).."_I_" .. checkname
	return ret
end

local function get_name(ent,params,checkname)
	local tbl = {}
	if params then
		table.insert(tbl,make_name(ent,params,checkname))
	else
		table.insert(tbl,make_name(ent,nil,checkname))
		table.insert(tbl,make_name(ent,{ignore_subtype = true},checkname))
		table.insert(tbl,make_name(ent,{ignore_variant = true},checkname))
		table.insert(tbl,make_name(ent,{ignore_type = true},checkname))
	end
	return tbl
end

function item.try_hold_entity(ent,checkname,params)		--可以传入：keep_level、ignore_type、ignore_subtype、ignore_variant。之后还应该支持重定义initseed的重载。
	checkname = checkname or "Check"
	if ent == nil then print("Wrong entity to hold!") return end
	if params == nil then params = {} end
	local tg = item.try_check_entity(ent,checkname,true)
	if tg ~= false then 		--若已经存储，则立刻直接覆盖
		tg.data = auxi.deepCopy(ent:GetData()._Data)
		for u,v in pairs(params) do
			tg[u] = v
		end
	else						--从未存储，进行新建。
		if save.elses.Consistance_holder == nil then save.elses.Consistance_holder = {} end
		local name = make_name(ent,params,checkname)
		save.elses.Consistance_holder[name] = {Variant = ent.Variant,Subtype = ent.Subtype,data = auxi.deepCopy(ent:GetData()._Data),InitSeed = ent.InitSeed,ent = ent,keep_level = params.keep_level,ignore_subtype = params.ignore_subtype,ignore_variant = params.ignore_variant}
		--if save.elses.Consistance_holder[ent.Type] == nil then save.elses.Consistance_holder[ent.Type] = {} end
		--table.insert(save.elses.Consistance_holder[ent.Type],{Variant = ent.Variant,Subtype = ent.Subtype,data = auxi.deepCopy(ent:GetData()._Data),InitSeed = ent.InitSeed,ent = ent,keep_level = params.keep_level,ignore_subtype = params.ignore_subtype,ignore_variant = params.ignore_variant})
	end
end

function item.try_check_entity(ent,checkname,testing)
	checkname = checkname or "Check"
	--print("st0 " .. checkname)
	if not testing and ent:GetData().checked_data ~= nil and ent:GetData().checked_data[checkname] ~= nil then return true end
	--print("st1 " .. checkname)
	if save.elses.Consistance_holder == nil then
		return false
	else
		local names = get_name(ent,nil,checkname)
		for u,v in pairs(names) do
			if save.elses.Consistance_holder[v] ~= nil then
				--if (v.Variant == ent.Variant or v.ignore_variant) and (v.Subtype == ent.Subtype or v.ignore_subtype) and v.InitSeed == ent.InitSeed then
				if testing then
					return save.elses.Consistance_holder[v]
				else
					ent:GetData()._Data = auxi.deepCopy(save.elses.Consistance_holder[v].data)
					if ent:GetData().checked_data == nil then ent:GetData().checked_data = {} end
					if ent:GetData().checked_data[checkname] == nil then ent:GetData().checked_data[checkname] = true end
					return true
				end
				--end
			end
		end
	end
	return false
end

function item.check_table()
	local counter = 0
	if save.elses.Consistance_holder then
		for u,v in pairs(save.elses.Consistance_holder) do
			if type(v) == "table" then
				counter = counter + 1
			end
		end
	end
	print(counter)
	--auxi.PrintTable(save.elses.Consistance_holder)
end


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EXECUTE_CMD, params = nil,
Function = function(_,str,params)
	if string.lower(str) == "meus" and params ~= nil then
		local args={}
		for str in string.gmatch(params, "([^ ]+)") do
			table.insert(args, str)
		end
		if args[1] == "check" then
			item.check_table()
		end
	end
end,
})

function item.try_remove_entity(ent,checkname,params)
	local succ = false
	if save.elses.Consistance_holder then
		local names = get_name(ent,params,checkname)
		for u,v in pairs(names) do
			if save.elses.Consistance_holder[v] then
				save.elses.Consistance_holder[v] = nil
				succ = true
			end
		end
	end
	return succ
end

return item