local g = require("Qing_Extra_scripts.core.globals")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local Attribute_holder = require("Qing_Extra_scripts.others.Attribute_holder")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")

local item = {
	ToCall = {},
	post_ToCall = {},
	start = false,
}

local AchievementQueue = {}
local AchievementSpr = Sprite()
AchievementSpr:Load("gfx/ui/achievement display api/achievements.anm2")
AchievementSpr.PlaybackSpeed = 0.5

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if AchievementQueue[1] then
		if not Game():IsPaused() then
			if (ModConfigMenu and ModConfigMenu.IsVisible) then
				ModConfigMenu.CloseConfigMenu()
			end
			if (DeadSeaScrollsMenu and DeadSeaScrollsMenu.OpenedMenu) then
				DeadSeaScrollsMenu:CloseMenu(true, true)
			end
		end
		if not item.start then
			Isaac.GetPlayer(0):UseActiveItem(CollectibleType.COLLECTIBLE_PAUSE, UseFlag.USE_NOANIM)
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				local d = player:GetData()
				local succ = Attribute_holder.try_hold_attribute(player,"ControlsEnabled",false)
				local succ2 = Attribute_holder.try_hold_attribute(player,"Velocity",Vector(0,0))
				if d.Achievement_control_enables_succ then
					Attribute_holder.try_rewind_attribute(player,"ControlsEnabled",d.Achievement_control_enables_succ)
				end
				if d.Achievement_velocity_succ then
					Attribute_holder.try_rewind_attribute(player,"Velocity",d.Achievement_velocity_succ)
				end
				d.Achievement_control_enables_succ = succ
				d.Achievement_velocity_succ = succ2
			end
			item.start = true
		end
		if not AchievementQueue[1].Appear then
			AchievementSpr:Play("Appear", true)
			AchievementQueue[1].Appear = true
			
			if AchievementQueue[1].GfxRoot then
				AchievementSpr:ReplaceSpritesheet(3, AchievementQueue[1].GfxRoot)
				AchievementSpr:LoadGraphics()
			end
		end
		
		if AchievementSpr:IsFinished("Appear") then
			if not AchievementQueue[1].SoundPlayed then
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_BOOK_PAGE_TURN_12, 1, 1, false, 0,2)
				AchievementQueue[1].SoundPlayed = true
			end
		
			if AchievementQueue[1].Duration <= 0 then
				AchievementSpr:Play("Dissapear", true)
			else
				AchievementQueue[1].Duration = AchievementQueue[1].Duration - 1
			end
		end
	
		if AchievementSpr:IsFinished("Dissapear") then
			table.remove(AchievementQueue, 1)
			if (not AchievementQueue[1]) then
				item.start = false
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					local d = player:GetData()
					if d.Achievement_control_enables_succ then
						local succs = Attribute_holder.try_rewind_attribute(player,"ControlsEnabled",d.Achievement_control_enables_succ)
					end
					if d.Achievement_velocity_succ then
						local succs = Attribute_holder.try_rewind_attribute(player,"Velocity",d.Achievement_velocity_succ)
					end
					d.Achievement_control_enables_succ = nil
					d.Achievement_velocity_succ = nil
				end
			end
		end
		
		local Center = auxi.GetScreenSize()
		AchievementSpr:Render(Vector(Center.X/2, Center.Y/2), Vector(0,0), Vector(0,0))
		AchievementSpr:Update()
	end
end,
})

function item.PlayAchievement(gfxroot, duration)
	table.insert(AchievementQueue, {GfxRoot = gfxroot, Duration = duration or 90})
end

function item.Is_Finished_playing()
	return item.start ~= true
end

return item