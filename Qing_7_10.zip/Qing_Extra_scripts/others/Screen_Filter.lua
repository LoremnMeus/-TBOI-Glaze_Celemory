local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
	should_filter = 0,
}

local s = Sprite()
s:Load("gfx/Black.anm2",true)
s:Play("Idle",true)

function item.add_filter(tm)
	item.should_filter = math.max(item.should_filter,tm)
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if item.should_filter and item.should_filter > 0 then
		item.should_filter = item.should_filter - 1
		s:Render(Vector(0,0),Vector(0,0),Vector(0,0))
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_END, params = nil,
Function = function(_,shouldsave)
	item.should_filter = 0
end,
})

return item