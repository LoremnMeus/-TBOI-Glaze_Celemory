local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local save = require("Qing_Extra_scripts.core.savedata")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	original_info = {
		monsters = {
			normal = {
				{Type = 10,Variant = 0,level = 1,},
				{Type = 10,Variant = 1,level = 1,},
				{Type = 10,Variant = 2,level = 1,},
				{Type = 10,Variant = 3,SubType = {0,1,2,3,4,5,},level = 4,},
				{Type = 87,Variant = 0,level = 2,},
				{Type = 87,Variant = 1,level = 2,},
				{Type = 252,Variant = 0,level = 3,},
				{Type = 284,Variant = 0,level = 1,},
				{Type = 297,Variant = 0,level = 4,},
				{Type = 299,Variant = 0,level = 5,},
				{Type = 807,Variant = 0,level = 1,},
				{Type = 811,Variant = 0,SubType = {0,1,2,3,4,5,6,},level = 1,},
				{Type = 813,Variant = 0,level = 1,},
				{Type = 850,Variant = 0,level = 4,},
				{Type = 850,Variant = 1,level = 4,},
				{Type = 850,Variant = 2,level = 4,},
				{Type = 912,Variant = 20,level = 4,},
				{Type = 827,Variant = 0,level = 2,},
				{Type = 827,Variant = 1,level = 5,},
				{Type = 832,Variant = 0,level = 3,},
				{Type = 832,Variant = 1,level = 3,},
				{Type = 876,Variant = 0,level = 1,},
				{Type = 876,Variant = 1,level = 1,},
				{Type = 11,Variant = 0,level = 1,},
				{Type = 11,Variant = 1,level = 1,},
				{Type = 238,Variant = 0,level = 2,},
				{Type = 280,Variant = 0,level = 3,},
				{Type = 12,Variant = 0,level = 1,},
				{Type = 248,Variant = 0,level = 3,},
				{Type = 812,Variant = 0,level = 1,},
				{Type = 812,Variant = 1,level = 5,},
				{Type = 828,Variant = 0,level = 2,},
				{Type = 15,Variant = 0,level = 1,},
				{Type = 15,Variant = 1,level = 3,},
				{Type = 15,Variant = 2,level = 1,},
				{Type = 15,Variant = 3,level = 1,},
				{Type = 872,Variant = 0,level = 1,},
				{Type = 16,Variant = 0,level = 1,},
				{Type = 16,Variant = 1,level = 1,},
				{Type = 16,Variant = 2,level = 1,},
				{Type = 22,Variant = 0,level = 1,},
				{Type = 22,Variant = 1,level = 1,},
				{Type = 22,Variant = 2,level = 5,},
				{Type = 22,Variant = 3,level = 5,},
				{Type = 205,Variant = 0,level = 1,},
				{Type = 310,Variant = 0,level = 4,},
				{Type = 310,Variant = 0,SubType = 1,level = 4,},
				{Type = 310,Variant = 0,SubType = 2,level = 4,},
				{Type = 310,Variant = 0,SubType = 3,level = 4,},
				{Type = 310,Variant = 1,level = 4,},
				{Type = 817,Variant = 0,level = 1,},
				{Type = 817,Variant = 1,level = 1,},
				{Type = 822,Variant = 0,level = 2,},
				{Type = 874,Variant = 0,level = 1,},
				{Type = 820,Variant = 0,level = 2,},
				{Type = 820,Variant = 1,level = 2,},
				{Type = 821,Variant = 0,level = 2,},
				{Type = 21,Variant = 0,level = 2,},
				{Type = 23,Variant = 0,SubType = {0,1,},level = 2,},
				{Type = 23,Variant = 1,level = 2,},
				{Type = 23,Variant = 2,level = 3,},
				{Type = 23,Variant = 3,level = 2,},
				{Type = 810,Variant = 0,level = 1,},
				{Type = 853,Variant = 0,level = 4,},
				{Type = 855,Variant = 0,level = 5,},
				{Type = 855,Variant = 1,level = 5,},
				{Type = 884,Variant = 0,level = 3,},
				--802
				{Type = 31,Variant = 0,level = 2,},
				{Type = 31,Variant = 1,level = 5,},
				{Type = 243,Variant = 0,level = 2,},
				{Type = 24,Variant = 0,level = 2,},
				{Type = 24,Variant = 1,level = 2,},
				{Type = 24,Variant = 2,level = 3,},
				{Type = 24,Variant = 3,level = 3,},
				{Type = 278,Variant = 0,level = 3,},
				{Type = 889,Variant = 0,level = 2,},
				{Type = 856,Variant = 0,level = 1,},
				{Type = 857,Variant = 0,level = 4,},
				{Type = 27,Variant = 0,level = 3,},
				{Type = 27,Variant = 1,level = 4,},
				{Type = 27,Variant = 3,level = 2,},
				{Type = 204,Variant = 0,level = 3,},
				{Type = 247,Variant = 0,level = 3,},
				{Type = 300,Variant = 0,level = 2,},
				{Type = 30,Variant = 0,level = 1,},
				{Type = 30,Variant = 1,level = 2,},
				{Type = 30,Variant = 2,level = 1,},
				{Type = 298,Variant = 0,level = 4,},
				{Type = 309,Variant = 0,level = 3,},
				{Type = 861,Variant = 0,level = 4,},
				{Type = 88,Variant = 0,level = 2,},
				{Type = 88,Variant = 1,level = 2,},
				{Type = 88,Variant = 2,level = 2,},
				{Type = 32,Variant = 0,level = 4,},
				{Type = 279,Variant = 0,level = 3,},
				{Type = 831,Variant = 20,level = 4,},
				{Type = 824,Variant = 0,level = 2,},
				{Type = 824,Variant = 1,level = 1,},
				{Type = 35,Variant = 0,level = 3,},
				{Type = 35,Variant = 2,level = 3,},
				{Type = 216,Variant = 0,level = 4,},
				{Type = 39,Variant = 0,level = 3,},
				{Type = 39,Variant = 1,level = 3,},
				{Type = 39,Variant = 2,level = 4,},
				{Type = 39,Variant = 3,level = 4,},
				{Type = 836,Variant = 0,level = 3,},
				{Type = 865,Variant = 0,level = 4,},
				{Type = 40,Variant = 0,level = 4,},
				{Type = 40,Variant = 1,level = 4,},
				{Type = 40,Variant = 2,level = 3,},
				{Type = 862,Variant = 0,level = 4,},
				{Type = 41,Variant = 0,level = 3,},
				{Type = 41,Variant = 1,level = 3,},
				{Type = 41,Variant = 2,level = 3,},
				--41.3
				{Type = 41,Variant = 4,level = 3,},
				{Type = 283,Variant = 0,level = 5,},
				{Type = 834,Variant = 0,level = 4,},
				{Type = 834,Variant = 1,level = 4,},
				{Type = 834,Variant = 2,level = 4,},
				{Type = 57,Variant = 0,level = 4,},
				{Type = 57,Variant = 1,level = 4,},
				{Type = 57,Variant = 2,level = 4,},
				{Type = 223,Variant = 0,level = 3,},
				{Type = 282,Variant = 0,level = 2,},
				{Type = 60,Variant = 0,level = 4,},
				{Type = 60,Variant = 1,level = 4,},
				{Type = 60,Variant = 2,level = 5,},
				{Type = 77,Variant = 0,level = 1,},
				{Type = 85,Variant = 0,level = 1,},
				{Type = 94,Variant = 0,level = 1,},
				{Type = 814,Variant = 0,level = 1,},
				{Type = 818,Variant = 0,SubType = {0,1,2,3,},level = 2,},
				{Type = 818,Variant = 2,SubType = {0,1,2,3,},level = 2,},
				{Type = 89,Variant = 0,level = 2,},
				{Type = 878,Variant = 0,level = 3,},
				{Type = 93,Variant = 0,level = 3,},
				{Type = 206,Variant = 0,level = 1,},
				{Type = 206,Variant = 1,level = 1,},
				{Type = 207,Variant = 0,level = 1,},
				{Type = 207,Variant = 1,level = 1,},
				{Type = 208,Variant = 0,level = 1,},
				{Type = 208,Variant = 1,level = 2,},
				{Type = 208,Variant = 2,level = 1,},
				{Type = 209,Variant = 0,level = 3,},
				{Type = 210,Variant = 0,level = 3,},
				{Type = 211,Variant = 0,level = 3,},
				{Type = 257,Variant = 0,level = 2,},
				{Type = 257,Variant = 1,level = 4,},
				{Type = 302,Variant = 0,nonly_spawn = true,level = 1,},
				{Type = 302,Variant = 10,only_spawn = true,level = 1,},
				{Type = 806,Variant = 0,level = 1,},
				{Type = 823,Variant = 0,level = 2,},
				{Type = 830,Variant = 0,level = 2,},
				{Type = 831,Variant = 0,level = 4,},
				--831.10
				{Type = 835,Variant = 0,level = 4,},
				--835.10
				{Type = 879,Variant = 0,level = 1,},
				{Type = 886,Variant = 0,level = 3,},		--special
				{Type = 888,Variant = 0,level = 5,},
				{Type = 217,Variant = 0,level = 1,},
				{Type = 217,Variant = 1,level = 1,},
				{Type = 217,Variant = 2,level = 1,},
				{Type = 217,Variant = 3,level = 1,},
				{Type = 870,Variant = 0,level = 1,},
				{Type = 220,Variant = 0,level = 2,},
				{Type = 220,Variant = 1,level = 3,},
				{Type = 826,Variant = 0,level = 2,},
				{Type = 871,Variant = 0,level = 1,},
				{Type = 221,Variant = 0,level = 4,},
				{Type = 226,Variant = 0,level = 1,},
				{Type = 226,Variant = 1,level = 3,},
				{Type = 226,Variant = 2,level = 1,},
				{Type = 227,Variant = 0,level = 3,},
				{Type = 227,Variant = 1,level = 5,},
				{Type = 277,Variant = 0,level = 3,},
				{Type = 841,Variant = 0,level = 3,},
				{Type = 841,Variant = 1,level = 3,},
				{Type = 890,Variant = 0,SubType = {0,1,},level = 3,},
				{Type = 228,Variant = 0,level = 4,},
				{Type = 251,Variant = 0,level = 5,},
				{Type = 231,Variant = 0,level = 4,},
				{Type = 231,Variant = 1,level = 4,},
				{Type = 805,Variant = 0,level = 3,},
				{Type = 237,Variant = 0,level = 2,},
				{Type = 891,Variant = 0,level = 3,},
				{Type = 891,Variant = 1,level = 3,},
				--{Type = 239,Variant = 0,mul = {3,4,5,},level = 2,},
				{Type = 290,Variant = 0,level = 4,},
				{Type = 844,Variant = 0,level = 2,},
				{Type = 306,Variant = 0,level = 5,},
				{Type = 306,Variant = 1,level = 3,},
				{Type = 295,Variant = 0,level = 3,},
				{Type = 892,Variant = 0,level = 3,},
				{Type = 293,Variant = 0,level = 6,},
				{Type = 293,Variant = 1,level = 6,},
				{Type = 293,Variant = 2,level = 6,},
				{Type = 293,Variant = 3,level = 6,},
				{Type = 818,Variant = 1,SubType = {0,1,2,3,},level = 4,},
				{Type = 829,Variant = 0,level = 2,},
				{Type = 829,Variant = 1,level = 5,},
				--{Type = 906,Variant = 1,},
				--966
			},
			onwall = {
				{Type = 240,Variant = 0,level = 2,},
				{Type = 240,Variant = 1,level = 2,},
				{Type = 240,Variant = 2,level = 3,},
				{Type = 240,Variant = 3,level = 5,},
				{Type = 241,Variant = 0,level = 3,},
				{Type = 241,Variant = 1,level = 3,},
				{Type = 242,Variant = 0,level = 2,},
				{Type = 304,Variant = 0,level = 2,},
			},
			jumpable = {
				{Type = 29,Variant = 0,level = 1,},
				{Type = 29,Variant = 1,level = 2,},
				{Type = 29,Variant = 2,level = 3,},
				{Type = 29,Variant = 3,level = 5,},
				{Type = 34,Variant = 0,level = 3,},
				{Type = 34,Variant = 1,level = 3,},
				{Type = 54,Variant = 0,level = 1,},
				{Type = 246,Variant = 0,level = 2,},
				{Type = 246,Variant = 1,level = 3,},
				{Type = 303,Variant = 0,level = 3,},
				{Type = 840,Variant = 0,level = 3,},
				{Type = 86,Variant = 0,level = 2,},
				{Type = 215,Variant = 0,level = 1,},
				{Type = 250,Variant = 0,level = 1,},
				{Type = 869,Variant = 0,level = 1,},
				{Type = 305,Variant = 0,level = 1,},
				{Type = 851,Variant = 0,level = 4,},
				--815.0
			},
			hideable = {
				{Type = 56,Variant = 0,level = 4,},
				{Type = 307,Variant = 0,level = 3,},
				{Type = 58,Variant = 0,level = 4,},
				{Type = 58,Variant = 1,level = 4,},
				{Type = 59,Variant = 0,level = 4,},
				{Type = 244,Variant = 0,level = 1,},
				{Type = 244,Variant = 1,level = 2,},
				{Type = 244,Variant = 2,level = 5,},
				{Type = 244,Variant = 3,level = 5,},
				{Type = 255,Variant = 0,level = 2,},
				{Type = 276,Variant = 0,level = 1,},
				{Type = 289,Variant = 0,level = 1,},
				{Type = 881,Variant = 0,level = 2,},
				{Type = 881,Variant = 1,level = 2,},
			},
			flyable = {
				{Type = 13,Variant = 0,level = 1,},
				{Type = 18,Variant = 0,level = 1,},
				{Type = 80,Variant = 0,level = 1,},
				--{Type = 96,Variant = 0,},
				{Type = 222,Variant = 0,level = 1,},
				{Type = 256,Variant = 0,level = 1,},
				--{Type = 281,Variant = 0,is_multi = true,level = 1,},
				{Type = 296,Variant = 0,level = 4,},
				{Type = 808,Variant = 0,level = 1,},
				{Type = 868,Variant = 0,level = 1,},
				{Type = 951,Variant = 11,level = 4,},
				{Type = 951,Variant = 21,level = 4,},
				{Type = 819,Variant = 0,level = 2,},
				--{Type = 819,Variant = 1,},
				{Type = 79,Variant = 10,SubType = {0,1,2,},level = 4,},
				{Type = 79,Variant = 11,SubType = 0,level = 3,},
				{Type = 61,Variant = 0,level = 1,},
				{Type = 61,Variant = 1,level = 2,},
				{Type = 61,Variant = 2,level = 3,},
				{Type = 61,Variant = 3,level = 3,},
				{Type = 61,Variant = 4,level = 4,},
				{Type = 61,Variant = 5,level = 1,},
				{Type = 61,Variant = 6,level = 4,},
				{Type = 61,Variant = 7,level = 5,},
				{Type = 14,Variant = 0,level = 1,},
				{Type = 14,Variant = 1,level = 1,},
				{Type = 14,Variant = 2,level = 5,},
				{Type = 25,Variant = 0,level = 2,},
				{Type = 25,Variant = 1,level = 2,},
				{Type = 25,Variant = 2,level = 2,},
				{Type = 25,Variant = 3,SubType = 0,level = 2,},
				{Type = 25,Variant = 3,SubType = 1,level = 2,},
				{Type = 25,Variant = 4,level = 2,},
				{Type = 25,Variant = 5,level = 4,},
				{Type = 25,Variant = 6,level = 5,},
				{Type = 26,Variant = 0,level = 2,},
				{Type = 26,Variant = 1,level = 2,},
				{Type = 26,Variant = 2,level = 3,},
				{Type = 859,Variant = 0,level = 4,},
				{Type = 301,Variant = 0,level = 4,},
				{Type = 38,Variant = 0,level = 3,},
				{Type = 38,Variant = 1,level = 5,},
				{Type = 38,Variant = 2,level = 5,},
				{Type = 38,Variant = 1,SubType = 1,level = 3,},
				{Type = 38,Variant = 3,level = 4,},
				{Type = 259,Variant = 0,level = 5,},
				{Type = 860,Variant = 0,level = 4,},
				{Type = 883,Variant = 0,level = 3,},
				{Type = 833,Variant = 0,level = 3,},
				{Type = 254,Variant = 0,level = 3,},
				{Type = 55,Variant = 0,level = 3,},
				{Type = 55,Variant = 1,level = 4,},
				{Type = 55,Variant = 2,level = 5,},
				{Type = 854,Variant = 0,level = 4,},
				{Type = 90,Variant = 0,level = 3,},
				{Type = 91,Variant = 0,level = 2,},
				{Type = 886,Variant = 1,level = 3,},
				--{Type = 212,Variant = 0,ignore_place = true,level = 2,},
				{Type = 212,Variant = 1,level = 3,},
				--{Type = 212,Variant = 2,only_spawn = true,ignore_place = true,level = 3,},
				--{Type = 212,Variant = 3,only_spawn = true,ignore_place = true,level = 3,},
				{Type = 212,Variant = 4,level = 2,},
				{Type = 286,Variant = 0,level = 4,},
				--{Type = 887,Variant = 0,ignore_place = true,only_spawn = true,level = 2,},
				--{Type = 951,Variant = 42,},
				{Type = 213,Variant = 0,level = 3,},
				{Type = 287,Variant = 0,level = 4,},
				{Type = 214,Variant = 0,level = 1,},
				{Type = 249,Variant = 0,level = 1,},
				{Type = 838,Variant = 0,level = 2,},
				{Type = 219,Variant = 0,level = 3,},
				{Type = 285,Variant = 0,level = 5,},
				{Type = 224,Variant = 0,level = 4,},
				{Type = 225,Variant = 0,level = 5,},
				{Type = 229,Variant = 0,level = 3,},
				{Type = 229,Variant = 1,level = 4,},
				{Type = 230,Variant = 0,level = 5,},
				{Type = 253,Variant = 0,level = 5,},
				{Type = 234,Variant = 0,level = 2,},
				{Type = 258,Variant = 0,level = 2,},
				{Type = 885,Variant = 0,level = 3,},
				{Type = 885,Variant = 1,level = 3,},
				{Type = 260,Variant = 10,level = 3,},
				{Type = 816,Variant = 0,level = 2,},
				{Type = 816,Variant = 1,level = 2,},
				{Type = 882,Variant = 0,level = 2,},
				{Type = 288,Variant = 0,level = 3,},
				{Type = 308,Variant = 0,level = 4,},
				{Type = 873,Variant = 0,level = 1,},
				{Type = 875,Variant = 0,level = 1,},
				{Type = 880,Variant = 0,level = 2,},
				{Type = 863,Variant = 0,SubType = {0,1,2,},level = 3,},
				{Type = 864,Variant = 0,level = 3,},
				--409.1
				{Type = 903,Variant = 20,level = 3,},
				{Type = 951,Variant = 23,level = 5,},
				{Type = 404,Variant = 1,SubType = {0,1,2,},level = 2,},
				{Type = 950,Variant = 10,level = 5,},
			},
			special = {
				{Type = 53,Variant = 0,},
				{Type = 53,Variant = 1,},
				--{Type = 818,Variant = 1,},
			},
			water = {
				{Type = 311,Variant = 0,},
				{Type = 825,Variant = 0,},
				{Type = 837,Variant = 0,},
			},
			unbreakable = {
				{Type = 42,Variant = 0,},
				{Type = 42,Variant = 1,},
				{Type = 42,Variant = 2,},
				{Type = 201,Variant = 0,},
				{Type = 202,Variant = 0,only_spawn = true,SubType = {0,1,2,3,},},
				{Type = 202,Variant = 10,},
				{Type = 203,Variant = 0,only_spawn = true,SubType = {0,1,2,3,},},
				{Type = 235,Variant = 0,},
				{Type = 236,Variant = 0,},
				{Type = 804,Variant = 0,only_spawn = true,SubType = {0,1,2,3,},},
				{Type = 809,Variant = 0,only_spawn = true,},
				{Type = 893,Variant = 0,only_spawn = true,},
				{Type = 852,Variant = 0,},
				{Type = 915,Variant = 1,},
				{Type = 291,Variant = 0,},
				{Type = 291,Variant = 1,},
				{Type = 291,Variant = 2,},
			},
			spike = {
				{Type = 44,Variant = 0,},
				{Type = 44,Variant = 1,},
				{Type = 218,Variant = 0,},
				{Type = 877,Variant = 0,only_spawn = true,},
			},
		},
		sins = {
			normal = {
				{Type = 46,Variant = 0,},
				{Type = 46,Variant = 1,},
				{Type = 46,Variant = 2,},
				{Type = 47,Variant = 0,},
				{Type = 47,Variant = 1,},
				{Type = 48,Variant = 0,},
				{Type = 48,Variant = 1,},
				{Type = 49,Variant = 0,},
				{Type = 49,Variant = 1,},
				{Type = 50,Variant = 0,},
				{Type = 50,Variant = 1,},
				{Type = 51,Variant = {0,10},only_spawn = true,},
				{Type = 51,Variant = {0,11},only_spawn = true,},
				{Type = 51,Variant = {20,30,},},
				{Type = 51,Variant = {21,31,},},
				{Type = 52,Variant = 0,},
				{Type = 52,Variant = 1,},
			},
		},
		boss = {
			normal = {
				{Type = 19,Variant = 0,SubType = {0,1,2,},mul = {4,5,6,7,},is_multi = true,},
				{Type = 19,Variant = 2,SubType = 0,mul = {4,5,6,7,},is_multi = true,special = function(pos) local q = Isaac.Spawn(809,0,0,pos,Vector(0,0),nil) end,},
				{Type = 79,Variant = 0,SubType = {0,1,2,},myspecial = function(ent) local n_entity = Isaac.GetRoomEntities() local chains = auxi.getothers(n_entity,79,20,nil) for u,v in pairs(chains) do v:Remove() end end,},
				{Type = 79,Variant = 1,SubType = 0,},
				{Type = 79,Variant = 2,SubType = 0,},
				{Type = 237,Variant = 1,SubType = {0,1,2,},},
				{Type = 237,Variant = 2,SubType = 0,},
				{Type = 261,Variant = 0,SubType = {0,1,2,},},
				{Type = 261,Variant = 1,SubType = 0,},
				{Type = 404,Variant = 0,SubType = {0,1,2,},},
				{Type = 405,Variant = 0,SubType = {0,1,2,},},
				{Type = 405,Variant = 1,SubType = {0,1,2,},},
				{Type = 902,Variant = 0,SubType = 0,},
				{Type = 914,Variant = 0,SubType = 0,},
				{Type = 917,Variant = 0,SubType = 0,},
				{Type = 918,Variant = 0,SubType = 0,mul = {3,4,5,6,7,},is_multi = true,},
				{Type = 28,Variant = 0,SubType = {0,1,2,},mul = {3,4,5,},is_multi = true,},
				{Type = 28,Variant = 1,SubType = 0,mul = {3,4,5,},is_multi = true,},
				{Type = 28,Variant = 2,SubType = {0,1,},mul = {3,},is_multi = true,},
				{Type = 36,Variant = 0,SubType = {0,1,},},
				{Type = 99,Variant = 0,SubType = {0,1,2,},},
				{Type = 262,Variant = 0,SubType = {0,1,2,},},
				{Type = 263,Variant = 0,SubType = {0,1,2,},},
				{Type = 402,Variant = 0,SubType = {0,1,},},
				{Type = 270,Variant = 0,SubType = 0,},
				{Type = 74,Variant = 0,SubType = 0,},
				{Type = 75,Variant = 0,SubType = 0,},
				{Type = 76,Variant = 0,SubType = 0,},
				{Type = 413,Variant = 0,SubType = 0,},
				{Type = 910,Variant = 0,SubType = 0,},
				{Type = 910,Variant = 1,SubType = 0,},
				{Type = 910,Variant = 2,SubType = 0,},
				{Type = 911,Variant = 0,SubType = 0,},		--有点特殊
				{Type = 407,Variant = 0,SubType = 0,},
				{Type = 84,Variant = 0,SubType = 0,},		--问题不大
				{Type = 273,Variant = 0,SubType = 0,},
				{Type = 406,Variant = 0,SubType = 0,},
				{Type = 406,Variant = 1,SubType = 0,},
				--{Type = 906,Variant = 0,SubType = 0,only_spawn = true,},
				{Type = 903,Variant = 0,SubType = 0,only_spawn = true,},
				{Type = 921,Variant = 0,SubType = 0,special = function(pos) local rnd = math.random(3) + 2 for i = 1,rnd do local q = Isaac.Spawn(889,0,0,pos,Vector(0,0),nil) local d2 = q:GetData() d2.has_been_checked_by_Danger = true q.SpawnerType = 10001 end end,},
			},
			jumpable = {
				{Type = 20,Variant = 0,SubType = {0,1,2,},},
				{Type = 100,Variant = 0,SubType = {0,1,2,},},
				{Type = 100,Variant = 1,SubType = 0,},
				{Type = 68,Variant = 0,SubType = 0,},
				{Type = 264,Variant = 0,SubType = {0,1,2,},},
				{Type = 916,Variant = 0,SubType = 0,},
				{Type = 900,Variant = 0,SubType = 0,},
				{Type = 43,Variant = 0,SubType = {0,1,},},
				{Type = 43,Variant = 1,SubType = 0,},
				{Type = 69,Variant = 0,SubType = 0,},
				{Type = 69,Variant = 1,SubType = 0,mul = 2},
				{Type = 265,Variant = 0,SubType = {0,1,2,},},
				{Type = 410,Variant = 0,SubType = 0,},		--这个会一次生成2个哦！
			},
			hideable = {
				{Type = 62,Variant = 0,SubType = {0,1,},is_multi = true,},
				{Type = 62,Variant = 1,SubType = 0,is_multi = true,},
				{Type = 62,Variant = 2,SubType = {0,1,},is_multi = true,},
				{Type = 401,Variant = 0,SubType = {0,1,},},
				{Type = 411,Variant = 0,SubType = 0,},
				{Type = 269,Variant = 0,SubType = {0,1,2,},},
				{Type = 269,Variant = 1,SubType = 0,},
			},
			flyable = {
				{Type = 19,Variant = 1,SubType = {0,1,2,3},mul = {3,4,5,6,7,},is_multi = true,},
				{Type = 63,Variant = 0,SubType = {0,1,},},
				{Type = 64,Variant = 0,SubType = {0,1,},},
				{Type = 65,Variant = 0,SubType = {0,1,},},
				{Type = 65,Variant = 1,SubType = 0,},
				{Type = 66,Variant = 0,SubType = {0,1,},},
				{Type = 67,Variant = 0,SubType = {0,1,2,},},
				{Type = 67,Variant = 1,SubType = {0,1,2,},},
				{Type = 908,Variant = 0,SubType = 0,},
				{Type = 260,Variant = 0,SubType = {0,1,2,},},
				{Type = 901,Variant = 0,SubType = 0,},
				{Type = 913,Variant = 0,SubType = 0,},
				{Type = 71,Variant = 0,SubType = {0,1,},},
				{Type = 71,Variant = 1,SubType = 0,},
				{Type = 72,Variant = 0,SubType = {0,1,},},
				{Type = 72,Variant = 1,SubType = 0,},
				{Type = 73,Variant = 0,SubType = {0,1,},},
				{Type = 73,Variant = 1,SubType = 0,},
				{Type = 267,Variant = 0,SubType = 0,},
				{Type = 403,Variant = 0,SubType = {0,1,},},
				{Type = 409,Variant = 0,SubType = 0,},
				{Type = 268,Variant = 0,SubType = 0,},
				{Type = 97,Variant = 0,SubType = {0,1,},},			--会生成心脏
				{Type = 904,Variant = 0,SubType = 0,},
				{Type = 905,Variant = 0,SubType = 0,},
				{Type = 920,Variant = 0,SubType = 0,},
				{Type = 78,Variant = 0,SubType = 0,},
				{Type = 78,Variant = 0,SubType = 1,},
				{Type = 78,Variant = 1,SubType = 0,},
				{Type = 78,Variant = 1,SubType = 1,},
				{Type = 101,Variant = 0,SubType = 0,},
				{Type = 101,Variant = 1,SubType = 0,},
				{Type = 266,Variant = 0,SubType = 0,},
				{Type = 909,Variant = 0,SubType = 0,},
				{Type = 911,Variant = 2,SubType = 0,},			--没问题
				{Type = 912,Variant = 10,SubType = 0,},
				{Type = 912,Variant = 0,SubType = 0,only_spawn = true,pre_special_work = function()
					local level = Game():GetLevel()
					local room = Game():GetRoom()
					local listindex = level:GetCurrentRoomDesc().ListIndex
					save.elses.alldoorsinfo = save.elses.alldoorsinfo or {}
					save.elses.alldoorsinfo[listindex] = {}
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do 
						if room:IsDoorSlotAllowed(slot) then
							local door = room:GetDoor(slot)
							if door then
								--print(slot)
								save.elses.alldoorsinfo[listindex][slot] = {slot = slot,spritefilename = door:GetSprite():GetFilename(),linked = door.TargetRoomIndex,dir = door.Direction,}
							end
						end
					end
					--l local room = Game():GetRoom() for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do local door = room:GetDoor(slot) if door then door:SetType(16) door:Init(1) door.TargetRoomIndex = 84 end end
				end,should_remakeroom = true,},
				{Type = 102,Variant = 0,SubType = 0,},
				{Type = 102,Variant = 1,SubType = 0,},
				{Type = 102,Variant = 2,SubType = 0,},
				{Type = 84,Variant = 10,SubType = 0,},			--没问题
				--{Type = 274,Variant = 0,SubType = 0,only_spawn = true,},
				{Type = 412,Variant = 0	,SubType = 0,nonly_spawn = true,},
				{Type = 950,Variant = 0,SubType = 0,only_spawn = true,special_work = function(ent)
					local d = ent:GetData()
					d.danger_kill_dogma = true
				end,should_transmit = true,},
				{Type = 950,Variant = 2	,SubType = 0,only_spawn = true,special_work = function(ent)
					local d = ent:GetData()
					d.danger_help_with_idle = true
				end},
				{Type = 951,Variant = 10,SubType = 0,},
				{Type = 951,Variant = 20,SubType = 0,},
				{Type = 951,Variant = 30,SubType = 0,},
				{Type = 951,Variant = 40,SubType = 0,},
				{Type = 81,Variant = 0,SubType = 0,},
				{Type = 81,Variant = 1,SubType = 0,},
				{Type = 82,Variant = 0,SubType = 0,special = function(pos) local mul = math.random(3) for i = 1,mul do local q = Isaac.Spawn(83,0,0,pos,Vector(0,0),nil) local d2 = q:GetData() d2.has_been_checked_by_Danger = true q.SpawnerType = 10001 end end},
				{Type = 271,Variant = 0,SubType = 0,},
				{Type = 271,Variant = 1,SubType = 0,},
				{Type = 272,Variant = 1,SubType = 0,},
				{Type = 272,Variant = 0,SubType = 0,},
				{Type = 272,Variant = 0,SubType = 0,},
				{Type = 19,Variant = 3,SubType = 0,mul = {3,4,5,6,7,},is_multi = true,special = function(pos) local q = Isaac.Spawn(809,0,0,pos,Vector(0,0),nil) end,},
				{Type = 45,Variant = 10,SubType = 3,should_delay = true,special_morph = {Variant = 0,},center_pos = true,special = function(pos) 
					local room = Game():GetRoom()
					local n_entity = Isaac.GetRoomEntities()
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do 
						if room:IsDoorSlotAllowed(slot) then
							local pos = room:GetDoorSlotPosition(slot)
							local should_spawn = true
							for u,v in pairs(n_entity) do
								if v.Type == 45 and (v.Position - pos):Length() < 60 then
									should_spawn = false
									break
								end
							end
							if should_spawn then
								local q = Isaac.Spawn(45,0,3,pos,Vector(0,0),nil) 
								local d2 = q:GetData() 
								d2.has_been_checked_by_Danger = true
								--q.SpawnerType = 10001
								d2.fixed_position = pos
							end
						end
					end
				end,},
				{Type = 45,Variant = 10,SubType = 2,should_delay = true,special_morph = {Variant = 0,},center_pos = true,special = function(pos) 
					local room = Game():GetRoom()
					local n_entity = Isaac.GetRoomEntities()
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do 
						if room:IsDoorSlotAllowed(slot) then
							local pos = room:GetDoorSlotPosition(slot)
							local should_spawn = true
							for u,v in pairs(n_entity) do
								if v.Type == 45 and (v.Position - pos):Length() < 60 then
									should_spawn = false
									break
								end
							end
							if should_spawn then
								local q = Isaac.Spawn(45,0,2,pos,Vector(0,0),nil) 
								local d2 = q:GetData() 
								d2.has_been_checked_by_Danger = true
								--q.SpawnerType = 10001
								d2.fixed_position = pos
							end
						end
					end
				end,},
				{Type = 45,Variant = 10,SubType = 1,should_delay = true,special_morph = {Variant = 0,},center_pos = true,special = function(pos) 
					local room = Game():GetRoom()
					local n_entity = Isaac.GetRoomEntities()
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do 
						if room:IsDoorSlotAllowed(slot) then
							local pos = room:GetDoorSlotPosition(slot)
							local should_spawn = true
							for u,v in pairs(n_entity) do
								if v.Type == 45 and (v.Position - pos):Length() < 60 then
									should_spawn = false
									break
								end
							end
							if should_spawn then
								local q = Isaac.Spawn(45,0,1,pos,Vector(0,0),nil) 
								local d2 = q:GetData() 
								d2.has_been_checked_by_Danger = true
								--q.SpawnerType = 10001
								d2.fixed_position = pos
							end
						end
					end
				end,},
				{Type = 45,Variant = 10,SubType = 0,should_delay = true,special_morph = {Variant = 0,},center_pos = true,special = function(pos) 
					local room = Game():GetRoom()
					local n_entity = Isaac.GetRoomEntities()
					for slot = 0, DoorSlot.NUM_DOOR_SLOTS - 1 do 
						if room:IsDoorSlotAllowed(slot) then
							local pos = room:GetDoorSlotPosition(slot)
							local should_spawn = true
							for u,v in pairs(n_entity) do
								if v.Type == 45 and (v.Position - pos):Length() < 60 then
									should_spawn = false
									break
								end
							end
							if should_spawn then
								local q = Isaac.Spawn(45,0,0,pos,Vector(0,0),nil) 
								local d2 = q:GetData() 
								d2.has_been_checked_by_Danger = true
								--q.SpawnerType = 10001
								d2.fixed_position = pos
							end
						end
					end
				end,},
			},
			special = {
				--{Type = 906,Variant = 0,SubType = 0,},
				--{Type = 907,Variant = 0,SubType = 0,},
				--{Type = 903,Variant = 0,SubType = 0,},
			},
			water = {
				{Type = 62,Variant = 3,SubType = 0,},
			},
		},
	},
	info_data = {},
	other_info = {		--处理某些不应该生成，但是却应该被转化的怪物。
		monsters = {
			normal = {
			},
			flyable = {
				{Type = 66,Variant = 10,SubType = 0,},
				{Type = 951,Variant = 42,SubType = 0,},
				--{Type = 951,Variant = 41,SubType = 0,},
				{Type = 951,Variant = 1,SubType = {0,1,},},
				{Type = 819,Variant = 1,true_life = 50,},
				--{Type = 96,Variant = 0,true_life = 50,},
			},
		},
		sins = {},
		boss = {
			normal = {
				{Type = 904,Variant = 1,SubType = 0,},
			},
			flyable = {
				{Type = 79,Variant = 12,SubType = 0,},
				{Type = 951,Variant = 3,SubType = 0,},
				{Type = 83,Variant = 0,SubType = 0,},
				{Type = 45,Variant = 0,SubType = {0,1,2,3,},},
			},
			special = {
			},
		},
	},
	morph_dirs = {
		normal = {"normal","jumpable","hideable","flyable",},
		onwall = {"onwall","jumpable","hideable","flyable",},
		jumpable = {"jumpable","hideable","flyable",},
		hideable = {"jumpable","hideable","flyable",},
		flyable = {"onwall","jumpable","hideable","flyable",},
		water = {"water","onwall","jumpable","hideable","flyable",},
		spike = {"spike",},
		unbreakable = {"unbreakable",},
		special = {"special",},
	},
	availables_dirs = {"normal","jumpable","hideable","flyable","onwall",},
	level_map = {
		[9] = 4,
		[11] = 5,
		[12] = 6,
		[13] = 6,
	},
}

function item.get_now_level()
	if Game():IsGreedMode() then
		local stag = Game():GetLevel():GetStage()
		local ret = stag
		if ret >= 7 then ret = 6 end
		return ret
	else
		local level = Game():GetLevel()
		local stag = level:GetStage()
		local ret = item.level_map[stag] or math.ceil(stag/2)
		if level:IsAscent() then ret = 5 end
		return ret
	end
end

function item.get_safe_level(level)
	level = level or item.get_now_level()
	if level > 6 then level = 6 end
	if level < 0 then level = 0 end
	return level
end

local function check_multiple(stb)
	local ret = {}
	if type(stb) == "table" then
		for u,v in pairs(stb) do
			table.insert(ret,#ret + 1,v)
		end
	else
		ret[1] = stb
	end
	return ret
end

local function get_multiple(stb)
	local ret = 0
	if type(stb) == "table" then
		if #stb > 0 then
			ret = stb[math.random(#stb)]
		end
	elseif stb ~= nil then 
		ret = stb 
	end
	return ret
end

local function form_info_name(tp)
	if type(tp) == "table" then
		local ret = {}
		local ret_1 = ""
		local ret_2 = ""
		local ret_3 = ""
		local Typeinfo = check_multiple(tp.Type or 0)
		for u,v in pairs(Typeinfo) do
			ret_1 = tostring(v) .. "_"
			local Variantinfo = check_multiple(tp.Variant or 0)
			for u2,v2 in pairs(Variantinfo) do
				ret_2 = ret_1 .. tostring(v2) .. "_"
				local SubTypeinfo = check_multiple(tp.SubType or 0)
				for u3,v3 in pairs(SubTypeinfo) do
					ret_3 = ret_2 .. tostring(v3)
					table.insert(ret,#ret + 1,{name = ret_3,Type = v,Variant = v2,SubType = v3,})
				end
			end
		end
		return ret
	else
		local ret = nil
		if tp.Type ~= nil and tp.Variant ~= nil and tp.SubType ~= nil then
			ret = tostring(tp.Type) .. "_" .. tostring(tp.Variant) .. "_" .. tostring(tp.SubType)
		end
		return ret
	end
end

function item.make_data()
	item.info_data = {}
	for	u1,v1 in pairs(item.original_info) do
		for u2,v2 in pairs(v1) do
			for u3,v3 in pairs(v2) do
				local name_info = form_info_name(v3)
				if type(name_info) == "table" then
					for u4,v4 in pairs(name_info) do
						item.info_data[v4.name] = {base = v4,i1 = u1,i2 = u2,data = v3,}
					end
				end
			end
		end
	end
	for	u1,v1 in pairs(item.other_info) do
		for u2,v2 in pairs(v1) do
			for u3,v3 in pairs(v2) do
				local name_info = form_info_name(v3)
				if type(name_info) == "table" then
					for u4,v4 in pairs(name_info) do
						item.info_data[v4.name] = {base = v4,i1 = u1,i2 = u2,data = v3,is_other = true,}
					end
				end
			end
		end
	end
end

function item.check_data(ent)
	if item.info_data == nil or #item.info_data == 0 then 
		item.make_data()
	end
	local name = form_info_name(ent)
	if name ~= nil then
		return item.info_data[name]
	end
end

function item.get_morph_dir(tp)
	local ret = {}
	if type(tp) == "string" then
		ret = item.morph_dirs[tp] or ret
	end
	return ret
end

function item.spawn_it_now(ent,info,should_protect,specialwork)
	local mul = get_multiple(info.data.mul) or 1
	local ret = nil
	local room = Game():GetRoom() 
	if mul == 0 then mul = 1 end
	local pos = ent.Position or room:GetRandomPosition(20) 
	local tg_mxhp = ent.MaxHitPoints
	local should_transmit = nil
	local should_remakeroom = nil
	if info.data.pre_special_work then info.data.pre_special_work() end
	for i = 1,mul do
		--if info.data.ignore_place then pos = room:GetRandomPosition(20) end
		local tp = ent.Type
		local vr = ent.Variant
		local st = ent.SubType
		if info.data.special_morph then
			local mpif = info.data.special_morph
			tp = mpif.Type or tp
			vr = mpif.Variant or vr
			st = mpif.SubType or st
		end
		--print(tp.." "..vr.." "..st)
		local q = Isaac.Spawn(tp,vr,st,pos,Vector(0,0),nil):ToNPC()
		if ent.GetChampionColorIdx then q:Morph(tp,vr,st,ent:GetChampionColorIdx()) end
		if tg_mxhp then
			q.MaxHitPoints = tg_mxhp
			q.HitPoints = q.MaxHitPoints
		end
		ret = q
		if should_protect then q:AddEntityFlags(EntityFlag.FLAG_AMBUSH) end
		if specialwork then specialwork(q) end
		if info.data.special_work then info.data.special_work(q) end
	end
	if info.data.special then info.data.special(pos) end
	return ret
end

function item.spawn_by_info(ent,info,should_protect,specialwork)
	if info.is_other then return end
	if info.data.should_delay then
		delay_buffer.addeffe(function(params)
			item.spawn_it_now(ent,info,should_protect,specialwork)
		end,{},5)
	else
		return item.spawn_it_now(ent,info,should_protect,specialwork)
	end
	return nil
end

function item.random_add_ent()
	local stag = {}
	local tot_wei = 0
	local sel = nil
	for u,v in pairs(item.availables_dirs) do
		for uu,vv in pairs(item.original_info.monsters[v]) do
			table.insert(stag,#stag + 1,{wei = 1,sel = vv,})
			tot_wei = tot_wei + 1
		end
	end
	tot_wei = math.random(tot_wei)
	for u,v in pairs(stag) do
		tot_wei = tot_wei - v.wei
		if tot_wei <= 0 then
			sel = v.sel
			break
		end
	end
	if sel then
		return item.spawn_by_info({
			Type = get_multiple(sel.Type),
			Variant = get_multiple(sel.Variant),
			SubType = get_multiple(sel.SubType),
			Position = Vector(2000,2000),
		},{data = sel,},true)
	end
end

function item.check_and_add_ent(ent,lev)
	local name_info = item.check_data(ent)
	if name_info then
		local dir = item.get_morph_dir(name_info.i2)
		if #dir > 0 then
			local stag = {}
			local tot_wei = 0
			local sel = nil
			for u,v in pairs(dir) do
				if item.original_info[name_info.i1][v] and #(item.original_info[name_info.i1][v]) > 0 then
					for uu,vv in pairs(item.original_info[name_info.i1][v]) do
						if (vv.level or 1000) <= lev then
							table.insert(stag,#stag + 1,{wei = 1,sel = vv,})
							tot_wei = tot_wei + 1
						end
					end
				end
			end
			if #stag > 0 then
				tot_wei = math.random(tot_wei)
				for u,v in pairs(stag) do
					tot_wei = tot_wei - v.wei
					if tot_wei <= 0 then
						sel = v.sel
						break
					end
				end
				if sel then
					item.spawn_by_info({
						Type = get_multiple(sel.Type),
						Variant = get_multiple(sel.Variant),
						SubType = get_multiple(sel.SubType),
						Position = ent.Position,
					},{data = sel,},nil,function(ent) ent:GetData().checked_by_crisis_option_list_5 = true ent.SpawnerType = 10001 end)
				end
			end
		end
	end
end

function item.check_and_morph_ent(ent,should_protect)
	local name_info = item.check_data(ent)
	if name_info and not name_info.data.only_spawn then
		local dir = item.get_morph_dir(name_info.i2)
		if #dir > 0 then
			local stag = {}
			local tot_wei = 0
			local sel = nil
			for u,v in pairs(dir) do
				if item.original_info[name_info.i1][v] and #(item.original_info[name_info.i1][v]) > 0 then
					table.insert(stag,#stag + 1,{wei = #item.original_info[name_info.i1][v],sel = item.original_info[name_info.i1][v],})
					tot_wei = tot_wei + #item.original_info[name_info.i1][v]
				end
			end
			tot_wei = math.random(tot_wei)
			for u,v in pairs(stag) do
				tot_wei = tot_wei - v.wei
				if tot_wei <= 0 then
					sel = v.sel
					break
				end
			end
			if sel then
				--print("morph:" .. ent.Type .. " " ..ent.Variant .. " " .. ent.SubType)
				if name_info.data.is_multi and ent.ParentNPC ~= nil and ent.ChildNPC ~= nil then return {should_kill = true,} end
				local target_info = sel[math.random(#sel)]
				local mul = get_multiple(target_info.mul) or 1
				if mul == 0 then mul = 1 end
				local pos = ent.Position
				local tg_mxhp = ent.MaxHitPoints
				local should_transmit = nil
				local should_remakeroom = nil
				if name_info.data.true_life then tg_mxhp = name_info.data.true_life end
				if target_info.pre_special_work then target_info.pre_special_work() end
				if target_info.should_remakeroom then should_remakeroom = true end
				if target_info.should_transmit then should_transmit = true end
				for i = 1,mul do
					if target_info.ignore_place then 
						local room = Game():GetRoom() 
						pos = room:GetRandomPosition(20) 
					end
					local q = Isaac.Spawn(get_multiple(target_info.Type),get_multiple(target_info.Variant),get_multiple(target_info.SubType),pos,ent.Velocity,nil):ToNPC()
					if ent:IsChampion() then
						local champColor = ent:GetChampionColorIdx()
						q:MakeChampion(q.InitSeed, -1)
					end
					q.MaxHitPoints = tg_mxhp * 0.8 / mul + q.MaxHitPoints * 0.2
					q.HitPoints = q.MaxHitPoints
					if should_protect then q:AddEntityFlags(EntityFlag.FLAG_AMBUSH) end
					local d2 = q:GetData()
					d2.Crisis_option_4_checked = true
					if target_info.special_work then target_info.special_work(q) end
				end
				if target_info.special then
					target_info.special(pos)
				end
				if name_info.data.myspecial then
					name_info.data.myspecial(ent)
				end
				return {should_kill = true,should_transmit = should_transmit,should_remakeroom = should_remakeroom,}
			end
		end
	end
	return nil
end

function item.check_and_keep_ent(ent,should_protect)
	local name_info = item.check_data(ent)
	if name_info and not name_info.data.only_spawn then
		local dir = item.get_morph_dir(name_info.i2)
		if #dir > 0 then
			local stag = {}
			local tot_wei = 0
			local sel = nil
			for u,v in pairs(dir) do
				if item.original_info[name_info.i1][v] and #(item.original_info[name_info.i1][v]) > 0 then
					table.insert(stag,#stag + 1,{wei = #item.original_info[name_info.i1][v],sel = item.original_info[name_info.i1][v],})
					tot_wei = tot_wei + #item.original_info[name_info.i1][v]
				end
			end
			tot_wei = math.random(tot_wei)
			for u,v in pairs(stag) do
				tot_wei = tot_wei - v.wei
				if tot_wei <= 0 then
					sel = v.sel
					break
				end
			end
			if sel then
				--print("morph:" .. ent.Type .. " " ..ent.Variant .. " " .. ent.SubType)
				if name_info.data.is_multi and ent.ParentNPC ~= nil then return {should_kill = true,} end
				local target_info = name_info
				local mul = get_multiple(target_info.mul) or 1
				if mul == 0 then mul = 1 end
				local pos = ent.Position
				local tg_mxhp = ent.MaxHitPoints
				local should_transmit = nil
				local should_remakeroom = nil
				if name_info.data.true_life then tg_mxhp = name_info.data.true_life end
				if target_info.pre_special_work then target_info.pre_special_work() end
				if target_info.should_remakeroom then should_remakeroom = true end
				if target_info.should_transmit then should_transmit = true end
				for i = 1,mul do
					if target_info.ignore_place then 
						local room = Game():GetRoom() 
						pos = room:GetRandomPosition(20) 
					end
					local q = Isaac.Spawn(get_multiple(target_info.Type),get_multiple(target_info.Variant),get_multiple(target_info.SubType),pos,ent.Velocity,nil):ToNPC()
					if ent:IsChampion() then
						local champColor = ent:GetChampionColorIdx()
						q:MakeChampion(q.InitSeed,-1)
					end
					--q.MaxHitPoints = tg_mxhp * 0.8 / mul + q.MaxHitPoints * 0.2
					--q.HitPoints = q.MaxHitPoints
					if should_protect then q:AddEntityFlags(EntityFlag.FLAG_AMBUSH) end
					local d2 = q:GetData()
					d2.Crisis_option_4_checked = true
					if target_info.special_work then target_info.special_work(q) end
				end
				if target_info.special then
					target_info.special(pos)
				end
				if name_info.data.myspecial then
					name_info.data.myspecial(ent)
				end
				return {should_kill = true,should_transmit = should_transmit,should_remakeroom = should_remakeroom,}
			end
		end
	end
	return nil
end

if true then
	item.make_data()
end

return item