local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	pre_ToCall = {},
	post_ToCall = {},
}

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = nil,		--高速枚举
Function = function(_,cardtype,player,useFlags)
	local d = player:GetData()
	if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
		d.tarot_cloth_used = cardtype
	else
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = nil,		--高速枚举
Function = function(_,cardtype,player,useFlags)
	local d = player:GetData()
	if useFlags & UseFlag.USE_CARBATTERY == UseFlag.USE_CARBATTERY then
	else
		if d.tarot_cloth_used then
			d.tarot_cloth_used = nil
		end
	end
end,
})

return item