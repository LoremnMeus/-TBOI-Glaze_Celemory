local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")

local item = {
	ToCall = {},
}

function item.find_a_new_index()
	local ret = 0
	local banned = {}
	local n_entity = Isaac.GetRoomEntities()
	local n_pickups = auxi.getpickups(n_entity,false)
	for u,v in pairs(n_pickups) do
		local pk = v:ToPickup()
		if pk then
			if pk.OptionsPickupIndex then
				banned[pk.OptionsPickupIndex] = true
			end
		end
	end
	for i = 1,1000 do
		if banned[i] ~= true then
			return i
		end
	end
	return ret		--查询失败
end

return item