local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ui = require("Qing_Extra_scripts.auxiliary.ui")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_big_poop,
	ToCall = {},
}

local poop_ui = Sprite()
poop_ui:Load("gfx/glazed_poop.anm2", true)
poop_ui:Play("Idle",true)
poop_ui.Scale = Vector(0.5,0.5)
local frame = 0

function item.try_collect(player,ent)
	if ent:IsShopItem() then
		if ent.Price <= player:GetNumCoins() and player:IsExtraAnimationFinished() then
		else
			return nil
		end
	end
	if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
		save.elses.poop_counter = math.min(2,save.elses.poop_counter + 1)
	else
		save.elses.poop_counter = 1		
	end
	if auxi.has_poop_player() then
		player:AddPoopMana(2)
	end
	return true
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = 1,
Function = function(_,ent,amt,flag,source,cooldown)
	if amt > 0 and auxi.is_damage_from_enemy(ent, amt, flag, source, cooldown) then
		local player = ent:ToPlayer()
		local rng = player:GetDropRNG()
		rng = auxi.rng_for_sake(rng)
		if player then
			if save.elses.poop_counter and save.elses.poop_counter > 0 then
				player:UsePoopSpell(rng:RandomInt(11) + 1)
				save.elses.poop_counter = 0
			end
		end
	end
end,
})


table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,shadername)
	if shadername == "Qing_HelpfulShader" then
		if save.elses.poop_counter and save.elses.poop_counter > 0 and Game():GetHUD():IsVisible() then
			if Game():IsPaused() == false then
				frame = frame + 1
			else
				frame = frame - 1
			end
			if frame > 47 then frame = 0 end
			if frame < 0 then frame = 47 end
			poop_ui:SetFrame(frame)
			local pos = ui.UIPoopPos(0,auxi.is_double_player())
			poop_ui:Render(pos,Vector(0,0),Vector(0,0))
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
    if continue then
	else
		save.elses.poop_counter = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if ent.SubType == item.pickup.SubType then
		if player then
			local should_collect = item.try_collect(player,ent)
			if should_collect == true then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
					save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
				end
				if ent:IsShopItem() then player:AddCoins(-ent.Price) end
				ent.Velocity = Vector(0,0)
				ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_PING_PONG,1,1,false,0,2)
				if ent:IsShopItem() then
					player:AnimatePickup(ent:GetSprite())
					ent:Remove()
				else
					ent:GetSprite():Play("Collect", true)
				end
				if ent.OptionsPickupIndex ~= 0 then
					auxi.remove_others_option_pickup(ent)
				end
				return true
			elseif should_collect == nil then
				return true 
			else
				return false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		if ent:GetSprite():IsEventTriggered("DropSound") then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_SPLATTER,1,1,false,0,2)
		end
		if ent:GetSprite():IsFinished("Collect") or ent:GetSprite():IsEventTriggered("Remove") then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 42,
Function = function(_,ent)
	if save.UnlockData.Glaze.BlueBaby.Unlock == true and ModConfigSettings.Pickup_allow then
		if ent.SubType == 1 then
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			local rand = rng:RandomInt(60)		--大的有1/60的概率转化
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					if rand == 2 then
						rand = 1
					end
				end
			end
			if rand == 1 then
				ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
			end
		end
	end
end,
})

return item