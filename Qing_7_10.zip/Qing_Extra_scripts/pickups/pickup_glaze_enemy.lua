local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_grabbag,
	ToCall = {},
	Colors = {
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,25/255,50/255),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,25/255,75/255),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,50/255,75/255),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,50/255,55/255),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,-50/255,-55/255),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,-50/255,-75/255),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,-25/255,-75/255),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,-25/255,-50/255),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1/0.95,0.95)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(0.95,1/0.95)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
		{color = Color(0,0,0,0,0,0,0),scale = Vector(1,1)},
	},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_NPC_COLLISION, params = nil,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if player and (player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0) then
		local d = ent:GetData()
		if d.is_glazed_enemy and d.is_glazed_enemy == true then
			return false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_ENTITY_TAKE_DMG, params = nil,
Function = function(_,ent,amt,flag,source,cooldown)
    local d = ent:GetData()
	if d.is_glazed_enemy and d.is_glazed_enemy == true then
		if flag & DamageFlag.DAMAGE_CLONES ~= DamageFlag.DAMAGE_CLONES then
			if d.glaze_enemy_counter == nil then d.glaze_enemy_counter = 0 end
			d.glaze_enemy_counter = d.glaze_enemy_counter + 1
			if d.glaze_enemy_counter == 1 then
				return false
			else
				ent:TakeDamage(amt * math.min(1.5,(d.glaze_enemy_counter / 5)),flag | DamageFlag.DAMAGE_CLONES,source,cooldown)
				return false
			end
		end
		local s = ent:GetSprite()
		local c = s.Color
		s.Color = Color(1,1,1,1,s.RO,s.GO,s.BO)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_glazed_enemy and d.is_glazed_enemy == true then
		if ent:IsActiveEnemy() then --and (not ent:HasEntityFlags(EntityFlag.FLAG_ICE_FROZEN)) then
			local s = ent:GetSprite()
			local ts = ent:GetSprite()
			if Game():IsPaused() ~= true then
				--s.Scale = auxi.mul_t(ts.Scale,(item.Colors[ent.FrameCount%(#item.Colors) + 1].scale))
				s.Color = auxi.AddColor(ts.Color,item.Colors[ent.FrameCount%(#item.Colors) + 1].color,0.995,1)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_NPC_UPDATE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	if d.is_glazed_enemy and d.is_glazed_enemy == true then
		if ent.FrameCount % 480 == 240 then
			d.glaze_enemy_counter = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local room = Game():GetRoom()
	if d.is_glazed_enemy and d.is_glazed_enemy == true and room:IsFirstVisit() and ent:CanShutDoors() then
		if (not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and (not ent:IsBoss()) and (not ent:HasEntityFlags(EntityFlag.FLAG_NO_REWARD)) and (not Game():IsGreedMode())then
			local info = item.pickup
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			if rng:RandomInt(30) < ent.MaxHitPoints then		--血量上限越少，掉落概率越低。
				local wei = 0
				for u,v in pairs(enums.Pickups) do
					wei = wei + v.wei
				end
				wei = rng:RandomInt(wei)
				for u,v in pairs(enums.Pickups) do
					if v.wei > 0 then
						wei = wei - v.wei
						if wei <= 0 then
							info = v
							if u == "Glaze_bomb" and auxi.has_poop_player() then
								info = enums.Pickups.Glaze_big_poop
							end
							break
						end
					end
				end
				local q = Isaac.Spawn(5,info.Variant,info.SubType,ent.Position,math.random(1000)/500 * auxi.MakeVector(math.random(36000)/100),nil)
				auxi.special_morph(q,info)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = nil,
Function = function(_,ent)
	if save.UnlockData.Glaze.Judas.Unlock == true and ModConfigSettings.Pickup_allow and ent.Type ~= 996 then
		local d = ent:GetData()
		local rng = ent:GetDropRNG()
		rng = auxi.rng_for_sake(rng)
		local rand = rng:RandomInt(100)		--1/100的概率转化
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				if rand < 4 then
					rand = 1
				end
			end
		end
		if rand == 1 then
			if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() and (not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) then --and (not ent:IsBoss()) then
				d.is_glazed_enemy = true
			end
		end
	end
end,
})

return item