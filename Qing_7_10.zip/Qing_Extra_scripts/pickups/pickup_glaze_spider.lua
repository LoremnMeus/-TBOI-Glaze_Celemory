local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	familiar = {Variant = 73,SubType = 0,},
	familiar2 = {Variant = 43,SubType = 0,},
	ToCall = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = item.familiar.Variant,
Function = function(_,ent, col, low)
	if ent.Variant == item.familiar.Variant then
		local should_glaze = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				should_glaze = true
			end
		end
		local d = ent:GetData()
		if d.is_glazed_familiar and d.is_glazed_familiar == true then
			if col:IsVulnerableEnemy() and col:IsActiveEnemy() and (not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and col:CanShutDoors() == true then
				col:AddFreeze(EntityRef(ent),90)
				if should_glaze then
					col:GetData().is_glazed_enemy = true
				end
				d.is_glazed_familiar = false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_FAMILIAR_COLLISION, params = item.familiar2.Variant,
Function = function(_,ent, col, low)
	if ent.Variant == item.familiar2.Variant then
		local should_glaze = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				should_glaze = true
			end
		end
		local d = ent:GetData()
		if d.is_glazed_familiar and d.is_glazed_familiar == true then
			if col:IsVulnerableEnemy() and col:IsActiveEnemy() and not col:HasEntityFlags(EntityFlag.FLAG_FRIENDLY) and col:CanShutDoors() == true then
				col:AddFreeze(EntityRef(ent),60)
				if should_glaze then
					col:GetData().is_glazed_enemy = true
				end
				d.is_glazed_familiar = false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar.Variant,
Function = function(_,ent, col, low)
	if ent.Variant == item.familiar.Variant then
		local d = ent:GetData()
		if d.is_glazed_familiar and d.is_glazed_familiar == true then
			
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar2.Variant,
Function = function(_,ent, col, low)
	if ent.Variant == item.familiar2.Variant then
		local d = ent:GetData()
		if d.is_glazed_familiar and d.is_glazed_familiar == true then
			
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = item.familiar.Variant,
Function = function(_,ent)
	if save.UnlockData.Glaze.Apollyon.Unlock == true and ModConfigSettings.Pickup_allow then
		local rng = ent:GetDropRNG()
		rng = auxi.rng_for_sake(rng)
		local rand = rng:RandomInt(35)		--1/35的概率转化
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				if rand < 5 then
					rand = 1
				end
			end
		end
		if rand == 1 then
			local d = ent:GetData()
			local s = ent:GetSprite()
			d.is_glazed_familiar = true
			s:Load("gfx/glaze_spider.anm2", true)
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = item.familiar2.Variant,
Function = function(_,ent)
	if save.UnlockData.Glaze.Apollyon.Unlock == true and ModConfigSettings.Pickup_allow then
		local rng = ent:GetDropRNG()
		rng = auxi.rng_for_sake(rng)
		local rand = rng:RandomInt(25)		--1/25的概率转化
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				if rand < 5 then
					rand = 1
				end
			end
		end
		if rand == 1 then
			local d = ent:GetData()
			local s = ent:GetSprite()
			d.is_glazed_familiar = true
			s:Load("gfx/glaze_fly.anm2", true)
			s:Play("Idle")
		end
	end
end,
})

return item