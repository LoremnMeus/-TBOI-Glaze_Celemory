local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_chest,
	ToCall = {},
	familiar = enums.Familiars.Glaze_Chest_Key,
	familiar2 = enums.Familiars.Glaze_Chest_Key2,
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_EVALUATE_CACHE, params = nil,
Function = function(_,player,cacheFlag)
	if cacheFlag == CacheFlag.CACHE_FAMILIARS then
		local idx = player:GetData().__Index
		if idx then
			if save.elses["glaze_chest_cnt"..tostring(idx)] then
				player:CheckFamiliar(item.familiar, save.elses["glaze_chest_cnt"..tostring(idx)], player:GetCollectibleRNG(33))		--圣经真好玩
			end
			if player:GetData().should_erase_familiar_key then
				player:GetData().should_erase_familiar_key = nil
				local n_entity = Isaac.GetRoomEntities()
				local n_tg_familiar = auxi.getothers(n_entity,3,item.familiar2)
				for u,v in pairs(n_tg_familiar) do
					local d = v:GetData()
					if (d.is_waiting and d.has_follow) then		--只移除跟随角色的钥匙跟班。
						d:Remove()
					end
				end
			end
			if player:GetData().should_reset_familiar_key then
				player:CheckFamiliar(item.familiar2, 0, player:GetCollectibleRNG(33))
				player:GetData().should_reset_familiar_key = nil
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if player then
		if ent.SubType == item.pickup.SubType then		--通常方法不可打开。只有当角色拥有钥匙跟班才可以开启。
			local s = ent:GetSprite()
			if s:IsPlaying("Idle") then
				local d = ent:GetData()
				local idx = player:GetData().__Index
				if d.key_to_cn == nil then
					if idx then
						if save.elses["glaze_chest_cnt"..tostring(idx)] and save.elses["glaze_chest_cnt"..tostring(idx)] > 0 or save.elses["glaze_chest_cnt_fake_"..tostring(idx)] and save.elses["glaze_chest_cnt_fake_"..tostring(idx)] > 0 then
							local n_entity = Isaac.GetRoomEntities()
							local n_tg_familiar = auxi.getothers(n_entity,3,item.familiar)
							for u,v in pairs(n_tg_familiar) do
								local d2 = v:GetData()
								if d2.locked_chest == nil and not (d2.is_waiting and not d2.has_follow) then
									d2.locked_chest = ent
									d.key_to_cn = v
									break
								end
							end
							if d.key_to_cn == nil then
								local n_tg_familiar = auxi.getothers(n_entity,3,item.familiar2)
								for u,v in pairs(n_tg_familiar) do
									local d2 = v:GetData()
									if d2.locked_chest == nil and not (d2.is_waiting and not d2.has_follow) then
										d2.locked_chest = ent
										d.key_to_cn = v
										break
									end
								end
							end
						end
					end
				end
			end
			return false
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = item.familiar,
Function = function(_,ent)
	if ent.Variant == item.familiar then
		local s = ent:GetSprite()
		s:Play("Float",true)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	if d.locked_chest then
		if d.locked_chest:Exists() == false or d.locked_chest:IsDead() == true then
			d.locked_chest = nil
			if s:IsPlaying("Float") == false then
				s:Play("Float",true)
			end
		else
			if (d.IsFollowing) then
				ent:RemoveFromFollowers()
				d.IsFollowing = false
			end
			if (ent.Position - d.locked_chest.Position):Length() < 70 then
				if s:IsPlaying("Open") == false and s:IsFinished("Open") == false then
					s:Play("Open",true)
				end
				ent.Position = ent.Position * 0.8 + d.locked_chest.Position * 0.2
				ent.Velocity = ent.Velocity * 0.5
			else
				ent:FollowPosition(d.locked_chest.Position)	
			end
		end
	elseif d.is_waiting then
		if s:IsPlaying("Idle") then
			if d.has_follow_player == nil or d.has_follow_player:Exists() == false or d.has_follow_player:IsDead() == true then
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					if (player.Position - ent.Position):Length() < 20 then
						ent.Player = player
						d.has_follow = true
						d.has_follow_player = player
						local idx = player:GetData().__Index
						if idx ~= nil then	
							if save.elses["glaze_chest_cnt_fake_"..tostring(idx)] == nil then save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = 0 end
							save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = save.elses["glaze_chest_cnt_fake_"..tostring(idx)] + 1
						end
						s:Play("Idle_Float",true)
						break
					end
				end
			end
			if d.now_pos == nil then d.now_pos = ent.Position end
			ent:FollowPosition(d.now_pos)
		end
		if s:IsFinished("Idle_Float") then
			s:Play("Float",true)
		end
		if s:IsPlaying("Float") or s:IsPlaying("Idle_Float") then
			if ent.Player and ent.Player:Exists() and not ent.Player:IsDead() then
				if (not d.IsFollowing) then
					ent:AddToFollowers()
					d.IsFollowing = true
				end
				ent:FollowParent()
			else
				if (d.IsFollowing) then
					ent:RemoveFromFollowers()
					d.IsFollowing = false
				end
				d.has_follow = false
				s:Play("Idle",true)
			end
		end
	else
		if (not d.IsFollowing) then
			ent:AddToFollowers()
			d.IsFollowing = true
		end
		ent:FollowParent()
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_UPDATE, params = item.familiar2,
Function = function(_,ent)
	local s = ent:GetSprite()
	local d = ent:GetData()
	local room = Game():GetRoom()
	if d.locked_chest then
		if d.locked_chest:Exists() == false or d.locked_chest:IsDead() == true then
			d.locked_chest = nil
			if s:IsPlaying("Float") == false then
				s:Play("Float",true)
			end
		else
			if (d.IsFollowing) then
				ent:RemoveFromFollowers()
				d.IsFollowing = false
			end
			if (ent.Position - d.locked_chest.Position):Length() < 70 then
				if s:IsPlaying("Open") == false and s:IsFinished("Open") == false then
					s:Play("Open",true)
				end
				ent.Position = ent.Position * 0.8 + d.locked_chest.Position * 0.2
				ent.Velocity = ent.Velocity * 0.5
			else
				ent:FollowPosition(d.locked_chest.Position)
			end
		end
	elseif d.is_waiting then
		if s:IsPlaying("Idle") then
			if d.has_follow_player == nil or d.has_follow_player:Exists() == false or d.has_follow_player:IsDead() == true then
				for playerNum = 1, Game():GetNumPlayers() do
					local player = Game():GetPlayer(playerNum - 1)
					if (player.Position - ent.Position):Length() < 20 then
						ent.Player = player
						d.has_follow = true
						d.has_follow_player = player
						local idx = player:GetData().__Index
						if idx ~= nil then	
							if save.elses["glaze_chest_cnt_fake_"..tostring(idx)] == nil then save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = 0 end
							save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = save.elses["glaze_chest_cnt_fake_"..tostring(idx)] + 1
						end
						s:Play("Idle_Float",true)
						break
					end
				end
			end
			if d.now_pos == nil then d.now_pos = ent.Position end
			ent:FollowPosition(d.now_pos)
		end
		if s:IsFinished("Idle_Float") then
			s:Play("Float",true)
		end
		if s:IsPlaying("Float") or s:IsPlaying("Idle_Float") then
			if ent.Player and ent.Player:Exists() and not ent.Player:IsDead() then
				if (not d.IsFollowing) then
					ent:AddToFollowers()
					d.IsFollowing = true
				end
				ent:FollowParent()
			else
				if (d.IsFollowing) then
					ent:RemoveFromFollowers()
					d.IsFollowing = false
				end
				d.has_follow = false
				s:Play("Idle",true)
			end
		end
	else
		if (not d.IsFollowing) then
			ent:AddToFollowers()
			d.IsFollowing = true
		end
		ent:FollowParent()
	end
end,
})

function item.try_open(player,ent)
	if player == nil then player = Game():GetPlayer(0) end
	if ent == nil then return end
	local rng = ent:GetDropRNG()
	rng = auxi.rng_for_sake(rng)
	local rnd = rng:RandomInt(100)
	local level = Game():GetLevel()
	if level:GetStage() == LevelStage.STAGE6 then rnd = 1 end
	if rnd > 20 then				--生成基础
		local cnt = rng:RandomInt(4) + 2
		if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then cnt = cnt + 4 end
		local idx = player:GetData().__Index
		if idx ~= nil then
			if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
			save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
		end
		for i = 1,cnt do
			local info = item.pickup
			local wei = 0
			for u,v in pairs(enums.Pickups) do
				wei = wei + v.wei
			end
			wei = rng:RandomInt(wei)
			for u,v in pairs(enums.Pickups) do
				wei = wei - v.wei
				if wei <= 0 then
					info = v
					if u == "Glaze_bomb" and auxi.has_poop_player() then
						info = enums.Pickups.Glaze_big_poop
					end
					break
				end
			end
			local q = Isaac.Spawn(5,info.Variant,info.SubType,ent.Position,math.random(1000)/500 * auxi.MakeVector(math.random(36000)/100),nil)
			auxi.special_morph(q,info)
		end
	else
		local target = auxi.get_random_item_that_player_has(nil,rng,false)
		if target == -1 then
			target = enums.Items.It_s_a_trick
		end
		local q = Isaac.Spawn(5,100,target,ent.Position,Vector(0,0),nil):ToPickup()
		q:ClearEntityFlags(EntityFlag.FLAG_ITEM_SHOULD_DUPLICATE)
		local d1 = q:GetData()
		if d1._Data == nil then d1._Data = {} end
		d1._Data.is_glaze_chest = true
		consistance_holder.try_hold_entity(q,"Glaze_Chest",{ignore_subtype = true})
		local s1 = q:GetSprite()
		s1:ReplaceSpritesheet(5,"gfx/items/to_item_altar.png")
		s1:LoadGraphics()
		s1:SetOverlayFrame("Alternates", 4)
		consistance_holder.try_remove_entity(ent,"Glaze_Chest",{})
		ent:Remove()
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 100,
Function = function(_,ent)
	if ent.Type == 5 and ent.Variant == 100 then
		if consistance_holder.try_check_entity(ent,"Glaze_Chest") then
			local d = ent:GetData()
			if d._Data.is_glaze_chest then
				local s = ent:GetSprite()
				s:ReplaceSpritesheet(5,"gfx/items/to_item_altar.png")
				s:LoadGraphics()
				s:SetOverlayFrame("Alternates", 4)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		local s = ent:GetSprite()
		local d = ent:GetData()
		if s:IsEventTriggered("DropSound") then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_CHEST_DROP,1,1,false,0,2)
		end
		if s:IsPlaying("Idle") then
			if d.key_to_cn and d.key_to_cn:Exists() and d.key_to_cn:IsDead() == false then
				local dis = ent.Position - d.key_to_cn.Position
				local s2 = d.key_to_cn:GetSprite()
				local d2 = d.key_to_cn:GetData()
				if dis:Length() < 40 and s2:IsFinished("Open") then
					item.try_open(player,ent)
					if ent.OptionsPickupIndex ~= 0 then
						auxi.remove_others_option_pickup(ent)
					end
					s:Play("Open",true)
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_UNLOCK00,1,1,false,0,2)
					local player = d.key_to_cn:ToFamiliar().Player
					if d2.is_waiting and d2.has_follow then player = d2.has_follow_player end
					if d._Data == nil then d._Data = {} end
					d._Data.remove_this_chest = true
					consistance_holder.try_hold_entity(ent,"Glaze_Chest")
					if player then
						local idx = player:GetData().__Index
						if idx then
							if d2.is_waiting ~= true and save.elses["glaze_chest_cnt"..tostring(idx)] and save.elses["glaze_chest_cnt"..tostring(idx)] > 0 then
								save.elses["glaze_chest_cnt"..tostring(idx)] = save.elses["glaze_chest_cnt"..tostring(idx)] - 1
							elseif d2.is_waiting and d2.has_follow then		--直接remove请求。
								local level = Game():GetLevel()
								local desc = level:GetCurrentRoomDesc()
								local lsid = desc.ListIndex 
								if save.elses["glaze_chest_cnt_tsk"] and save.elses["glaze_chest_cnt_tsk"] > 0 and save.elses["glaze_chest_cnt_tsks"] then
									if save.elses["glaze_chest_cnt_tsks"][lsid] then
										for u,v in pairs(save.elses["glaze_chest_cnt_tsks"][lsid]) do
											if type(v) == "table" then
												if v.ent and v.ent:Exists() and v.ent:IsDead() == false and v.ent.InitSeed == d.key_to_cn.InitSeed then
													save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = save.elses["glaze_chest_cnt_fake_"..tostring(idx)] - 1
													save.elses["glaze_chest_cnt_tsks"][lsid][u] = nil
													break
												end
											end
										end
									end
								end
							end
						end
					end
					d.key_to_cn:Remove()
					d.key_to_cn = nil		--不知道为什么，但这样比较好
				end
			end
		end
		if s:IsFinished("Open") then
			s:Play("Opened",true)
		end
		if ent.Velocity:Length() > 0.1 then
			ent.Velocity = ent.Velocity * 0.8
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		if consistance_holder.try_check_entity(ent,"Glaze_Chest") then
			local d = ent:GetData()
			if d._Data.remove_this_chest then
				local succ = consistance_holder.try_remove_entity(ent,"Glaze_Chest",{})
				--print("remove chest:"..tostring(succ))
				ent:Remove()
			end
		else
			ent:GetData()._Data = {}
			consistance_holder.try_hold_entity(ent,"Glaze_Chest")
			if save.elses["glaze_chest_cnt_tsks"] == nil then save.elses["glaze_chest_cnt_tsks"] = {} end
			local level = Game():GetLevel()
			local rooms = level:GetRooms()
			local tgs = {}
			for i = 0, rooms.Size do
				local targ = rooms:Get(i)
				if targ ~= nil and targ.SafeGridIndex >= 0 and targ.ListIndex >= 0 then
					local desc = level:GetRoomByIdx(targ.SafeGridIndex,-1)
					if desc and desc.Data and desc.Data.Type ~= RoomType.ROOM_ULTRASECRET and desc.ListIndex ~= level:GetCurrentRoomDesc().ListIndex and desc.ListIndex == targ.ListIndex then		--一定不会出现在自己的房间。一定不会出现在红隐。
						table.insert(tgs,#tgs + 1,desc.ListIndex)
					end
				end
			end
			if #tgs > 0 then
				local rng = ent:GetDropRNG()
				rng = auxi.rng_for_sake(rng)
				local tg = tgs[rng:RandomInt(#tgs) + 1]
				if save.elses["glaze_chest_cnt_tsks"][tg] == nil then save.elses["glaze_chest_cnt_tsks"][tg] = {} end
				table.insert(save.elses["glaze_chest_cnt_tsks"][tg],{})
				if save.elses["glaze_chest_cnt_tsk"] == nil then save.elses["glaze_chest_cnt_tsk"] = 0 end
				save.elses["glaze_chest_cnt_tsk"] = save.elses["glaze_chest_cnt_tsk"] + 1
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	--print("new room")
	local level = Game():GetLevel()
	local room = Game():GetRoom()
	local desc = level:GetCurrentRoomDesc()
	local lsid = desc.ListIndex 
	if lsid >= 0 and desc.SafeGridIndex >= 0 then
		if save.elses["glaze_chest_cnt_tsk"] and save.elses["glaze_chest_cnt_tsk"] > 0 and save.elses["glaze_chest_cnt_tsks"] then
			if save.elses["glaze_chest_cnt_tsks"][lsid] then
				for u,v in pairs(save.elses["glaze_chest_cnt_tsks"][lsid]) do
					if type(v) == "table" then
						if v.pos == nil then 
							if v.posX and v.posY then
								v.pos = Vector(v.posX,v.posY)
							else
								v.pos = room:GetRandomPosition(10)
								v.posX = v.pos.X
								v.posY = v.	pos.Y
							end
						end
						local q = Isaac.Spawn(3,item.familiar2,0,v.pos,Vector(0,0),nil):ToFamiliar()
						local d = q:GetData()
						local s = q:GetSprite()
						d.is_waiting = true
						v.ent = q
						s:Play("Idle")
					end
				end
			end
		end
	end
	local desc2 = level:GetLastRoomDesc()		--检查上个房间收集的钥匙。
	local lsid2 = desc2.ListIndex 
	if lsid2 >= 0 and desc2.SafeGridIndex >= 0 and lsid2 ~= lsid then
		if save.elses["glaze_chest_cnt_tsk"] and save.elses["glaze_chest_cnt_tsk"] > 0 and save.elses["glaze_chest_cnt_tsks"] then
			if save.elses["glaze_chest_cnt_tsks"][lsid2] then
				for u,v in pairs(save.elses["glaze_chest_cnt_tsks"][lsid2]) do
					if type(v) == "table" then
						if v.ent and v.ent:Exists() and v.ent:IsDead() == false then
							local should_erase = false
							local d = v.ent:GetData()
							if d.has_follow then
								local player = d.has_follow_player
								if player ~= nil then
									local idx = player:GetData().__Index
									if idx ~= 0 then
										save.elses["glaze_chest_cnt"..tostring(idx)] = save.elses["glaze_chest_cnt"..tostring(idx)] + 1
										player:GetData().should_erase_familiar_key = true
										player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
										player:GetData().should_evaluate_on_update_once = true
									end
								end
								should_erase = true
							end
							--print("removed")
							v.ent:Remove()
							v.ent = nil
							if should_erase then
								save.elses["glaze_chest_cnt_tsks"][lsid2][u] = nil
							end
						end
					end
				end
			end
		end
	end
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
		if idx then
			save.elses["glaze_chest_cnt_fake_"..tostring(idx)] = 0
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for j = 1,10 do
		save.elses["glaze_chest_cnt"..tostring(j)] = 0
	end
	save.elses["glaze_chest_cnt_tsk"] = 0
	save.elses["glaze_chest_cnt_tsks"] = {}
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
		player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
		player:GetData().should_reset_familiar_key = true
		player:GetData().should_evaluate_on_update_once = true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["glaze_chest_cnt"..tostring(j)] = 0
		end
		save.elses["glaze_chest_cnt_tsk"] = 0
		save.elses["glaze_chest_cnt_tsks"] = {}
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			player:AddCacheFlags(CacheFlag.CACHE_FAMILIARS)
			player:GetData().should_reset_familiar_key = true
			player:GetData().should_evaluate_on_update_once = true
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = nil,
Function = function(_,ent)
	if save.UnlockData.Glaze.Samson.Unlock == true and ModConfigSettings.Pickup_allow then
		if (ent.Variant >= 50 and ent.Variant <= 60 and ent.SubType ~= item.pickup.SubType) or ent.Variant == 360 then
			local rng = RNG()
			rng:SetSeed(ent:GetDropRNG():GetSeed(),0)
			local rand = rng:RandomInt(80)		--1/80的概率转化
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) then
					if rand <= 3 then
						rand = 1
					end
				end
			end
			if rand == 1 then
				ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
			end
		end
	end
end,
})

return item