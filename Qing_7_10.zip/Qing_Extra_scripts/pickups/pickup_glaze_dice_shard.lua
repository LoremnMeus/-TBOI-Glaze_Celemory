local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings
--local png = require("Qing_Extra_scripts.png-lua-master.png")

local item = {
	pickup = enums.Cards.Glaze_dice_shard,
	ToCall = {},
	color_item = {		--部分道具：9,48,68,76,83,91,123,155,158,182,200,252,258,282,293,322,331,341,354,370,371,405,480,486,489,498,499,505,513,515,527,528,538,570,585,633,640,643,655,685,709,
		red = {
		9,12,13,15,30,31,40,45,48,49,51,53,55,64,65,67,68,72,73,79,80,82,83,96,97,105,109,110,118,119,122,135,137,155,157,159,166,172,177,182,208,214,230,244,247,253,254,261,269,276,289,290,292,324,329,334,354,373,391,394,396,399,411,412,421,435,443,452,
		462,466,475,481,506,511,513,515,529,531,554,556,558,565,572,573,580,606,607,611,613,616,618,621,637,650,654,657,659,671,682,684,692,694,695,700,702,703,704,705,706,711,724,726,728,enums.Items.Darkness,enums.Items.Tech_9,enums.Items.A_Shard_Of_Meat,
		enums.Items.Brimstream,enums.Items.The_Watcher,enums.Items.Air_Flight,enums.Items.Blaststone,enums.Items.A_Shard_Of_Blood,enums.Items.Air_Terror,enums.Items.Colorblindness,enums.Items.Devil_s_Heart,enums.Items.Book_of_The_Law,enums.Items.Nazca,
		enums.Items.Squiresaga,enums.Items.Drama_of_sorrow_and_joy,
		},
		orange = {
		182,217,221,223,256,257,282,285,401,427,444,414,456,528,567,665,715,722,enums.Items.A_Shard_Of_Lava,enums.Items.Giant_Punch,enums.Items.Granel,
		},
		pink = {
		29,46,52,58,75,76,92,104,112,136,144,167,168,207,227,229,322,341,351,363,370,384,385,390,398,432,447,454,457,458,467,469,471,491,493,497,508,509,525,526,537,563,615,638,641,642,658,669,677,678,688,707,721,725,729,731,enums.Items.My_Best_Friend,
		enums.Items.Fenfluramine,enums.Items.Sildenafil,
		},
		blue = {
		2,8,44,71,98,123,128,151,164,169,178,179,200,211,222,232,243,246,248,258,280,296,297,299,300,301,302,303,304,305,306,307,308,309,313,318,320,323,335,337,338,342,361,368,374,383,386,397,410,415,422,428,430,438,448,461,464,470,472,490,494,507,516,522,532,
		533,535,540,543,561,566,571,584,588,589,590,591,592,593,594,595,596,597,598,608,622,628,632,643,651,652,673,674,685,686,696,714,720,730,enums.Items.A_Shard_Of_Glaze,enums.Items.Tianyi,enums.Items.Abecarnil,enums.Items.Ephedrine,enums.Items.Pendulum_Star,
		enums.Items.Book_of_Vision,
		},
		yellow = {
		6,26,56,101,102,108,146,192,199,228,238,239,240,264,258,295,314,330,331,333,357,370,372,387,419,463,489,492,502,517,555,568,578,586,602,603,604,625,643,660,685,689,enums.Items.Little_Duck,enums.Items.Ephedrine,enums.Items.Ginsenoside,enums.Items.My_Emblem,
		enums.Items.Live_Broadcast,
		},
		green = {
		1,11,14,18,42,91,93,103,140,153,154,188,210,268,273,284,317,350,376,393,395,458,478,505,515,521,648,690,enums.Items.Glaze_Mushroom,enums.Items.Colorblindness,enums.Items.More_Options___,enums.Items.Dexamethasone,enums.Items.Cloundy,enums.Items.Wisel,
		},
		purple = {
		70,78,133,139,141,149,174,191,197,212,218,226,242,271,312,369,389,426,439,451,477,512,550,551,552,553,581,649,681,enums.Items.My_Best_Friend,enums.Items.Alchemy_Pot,enums.Items.Pageant_Cross_dresser,enums.Items.Field,enums.Items.Oxytocin,enums.Items.Fate_s_Draw,
		enums.Items.Wavering_Eyes,enums.Items.Skiel,enums.Items.Heart_Change,
		},
		brown = {
		7,16,22,23,24,28,33,36,69,111,123,120,121,138,176,186,187,193,203,204,215,224,234,236,241,252,262,279,281,336,346,349,362,402,418,480,486,487,488,500,501,504,518,527,534,536,541,576,577,626,635,639,640,644,664,680,719,enums.Items.Gold_Rush,enums.Items.Barbital,
		enums.Items.Tiramisu,
		},
		bright_green = {
		91,93,395,492,521,
		},
		bright = {
		4,20,21,27,38,39,54,60,63,85,88,115,116,124,148,173,175,183,184,195,196,198,202,209,251,343,354,404,424,440,473,479,485,499,523,530,538,539,546,557,574,579,585,601,619,624,636,668,691,697,709,710,732,enums.Items.Touchstone,enums.Items.A_Shard_Of_Coin,
		enums.Items.Book_of_Thoth,enums.Items.Lofty,enums.Items.Cable_Jar,
		},
		black = {
		9,10,32,34,35,37,47,50,57,62,74,76,81,97,99,100,113,125,130,132,134,145,150,156,161,162,165,171,180,190,194,216,225,231,259,260,270,272,275,278,310,311,315,321,328,356,360,366,406,408,409,417,420,433,441,442,468,482,483,496,498,503,514,545,575,582,583,
		617,645,646,647,661,672,676,679,693,698,699,701,712,723,enums.Items.My_Hat,enums.Items.Assassin_s_Eye,enums.Items.Super_Bombs,enums.Items.Heroisch,enums.Items.Ingestion_to_Night,
		},
		white = {
		5,25,41,77,86,114,126,127,129,143,158,160,163,170,181,185,205,206,213,219,245,249,263,265,266,274,277,283,286,287,294,298,316,326,327,332,340,348,347,352,353,355,358,364,365,367,377,378,379,381,392,407,413,423,425,434,436,445,453,460,474,476,
		484,489,495,498,499,510,519,528,542,544,547,548,549,559,564,585,600,609,612,627,633,640,683,687,727,enums.Items.Suture_Needle,enums.Items.Cyanide,enums.Items.Hyper_Velocity,enums.Items.Aphasia,enums.Items.Spectralsword,enums.Items.Moment,
		enums.Items.Drama_of_sorrow_and_joy,
		},
		grey = {
		3,17,19,48,66,68,83,84,87,89,90,91,94,95,106,107,117,131,142,147,152,189,200,201,220,233,237,250,255,267,288,291,293,319,325,339,344,345,359,375,380,382,388,400,403,416,429,431,437,446,449,450,455,465,520,524,560,562,569,599,605,610,623,629,631,634,653,663,667,
		670,675,708,709,713,716,717,enums.Items.A_Shard_Of_Rock,enums.Items.Black_Map,enums.Items.Air_Terror,
		},
		others = {		--杂色
		200,123,252,258,371,405,570,655,331,enums.Items.Mental_Hypnosis,enums.Items.Memory,enums.Items.Crown_of_the_glaze,enums.Items.A_Shard_Of_Glaze,enums.Items.It_s_a_trick,enums.Items.D773,enums.Items.Book_of_Future,enums.Items.Book_of_Voice,
		enums.Items.Theseus_s_Sign,enums.Items.Cable_Jar,
		},
	},
	item_color = {},
}

if true then
	local itemConfig = Isaac.GetItemConfig()
	for k,v in pairs(item.color_item) do
		local lst = {}
		for u,w in pairs(item.color_item[k]) do
			if item.item_color[w] == nil then
				item.item_color[w] = {}
			end
			item.item_color[w][#(item.item_color[w])+1] = k
			local collectible = itemConfig:GetCollectible(w)
			if (collectible and (collectible.Hidden or collectible:HasTags(1<<15))) then				--记得忽略部分道具
				--print(w)
				lst[#lst+1] = u
			end
		end
		table.sort(lst)
		for i = #lst,1,-1 do
			table.remove(item.color_item[k],lst[i])
		end
	end
end

local function the_same(c1,c2,rg)
	if c1 - c2 < rg and c2 - c1 < rg then
		return true
	else
		return false
	end
end

local function check_col(idx)
	local s1 = Sprite()
	s1:Load("gfx/1000.2338_NILL.anm2",false)
	local itemConfig = Isaac.GetItemConfig()
	local collectible = itemConfig:GetCollectible(idx)
	if (collectible and not collectible.Hidden) then
		local s = itemConfig:GetCollectible(idx).GfxFileName
		s1:ReplaceSpritesheet(0,s)
		s1:LoadGraphics()
		s1:SetFrame("Idle",0)
		local frame = 0
		local cnt = 0
		local cnt2 = 0
		local cnt3 = 0
		local cnt4 = 0
		local red = 0
		local blue = 0
		local green = 0
		for i = -6,6 do
			for j = -6,6 do
				local Kcol = s1:GetTexel(Vector(i,j),Vector(0,0))
				if Kcol.Red < 0.02 and Kcol.Blue < 0.02 and Kcol.Green < 0.02 then	--非颜色
				--	cnt = cnt + 1
				elseif Kcol.Red < 0.04 and Kcol.Blue < 0.02 and Kcol.Green < 0.02 then		--去掉黑色
					cnt = cnt + 1
				elseif Kcol.Red > 0.99 and Kcol.Blue > 0.99 and Kcol.Green > 0.99 then		--去掉白色
					cnt2 = cnt2 + 1
				else
					if the_same(Kcol.Red * 255,Kcol.Blue* 255,5) and the_same(Kcol.Red* 255,Kcol.Green* 255,5) and the_same(Kcol.Blue* 255,Kcol.Green* 255,5) then
						cnt3 = cnt3 + 1
					elseif the_same(Kcol.Red * 255,Kcol.Blue* 255,15) and the_same(Kcol.Red* 255,Kcol.Green* 255,15) and the_same(Kcol.Blue* 255,Kcol.Green* 255,15) then
						cnt3 = cnt3 + 0.75
						frame = frame + 0.25
						red = red + Kcol.Red/4
						blue = blue + Kcol.Blue/4
						green = green + Kcol.Green/4
					elseif the_same(Kcol.Red * 255,Kcol.Blue* 255,50) and the_same(Kcol.Red* 255,Kcol.Green* 255,50) and the_same(Kcol.Blue* 255,Kcol.Green* 255,50) then
						cnt3 = cnt3 + 0.5
						frame = frame + 0.5
						red = red + Kcol.Red/2
						blue = blue + Kcol.Blue/2
						green = green + Kcol.Green/2
					else
						if (Kcol.Red > Kcol.Blue + 80 and Kcol.Red > Kcol.Green + 80) or (Kcol.Blue > Kcol.Red + 80 and Kcol.Blue > Kcol.Green + 80) or (Kcol.Green > Kcol.Blue + 80 and Kcol.Green > Kcol.Red + 80) then
							cnt4 = cnt4 + 1
						end
						frame = frame + 1
						red = red + Kcol.Red
						blue = blue + Kcol.Blue
						green = green + Kcol.Green
					end
				end
			end
		end
		if frame > 0 then
			red = (red * 255)// frame
			blue = (blue * 255) // frame
			green = (green * 255) // frame
		end
		
		--print(tostring(cnt)..tostring(cnt2)..tostring(cnt3)..tostring(frame)..tostring(red)..tostring(blue)..tostring(green))
		if cnt > frame * 2 then
			return "black"
		end
		if cnt2 > frame * 2 then
			return "white"
		end
		if cnt3 > frame * 1.3 then
			return "grey"
		end
		
		if cnt4 < 0.5 * frame and (the_same(red,blue,30) and the_same(blue,green,30) and the_same(red,green,30) and blue + red + green > 255 * 2.5)  then
			return "white"
		end
		if cnt4 < 0.5 * frame and (the_same(red,blue,20) and the_same(blue,green,20) and the_same(red,green,20) and blue + red + green < 255) then
			return "black"
		end
		if cnt4 < 0.5 * frame and (the_same(red,blue,40) and the_same(blue,green,40) and the_same(red,green,40) and blue + red + green < 255 * 2.5 and blue + red + green > 255) then
			return "grey"
		end
		
		if red > 180 and ((red > green + 60 and green > blue + 60) or (red > green + 40 and green > blue + 80) or (red > green + 80 and green > blue + 40)) then
			return "orange"
		end
		if red > 180 and ((red > blue + 60 and blue > green + 60) or (red > blue + 40 and blue > green + 80) or (red > blue + 80 and blue > green + 40)) then
			return "pink"
		end
		if (red > blue + 150 and red > green + 100) or (red > blue + 100 and red > green + 150) or (red > blue + 200 and red > green + 80) or (red > blue + 80 and red > green + 200) or (the_same(green,blue,15) and red > green + 75 and red > blue + 75) then
			return "red"
		end
		if red > blue and the_same(red,blue,20) and (red > green + 80 or blue > green + 80) then
			return "pink"
		end
		if the_same(red,green,20) and (red > blue + 40 and green > blue + 40) and red + green > 400 then
			return "yellow"
		end
		if blue > red and the_same(red,blue,20) and (red > green + 80 or blue > green + 80) then
			return "purple"
		end
		if (green > blue + 40 and green > red + 25) or (green > blue + 25 and green > red + 40) or (green > blue + 60 and green > red + 15) or (green > blue + 15 and green > red + 60) then
			return "green"
		end
		if (blue > red + 40 and blue > green + 25) or (blue > red + 25 and blue > green + 40) or (blue > red + 60 and blue > green + 15) or (blue > red + 15 and blue > green + 60) then
			return "blue"
		end
		
		if the_same(red,blue,20) and (red > green + 40 and blue > green + 40) then
			if red + blue + green > 500 then
				return "pink"
			else
				return "purple"
			end
		end
		if the_same(green,blue,20) and (green > red + 40 and blue > red + 40) then
			return "blue"
		end
		if the_same(red,blue + 40,10) and the_same(red,green + 40,10) then
			return "pink"
		end
		
		if red > 180 and ((red > blue + 50 and blue > green + 50) or (red > blue + 30 and blue > green + 70) or (red > blue + 70 and blue > green + 30)) then
			return "pink"
		end
		if red > green + 20 and green > blue + 20 and blue + red + green > 255 then
			return "bright"
		end
		if red > green + 20 and green > blue + 20 and blue + red + green < 255 then
			return "brown"
		end
		if (red > blue + 60 and red > green + 60) then 
			return "red"
		end
		return "others"
	else
		return "black"
	end
end

local function Check_color(orig)
	local itemConfig = Isaac.GetItemConfig()
	local s1 = Sprite()
	s1:Load("gfx/1000.2338_NILL.anm2",false)
	local size = itemConfig:GetCollectibles().Size
	local st = 1
	if orig ~= true then
		st = 733
	else
		--print(size)
		size = 15
	end
	for k = st,size do
		local collectible = itemConfig:GetCollectible(k)
		if (collectible and not collectible.Hidden) then
			local s = itemConfig:GetCollectible(k).GfxFileName
			s1:ReplaceSpritesheet(0,s)
			s1:LoadGraphics()
			s1:SetFrame("Idle",0)
			local frame = 0
			local cnt = 0
			local red = 0
			local blue = 0
			local green = 0
			if false then
			for i = -4,4 do
				for j = -4,4 do
					local Kcol = s1:GetTexel(Vector(i,j),Vector(0,0))
					if Kcol.Red < 0.02 and Kcol.Blue < 0.02 and Kcol.Green < 0.02 then	--非颜色
					--	cnt = cnt + 1
					elseif Kcol.Red < 0.04 and Kcol.Blue < 0.02 and Kcol.Green < 0.02 then		--去掉黑色
						cnt = cnt + 1
					elseif Kcol.Red > 0.99 and Kcol.Blue > 0.99 and Kcol.Green > 0.99 then		--去掉白色
						cnt = cnt - 1
					else
						frame = frame + 1
						red = red + Kcol.Red
						blue = blue + Kcol.Blue
						green = green + Kcol.Green
					end
				end
			end
			if frame > 0 then
				red = (red * 10)// frame
				blue = (blue * 10) // frame
				green = (green * 10) // frame
			end
			end
			if item.color_item[red * 100 + green * 10 + blue] == nil then
				item.color_item[red * 100 + green * 10 + blue] = {}
			end
			table.insert(item.color_item[red * 100 + green * 10 + blue],k)
			item.item_color[k] = red * 100 + green * 10 + blue
		end
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = item.pickup,
Function = function(_,card,player,useflags)
	local n_entity = Isaac.GetRoomEntities()
	local n_col = auxi.getothers(n_entity,5,100)
	for col_id = 1,#n_col do
		local rng = n_col[col_id]:GetDropRNG()
		rng = auxi.rng_for_sake(rng)
		local idx = n_col[col_id].SubType
		if idx == 0 then 
		elseif item.item_color[idx] then
			local targ = item.color_item[item.item_color[idx][rng:RandomInt(#(item.item_color[idx])) + 1]]
			local rg = rng:RandomInt(#targ) + 1
			while targ[rg] == idx do
				rg = rng:RandomInt(#targ) + 1
				--print("find")
			end
			n_col[col_id]:ToPickup():Morph(5,100,targ[rg],true,false,false)
		else
			local tg = check_col(idx)
			--print(tostring(idx)..tostring(tg))
			item.item_color[idx] = {tg}
			local targ = item.color_item[item.item_color[idx][rng:RandomInt(#(item.item_color[idx])) + 1]]
			n_col[col_id]:ToPickup():Morph(5,100,targ[rng:RandomInt(#targ) + 1],true,false,false)
		end
	end
	local pu = enums.Pickups
	local n_penny = auxi.getothers(n_entity,5,20)
	for i = 1,#n_penny do
		if n_penny[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_penny[i],pu.Glaze_coin)
		end
	end
	local n_heart = auxi.getothers(n_entity,5,10)
	for i = 1,#n_heart do
		local rng = n_heart[i]:GetDropRNG()
		if n_heart[i]:ToPickup().Price ~= -5 then
			if rng:RandomInt(10) > 2 then
				auxi.special_morph(n_heart[i],pu.Glaze_heart_half)
			else
				auxi.special_morph(n_heart[i],pu.Glaze_heart)
			end
		end
	end
	local n_key = auxi.getothers(n_entity,5,30)
	for i = 1,#n_key do
		if n_key[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_key[i],pu.Glaze_key)
		end
	end
	local n_bomb = auxi.getothers(n_entity,5,40)
	for i = 1,#n_bomb do
		if n_bomb[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_bomb[i],pu.Glaze_bomb)
		end
	end
	local n_bag = auxi.getothers(n_entity,5,69)
	for i = 1,#n_bag do
		if n_bag[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_bag[i],pu.Glaze_grabbag)
		end
	end
	local n_battery = auxi.getothers(n_entity,5,90)
	for i = 1,#n_battery do
		if n_battery[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_battery[i],pu.Glaze_battery)
		end
	end
	local n_poop = auxi.getothers(n_entity,5,42)
	for i = 1,#n_poop do
		if n_poop[i]:ToPickup().Price ~= -5 then
			auxi.special_morph(n_poop[i],pu.Glaze_big_poop)
		end
	end
	local n_chest = auxi.getothers(n_entity,5,nil,nil,
		function(ent)
			if ent.Variant >= 50 and ent.Variant < 69 then 
				return true 
			else 
				return false 
			end 
		end)
	for i = 1,#n_chest do
		auxi.special_morph(n_chest[i],pu.Glaze_chest)
	end
	local n_card = auxi.getothers(n_entity,5,300,item.pickup)
	for i = 1,#n_card do
		auxi.special_morph(n_card[i],pu.Glaze_dice_shard)
	end
	local n_card = auxi.getothers(n_entity,5,300,49)
	for i = 1,#n_card do
		auxi.special_morph(n_card[i],pu.Glaze_dice_shard)
	end
	local n_enemy = auxi.getenemies(n_entity)
	for i = 1,#n_enemy do
		local ent = n_enemy[i]
		if ent:IsVulnerableEnemy() and ent:IsActiveEnemy() and (not ent:HasEntityFlags(EntityFlag.FLAG_FRIENDLY)) and ent:CanShutDoors() == true and ent.Type ~= 996 then
			local d = ent:GetData()
			d.is_glazed_enemy = true
			Isaac.Spawn(EntityType.ENTITY_EFFECT, EffectVariant.POOF01, 0, ent.Position, Vector(0, 0), nil)
		end
	end
	local idx = player:GetData().__Index
	if idx ~= nil then
		if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
		save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + enums.Pickups.Glaze_dice_shard.heavy		--也许还需要加参数
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_CARD, params = nil,
Function = function(_,rng,card,playing,rune,onlyrune)
	rng = auxi.rng_for_sake(rng)
	local rnd = rng:RandomInt(10)
	local set_true = false
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		if player:HasCollectible(enums.Items.Crown_of_the_glaze) then
			set_true = true
		end
	end
	if card == item.pickup and set_true == false and rnd > 5 then		--相比于其他卡牌，仅有50%的概率生成，除非角色拥有琉璃的冠冕。
		rng:Next()
		local cd = Game():GetItemPool():GetCard(rng:GetSeed(), playing, rune, onlyrune)
		return cd
	end
end,
})

return item