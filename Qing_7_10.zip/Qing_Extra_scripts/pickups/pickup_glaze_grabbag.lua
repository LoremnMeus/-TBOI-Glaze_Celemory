local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_grabbag,
	ToCall = {},
	check_function = {
		Glaze_heart = {check = function(player) return (player:GetSoulHearts() > 1 and player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 2) end,get = function(player) player:AddSoulHearts(-2) end,},		--只能转化魂心，但代价稍低
		Glaze_heart_half = {check = function(player) return (player:GetSoulHearts() > 0 and player:GetBoneHearts() + player:GetSoulHearts() + player:GetHearts() > 1) end,get = function(player) player:AddSoulHearts(-1) end,},
		Glaze_key = {check = function(player) return (player:GetNumKeys() > 1) end,get = function(player) player:AddKeys(-2) end,},
		Glaze_bomb = {check = function(player) return (player:GetNumBombs() > 1) end,get = function(player) player:AddBombs(-2) end,},
		Glaze_coin = {check = function(player) return (player:GetNumCoins() > 2) end,get = function(player) player:AddCoins(-3) end,},
		Glaze_grabbag = {check = function(player)
			return player:HasCollectible(CollectibleType.COLLECTIBLE_SACK_HEAD) and (player:GetNumCoins() > 0) and (player:GetNumBombs() > 0) and (player:GetNumKeys() > 0)
		end,get = function(player)
			player:AddKeys(-1) 
			player:AddBombs(-1) 
			player:AddCoins(-1) 
		end,},			--若拥有福袋头，则有概率消耗炸弹、钥匙、硬币各一个，生成一个福袋。
		Glaze_battery = {check = function(player)
			local charge = 0
			for i = 0,3 do
				if player:GetActiveCharge(i) > 0 and player:GetActiveCharge(i) <= 12 then
					charge = charge + player:GetActiveCharge(i) + player:GetBatteryCharge(i)
				elseif player:GetActiveCharge(i) > 0 then
					charge = charge + 1
				end
			end
			return charge > 4
		end,get = function(player)
			for i = 0,3 do
				local charge = 4
				if player:GetActiveCharge(i) > 0 and player:GetActiveCharge(i) <= 12 then
					local t_charge = player:GetActiveCharge(i) + player:GetBatteryCharge(i)
					player:SetActiveCharge(math.max(0,t_charge - charge),i)
					charge = math.max(0,charge - t_charge)
					if charge <= 0 then break end
				elseif player:GetActiveCharge(i) > 0 then
					player:SetActiveCharge(0,i)
					charge = charge - 1
					if charge <= 0 then break end
				end
			end
		end,},
		Glaze_chest = {check = function(player) return false end,get = function(player) end,},
		Glaze_big_poop = {check = function(player) return (player:GetPoopMana() > 2) end,get = function(player) player:AddPoopMana(-3) end,},
		Glaze_dice_shard = {check = function(player) 
			for slot = 0,1 do
				if player:GetCard(slot) == Card.CARD_DICE_SHARD then 
					return true
				end
			end
			return false 
		end,get = function(player) 
			for slot = 0,1 do
				if player:GetCard(slot) == Card.CARD_DICE_SHARD then 
					player:SetCard(slot,0)
					return
				end
			end
		end,},
	},
	description = {
		[CollectibleType.COLLECTIBLE_SACK_HEAD] = {desc = "追加概率消耗基础各一个，生成自身",},
	},
}

function item.try_collect(player,ent)
	if ent:IsShopItem() then
		if ent.Price <= player:GetNumCoins() and player:IsExtraAnimationFinished() then
		else
			return nil
		end
	end
	local rng = ent:GetDropRNG()
	rng = auxi.rng_for_sake(rng)
	local cnt = rng:RandomInt(8) + 7
	if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then cnt = cnt + 2 end
	for i = 1,cnt do
		local tbl = {}
		local wei = 0
		local rnd = item.pickup
		for u,v in pairs(enums.Pickups) do
			local info = item.check_function[u]
			if info then
				if info.check(player) then
					table.insert(tbl,#tbl+1,{wei = v.wei,pickup = u,})
					wei = wei + v.wei
				end
			end
		end
		--auxi.PrintTable(tbl)
		if #tbl == 0 then
			if i == 1 then
				rnd = enums.Pickups.Glaze_big_poop
				local q = Isaac.Spawn(5,rnd.Variant,rnd.SubType,ent.Position,math.random(1000)/500 * auxi.MakeVector(math.random(36000)/100),nil):ToPickup()		--此法生成的不会被替换
				auxi.special_morph(q,rnd)
				--q:Morph(5,rnd.Variant,rnd.SubType,true,true,true)
			end
			break
		else
			wei = rng:RandomInt(wei)
			for u,v in pairs(tbl) do
				wei = wei - v.wei
				if wei <= 0 then
					rnd = v.pickup
					if u == "Glaze_bomb" and auxi.has_poop_player() then
						rnd = "Glaze_big_poop"
					end
					break
				end
			end
			local info = item.check_function[rnd]
			if info then
				info.get(player)
			end
			rnd = enums.Pickups[rnd]
			local q = Isaac.Spawn(5,rnd.Variant,rnd.SubType,ent.Position,math.random(1000)/500 * auxi.MakeVector(math.random(36000)/100),nil):ToPickup()		--此法生成的不会被替换
			auxi.special_morph(q,rnd)
			--q:Morph(5,rnd.Variant,rnd.SubType,true,true,true)
		end
	end
	return true
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if ent.SubType == item.pickup.SubType then
		if player then
			local should_collect = item.try_collect(player,ent)
			if should_collect == true then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
					save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
				end
				if ent:IsShopItem() then player:AddCoins(-ent.Price) end
				ent.Velocity = Vector(0,0)
				ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_SHELLGAME,1,1,false,0,2)
				if ent:IsShopItem() then
					player:AnimatePickup(ent:GetSprite())
					ent:Remove()
				else
					ent:GetSprite():Play("Collect", true)
				end
				if ent.OptionsPickupIndex ~= 0 then
					auxi.remove_others_option_pickup(ent)
				end
				return true
			elseif should_collect == nil then
				return true 
			else
				return false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		if ent:GetSprite():IsEventTriggered("DropSound") then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_FETUS_JUMP,1,1,false,0,2)
		end
		if ent:GetSprite():IsFinished("Collect") or ent:GetSprite():IsEventTriggered("Remove") then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 69,
Function = function(_,ent)
	if save.UnlockData.Glaze.Eden.Unlock == true and ModConfigSettings.Pickup_allow then
		if ent.SubType == 1 or ent.SubType == 2 then
			local rng = RNG()
			rng:SetSeed(ent:GetDropRNG():GetSeed(),0)
			local rand = rng:RandomInt(20)		--1/20的概率转化
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					if rand == 2 then
						rand = 1
					end
				end
			end
			if rand == 1 then
				ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
			end
		end
	end
end,
})

if EID then
	for u,v in pairs(item.description) do
		EID:addDescriptionModifier("qing_item_sync"..tostring(item.entity), function(desc) local ret = auxi.have_player_has_collectible(u) return ret end, function(desc)
			local tp = desc.ObjType
			local vr = desc.ObjVariant
			local st = desc.ObjSubType
			if (tp == 5 and vr == item.pickup.Variant and st == item.pickup.SubType and item.description[u]) then
				local info = item.description[u].desc
				if (info) then
					info = "#"..info
					local repl = "#{{Collectible"..tostring(u).."}} "
					info = string.gsub(info, "#", repl)
					EID:appendToDescription(desc, info)
				end
			end
			return desc
		end)
	end
end

return item