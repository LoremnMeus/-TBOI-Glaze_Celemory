local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local consistance_holder = require("Qing_Extra_scripts.others.Consistance_holder")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_coin,
	ToCall = {},
}

function item.try_collect(player,ent)
	if ent:IsShopItem() then
		if ent.Price <= player:GetNumCoins() and player:IsExtraAnimationFinished() then
		else
			return nil
		end
	end
	if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
		if math.random(1000) > 50 then
			player:AddCoins(1)
			ent:GetData().sound = 1
		else
			player:AddCoins(15)
			ent:GetData().sound = 2
		end
	else
		if math.random(1000) > 100 then
			player:AddCoins(1)
			ent:GetData().sound = 1
		else
			player:AddCoins(5)
			ent:GetData().sound = 2
		end
	end
	return true
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if ent.SubType == item.pickup.SubType then
		consistance_holder.try_check_entity(ent,"Glaze_Coin")
		if item.pickup.special_to_check(ent) then
			if player then
				local should_collect = item.try_collect(player,ent)
				if should_collect == true then
					local idx = player:GetData().__Index
					if idx ~= nil then
						if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
						save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
					end
					if ent:IsShopItem() then player:AddCoins(-ent.Price) end
					ent.Velocity = Vector(0,0)
					ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
					if ent:GetData().sound ~= 2 then
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_PENNYPICKUP,1,1,false,0,2)
					else
						sound_tracker.PlayStackedSound(SoundEffect.SOUND_DIMEPICKUP,1,1,false,0,2)
					end
					if ent:IsShopItem() then
						player:AnimatePickup(ent:GetSprite())
						ent:Remove()
					else
						ent:GetSprite():Play("Collect", true)
					end
					if ent.OptionsPickupIndex ~= 0 then
						auxi.remove_others_option_pickup(ent)
					end
					return true
				elseif should_collect == nil then
					return true 
				else
					return false
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		local d = ent:GetData()
		local s = ent:GetSprite()
		consistance_holder.try_check_entity(ent,"Glaze_Coin")
		if item.pickup.special_to_check(ent) then
			if d.Loaded_EID == nil then 
				item.pickup.load_EID(ent)
				d.Loaded_EID = true
			end
			if s:GetFilename() ~= "gfx/glaze_coin.anm2" then
				local name1 = s:GetAnimation()
				local name2 = s:GetOverlayAnimation()
				s:Load("gfx/glaze_coin.anm2",true)
				s:Play(name1,true)
				s:PlayOverlay(name2,true)
			end
			if s:IsEventTriggered("DropSound") then
				if math.random(3) == 1 then
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_PENNYDROP,1,1,false,0,2)
				elseif math.random(2) == 1 then
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_NICKELDROP,1,1,false,0,2)
				else
					sound_tracker.PlayStackedSound(SoundEffect.SOUND_DIMEDROP,1,1,false,0,2)
				end
			end
			if s:IsFinished("Collect") or s:IsEventTriggered("Remove") then
				ent:Remove()
			end
			if s:IsEventTriggered("Attract") then
				local n_entity = Isaac.GetRoomEntities()
				local pick_up = auxi.getothers(n_entity,5)
				for i = 1,#pick_up do
					if pick_up[i]:ToPickup():IsShopItem() == false then
						local dir = (ent.Position - pick_up[i].Position)
						if dir:Length() > 10 then
							dir = dir:Normalized()
						else
							dir = dir/10
						end
						pick_up[i]:AddVelocity(dir)
						ent:AddVelocity(-dir/4)
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 20,
Function = function(_,ent)
	if save.UnlockData.Glaze.Keeper.Unlock == true and ModConfigSettings.Pickup_allow then
		if ent.SubType == 1 or ent.SubType == 3 then
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			local rand = rng:RandomInt(40)		--1/40的概率转化
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					if rand == 2 then
						rand = 1
					end
				end
			end
			if rand == 1 then
				--ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
				auxi.special_morph(ent,item.pickup,true,false,false)
			end
		end
	end
end,
})

return item