local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local ui = require("Qing_Extra_scripts.auxiliary.ui")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_battery,
	ToCall = {},
}

local frame = 0
local charge_ui = Sprite()
local charge_ui2 = Sprite()
local charge_ui3 = Sprite()
local charge_ui4 = Sprite()
charge_ui:Load("gfx/glazed_item.anm2", true)
charge_ui3:Load("gfx/glazed_item2.anm2", true)
charge_ui2:Load("gfx/glazed_charge_bar.anm2", true)
charge_ui:Play("Idle",true)
charge_ui3:Play("Idle",true)
charge_ui2:Play("Idle",true)
charge_ui.Scale = Vector(0.65,0.65)
charge_ui2.Scale = Vector(1,1)
charge_ui3.Scale = Vector(1,1)

function item.try_collect(player,ent)
	if ent:IsShopItem() then
		if ent.Price <= player:GetNumCoins() and player:IsExtraAnimationFinished() then
		else
			return nil
		end
	end
	local level = Game():GetLevel()
	local targs = {}
	local rooms = level:GetRooms()
	local charge = 0
	local has_active = false
	for i = 0,3 do
		if player:GetActiveItem(i) > 0 then has_active = true end
		if player:GetActiveCharge(i) > 0 and player:GetActiveCharge(i) <= 12 then
			charge = charge + player:GetActiveCharge(i) + player:GetBatteryCharge(i)
			player:SetActiveCharge(0,i)
		elseif player:GetActiveCharge(i) > 0 then
			charge = charge + 1
			if player:GetBatteryCharge(i) > 0 then
				charge = charge + 1
			end
			player:SetActiveCharge(0,i)
		end
	end
	
	if has_active == true then
		if charge == 0 then charge = 1 end
		if save.elses.glaze_battery == nil then
			save.elses.glaze_battery = 0
		else
			if save.elses.glaze_battery < 99 then
				save.elses.glaze_battery = save.elses.glaze_battery + charge
			end
		end
		return true
	end
	if ent:IsShopItem() then
		return nil
	else
		return false
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if ent.SubType == item.pickup.SubType then
		if player then
			local should_collect = item.try_collect(player,ent)
			if should_collect == true then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
					save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
					if math.random(1000) > 800 then glaze_curse.cast_a_glaze() end
				end
				if ent:IsShopItem() then player:AddCoins(-ent.Price) end
				ent.Velocity = Vector(0,0)
				ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				sound_tracker.PlayStackedSound(SoundEffect.SOUND_BATTERYDISCHARGE,1,1,false,0,2)
				if ent:IsShopItem() then
					player:AnimatePickup(ent:GetSprite())
					ent:Remove()
				else
					ent:GetSprite():Play("Collect", true)
				end
				if ent.OptionsPickupIndex ~= 0 then
					auxi.remove_others_option_pickup(ent)
				end
				return true
			elseif should_collect == nil then
				return nil 
			else
				return false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
    if continue then
	else
		save.elses.glaze_battery = 0
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType then
		if ent:GetSprite():IsEventTriggered("DropSound") then
		end
		if ent:GetSprite():IsFinished("Collect") or ent:GetSprite():IsEventTriggered("Remove") then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_SPAWN_CLEAN_AWARD, params = nil,
Function = function(_,ent)
	if save.elses.glaze_battery and save.elses.glaze_battery > 0 then
		local should_should_spawn = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			local should_spawn = false
			for i = 0,3 do
				if player:NeedsCharge(i) then
					if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
						player:SetActiveCharge(player:GetActiveCharge(i) + player:GetBatteryCharge(i) + 2,i)
					else
						player:SetActiveCharge(player:GetActiveCharge(i) + player:GetBatteryCharge(i) + 1,i)
					end
					should_spawn = true
					should_should_spawn = true
				end
			end
			if should_spawn then
				local q = Isaac.Spawn(1000,EffectVariant.BATTERY,0,player.Position + Vector(0,-30) * player.SpriteScale.Y + player.Velocity,Vector(0,0),nil)
				local s = q:GetSprite()
				q.DepthOffset = 1000
				s:ReplaceSpritesheet(0,"gfx/effects/effect_glazed_batteryeffect.png")
				s:LoadGraphics()
			end
		end
		if should_should_spawn then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_ITEMRECHARGE,1.5,1,false,0,2)
		end
		local should_count = false
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
			if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
				should_count = true
			end
		end
		if should_count or should_should_spawn then
			save.elses.glaze_battery = save.elses.glaze_battery - 1
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 90,
Function = function(_,ent)
	if save.UnlockData.Glaze.Bethany.Unlock == true and ModConfigSettings.Pickup_allow then
		if ent.SubType == 1 or ent.SubType == 2 then
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			local rand = rng:RandomInt(20)		--1/20的概率转化
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					if rand == 2 then
						rand = 1
					end
				end
			end
			--if ent:IsShopItem() and rand == 1 then rand = rng:RandomInt(2) end		--在商店出现的概率减半。
			if rand == 1 then
				ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_RENDER, params = nil,
Function = function(_)
	if save.elses.glaze_battery and save.elses.glaze_battery > 0 and Game():GetHUD():IsVisible() then
		local player = Game():GetPlayer(0)
		local item = player:GetActiveItem(0)
		local item2 = player:GetActiveItem(2)
		local collectible = Isaac.GetItemConfig():GetCollectible(item)
		local collectible2 = Isaac.GetItemConfig():GetCollectible(item2)
		if Game():IsPaused() == false then
			frame = frame + 1
		else
			frame = frame - 1
		end
		if frame > 47 then frame = 0 end
		if frame < 0 then frame = 48 end
		if item and item ~= 0 and collectible then
			--charge_ui:SetFrame(frame)
			local name = collectible.GfxFileName
			if item == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
			charge_ui:ReplaceSpritesheet(0,name)
			charge_ui:LoadGraphics()
			local pos = ui.UIActivePos(0,false)
			for i = 1,save.elses.glaze_battery do
				local tg_fr = frame + math.ceil(i * 48 / save.elses.glaze_battery)
				while tg_fr > 47 do tg_fr = tg_fr - 48 end
				charge_ui:SetFrame(tg_fr)
				local id = 35 - i 
				if id < 0 then id = id + 48 end
				charge_ui.Color = Color(1,1,1,0.5 + 0.5/save.elses.glaze_battery * id)
				charge_ui:Render(pos - 15 * auxi.MakeVector(360/save.elses.glaze_battery * i + 90),Vector(0,0),Vector(0,0))
			end
		end
		if player:GetCard(0) == 0 and player:GetPill(0) == 0 and item2 and item2 ~= 0 and collectible2 then
			local name = collectible2.GfxFileName
			if item2 == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
			charge_ui:ReplaceSpritesheet(0,name)
			charge_ui:LoadGraphics()
			local pos = ui.UIActivePos(2,false)
			for i = 1,save.elses.glaze_battery do
				local tg_fr = frame + math.ceil(i * 48 / save.elses.glaze_battery)
				while tg_fr > 47 do tg_fr = tg_fr - 48 end
				charge_ui:SetFrame(tg_fr)
				local id = 35 - i 
				if id < 0 then id = id + 48 end
				charge_ui.Color = Color(1,1,1,0.5 + 0.5/save.elses.glaze_battery * id)
				charge_ui:Render(pos - 15 * auxi.MakeVector(360/save.elses.glaze_battery * i + 90),Vector(0,0),Vector(0,0))
			end
		elseif Game():GetNumPlayers() > 1 then
			local player = Game():GetPlayer(1)
			if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
				local item3 = player:GetActiveItem(0)
				local collectible3 = Isaac.GetItemConfig():GetCollectible(item3)
				if item3 and item3 ~= 0 and collectible3 then
					local name = collectible3.GfxFileName
					if item3 == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
					charge_ui:ReplaceSpritesheet(0,name)
					charge_ui:LoadGraphics()
					local pos = ui.UIActivePos(1,false)
					for i = 1,save.elses.glaze_battery do
						local tg_fr = frame + math.ceil(i * 48 / save.elses.glaze_battery)
						while tg_fr > 47 do tg_fr = tg_fr - 48 end
						charge_ui:SetFrame(tg_fr)
						local id = 35 - i 
						if id < 0 then id = id + 48 end
						charge_ui.Color = Color(1,1,1,0.5 + 0.5/save.elses.glaze_battery * id)
						charge_ui:Render(pos - 15 * auxi.MakeVector(360/save.elses.glaze_battery * i + 90),Vector(0,0),Vector(0,0))
					end
				end
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Qing_HelpfulShader" then
		if save.elses.glaze_battery and save.elses.glaze_battery > 0 and Game():GetHUD():IsVisible() then
			local player = Game():GetPlayer(0)
			local item = player:GetActiveItem(0)
			local item2 = player:GetActiveItem(2)
			local collectible = Isaac.GetItemConfig():GetCollectible(item)
			local collectible2 = Isaac.GetItemConfig():GetCollectible(item2)
			if item and item ~= 0 and collectible and item ~= 489 and item ~= enums.Items.It_s_a_trick then
				--charge_ui:SetFrame(frame)
				local name = collectible.GfxFileName
				if item == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
				charge_ui3:ReplaceSpritesheet(0,name)
				--charge_ui3:ReplaceSpritesheet(1,collectible.GfxFileName)
				charge_ui3:LoadGraphics()
				local pos = ui.UIActivePos(0,false)
				if (player:HasCollectible(584) and item ~= 584) or (player:HasCollectible(59) and item ~= 59)then
					pos = pos + Vector(0,-4)
				end
				charge_ui3:SetFrame(frame)
				charge_ui3:Render(pos,Vector(0,0),Vector(0,0))
			end
			if collectible and collectible.MaxCharges ~= 0 then			--渲染充能槽
				local pos = ui.UIChargeBarPos(0,false)
				if (player:HasCollectible(584) and item ~= 584) or (player:HasCollectible(59) and item ~= 59)then
					pos = pos + Vector(0,3)
				end
				charge_ui2:SetFrame(frame)
				charge_ui2:Render(pos,Vector(0,0),Vector(0,0))
			end
			if player:GetCard(0) == 0 and player:GetPill(0) == 0 and collectible2 and collectible2.MaxCharges ~= 0 then
				local pos = ui.UIChargeBarPos(2,false)
				charge_ui2:SetFrame(frame)
				charge_ui2:Render(pos,Vector(0,0),Vector(0,0))
			elseif Game():GetNumPlayers() > 1 then
				local player = Game():GetPlayer(1)
				if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
					local item3 = player:GetActiveItem(0)
					local collectible3 = Isaac.GetItemConfig():GetCollectible(item3)
					if item3 and item3 ~= 0 and collectible3 and collectible3.MaxCharges ~= 0 then
						local pos = ui.UIChargeBarPos(1,false)
						charge_ui2:SetFrame(frame)
						charge_ui2:Render(pos,Vector(0,0),Vector(0,0))
					end
				end
			end
			if player:GetCard(0) == 0 and player:GetPill(0) == 0 and item2 and item2 ~= 0 and collectible2 and item2 ~= 489 and item2 ~= enums.Items.It_s_a_trick then
				local name = collectible2.GfxFileName
				if item2 == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
				charge_ui3:ReplaceSpritesheet(0,name)
				charge_ui3:LoadGraphics()
				local pos = ui.UIActivePos(2,false)
				charge_ui3:SetFrame(frame)
				charge_ui3:Render(pos,Vector(0,0),Vector(0,0))
			elseif Game():GetNumPlayers() > 1 then
				local player = Game():GetPlayer(1)
				if player and player.ControllerIndex == 0 then		--拥有主动的非主角色人物
					local item3 = player:GetActiveItem(0)
					local collectible3 = Isaac.GetItemConfig():GetCollectible(item3)
					if item3 and item3 ~= 0 and collectible3 and item3 ~= 489 and item3 ~= enums.Items.It_s_a_trick then
						local name = collectible3.GfxFileName
						if item3 == enums.Items.It_s_a_trick then name = Isaac.GetItemConfig():GetCollectible(save.elses.glazed_trick).GfxFileName end
						charge_ui3:ReplaceSpritesheet(0,name)
						charge_ui3:LoadGraphics()
						local pos = ui.UIActivePos(1,false)
						if (player:HasCollectible(584) and item ~= 584) or (player:HasCollectible(59) and item ~= 59)then
							pos = pos + Vector(0,-4)
						end
						charge_ui3:SetFrame(frame)
						charge_ui3:Render(pos,Vector(0,0),Vector(0,0))
					end
				end
			end
		end
	end
end,
})

-- D无限、打包盒等道具有额外贴图，比较麻烦。

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GENESIS,
Function = function(_,collect,rng,player,useFlags,activeSlot,varData)
	save.elses.glaze_battery = 0
end,
})

return item