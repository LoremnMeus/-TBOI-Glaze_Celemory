local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local ModConfigSettings = ModConfig.ModConfigSettings
--local png = require("Qing_Extra_scripts.png-lua-master.png")

local item = {
	pickup = enums.Cards.Qing_s_Soul,
	ToCall = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = item.pickup,
Function = function(_,card,player,useflags)		--暂时先这样？？
	local list = auxi.get_qing_list(player)
	local rnd = math.random(25) + 13
	local cnt = 0
	for i = 1,rnd do
		delay_buffer.addeffe(function(params)
			local gdir = auxi.ggdir(player,false,ModConfigSettings.allow_mouse_control)
			local dir = player.Velocity + gdir * 10
			local rnd2 = math.random(2) + 2
			for i = 1,rnd2 do
				auxi.fire_dowhatknife(nil,player.Position + player.Velocity,auxi.MakeVector(dir:GetAngleDegrees() + math.random(30) - 15) * 20 * player.ShotSpeed,20,"IdleUp","IdleUp2",{source = nil,cooldown = 60,player = player,tearflags = player.TearFlags,color = player.TearColor,thor = false,Accerate = 0.75 + math.random(1000)/1000,size = 5,size1 = Vector(1,3),size2 = 13,list = list,tech = player:HasCollectible(68),should_rotate = true,Way_Accerate = dir:Normalized() * 20 * player.ShotSpeed})
			end
		end,{},cnt)
		cnt = cnt + 1 + math.random(4)
	end
end,
})

return item