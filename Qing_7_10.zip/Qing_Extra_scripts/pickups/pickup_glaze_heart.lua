local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local glaze_curse = require("Qing_Extra_scripts.pickups.pickup_glaze_curse")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	pickup = enums.Pickups.Glaze_heart,
	pickup2 = enums.Pickups.Glaze_heart_half,
	ToCall = {},
}

function item.try_collect(player,ent,toHeal)
	if ent:IsShopItem() then
		if ent.Price <= player:GetNumCoins() and player:IsExtraAnimationFinished() then
		else
			return nil
		end
	end
	local toplay = {id = SoundEffect.SOUND_HOLY,vol = 1,pit = 1}
	if player:GetBrokenHearts() > 0 then
		player:AddBrokenHearts(-1)
		if toHeal == 2 then
			player:AddSoulHearts(1)
		end
	elseif player:GetRottenHearts() > 0 then
		player:AddRottenHearts(-1)
		if toHeal == 1 then
			player:AddHearts(-1)
		end
	elseif player:GetEternalHearts() > 0 and math.random(1000) > 900 then
		player:AddEternalHearts(1)
		if toHeal == 2 then
			player:AddSoulHearts(1)
		end
		toplay.id = SoundEffect.SOUND_SUPERHOLY
	elseif player:GetBlackHearts() > 0 and player:CanPickBlackHearts() and math.random(1000) > 700 then
		player:AddBlackHearts(1)
	elseif player:GetBoneHearts() > 0 and player:CanPickBoneHearts() and math.random(1000) > 950 then
		player:AddBoneHearts(1)
		toplay.id = SoundEffect.SOUND_BONE_HEART
	elseif player:GetGoldenHearts() > 0 and player:CanPickGoldenHearts() and math.random(1000) > 600 then
		player:AddGoldenHearts(1)
		toplay.id = SoundEffect.SOUND_GOLD_HEART
	elseif player:GetSoulHearts() > 0 and player:CanPickSoulHearts() and math.random(1000) > 700 then
		player:AddSoulHearts(toHeal)
	elseif player:CanPickRedHearts() then
		player:AddHearts(toHeal)
		toplay.id = SoundEffect.SOUND_BOSS2_BUBBLES
	elseif player:GetSoulHearts() > 0 and player:CanPickSoulHearts() then
		player:AddSoulHearts(toHeal)
	elseif player:GetBlackHearts() > 0 and player:CanPickBlackHearts() then
		player:AddBlackHearts(1)
	elseif player:GetGoldenHearts() > 0 and player:CanPickGoldenHearts() then
		player:AddGoldenHearts(1)
		toplay.id = SoundEffect.SOUND_GOLD_HEART
	elseif player:GetBoneHearts() > 0 and player:CanPickBoneHearts() then
		player:AddBoneHearts(1)
		toplay.id = SoundEffect.SOUND_BONE_HEART
	elseif player:GetEternalHearts() > 0 then
		player:AddEternalHearts(1)
		if toHeal == 2 then
			player:AddSoulHearts(1)
		end
		toplay.id = SoundEffect.SOUND_SUPERHOLY
	else
		if ent:IsShopItem() then
			return nil
		else
			return false
		end
	end
	sound_tracker.PlayStackedSound(toplay.id,toplay.vol,toplay.pit,false,0,2)
	return true
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = item.pickup.Variant,
Function = function(_,ent, col, low)
    local player = col:ToPlayer()
	if ent.SubType == item.pickup.SubType or ent.SubType == item.pickup2.SubType then
		if player then
			local pinkType = ent.SubType
			local toHeal = 0
			if pinkType == item.pickup2.SubType then
				toHeal = 1
			elseif pinkType == item.pickup.SubType then
				toHeal = 2
			end
			local should_collect = item.try_collect(player,ent,toHeal)
			if should_collect == true then
				local idx = player:GetData().__Index
				if idx ~= nil then
					if save.elses["curse_of_glaze"..tostring(idx)] == nil then save.elses["curse_of_glaze"..tostring(idx)] = 0 end
					if ent.SubType == item.pickup.SubType then
						save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup.heavy
					else
						save.elses["curse_of_glaze"..tostring(idx)] = save.elses["curse_of_glaze"..tostring(idx)] + item.pickup2.heavy
					end
				end
				if ent:IsShopItem() then player:AddCoins(-ent.Price) end
				ent.Velocity = Vector(0,0)
				ent.EntityCollisionClass = EntityCollisionClass.ENTCOLL_NONE
				if ent:IsShopItem() then
					player:AnimatePickup(ent:GetSprite())
					ent:Remove()
				else
					ent:GetSprite():Play("Collect", true)
				end
				if ent.OptionsPickupIndex ~= 0 then
					auxi.remove_others_option_pickup(ent)
				end
				return true
			elseif should_collect == nil then
				return nil 
			else
				return false
			end
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = item.pickup.Variant,
Function = function(_,ent)
	if ent.SubType == item.pickup.SubType or ent.SubType == item.pickup2.SubType then
		if ent:GetSprite():IsEventTriggered("DropSound") then
			sound_tracker.PlayStackedSound(SoundEffect.SOUND_MEAT_FEET_SLOW0,1,1,false,0,2)
		end
		if ent:GetSprite():IsFinished("Collect") or ent:GetSprite():IsEventTriggered("Remove")  then
			ent:Remove()
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_INIT, params = 10,
Function = function(_,ent)
	if save.UnlockData.Glaze.Maggy.Unlock == true and ModConfigSettings.Pickup_allow then
		if ent.SubType == 1 or ent.SubType == 2 or ent.SubType == 3 or ent.SubType == 8 or ent.SubType == 9 or ent.SubType == 10 then
			local rng = ent:GetDropRNG()
			rng = auxi.rng_for_sake(rng)
			local rand = rng:RandomInt(25)		--1/25的概率转化。
			local has_crown = false
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					has_crown = true
					if rand == 2 then
						rand = 1
					end
				end
				if player:GetBrokenHearts() > 0 and rand == 1 then		--每一个角色拥有碎心，转化率下降80%。
					rand = rng:RandomInt(5)
				end
			end
			if rand == 1 then
				if ent.SubType == 2 or ent.SubType == 8 and has_crown ~= true then
					ent:Morph(5,item.pickup2.Variant,item.pickup2.SubType,true)
				else
					ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
				end
			end
		end
		if ent.SubType == item.pickup2.SubType then
			local has_crown = false
			for playerNum = 1, Game():GetNumPlayers() do
				local player = Game():GetPlayer(playerNum - 1)
				if player:HasCollectible(enums.Items.Crown_of_the_glaze) or player:GetEffects():GetCollectibleEffectNum(enums.Items.Crown_of_the_glaze) > 0 then
					has_crown = true
				end
			end
			if has_crown then
				ent:Morph(5,item.pickup.Variant,item.pickup.SubType,true)
			end
		end
	end
end,
})

return item