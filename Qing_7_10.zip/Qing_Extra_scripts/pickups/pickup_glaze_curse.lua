local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local ModConfig = require("Qing_Extra_scripts.Mod_Config_Menu_support")
local ModConfigSettings = ModConfig.ModConfigSettings

local item = {
	ToCall = {},
	curse_mul = 0,
	glaze_buffer = {},
	glaze_map = {
		0,
		0.1,
		0.2,
		0.3,
		0.4,
		0.5,
		0.6,
		0.75,
		0.7,
		0.6,
		0.5,
		0.4,
		0.2,
		0.15,
		0.1,
		0.05,
		0.05,
	},
	lst = 0,
}

function item.cast_a_glaze(wei,delta_time)		--稍微点亮片刻
	if wei == nil then wei = 0.3 end
	--table.insert(item.glaze_buffer,{weight = wei,})
end

function item.calculate_glaze()
	if Game():IsPaused() then
		return item.lst
	else
		local ret = 0
		for i = #(item.glaze_buffer),1,-1 do
			if item.glaze_buffer[i].weight == nil then item.glaze_buffer[i].weight = 0.3 end
			if item.glaze_buffer[i].cnt == nil or item.glaze_buffer[i].cnt <= 1 then item.glaze_buffer[i].cnt = 1 end
			ret = ret * 0.97 + item.glaze_map[item.glaze_buffer[i].cnt] * item.glaze_buffer[i].weight
			item.glaze_buffer[i].cnt = item.glaze_buffer[i].cnt + 1
			if item.glaze_buffer[i].cnt > #item.glaze_map then
				table.remove(item.glaze_buffer,i)
			end
		end
		ret = math.max(0,math.min(1,ret))
		item.lst = ret
		return ret
	end
	return 0
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_GET_SHADER_PARAMS, params = nil,
Function = function(_,name)
	if name == "Glaze_visions" then
		local cnt = 0
		--cnt = item.calculate_glaze()
		return {mul = cnt,}
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	for playerNum = 1, Game():GetNumPlayers() do
		local player = Game():GetPlayer(playerNum - 1)
		local idx = player:GetData().__Index
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		for j = 1,10 do
			save.elses["curse_of_glaze"..tostring(j)] = 0
		end
	end
	item.glaze_buffer = {}
	item.lst = 0
	item.curse_mul = 0
end,
})


return item