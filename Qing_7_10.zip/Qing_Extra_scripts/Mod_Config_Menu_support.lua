local json = require("json")

local g = require("Qing_Extra_scripts.core.globals")
local enums = require("Qing_Extra_scripts.core.enums")
local save = require("Qing_Extra_scripts.core.savedata")

local Mod_Config = {}
function Mod_Config.initlist()
	return {
		mouseSupport = 2,
		mouseSupport1 = true,
		mouseSupport2 = false,
		Items_allow = true,
		Pickup_allow = true,
		Thread_allow = true,
		Achievement_allow = true,
		allow_mouse_control = true,
		thor_key = 342,
		thor_controller = 12,
		On_air_key = 342,
		Off_air_key = 341,
	}
end

local modReference

Controller = Controller or {}
Controller.DPAD_LEFT = 0
Controller.DPAD_RIGHT = 1
Controller.DPAD_UP = 2
Controller.DPAD_DOWN = 3
Controller.BUTTON_A = 4
Controller.BUTTON_B = 5
Controller.BUTTON_X = 6
Controller.BUTTON_Y = 7
Controller.BUMPER_LEFT = 8
Controller.TRIGGER_LEFT = 9
Controller.STICK_LEFT = 10
Controller.BUMPER_RIGHT = 11
Controller.TRIGGER_RIGHT = 12
Controller.STICK_RIGHT = 13
Controller.BUTTON_BACK = 14
Controller.BUTTON_START = 15

function Mod_Config.init(mod)
	modReference = mod
	Mod_Config.ModConfigSettings = Mod_Config.initlist()
	if ModConfigMenu then
		local ModConfigQingCategory = ".W.Q."
		ModConfigMenu.UpdateCategory(ModConfigQingCategory, {Info = {"Settings for the W.Q character mod.",}})
		ModConfigMenu.AddText( ModConfigQingCategory, "Options", function() return "Others Options can be altered here." end )
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return true	end,Display = function()
			return 'Use This to Lock All Achievements'
		end,OnChange = function(currentBool)save.LockAll()	end,Info = {"Caution:There is no room to regret once you press it."}})
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Options" )
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return true	end,Display = function()
			return 'Use This to Unlock All Achievements'
		end,OnChange = function(currentBool)save.UnLockAll()end,Info = {"Caution:There is no room to regret once you press it."}})
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Options" )
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return Mod_Config.ModConfigSettings.Items_allow	end,Display = function()
			return 'Allow Mod items to natually appear:' .. (Mod_Config.ModConfigSettings.Items_allow and "Yes" or "No")
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings.Items_allow = currentBool end,Info = {"If true, unlocked items will appear by chance in the basement.(Remember this won't work until next run!) "}})
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return Mod_Config.ModConfigSettings.Pickup_allow end,Display = function()
			return 'Allow Mod pickups to natually appear:' .. (Mod_Config.ModConfigSettings.Pickup_allow and "Yes" or "No")
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings.Pickup_allow = currentBool	end,Info = {"If true, unlocked pickups will appear in the basement. "}})
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return Mod_Config.ModConfigSettings.Thread_allow end,Display = function()
			return 'Allow Mod bosses and quest items to natually appear:' .. (Mod_Config.ModConfigSettings.Thread_allow and "Yes" or "No")
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings.Thread_allow = currentBool	end,Info = {"If true, Experience the fancy story instead of the original story. "}})
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Options" )
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return Mod_Config.ModConfigSettings.Achievement_allow end,Display = function()
			return 'Allow Achievements to be Unlocked:' .. (Mod_Config.ModConfigSettings.Achievement_allow and "Yes" or "No")
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings.Achievement_allow = currentBool end,Info = {"If true, Achievements will be unlocked after require satisfied. "}})
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Options" )
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Options", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return true	end,Display = function()
			return 'Reset All'
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings = Mod_Config.initlist()end,Info = {"Reset all options back to default."}})
		
		
		
		ModConfigMenu.AddText( ModConfigQingCategory, "Settings", function() return "You can customize KeyBoardSetting here." end )
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Settings" )
		ModConfigMenu.AddText( ModConfigQingCategory, "Settings", function() return "W.Qing now teleports" end )
		ModConfigMenu.AddKeyboardSetting(ModConfigQingCategory,"Settings", "Qing\'s key",Mod_Config.ModConfigSettings.thor_key,"By Pressing",false,"Choose which button on your keyboard will lead to the final attack from W.Q.")
		ModConfigMenu.AddControllerSetting(ModConfigQingCategory, "Settings","Qing\'s controllerkey",Mod_Config.ModConfigSettings.thor_controller,"Or by controller",false,"Choose which button on your controller will lead to the final attack from W.Q.")
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Settings", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return Mod_Config.ModConfigSettings.allow_mouse_control end,Display = function()
			return 'Mouse Support On Qing:' .. (Mod_Config.ModConfigSettings.allow_mouse_control and "Yes" or "No")
		end,OnChange = function(currentBool)Mod_Config.ModConfigSettings.allow_mouse_control = currentBool end,Info = {"If true, You can use your mouse to control W.Qing. "}})
		ModConfigMenu.AddText( ModConfigQingCategory, "Settings", function() return "Tainted W.Qing now alters air balls" end )
		ModConfigMenu.AddKeyboardSetting(ModConfigQingCategory,"Settings", "Tainted W.Qing\'s key1",Mod_Config.ModConfigSettings.On_air_key,"By Pressing",false,"Choose which button on your keyboard make the air balls transform.")
		ModConfigMenu.AddText( ModConfigQingCategory, "Settings", function() return "Tainted W.Qing now retrieves air balls" end )
		ModConfigMenu.AddKeyboardSetting(ModConfigQingCategory,	"Settings", "Tainted W.Qing\'s key2",Mod_Config.ModConfigSettings.Off_air_key,"By Pressing",false,"Choose which button on your keyboard will retrieve all air balls.")
		ModConfigMenu.AddSpace( ModConfigQingCategory, "Settings")
		ModConfigMenu.AddSetting( ModConfigQingCategory, "Settings", {Type = ModConfigMenu.OptionType.BOOLEAN,CurrentSetting = function()return true end,Display = function()
			return 'Mouse Support:' .. (Mod_Config.ModConfigSettings.mouseSupport1 and (Mod_Config.ModConfigSettings.mouseSupport2 and 'Always Follow' or 'Only On Click') or 'Disabled')
		end,OnChange = function(currentBool)
			Mod_Config.ModConfigSettings.mouseSupport = Mod_Config.ModConfigSettings.mouseSupport + 1
			if Mod_Config.ModConfigSettings.mouseSupport > 3 then Mod_Config.ModConfigSettings.mouseSupport = 1 end
			Mod_Config.ModConfigSettings.mouseSupport1 = ((Mod_Config.ModConfigSettings.mouseSupport & 2) == 2)
			Mod_Config.ModConfigSettings.mouseSupport2 = ((Mod_Config.ModConfigSettings.mouseSupport & 1) == 1)
		end,Info = {"If true,Tainted W.Q.'s mark will follow your mouse."}})
		
		modReference:AddCallback(ModCallbacks.MC_POST_UPDATE,function()
			Mod_Config.ModConfigSettings.thor_key = ModConfigMenu.Config[ModConfigQingCategory]["Qing\'s key"]
			Mod_Config.ModConfigSettings.thor_controller = ModConfigMenu.Config[ModConfigQingCategory]["Qing\'s controllerkey"]
			Mod_Config.ModConfigSettings.On_air_key = ModConfigMenu.Config[ModConfigQingCategory]["Tainted W.Qing\'s key1"]
			Mod_Config.ModConfigSettings.Off_air_key = ModConfigMenu.Config[ModConfigQingCategory]["Tainted W.Qing\'s key2"]
		end)
	end
end

return Mod_Config