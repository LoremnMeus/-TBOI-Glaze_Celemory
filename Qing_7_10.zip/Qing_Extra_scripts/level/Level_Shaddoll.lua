local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local item_manager = require("Qing_Extra_scripts.core.item_manager")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local sound_tracker = require("Qing_Extra_scripts.auxiliary.sound_tracker")
local grid_manager = require("Qing_Extra_scripts.core.grid_manager")
local gui = require("Qing_Extra_scripts.auxiliary.gui")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")
local console_holder = require("Qing_Extra_scripts.others.Console_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	Post_ToCall = {},
	orig_col = Color(-0.3,0.2,-0.3,1,0.2,0,0.2),
	trans_col = Color(-0.3,0.2,-0.3,1,0.2,0,0.2),
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
	else
		
	end
end,
})

local function render_shadow(ent)
	if ent == nil or ent:GetSprite() == nil or ent:GetData() == nil then return end
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.shadoll_render_sprite == nil then
		d.shadoll_render_sprite = {}
	end
	local mx = 8
	local s2 = auxi.copy_sprite(ent:GetSprite())
	--print(s2:GetOverlayAnimation().." " .. s2:GetAnimation())
	if ent:IsVisible() then
		table.insert(d.shadoll_render_sprite,1,{sprite = s2,pos = ent.Position + ent.PositionOffset,})
	else
		table.insert(d.shadoll_render_sprite,1,{})
	end
	if #d.shadoll_render_sprite > mx then table.remove(d.shadoll_render_sprite,mx) end
	local ao = s.Color.A
	for i = 1,mx do 
		if d.shadoll_render_sprite[i] then
			local s3 = d.shadoll_render_sprite[i].sprite
			local pos = d.shadoll_render_sprite[i].pos
			if s3 and pos then
				s3.Color = Color(s.Color.R,s.Color.G,s.Color.B,(mx - i)/mx * ao * 0.85,s.Color.RO,s.Color.GO,s.Color.BO)				
				--if ent:IsVisible() then
				s3:Render(Isaac.WorldToScreen(pos),Vector(0,0),Vector(0,0))
				--end
			end
		end
	end
end

local function render_proj_shadow(ent)
	if ent == nil or ent:GetSprite() == nil then return end
	local s = auxi.copy_sprite(ent:GetSprite())
	local mx = 3
	local ao = s.Color.A
	for i = 1,mx do
		s.Color = Color(s.Color.R,s.Color.G,s.Color.B,(mx - i)/mx * ao * 0.85,s.Color.RO,s.Color.GO,s.Color.BO)
		s:Render(Isaac.WorldToScreen(ent.Position + ent.PositionOffset - ent.Velocity * 3 * i/mx),Vector(0,0),Vector(0,0))
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_INIT, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if save.elses.shadoll_level and save.elses.shadoll_level == 1 then
		d.is_shadoll = true
		s.Color = item.orig_col
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NPC_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_shadoll then
		s.Color = auxi.AddColor(s.Color,item.trans_col,0.8,0.2)
		render_shadow(ent)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PROJECTILE_INIT, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if save.elses.shadoll_level and save.elses.shadoll_level == 1 then
		d.is_shadoll = true
		s.Color = item.orig_col
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PROJECTILE_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_shadoll then
		s.Color = auxi.AddColor(s.Color,item.trans_col,0.8,0.2)
		render_proj_shadow(ent)
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_INIT, params = nil,
Function = function(_,ent)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if save.elses.shadoll_level and save.elses.shadoll_level == 1 then
		if ent.SpawnerType >= 9 then 
			d.is_shadoll = true
			s.Color = item.orig_col
		end
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_LASER_RENDER, params = nil,
Function = function(_,ent,offset)
	local d = ent:GetData()
	local s = ent:GetSprite()
	if d.is_shadoll then
		s.Color = auxi.AddColor(s.Color,item.trans_col,0.8,0.2)
	end
end,
})

return item