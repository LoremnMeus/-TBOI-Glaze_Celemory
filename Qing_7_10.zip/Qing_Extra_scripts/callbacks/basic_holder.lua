local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local callback_manager = require("Qing_Extra_scripts.core.callback_manager")

local modReference
local item = {
	ToCall = {},
	update_filter = nil,
	itemList = {},
	trinket_at_hand = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	 if (continue) then
        for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
            local d = player:GetData()
			d.basis_holder_buffer = auxi.get_basic_counter(player)
        end
    end
	item.update_filter = true
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.update_filter = nil
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
    if (item.update_filter) then 
        local d = player:GetData()
		local new_tbl = auxi.get_basic_counter(player)	
		if d.basis_holder_buffer == nil then d.basis_holder_buffer = new_tbl end
		for u,v in pairs(new_tbl) do
			if v.counter ~= d.basis_holder_buffer[u].counter then
				callback_manager.work("POST_CHANGE_BASIC",function(funct,params) if params == nil or params == v.name then funct(nil,player, v.name, v.counter - d.basis_holder_buffer[u].counter) end end)
				d.basis_holder_buffer[u].counter = v.counter
			end
		end
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function()
	if item.should_recharge then
		for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
            local d = player:GetData()
			d.basis_holder_buffer = auxi.get_basic_counter(player)
        end
		item.update_filter = true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS,
Function = function(_, colid, rng, player, flags, slot, data)
	item.should_recharge = true
	item.update_filter = nil
end,
})


return item
