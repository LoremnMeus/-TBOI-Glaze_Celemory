local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local callback_manager = require("Qing_Extra_scripts.core.callback_manager")

local modReference
local item = {
	ToCall = {},
	update_filter = nil,
	itemList = {},
	trinket_at_hand = {},
}

local config = Isaac:GetItemConfig()
local collectibles = config:GetCollectibles()
local size = collectibles.Size
for i= 1, size do
	local collectible = config:GetCollectible(i)
	if collectible then
		table.insert(item.itemList,#item.itemList + 1,i)
	end
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_GAME_STARTED, params = nil,
Function = function(_,continue)
	 if (continue) then
        for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
            local d = player:GetData()
            d.collectible_counter = player:GetCollectibleCount()
			for u,v in pairs(item.itemList) do
				d["collectible_counter_"..tostring(v)] = player:GetCollectibleNum(v, true)
			end
        end
    end
	item.update_filter = true
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_GAME_EXIT, params = nil,
Function = function(_,shouldsave)
	item.update_filter = nil
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PICKUP_UPDATE, params = nil,
Function = function(_,pickup)
    if (pickup.Variant == PickupVariant.PICKUP_COLLECTIBLE) then
        local d = pickup:GetData()
		d.collectible_last_id = pickup.SubType
    end
end,
})

local function CheckCollectibleChanged(player)
    local d = player:GetData()
    if (d.collectible_counter ~= player:GetCollectibleCount()) then
        return true
    end
	for u,v in pairs(item.itemList) do
        if d["collectible_counter_"..tostring(v)] ~= player:GetCollectibleNum(v, true) then
            return true
        end
    end
    return false
end

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_RENDER, params = nil,
Function = function(_,player, offset, variant)
    if (item.update_filter) then 
        local d = player:GetData()
		if ((d.collectible_queue_item and player:IsItemQueueEmpty()) or (CheckCollectibleChanged(player))) then
			d.collectible_counter = player:GetCollectibleCount()
			local queuedItem = d.collectible_queue_item
			for u,v in pairs(item.itemList) do
				local curNum = d["collectible_counter_"..tostring(v)] or 0
				local num = player:GetCollectibleNum(v, true)
				local diff = num - curNum;
				if (diff ~= 0) then
					if (diff > 0) then
						local gained = diff
						if (queuedItem) then
							if (v == queuedItem.Item and queuedItem.Type ~= ItemType.ITEM_TRINKET) then
								callback_manager.work("POST_GAIN_COLLECTIBLE",function(funct,params) if params == nil or params == v then funct(nil,player, v, 1, queuedItem.Touched , curNum) end end)
								gained = gained - 1
								d.collectible_queue_item = nil
							end
						end
						if (gained > 0) then
							callback_manager.work("POST_GAIN_COLLECTIBLE",function(funct,params) if params == nil or params == v then funct(nil,player, v, gained, false , curNum) end end)
						end
					else
						callback_manager.work("POST_LOSE_COLLECTIBLE",function(funct,params) if params == nil or params == v then funct(nil,player, v, -diff , curNum) end end)
					end
					callback_manager.work("POST_CHANGE_COLLECTIBLE",function(funct,params) if params == nil or params == v then funct(nil,player, v, diff , curNum) end end)
					d["collectible_counter_"..tostring(v)] = num
				end
			end
        end
        if (d.collectible_queue_item and player:IsItemQueueEmpty()) then 
            d.collectible_queue_item = nil
        end
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_ENTITY_REMOVE, params = EntityType.ENTITY_PICKUP,
Function = function(_,ent)
	if (ent.Variant == PickupVariant.PICKUP_TRINKET) then
        table.insert(item.trinket_at_hand, {ID = ent.SubType,});
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
    for u,v in pairs(item.trinket_at_hand) do
        if v.should_remove then
			table.remove(item.trinket_at_hand,u)
        else
            v.should_remove = true
        end 
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	if (item.update_filter) then
        if (not player:IsItemQueueEmpty()) then
            local d = player:GetData()
            if (not d.collectible_queue_item) then
                local queued = player.QueuedItem
				local id = queued.Item.ID
                d.collectible_queue_item = { Item = id, Type = queued.Item.Type, Touched = queued.Touched }
                if (queued.Item.Type == ItemType.ITEM_TRINKET) then
					for u,v in pairs(item.trinket_at_hand) do
                        if (v.ID == id or v.ID - 32768 == id) then
                            callback_manager.work("POST_PICKUP_TRINKET",function(funct,params) if params == nil or params == id then funct(nil,player,id, id > 32768,touched) end end)
                            table.remove(item.trinket_at_hand,u)
                            break
                        end
                    end
                else
                    for i, ent in pairs(Isaac.FindByType(EntityType.ENTITY_PICKUP, PickupVariant.PICKUP_COLLECTIBLE)) do
                        local d2 = ent:GetData()
                        local idMatches = (d2 and d2.collectible_last_id == id)
                        local swapped = ent.FrameCount <= 0
                        local taken = (ent.SubType <= 0 and idMatches) or not ent:Exists()
                        if (swapped or taken) then
							callback_manager.work("POST_PICKUP_COLLETIBILE",function(funct,params) if params == nil or params == id then funct(nil,player, id, queued.Touched) end end)
                            break
                        end
                    end
                end
            end
        end
    end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function()
	if item.should_recharge then
		 for playerNum = 1, Game():GetNumPlayers() do
			local player = Game():GetPlayer(playerNum - 1)
            local d = player:GetData()
            d.collectible_counter = player:GetCollectibleCount()
			for u,v in pairs(item.itemList) do
				d["collectible_counter_"..tostring(v)] = player:GetCollectibleNum(v, true)
			end
        end
		item.update_filter = true
	end
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS,
Function = function(_, colid, rng, player, flags, slot, data)
	item.should_recharge = true
	item.update_filter = nil
end,
})

return item
