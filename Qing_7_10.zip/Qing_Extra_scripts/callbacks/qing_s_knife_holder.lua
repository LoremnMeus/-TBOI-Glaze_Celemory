local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local callback_manager = require("Qing_Extra_scripts.core.callback_manager")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")

local item = {
	ToCall = {},
	myToCall = {},
}

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_PRE_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_QINGS_KNIFE_COLLISION, params = nil,
Function = function(_,ent,col,low)
	
end,
})

function item.collide_knife_on_it(ent,col,low)
	callback_manager.work("PRE_QINGS_KNIFE_COLLISION",function(funct,params) if params == nil or params == col.Type then funct(nil,ent,col,low) end end)
end

return item