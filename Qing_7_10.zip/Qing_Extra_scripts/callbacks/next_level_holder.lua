local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local callback_manager = require("Qing_Extra_scripts.core.callback_manager")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")

local item = {
	pre_ToCall = {},
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
}

--再爽、5点、R键、后悔药需要特判
--现在只有stage命令无法处理了
table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_ROOM, params = nil,
Function = function(_)
	if (not item.should_not_trigger) and (item.should_trigger or (item.now_level ~= nil and item.now_level ~= Game():GetLevel():GetStage()) or (item.now_level_seed ~= nil and item.now_level_seed ~= Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage()))) then
		--print("Success "..tostring(item.now_level_seed or 0).." "..tostring(item.now_level or 0).." ")
		callback_manager.work("PRE_NEW_LEVEL",function(funct,params) funct(nil,item.now_level) end)
		item.has_triggered = true
	end
	--print("New room")
	item.now_level = Game():GetLevel():GetStage()
	item.now_level_seed = Game():GetSeeds():GetStageSeed(Game():GetLevel():GetStage())
	item.should_not_trigger = nil
	item.should_trigger = nil
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_FORGET_ME_NOW,
Function = function(_, coll, rng, player, flags, slot, data)
	item.should_trigger = true
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_R_KEY,
Function = function(_, coll, rng, player, flags, slot, data)
	item.should_trigger = true
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = CollectibleType.COLLECTIBLE_GLOWING_HOUR_GLASS,
Function = function(_, coll, rng, player, flags, slot, data)
	item.should_not_trigger = true
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	item.has_triggered = nil
end,
})

table.insert(item.ToCall,#item.ToCall + 1,{CallBack = ModCallbacks.MC_POST_NEW_LEVEL, params = nil,
Function = function(_)
	if item.has_triggered == nil then
		--print("Fail")
		callback_manager.work("PRE_NEW_LEVEL",function(funct,params) funct(nil,item.now_level) end)		--检查失败，可能会引发bug。
		item.has_triggered = true
	end
end,
})

table.insert(item.myToCall,#item.myToCall + 1,{CallBack = enums.Callbacks.PRE_GAME_STARTED, params = nil,
Function = function(_,continue)
	if continue then
		item.now_level = nil
		item.now_level_seed = nil
	else
		item.now_level = -1
	end
end,
})

table.insert(item.pre_ToCall,#item.pre_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_INIT, params = nil,
Function = function(_,player)
	local TotPlayers = #Isaac.FindByType(EntityType.ENTITY_PLAYER)
	if TotPlayers == 0 then
		if Game():GetFrameCount() == 0 then
			callback_manager.work("PRE_GAME_STARTED",function(funct,params) funct(nil,false) end)
		else
			callback_manager.work("PRE_GAME_STARTED",function(funct,params) funct(nil,true) end)
		end
	end
end,
})


return item