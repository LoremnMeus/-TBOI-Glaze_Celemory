local g = require("Qing_Extra_scripts.core.globals")
local save = require("Qing_Extra_scripts.core.savedata")
local enums = require("Qing_Extra_scripts.core.enums")
local auxi = require("Qing_Extra_scripts.auxiliary.functions")
local callback_manager = require("Qing_Extra_scripts.core.callback_manager")
local input_holder = require("Qing_Extra_scripts.others.Input_holder")
local displaying_data = require("Qing_Extra_scripts.translations.data")
local delay_buffer = require("Qing_Extra_scripts.auxiliary.delay_buffer")

local item = {
	ToCall = {},
	post_ToCall = {},
	myToCall = {},
	check_for_fortune_teller = 0,
}

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_PLAYER_UPDATE, params = nil,
Function = function(_,player)
	local d = player:GetData()
	if (not player:IsItemQueueEmpty()) or d.card_showing_buff ~= nil then
		if player:GetData().showing_buff == nil or player:GetData().showing_buff == false then
			if (not player:IsItemQueueEmpty()) then
				local config = Isaac:GetItemConfig()
				local item = player.QueuedItem
				local id = item.Item.ID
				if (item.Item.Type == ItemType.ITEM_TRINKET) then
					local configitem = config:GetTrinket(item.Item.ID)
					if configitem then
						local typ = "Trinket"
						local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = auxi.check_name_data(configitem.Description),})
						if ret then
							callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
							Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
							player:GetData().showing_buff = true
						end
					end
				else
					local configitem = config:GetCollectible(item.Item.ID)
					if configitem then
						local typ = "Item"
						local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = auxi.check_name_data(configitem.Description),})
						if ret then
							callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
							Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
							player:GetData().showing_buff = true
						end
					end
				end
			elseif d.card_showing_buff ~= nil then
				for u,v in pairs(d.card_showing_buff) do
					local pickup = v
					if (not pickup:Exists() or pickup:IsDead()) then
						for i = 0,3 do
							local card = player:GetCard(i)
							if (card == pickup.SubType) then
								local config = Isaac:GetItemConfig()
								local configitem = config:GetCard(card)
								if configitem then
									local typ = "Card"
									local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,card,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = auxi.check_name_data(configitem.Description),})
									if ret then
										callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
										Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
										player:GetData().showing_buff = true
									end
								end
								break
							end
						end
					end
				end
				d.card_showing_buff = nil
			end
		else
			d.card_showing_buff = nil
		end
	else
		if player:GetData().showing_buff == true then
			player:GetData().showing_buff = false
		end
	end
	d.for_dead_sea_scrolls_minder = nil
	d.check_for_lemegeton = nil
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = nil,
Function = function(_,pickup, col, low)
	if pickup.Type == 5 and pickup.Variant == 300 then
		local player = col:ToPlayer()
		if player then
			local d = player:GetData()
			if d.card_showing_buff == nil then d.card_showing_buff = {} end
			table.insert(d.card_showing_buff,pickup)
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_PRE_PICKUP_COLLISION, params = 20,
Function = function(_,ent,col,low)
	if ent.Variant == 20 and ent.SubType == 5 then
		if col.Type == 1 then
			local player = col:ToPlayer()
			if player then
				local typ = "Coin"
				local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,5,value) end end,{Name = auxi.check_name_data("#LUCKY_PENNY_NAME"),Description = auxi.check_name_data("#LUCKY_PENNY_DESCRIPTION"),})
				if ret then
					delay_buffer.addeffe(function(params)
						callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
						Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
						player:GetData().showing_buff = true
					end,{},1)
				end
			end
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_PILL, params = nil,
Function = function(_,pill,player,flag)	
	if flag & UseFlag.USE_NOHUD ~= UseFlag.USE_NOHUD then
		local config = Isaac:GetItemConfig()
		local configitem = config:GetPillEffect(pill)
		if configitem then
			local typ = "Pill"
			local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,pill,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = "",})
			if ret then
				callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
				Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
				player:GetData().showing_buff = true
			end
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_CARD, params = nil,
Function = function(_,card,player,flag)
	if card == Card.CARD_RULES then
		local typ = "Tips"
		local ret = callback_manager.work_with_result("PRE_TELL_FORTUNE",function(funct,params,value) return funct(nil,typ,value) end,{Description = nil,})		--也许以后可以把player也传进来？
		if ret and ret.Description ~= nil then
			callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
			if type(ret.Description) == "table" then
				Game():GetHUD():ShowFortuneText(ret.Description[1] or "",ret.Description[2],ret.Description[3],ret.Description[4],ret.Description[5])
			else
				Game():GetHUD():ShowFortuneText(ret.Description or "")
			end
		end
	end
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_USE_ITEM, params = nil,			--死海和缺德书
Function = function(_, colid, rng, player, flags, slot, data)
	local d = player:GetData()
	if colid == CollectibleType.COLLECTIBLE_DEAD_SEA_SCROLLS then
		if d.for_dead_sea_scrolls_minder then
			local config = Isaac:GetItemConfig()
			local id = d.for_dead_sea_scrolls_minder
			local configitem = config:GetCollectible(id)
			if configitem then
				local typ = "Item"
				local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = "",})
				if ret then
					callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
					Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
					player:GetData().showing_buff = true
				end
			end
		end
	elseif colid == CollectibleType.COLLECTIBLE_LEMEGETON then
		if d.check_for_lemegeton then
			local config = Isaac:GetItemConfig()
			local id = d.check_for_lemegeton
			local configitem = config:GetCollectible(id)
			if configitem then
				local typ = "Item"
				local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = auxi.check_name_data(configitem.Name),Description = auxi.check_name_data(configitem.Description),})
				if ret then
					callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
					Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "")
					player:GetData().showing_buff = true
				end
			end
			d.check_for_lemegeton = nil
		end
	elseif colid == CollectibleType.COLLECTIBLE_FORTUNE_COOKIE then
		item.check_for_fortune_teller = 3
	end
	d.for_dead_sea_scrolls_minder = colid
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_FAMILIAR_INIT, params = FamiliarVariant.ITEM_WISP,
Function = function(_,ent)
	local player = ent.Player
	if player == nil then player = Game():GetPlayer(0) end
	local d = player:GetData()
	d.check_for_lemegeton = ent.SubType
end,
})

table.insert(item.post_ToCall,#item.post_ToCall + 1,{CallBack = ModCallbacks.MC_POST_UPDATE, params = nil,
Function = function(_)
	local n_entity = Isaac.GetRoomEntities()
	local n_fortune_teller = auxi.getothers(n_entity,6,3)
	for u,v in pairs(n_fortune_teller) do
		local s = v:GetSprite()
		if s:IsEventTriggered("Prize") then
			item.check_for_fortune_teller = 4
			break
		end
	end
	if item.check_for_fortune_teller and item.check_for_fortune_teller > 0 then
		if SFXManager():IsPlaying(SoundEffect.SOUND_SHELLGAME) then
			if SFXManager():GetAmbientSoundVolume(SoundEffect.SOUND_SHELLGAME) == 0.5 then
				local typ = "Fortune"
				local ret = callback_manager.work_with_result("PRE_TELL_FORTUNE",function(funct,params,value) return funct(nil,typ,value) end,{Description = nil,})		--也许以后可以把player也传进来？
				if ret and ret.Description ~= nil then
					callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,nil,typ,ret) end end)
					if type(ret.Description) == "table" then
						Game():GetHUD():ShowFortuneText(ret.Description[1] or "",ret.Description[2],ret.Description[3],ret.Description[4],ret.Description[5])
					else
						Game():GetHUD():ShowFortuneText(ret.Description or "")
					end
				end
				SFXManager():Stop(SoundEffect.SOUND_SHELLGAME)
				item.check_for_fortune_teller = 0
			end
		end
		item.check_for_fortune_teller = item.check_for_fortune_teller - 1
	end
end,
})

function item.check_and_description(tp,id,Name,Description,player,ispaper)			--必须要传入的参数
	if ispaper == nil then ispaper = false end
	local typ = tp
	if player == nil then player = Game():GetPlayer(0) end
	local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = Name,Description = Description,})
	if ret then
		callback_manager.work("POST_DESCRIPT_ITEM",function(funct,params) if params == nil or params == typ then funct(nil,player,typ,ret) end end)
		Game():GetHUD():ShowItemText(ret.Name or "", ret.Description or "",ispaper)
	end
	return ret
end

function item.check_description(tp,id,Name,Description,player)			--必须要传入的参数
	local typ = tp
	if player == nil then player = Game():GetPlayer(0) end
	local ret = callback_manager.work_with_result("PRE_DESCRIPT_ITEM",function(funct,params,value) if params == nil or params == typ then return funct(nil,player,typ,id,value) end end,{Name = Name,Description = Description,})
	return ret
end

return item